## launch_shinyadmb---------------------2020-11-11
## adnuts Functions: launch_shinyadmb
## --------------------------------------adnuts|RH
launch_shinyadmb = function(fit)
{
	tmp_params = fit$sampler_params
	nms_params = lapply(tmp_params,function(x){x[,setdiff(colnames(x),"lp__")]})
	fit$sampler_params = nms_params
	ttput(fit)
	shinystan::launch_shinystan(.as.shinyadnuts(fit))
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~launch_shinyadmb

