compTS = function(x, runs=c(24,39), val="Rtdev", type="bars")
{
	yrs = as.numeric(dimnames(x)[[2]])
	tslist= list()
	for (i in runs) {
		ii = paste0("R", pad0(i,2))
		its = x[grep(paste0("^",i),dimnames(x)[[1]]),,val]
		tslist[[ii]] =  apply(its,2,median)
	}
#browser();return()
	tsdf = do.call("cbind", lapply(tslist, data.frame, stringsAsFactors=FALSE))
	colnames(tsdf) = names(tslist)
	barplot(t(as.matrix(tsdf)),beside=T,col=c("black","green"),space=c(0,0))
	addLegend(0.05, 0.95, fill=c("black","green"), legend=colnames(tsdf), title=val, bty="n")
}
if ( !exists("senso", inherits=F) ) load("senso.220630.rda")
compTS(senso$senTS, val="BtB0")
