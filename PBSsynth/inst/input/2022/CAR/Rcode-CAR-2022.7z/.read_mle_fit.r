## .read_mle_fit------------------------2022-06-07
##  Read in MLE fits from model
## ----------------------------------------r4ss|RH
.read_mle_fit = function (model, path = getwd()) 
{
	oldwd <- getwd()
	on.exit(setwd(oldwd))
	setwd(path)
	f <- paste(model, ".par", sep = "")
	if (!file.exists(f)) {
		ff <- list.files()[grep(x = list.files(), pattern = ".par")]
		if (length(ff) == 1) {
			if (.Platform$OS.type == "windows" & length(grep("~", ff)) > 0) {
				warning("It appears a shortened Windows filename exists,", 
					"which occurs with long\nmodel names. Try shortening it.", 
					" See help for argument 'model'")
			}
			warning("Standard .par file ", f, " not found. Trying this one: ", ff)
			f <- ff
		}
		else if (length(ff) > 1) {
			stop("More than one .par file found in directory. Delete unused ones and try again")
		}
		else {
			warning("No .par file found so skipping MLE info and parameter names.\nOptimize model to get this.")
			return(NULL)
		}
	}
	par   <- as.numeric(scan(f, what = "", n = 16, quiet = TRUE)[c(6, 11, 16)]) ## scan the par file
	nopar <- as.integer(par[1])
	nll   <- par[2]
	maxgrad <- par[3]
	f <- paste(model, ".cor", sep = "")
	if (!file.exists(f)) {
		ff <- list.files()[grep(x = list.files(), pattern = ".cor")]
		if (length(ff) == 1) {
			if (.Platform$OS.type == "windows" & length(grep("~", ff)) > 0) {
				warning("It appears a shortened Windows filename exists,", 
					"which occurs with long\nmodel names. Try shortening it.", 
					" See help for argument 'model'")
			}
			warning("Standard .cor file ", f, " not found. Trying this one: ", ff)
			f <- ff
		}
		else if (length(ff) > 1) {
			stop("More than one .cor file found in directory. Delete unused ones and try again")
		}
		else {
			warning("No .cor file found so skipping MLE info and parameter names.\nOptimize model to get this.")
			return(NULL)
		}
	}
	xx <- readLines(f)
	totPar <- length(xx) - 2
	if (totPar < nopar) {
		warning(paste("File", f, "did not match the .cor file.. maybe hessian failed? MLE object not available"))
		return(NULL)
	}
	logDetHess <- as.numeric(strsplit(xx[1], "=")[[1]][2])
	sublin     <- lapply(strsplit(xx[1:totPar + 2], " "), function(x) x[x != ""])
	names.all  <- unlist(lapply(sublin, function(x) x[2]))#[1:nopar]
	names.all  <- as.vector(do.call(c, sapply(unique(names.all), function(n) {
			x <- names.all[names.all == n]
			if (length(x) == 1) 
				return(list(x))
			list(paste0(x, "[", 1:length(x), "]"))
		})))
	est <- as.numeric(unlist(lapply(sublin, function(x) x[3])))
	std <- as.numeric(unlist(lapply(sublin, function(x) x[4])))
	cor <- matrix(NA, totPar, totPar)
	corvec <- unlist(sapply(1:length(sublin), function(i) sublin[[i]][5:(4 + i)]))
	cor[upper.tri(cor, diag = TRUE)] <- as.numeric(corvec)
	cor[lower.tri(cor)] <- t(cor)[lower.tri(cor)]

	result <- list(nopar = nopar, nll = nll, maxgrad = maxgrad, 
		par.names = names.all[1:nopar], names.all = names.all, 
		est = est, se = std, cor = cor[1:nopar, 1:nopar])
#browser();return()
	return(result)
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~.read_mle_fit
