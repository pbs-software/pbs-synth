## runADnuts----------------------------2022-06-07
##  Based on Chris Grandis' R code that was used to manually run adnuts.
##  Originally see Cole Monnahan:
##    https://rdrr.io/github/Cole-Monnahan-NOAA/adnuts/src/R/samplers.R
##  Note: adnuts needs serious path intervention (RH 201021)
## ------------------------------------------CG|RH
runADnuts=function(path=getwd(), run="01.01", model="base", 
   rda_name, add2rda=FALSE, tag="REBSN", 
   parallel=TRUE, cores=6, syscall=c(FALSE,rep(TRUE,5)),
   iters=list(test=15,pilot=100,mle=500,update=500,pcburn=0.25),
   ssexe="ss", ssdir, ssfiles=c("control.ss","data.ss"), stupid_shiny=FALSE)
{
	## Check to see if file exists and keep a copy if it does before removing it.
	sweep.files = function(x) {
		rubbish = 0
		for (i in x) {
			if (file.exists(i)) {
				fstamp = paste0(sub("[[:space:]]","(",gsub("[[:punct:]]","",substring(file.info(i)$ctime,3,16))),")")
				ext    = tools::file_ext(i)
				pre    = gsub(paste0("\\.",ext,"$"),"",i)
				backup = paste0(pre,"-",fstamp,".",ext)
				if (!file.exists(backup))
					file.copy(from=i, to=backup, overwrite=TRUE, copy.date=TRUE)
				file.remove(i)
				rubbish = rubbish +1
			}
		}
		invisible(paste0(rubbish, " files removed"))
	}
	## Generate dispersed initial values from MLE estimates
	my_sample_inits = function(path, cv=0.025, reps) {
		fit   = .read_mle_fit("ss", path=path)  ##
		mle   = fit$est[1:fit$nopar]##; names(mle) = fit$par.names
		inits = lapply(1:reps, function(i) {
			ival = sapply(mle,function(x) { rnorm(1, mean=x, sd=abs(cv*x)) })
		})
		names(inits) = 1:reps
		return(inits)
	}

	start_time <- Sys.time()
	cwd  = getwd()
	poop = function(){ setwd(cwd); gdump = gc(verbose=FALSE) }
	on.exit(poop())
	setwd(path); d.path=getwd(); setwd(d.path)  ## Just in case a relative path is specified

	d.run  = file.path(path, run)
	if (!file.exists(d.run)) 
		stop(paste0("Need to start with an existing Run\n\t",d.run))
	d.mpd    = file.path(d.run, paste0("MPD.",model))
	if (!file.exists(d.mpd)) 
		stop(paste0("Need to start with an existing MPD\n\t",d.mpd))
#browser();return()
	file.copy(from=paste0(d.mpd,"/starter.ss"), to=paste0(d.mpd,"/starter.adnuts.ss"), overwrite=TRUE, copy.date=TRUE)
	d.nuts   = file.path(d.run, paste0("NUTS.",model))
	if (!file.exists(d.nuts)) 
		dir.create(d.nuts)
	d.mcmc   = file.path(d.run, paste0("MCMC.",model))
	if (!file.exists(d.mcmc)) 
		dir.create(d.mcmc)
	poop = function(){setwd(d.mcmc)}  ## set to MCMC directory
	if(missing(rda_name))
		rda_name = paste0(run,".nuts.",model,".rda")
		#rda_name = paste0(run,".",model,".rda")
	d.rda = file.path(d.run, rda_name)  ## store rda files in the run directory

	ssfiles = unique(c("starter.ss","forecast.ss",ssfiles))
	if (missing(ssdir)) ssdir = d.mpd
	if ( all(file.exists(paste0(ssdir,"/",ssfiles)))) {
		file.copy(from=paste0(ssdir,"/",ssfiles), to=paste0(d.nuts,"/",ssfiles), overwrite=TRUE, copy.date=TRUE)
		file.copy(from=paste0(ssdir,"/",ssfiles), to=paste0(d.mcmc,"/",ssfiles),  overwrite=TRUE, copy.date=TRUE)
		starter = readLines(file.path(d.mpd,"starter.adnuts.ss"))
		starter[grep("#_mcmc_burn",starter)] = sub("^[[:digit:]] #_mcmc_burn", paste0(0," #_mcmc_burn"), grep("#_mcmc_burn",starter,value=T))
		for (icon in file.path(c(d.nuts,d.mcmc),"starter.ss"))
			writeLines(starter, con=icon)
	} else
		stop("SS files: '", paste0(ssfiles,collapse="', '"),"'\n\tnot found in ", ssdir)
	
	mess  = "Hessian does not appear to be positive definite"
	dash  = paste0(rep("-",62),collapse="")
#browser();return()

	setwd(d.mpd)
	## ----------------------------------------------------------------
	if (syscall[1]) {
		## This step is needed to create files like 'covar.sso' and 'ss_summary.sso'
		## Should be done already but user might want to run again
#browser();return()
		if (ssdir!=d.mpd)
			file.copy(from=paste0(ssdir,"/",ssfiles), to=paste0(d.mpd,"/",ssfiles),   overwrite=TRUE, copy.date=TRUE)
		.flush.cat("SysCall 1 -- Running MPD for best fits...\n")
		#toast = setdiff(list.files("."),c(ssfiles))
		toast = setdiff(list.files("."),c(ssfile, basename(list.dirs("."))))  ## list files always sees subdirectories as files
		if (length(toast)>0)
			file.remove(toast)
		sys1 = system(paste0(ssexe), intern=TRUE)
		writeLines(sys1,"./sys1.txt")
		if (any(grepl(mess,sys1)))
			stop(paste0("\n",dash,"\nSystem call 1: ",mess,"\n",dash))
	}
	#file.remove(list.files(d.mpd, pattern="\\.log$"))  ## for now
	replist = SS_output(dir=d.mpd, verbose=FALSE)
#browser();return()
	ttput(replist)
	vals.save = c("replist")

	setwd(d.nuts)

	## Chains to run in parallel
	reps  <- min(cores, parallel::detectCores() - 1)
	set.seed(2022)
	seeds <- sample(1:1e4, size = reps)
	sweep.files(d.rda)
#browser();return()

	## ----------------------------------------------------------------
	if (syscall[2]) {
		## This step is needed before syscall 3
		.flush.cat("SysCall 2 -- Running precursor mcmc test...\n")
		fdump = file.remove(setdiff(list.files(),ssfiles))  ## Start fresh if syscall 2
		gdump = gc(verbose=FALSE)
		sys2 = system(paste0(ssexe, " -nox -iprint 200 -mcmc ", iters$test), intern=TRUE)
		writeLines(sys2,"./sys2.txt")
		if (any(grepl(mess,sys2)))
			stop(paste0("\n",dash,"\nSystem call 2: ",mess,"\n",dash))
	}
	## Then run parallel RWM chains as a first test to ensure
	## mcmc itself is working properly, or that model is converging in mcmc space
	thin   <- 10
	iter   <- iters$pilot * thin ## iter is per core !!!
	#warmup <- ceiling(iter/4)
	warmup <- ceiling(0.25 * iter)
	inits  <- NULL               ## start chains from MLE
	inits  <- my_sample_inits(path=d.mpd, reps=reps)
	vals.save = c(vals.save,c("seeds","iters"))

	## ----------------------------------------------------------------
	if (syscall[3]){
		.flush.cat("SysCall 3 -- Running pilot RWM chains...\n")
		gdump = gc(verbose=FALSE)
		pilot  <- sample_admb(model=basename(ssexe), path=d.nuts, iter=iter, init=inits, chains=reps, warmup=warmup, seeds=seeds, thin=thin, mceval=FALSE, duration=NULL, parallel=parallel, cores=reps, control=NULL, algorithm="RWM")
		ttput(pilot)
		save("pilot","inits","warmup","thin","seeds", file="pilot.rda")
	} else {
		ttget(pilot)
		if (!exists("pilot", inherits=F))
			load("pilot.rda")
	}

	## Check convergence and slow mixing parameters
#mon  <- rstan::monitor(pilot$samples, warmup=pilot$warmup, print=FALSE)
#ttput(mon)
	## max(mon[,'Rhat'])
	## min(mon[,'n_eff'])
	## Examine the slowest mixing parameters
#slow <- names(sort(mon[,"n_eff"]))[1:10]
#ttput(slow)
#vals.save = c(vals.save,c("pilot","mon","slow"))

#browser();return()
	#so("pairs_admb.r","synth")
	#pairs_admb(fit=pilot, pars=slow, label.cex=1)
	#pairs_admb(fit = pilot, pars = c("MGparm[1]", "SR_parm[1]", "SR_parm[2]")) ## must be specific to Hake
	#pairs_admb(fit = pilot, pars = c("SR_parm[1]", "Q_parm[1]", "selparm[1]"), label.cex=1)
	
	## After regularizing run NUTS chains. First reoptimize to get the
	## correct mass matrix for NUTS. Note the -hbf 1 argument. This is a
	## technical requirement b/c NUTS uses a different set of bounding
	## functions and thus the mass matrix will be different.
	## ----------------------------------------------------------------
	if (syscall[4]) {
		.flush.cat("SysCall 4 -- Reoptimize to get correct mass matrix...\n")
		#mess  = sys4 = "Hessian does not appear to be positive definite"
		#nsys4 = 0; isys4 = iters$test
		#while (any(grepl(mess,sys4)) && nsys4<5){ 
		#	nsys4 = nsys4 + 1
		#	iters$test = isys4 * nsys4
		#	.flush.cat(paste0("  System call 4, loop ", nsys4,": trying ", iters$test, " iterations\n"))
		gdump = gc(verbose=FALSE)
		sys4  = system(paste0(ssexe, " -hbf 1 -nox -iprint 100 -mcmc ", iters$test), intern=TRUE) 
		writeLines(sys4,"./sys4.txt")
		if (any(grepl(mess,sys4))) {
			message( paste0("\n",dash,"\nSystem call 4: ",mess,"\n",dash) )
			#replist <- SS_output(dir=d.nuts, verbose=F, printstats=F)
			#rep.names = row.names(replist$parameters[!is.na(replist$parameters[,"Active_Cnt"]),])
			fit <- .read_mle_fit("ss", path=d.nuts)
			par.names = fit$par.names; #names(par.names) = rep.names
			hes <- adnuts:::.getADMBHessian(path=d.nuts)
			ev  <- eigen(hes)
			hdiag = diag(hes); names(hdiag) = fit$par.names
			zbad  = hdiag < 0
			.flush.cat("Paramaters with concave (negative) 2nd derivatives :\n")
			.flush.cat( paste0(paste0("\t",sapply( grep(T,zbad), function(i) { paste0(names(hdiag)[i], " : ",hdiag[i], collapse="") }), "\n"),collapse="") )
			browser();return()
			#stop(paste0("\n",dash,"\nSystem call 4: ",mess,"\n",dash))
		}
		#}
#browser();return()
	}

	## Use default MLE covariance (mass matrix) and short parallel NUTS chains started from the MLE.
	## ----------------------------------------------------------------
	if (syscall[5]) {
		.flush.cat("SysCall 5 -- Using MLE covariance and short parallel NUTS chains...\n")
		sweep.files(c("ss.psv","unbounded.csv"))
		warmup <- ceiling(iters$pcburn * iters$mle)  ## Monnahan et al. (2019)
		gdump  <- gc(verbose=FALSE)
		inits  <- my_sample_inits(path=d.mpd, reps=reps)

##=== Break here to run on the command line ===
browser();return()
		nuts.mle <-  sample_admb(model=ssexe, path=d.nuts, iter=iters$mle, init=inits, chains=reps, warmup=warmup, seeds=seeds, thin=1, mceval=FALSE, duration=NULL, parallel=parallel, cores=reps, control=list(metric="mle", adapt_delta=0.9), algorithm="NUTS")
		ttput(nuts.mle)
		save("nuts.mle","inits","warmup","seeds", file="nuts.mle.rda")
	} else {
		ttget(nuts.mle)
		if (!exists("nuts.mle", inherits=F))
			load("nuts.mle.rda")
	}
	#vals.save = c(vals.save,c("nuts.mle"))
	## Check for issues like slow mixing, divergences, max treedepths with
	## ShinyStan and pairs_admb as above. Fix and rerun this part as needed.
	## launch_shinyadmb(nuts.mle)
#browser();return()
	
	## Once acceptable, run again for inference using updated mass matrix. Increase
	## adapt_delta toward 1 if you have divergences (runs will take longer).
	## Note this is in unbounded parameter space
	## The following, nuts.updated, was used for inferences in this appendix
	#vals.save = c(vals.save,c("nuts.mle"))
	mass  <- nuts.mle$covar.est
	inits <- sample_inits(nuts.mle, reps)
	## ----------------------------------------------------------------
	if (syscall[6]) {
		.flush.cat("SysCall 6 -- Run final NUTS MCMC using updated mass matrix...\n")
		setwd(d.mcmc)
		## Check to see if psv file exists and keep a copy if it does
		sweep.files(c("ss.psv","unbounded.csv"))
		#toast = setdiff(list.files("."),c(ssfiles,"mcmc",".RData"))
		toast = setdiff(list.files("."),c(ssfiles,"mcmc",".RData", basename(list.dirs("."))))  ## list files always sees subdirectories as files
#browser();return()
		if (length(toast)>0)
			file.remove(toast)
		warmup = ceiling(iters$pcburn * iters$update)  ## Monnahan et al. (2019)
		thin   = ifelse(is.null(iters$thin), 1, iters$thin)
		butter = c("admodel.cov","admodel.hes","ss.par","ss.cor")
		if ( all(file.exists(paste0(d.nuts,"/",butter))) )
			zb = file.copy(from=paste0(d.nuts,"/",butter), to=paste0(d.mcmc,"/",butter), overwrite=TRUE, copy.date=TRUE)
		else
			stop("MPD precursor directory is missin:\n\t'",paste0(butter[!xb],collapse="', '"),"'")
		gdump = gc(verbose=FALSE)
		nuts.updated <- sample_admb(model=ssexe, path=d.mcmc, iter=iters$update, init=inits, chains=reps, warmup=warmup, seeds=seeds, thin=thin, mceval=TRUE, duration=NULL, parallel=parallel, cores=reps, control=list(metric=mass, adapt_delta=0.9), algorithm="NUTS")
		ttput(nuts.updated)
		save("nuts.updated","inits","warmup","seeds","thin","mass", file="nuts.updated.rda")
	} else {
		ttget(nuts.updated)
		if (!exists("nuts.updated", inherits=F))
			load("nuts.updated.rda")
	}

	#vals.save = c(vals.save,c("nuts.updated","mass","inits"))
	tmpenv <- new.env()
	if (file.exists(d.rda) && add2rda) {
		load(d.rda, envir=tmpenv)
		oldtags = ls(envir=tmpenv)
	}
	mess = paste0(tag,"=list(",paste0(paste0(vals.save,"=",vals.save),collapse=","),"); ttput(", tag, "); tput(", tag, ",tenv=tmpenv); save(list=ls(tmpenv),file=\"",d.rda,"\", envir=tmpenv)")
	eval(parse(text=mess))
	end_time <- Sys.time()
	elapsed_time = end_time - start_time
	cat("Elapsed time: ", elapsed_time, " ", attributes(elapsed_time)$units, "\n")
	f.history = file.path(path, "runHistory.tex")
	if (file.exists(f.history))
		file.copy(from=f.history, to=file.path(d.run,"run.history.txt"), overwrite=TRUE, copy.date=TRUE)
	gdump = gc(verbose=FALSE)
	return(invisible(elapsed_time))

	## Have to get rid of column "lp__" to make shinyadmb work (bad programming in '.validate_sampler_params')
	#if (stupid_shiny) {
	#	fit = nuts.updated
	#	tmp_params = fit$sampler_params
	#	nms_params = lapply(tmp_params,function(x){x[,setdiff(colnames(x),"lp__")]})
	#	fit$sampler_params = nms_params
	#	ttput(fit)
	#	launch_shinyadmb(fit)
	#}
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~runADnuts

require(adnuts)
require(snowfall)
require(rstan)
require(shinystan)
require(matrixcalc)
require(r4ss)

d.tools = "C:/Users/haighr/Files/Projects/R/Develop/PBStools/Authors/Rcode/develop/"
r.tools = c("linguaFranca", "calcStockArea","clearFiles")
for (i in r.tools) source(paste0(d.tools,i,".r"))

type="MCMC"

d.synth = "C:/Users/haighr/Files/Projects/R/Develop/PBSsynth/Authors/Rcode/develop"
r.synth = c("plotFuns","utilFuns","overFuns","sample_admb","sample_admb_parallel","sample_admb_rwm","sample_admb_nuts","convPN", "SS_output",".read_mle_fit", "initialise")
for (i in r.synth) source(paste0(d.synth,"/",i,".r"))

#so("plotFuns.r"); source("sample_admb_parallel.r"); source("pairs_admb.r")
#runADnuts(path=".", parallel=TRUE, syscall=c(F,F,F,F,F), iters=list(test=15,pilot=100,mle=60,update=100), tag="BSR_FU", add2rda=TRUE)
#runADnuts(path=".", parallel=TRUE, syscall=c(T,T,T,T,T), iters=list(test=15,pilot=100,mle=100,update=500), rda_name="BSR_2F.rda", tag="REBSN")
#runADnuts(path=".", run="BSR", model="wong", parallel=TRUE, syscall=c(F,F,F,F,T), iters=list(test=15,pilot=100,mle=60,update=100), rda_name="sumtingwong.rda", tag="REBSN", ssfiles=c("rebsn.control.46.01.ss","rebsn.data.46.01.ss"))

## 1912 MCMC samples after 200 burn-in specified in starter file and 20% warmup for AD nuts using 6 cores
#runADnuts(path=".", run="BSR", model="zanadu", parallel=TRUE, cores=6, syscall=c(F,F,F,F,T), iters=list(test=15,pilot=100,mle=500,update=(2200/6)*1.2), tag="rebsn", ssfiles=c("rebsn.control.46.01.ss","rebsn.data.46.01.ss"))

## 2000 MCMC samples after 400 burn-in specified in starter file and 20% warmup for AD nuts using 6 cores
#runADnuts(path=".", run="BSR", model="zebu", parallel=TRUE, cores=6, syscall=c(F,rep(T,5)), iters=list(test=15,pilot=100,mle=500,update=500), tag="rebsn", ssfiles=c("rebsn.control.46.01.ss","rebsn.data.46.01.ss"))

## 2000 MCMC samples after 400 burn-in specified in starter file and 20% warmup for AD nuts using 6 cores
#iters=list(test=15,pilot=100,mle=500,update=500)
#runADnuts(path=".", run="Run02", model="02.01", parallel=TRUE, cores=6, syscall=c(F,F,F,T,T,T), iters=iters, tag="ymr2021", ssfiles=c("control.02.01.ss","data.02.01.ss"))
#iters=list(test=15,pilot=100,mle=375,update=375,burn=0)

## Testing for Jon Schnute
#iters=list(test=15,pilot=100,mle=100,update=100,burn=0)
#ad.base = "C:/Users/haighr/Files/GFish/PSARC21/YMR/Data/SS/Explore"; ad.run="Run12"; ad.model="12.01"
#runADnuts(path=ad.base, run=ad.run, model=ad.model, parallel=FALSE, cores=2, syscall=c(F,F,F,F,F,T), iters=iters, tag="test12", ssfiles=paste(c("control","data"),ad.model,"ss",sep="."))


##==========================================================
## Determine number of iterations:
##  where a = desired # MCMC samples, b = burn-in specified in 'starter.ss', c = # cores, w = warmup used in AD nuts
##  Note: no burn-in required at end because each chain has a burn-in !!!
icalc = function(a=2000,b=0,c=8,w=0.2){ (a+b)/(c*(1-w)) } ## icalc(b=400)=500; icalc(b=400,c=8)=375; icalc(a=3200,c=8)=500

## Determine number of final MCMC samples:
##  where i = number of iterations for AD nuts, b = burn-in specified in 'starter.ss', c = # cores, w = warmup used in AD nuts
scalc = function(i=500,b=0,c=8,w=0.2){ (1-w)*i*c-b }  ## acalc(i=500, b=400)=2000; acalc(i=375,b=400,c=8)=2000
##==========================================================


