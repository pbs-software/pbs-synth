	## SS_doRetro---------------------------2022-06-01
## r4ss function 'SS-doRetro' overwrite (because buggy)
## ----------------------------------------r4ss|RH
SS_doRetro = function (masterdir, oldsubdir, newsubdir = "retrospectives", 
	subdirstart = "retro", years = 0:-5, overwrite = TRUE, exefile = "ss", 
	extras = "-nox", intern = FALSE, CallType = "system", RemoveBlocks = FALSE) 
{
	OS <- .Platform[["OS.type"]]
	prefix <- ifelse(OS == "windows", "", "./")
	oldwd <- getwd()
	on.exit(setwd(oldwd))
	olddir <- file.path(masterdir, oldsubdir)
	newdir <- file.path(masterdir, newsubdir)
	if (!is.null(exefile) & OS == "windows") {
		exefiles <- dir(olddir)[grep(".exe", dir(olddir))]
		if (length(exefiles) == 1) {
			exefile <- exefiles
		}
		if (exefile == "ss") {
			exefile <- "ss.exe"
		}
		if (!exefile %in% exefiles) {
			stop("Missing executable file ", exefile, " in ", olddir)
		}
	}
	startfile <- dir(olddir)[tolower(dir(olddir)) == "starter.ss"]
	forefile <- dir(olddir)[tolower(dir(olddir)) == "forecast.ss"]
	wtatagefile <- dir(olddir)[tolower(dir(olddir)) == "wtatage.ss"]
	testfile <- dir(olddir)[tolower(dir(olddir)) == "test.ss"]
	if (length(startfile) == 0) 
		stop("No starter.ss file found in ", olddir)
	startfile <- file.path(olddir, startfile)
	message("Getting input file names from starter file:\n", startfile)
	starter <- SS_readstarter(startfile, verbose = FALSE)
	ctlfile <- starter[["ctlfile"]]
	datfile <- starter[["datfile"]]
	filenames <- c(exefile, forefile, ctlfile, datfile, wtatagefile, testfile)
	message("copying model files from\n", olddir, "\n  to\n", newdir)
	message("model files to copy:\n ", paste(filenames, collapse = "\n "))
	if (!file.exists(newdir)) 
		dir.create(newdir)
	subdirnames <- paste0(subdirstart, years)
#browser();return()
	
	for (iyr in 1:length(years)) {
		if (!file.exists(file.path(newdir, subdirnames[iyr]))) {
			dir.create(file.path(newdir, subdirnames[iyr]))
		}
		copy.test <- file.copy(file.path(olddir, filenames), file.path(newdir, subdirnames[iyr], filenames), overwrite = TRUE)
		if (!all(copy.test)) {
			stop("error copying file(s): ", filenames[!copy.test])
		}
		starter[["retro_yr"]] <- years[iyr]
		starter[["init_values_src"]] <- 0
		setwd(file.path(newdir, subdirnames[iyr]))
		SS_writestarter(starter, dir = getwd(), verbose = FALSE, overwrite = TRUE)
		ctl <- readLines(ctlfile)
		if (RemoveBlocks == TRUE) {
			ctl[grep("block designs", ctl)] <- "0 # Number of block designs for time varying parameters"
			ctl[grep("blocks per design", ctl) + 0:2] <- "# blocks deleted"
		}
		file.remove(ctlfile)
		writeLines(ctl, ctlfile)
		if (length(grep(" ", exefile)) > 0) {
			exefile_to_run <- paste0("\"", exefile, "\"")
		}
		else {
			exefile_to_run <- exefile
			exefile_to_run <- "C:/Users/haighr/Files/Archive/Bat/ss.exe"
		}
		command <- paste0(prefix, exefile_to_run, " ", extras)
		message("Running model in ", getwd(), "\n", "using the command:\n   ", command, sep = "")
		if (file.exists("covar.sso")) 
			file.remove("covar.sso")
		if (intern) {
			message("ADMB output generated during model run will be written to:\n   ", 
				getwd(), "/ADMBoutput.txt. \n   To change this, set intern=FALSE\n", 
				"Note: ignore message about 'Error trying to open data input file ss3.dat'\n", sep = "")
		}
		if (CallType == "system") {
			ADMBoutput <- system(command, intern = intern)
		}
		if (CallType == "shell") {
			ADMBoutput <- shell(command, intern = intern)
		}
		if (!file.exists("Report.sso")) {
			warning("The retrospective model run failed in ", getwd())
		}
		if (intern) {
			writeLines(c("###", "ADMB output", as.character(Sys.time()), "###", " ", ADMBoutput), con = "ADMBoutput.txt")
		}
		setwd("../..")
	}
	setwd(oldwd)
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~SS_doRetro

#SS_doRetro(masterdir=".", oldsubdir="", newsubdir="retros", years = -6:-10, intern=T, exefile=NULL)

