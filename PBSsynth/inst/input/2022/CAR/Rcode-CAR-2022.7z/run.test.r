require(r4ss)
replist=SS_output(dir=getwd())
species.name="Yellowmouth Rockfish"; strSpp="YMR"; assyr=2021
#species.name="Rougheye/Blackspotted Rockfish"; strSpp="REBSN"; assyr=2020
so("plotSS.ts.r","synth")
so("plotSS.index.r","synth")
so("plotSS.francis.r","synth")
so("plotSS.comps.r","synth")
so("plotSS.stdres.r","synth")
so("plotSS.selex.r","synth")
SSplotPars(replist,nrows=4,ncols=3,plot=F,print=T,showpost=FALSE)
SSplotRecdevs(replist,subplot=1,print=T)


