## SSgetoutput--------------------------2022-05-27
##  Read in multiple sets of model results using SS_output
## ----------------------------------------r4ss|RH
SSgetoutput=function (keyvec=NULL, dirvec=NULL, getcovar=TRUE, getcomp=TRUE, 
   forecast=TRUE, verbose=TRUE, ncols=210, listlists=TRUE, 
   underscore=FALSE, save.lists=FALSE) 
{
	if (!is.null(keyvec) & verbose) 
		cat("length(keyvec) as input to SSgetoutput:", length(keyvec), "\n")
	if (!is.null(dirvec) & verbose) 
		cat("length(dirvec) as input to SSgetoutput:", length(dirvec), "\n")
	if (listlists) 
		biglist <- list()
	n1 <- length(keyvec)
	n2 <- length(dirvec)
	if (n1 > 1 & n2 > 1 & n1 != n2) {
		cat("inputs 'keyvec' and 'dirvec' have unmatched lengths > 1\n")
	}
	else {
		n <- max(1, n1, n2)
	}
	if (n1 == 1) 
		keyvec <- rep(keyvec, n)
	objectnames <- paste("replist", keyvec, sep="")
	if (n1 == 0) 
		objectnames <- paste("replist", 1:n, sep="")
	if (n2 == 0) 
		dirvec <- getwd()
	if (length(dirvec) == 1) 
		dirvec <- rep(dirvec, n)
	dirvec <- paste(dirvec, "/", sep="")
	for (i in 1:n) {
		key <- keyvec[i]
		mydir <- dirvec[i]
		if (is.null(key)) {
			key2 <- NULL
		}
		else {
			key2 <- ifelse(underscore, paste("_", key, sep=""), key)
		}
		newobject <- objectnames[i]
		if (verbose & !is.null(key)) 
			cat("getting files with key =", key, "\n")
		repFileName <- paste("Report", key2, ".sso", sep="")
		covarname <- paste("covar", key2, ".sso", sep="")
		warnFileName <- paste("warning", key2, ".sso", sep="")
		if (getcomp) {
			compFileName <- paste("CompReport", key2, ".sso",  sep="")
			NoCompOK <- FALSE
		}
		else {
			compFileName <- NULL
			NoCompOK <- TRUE
		}
		mycovar <- file.exists(file.path(sub("/+$","",mydir), covarname)) &  getcovar
		fullfile <- paste(mydir, repFileName, sep="")
		if (verbose) 
			cat("reading output from", fullfile, "\n")
		repfilesize <- file.info(fullfile)$size
		output <- NA
		if (!is.na(repfilesize) && repfilesize > 0) {
			output <- SS_output(dir=mydir, repfile=repFileName, covarfile=covarname, compfile=compFileName, 
				NoCompOK=NoCompOK, warnfile=warnFileName, printstats=FALSE, covar=mycovar, forecast=forecast, verbose=FALSE, ncols=ncols)
#browser();return()
			if (is.null(output)) {
				cat("output==NULL so trying again with covar=FALSE\n")
				output <- SS_output(dir=mydir, repfile=repFileName, covarfile=covarname, compfile=compFileName, 
				  NoCompOK=NoCompOK, printstats=FALSE, covar=FALSE, forecast=forecast, verbose=FALSE, ncols=ncols)
			}
			output[["key"]] <- as.character(key)
		}
		else {
			cat("!repfile doesn't exists or is empty\n")
		}
		if (verbose) 
			cat("added element '", newobject, "' to list\n", sep="")
		if (listlists) 
			biglist[[newobject]] <- output
		if (save.lists) {
			biglist.file <- paste("biglist", i, "_", format(Sys.time(), "%d-%b-%Y_%H.%M"), ".Rdata", sep="")
			save(biglist, file=biglist.file)
		}
	}
	return(invisible(biglist))
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~SSgetoutput

require(r4ss)
#setwd("C:/Users/haighr/Files/GFish/PSARC22/CAR/Data/SS/CAR2022/Run24/Like.24.01/LL.f.M")
#setwd("C:/Users/haighr/Files/GFish/PSARC22/CAR/Data/SS/CAR2022/Run24/Like.24.01/LL.m.M")
setwd("C:/Users/haighr/Files/GFish/PSARC22/CAR/Data/SS/CAR2022/Run24/Like.24.01/LL.R0")
so("SS_output.r","synth")
pmods <- SSgetoutput(dirvec=NULL, keyvec=1:12)
psum  <- SSsummarize(pmods, verbose=FALSE)
save("pmods",file="pmods.rda")

