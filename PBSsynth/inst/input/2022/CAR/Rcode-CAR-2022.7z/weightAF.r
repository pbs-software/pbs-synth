## weightAF-----------------------------2022-02-24
##  Weight age frequencies using harmonic mean ratio method
## ---------------------------------------------RH
weightAF = function(replist, fleets, abase="agedbase", afld="Nsamp_adj",
   hfld="effN", rbase="recruit", rfld="pred_recr")
{
	agebase = replist[[abase]]
	fltbase = agebase[is.element(agebase$Fleet,fleets),]
	lstbase = split(fltbase, fltbase$Fleet)
	hmean  = sapply(lstbase,function(x){ 1/mean(1/x[,hfld]) })
	amean  = sapply(lstbase,function(x){ mean(x[,afld]) })
	wmean  = sapply(lstbase,function(x){ 1/mean(1/x[,hfld]) / mean(x[,afld]) })
#browser();return()

	## Recruitment predictions (flaky so do not use 'wadj')
	recbase = replist[[rbase]]
	Rmax = max(recbase[,rfld])
	#M = replist$parameters["NatM_p_1_Fem_GP_1","Value"]
	midx = grep("^Nat(.+)Fem",rownames(replist$parameters))
	M = replist$parameters[midx,"Value"]
	wsub = 1/((Rmax/10^floor(log10(Rmax)))*M^0.7)
	wadj = wmean / wsub

	w.mcallister = list(agedat=fltbase, hmean=hmean, amean=amean, wmean=wmean, Rmax=Rmax, M=M, wsub=wsub, wadj=wadj)
#browser();return()
	ttput(w.mcallister)
	return(w.mcallister)
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~weightAF

#out = weightAF(replist,fleets=1:5)
#out = weightAF(rep58,fleets=1:5)