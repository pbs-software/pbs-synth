## plotSS.ts----------------------------2022-07-26
##  Plot SS time series (Bt, BtB0, Age-0 recruits)
##  Modified r4ss functio 'SSplotTimeseries'.
## ----------------------------------------r4ss|RH
plotSS.ts = function (replist, subplot, add=FALSE, areas="all", areacols="default", 
   areanames="default", forecastplot=TRUE, uncertainty=TRUE, 
   bioscale=1, minyr=-Inf, maxyr=Inf, plot=TRUE, print=FALSE, 
   plotdir="default", verbose=TRUE, btarg="default", minbthresh="default", 
   xlab="Year", labels=NULL, punits="in", ptsize=10, cex.main=1, sobj=NULL,
   res=400, outnam, PIN=c(9,9), lang="e") 
 
{
	oldpar = par(no.readonly=TRUE)
	fart = function(opar) { if (any("windows"%in%names(dev.list()))) par(opar) }
	on.exit(fart(oldpar))

	if (missing(subplot)) 
		stop("'subplot' input required")
	if (length(subplot) > 1) 
		stop("function can only do 1 subplot at a time")
	pngfun <- function(file, caption=NA, lang="e") {
		metas = c("\\", "/", ":", "*", "?", "\"", "<", ">", "|")
		meta  = paste0(c("[",metas,"]"),collapse="")
		fnam  = gsub("[_ ]+", "_", gsub(meta,"",file))
		createFdir(lang, dir=plotdir)
		changeLangOpts(L=lang)
		fout = switch(lang, 'e' = file.path(plotdir, file), 'f' = file.path(plotdir,"french", file) )
		clearFiles(fout)
		##.flush.cat("Figure file:", fout, "\nsaved to:", plotdir, "\n")
		png(filename=fout, width=PIN[1], height=PIN[2], units=punits, res=res, pointsize=ptsize)
		plotinfo <- rbind(plotinfo, data.frame(file=fout, caption=caption))
		return(plotinfo)
	}
	plotinfo <- NULL
	if (is.null(labels)) {
		labels <- c("Total biomass (t)", "Total biomass (t) at beginning of season", "Summary biomass (t)", "Summary biomass (t) at beginning of season", "Spawning biomass (t)", "Bt / B0", "Spawning output", "Age-0 recruits (1000s)", "Fraction of total age-0 recruits", "Management target", "Minimum stock size threshold")
	}
	SS_versionshort <- replist$SS_versionshort
	timeseries      <- replist$timeseries
	nseasons        <- replist$nseasons
	spawnseas       <- replist$spawnseas
	birthseas       <- replist$birthseas
	startyr         <- replist$startyr
	endyr           <- replist$endyr
	nsexes          <- replist$nsexes
	nareas          <- replist$nareas
	derived_quants  <- replist$derived_quants
	seasfracs       <- replist$seasfracs
	B_ratio_denominator <- replist$B_ratio_denominator
	recruitment_dist    <- replist$recruitment_dist
	if (btarg == "default") 
		btarg <- replist$btarg
	if (length(minbthresh)==1 && minbthresh == "default") 
		minbthresh <- replist$minbthresh
	if (areacols[1] == "default") {
		areacols <- rich.colors.short(nareas)
		if (nareas == 3) {
			areacols <- c("blue", "red", "green3")
		}
		if (nareas > 3) {
			areacols <- rich.colors.short(nareas + 1)[-1]
		}
	}
	if (!is.null(birthseas)) {
		nbirthseas <- length(birthseas)
		seascols <- rich.colors.short(nbirthseas)
		if (nbirthseas > 2) 
			seascols <- rich.colors.short(nbirthseas + 1)[-1]
	}
	if (is.null(B_ratio_denominator)) 
		B_ratio_denominator <- 1
	if (plotdir == "default") {
		plotdir <- replist$inputs$dir
	}
	if (is.null(replist$SpawnOutputUnits) || is.na(replist$SpawnOutputUnits) || 
		replist$SpawnOutputUnits == "numbers") {
		labels[5] <- labels[7]
		labels[6] <- gsub("biomass", "output", labels[6])
	}
	if (areas[1] == "all") {
		areas <- 1:nareas
	}
	else {
		if (length(intersect(areas, 1:nareas)) != length(areas)) 
			stop("Input 'areas' should be 'all' or a vector of values between 1 and nareas.")
	}
	if (nareas > 1 & areanames[1] == "default") {
		areanames <- paste("area", 1:nareas)
	}
	ts <- timeseries
	if (nseasons > 1) {
		if (SS_versionshort == "SS-V3.11") {
			ts$YrSeas <- ts$Yr + (ts$Seas - 1)/nseasons
		}
		else {
			ts$YrSeas <- ts$Yr + seasfracs
		}
	}
	else {
		ts$YrSeas <- ts$Yr
	}
	ts <- ts[ts$YrSeas >= minyr & ts$YrSeas <= maxyr, ]
#browser();return()
	ts$period <- "time"
	ts$period[ts$Yr < startyr] <- "equilibria"
	ts$period[ts$Yr > endyr + 1] <- "fore"
	if (!forecastplot) 
		ts$period[ts$Yr > endyr + 1] <- "exclude"
	biofunc <- function(subplot, outnam, l="e") {
		plot1 <- ts$Area == 1 & ts$Era == "VIRG"
		plot2 <- ts$Area == 1 & ts$period == "time" & ts$Era != "VIRG"
		plot3 <- ts$Area == 1 & ts$period == "fore" & ts$Era != "VIRG"
		if (subplot %in% c(3, 6, 7, 9)) {
			plot1 <- ts$Area == 1 & ts$Era == "VIRG" & ts$Seas == spawnseas
			plot2 <- ts$Area == 1 & ts$period == "time" & ts$Era != "VIRG" & ts$Seas == spawnseas
			plot3 <- ts$Area == 1 & ts$period == "fore" & ts$Era != "VIRG" & ts$Seas == spawnseas
		}
		if (subplot %in% 1:3) {
			yvals <- ts[,"Bio_all",drop=FALSE]  ##ts$Bio_all  ## includes the forecast if SS has been run properly as an MPD
			ylab <- labels[1]
			if (subplot == 3) {
				ylab <- paste(labels[2], spawnseas)
			}
		}
		if (subplot %in% 4:6) {
			yvals <- ts[,"Bio_smry",drop=FALSE] ##ts$Bio_smry
			ylab <- labels[3]
			if (subplot == 6) {
				ylab <- paste(labels[4], spawnseas)
			}
		}
		if (subplot %in% 7:8) {
			yvals <- bioscale * ts[,"SpawnBio",drop=FALSE] ##ts$SpawnBio
			ylab <- labels[5]
		}
		if (subplot %in% 9:10) {
			B0 = ts$SpawnBio[grep("TIME",ts$Era)[1]]  ## do not want 'VIRG' or 'INIT'
			#B0 = ts$SpawnBio[!is.na(ts$SpawnBio)][1]
			yvals <- ts[,"SpawnBio",drop=FALSE] / B0 # $SpawnBio/ts$SpawnBio[!is.na(ts$SpawnBio)][1]
#browser();return()
			ylab <- labels[6]
		}
		if (subplot %in% 11:15) {
			yvals <- ts[,"Recruit_0",drop=FALSE] ##$Recruit_0
			ylab <- labels[8]
			if (all(yvals[ts$Era == "VIRG",] == 0 & max(ts$Seas == 1))) {
				yvals[ts$Era == "VIRG",] <- derived_quants["Recr_Virgin", "Value"]
			}
			if (all(yvals[ts$Era == "INIT",] == 0 & max(ts$Seas == 1))) {
				yvals[ts$Era == "INIT",] <- derived_quants["Recr_Unfished", "Value"]
			}
		}
		if (subplot %in% c(13, 15)) 
			ylab <- labels[9]
		if (subplot %in% c(101)){
			ylab = "Biomass comparisons"
			yvals = ts[,c("Bio_all","SmryBio_SX:1_GP:1","SmryBio_SX:2_GP:1","SpawnBio")] * bioscale
		}
		if (subplot %in% c(102)){
			ylab = "Vulnerable biomass"
			#nfleets = length(.su(grep("F:",colnames(ts),value=T)))
			nfleets = length(.su(grep("Hrate:",colnames(ts),value=T)))
			for (j in 1:nfleets) {
				#ts[,paste0("u",j)]  = 1-exp(-ts[,paste0("F:_",j)])
				ts[,paste0("u",j)]  = ts[,paste0("Hrate:_",j)]
				ts[,paste0("V",j)]  = ts[,paste0("sel(B):_",j)] / ts[,paste0("u",j)]
				ts[1,paste0("V",j)] = ts[2,paste0("V",j)]
			}
			yvals = ts[,c("Bio_all",paste0("V",1:nfleets))] * bioscale
#browser();return()
		}
		if (subplot %in% c(103)){
			ylab = "Harvest Rate"
			nfleets = length(.su(grep("Hrate:",colnames(ts),value=T)))
			for (j in 1:nfleets) {
				ts[,paste0("u",j)]  = ts[,paste0("Hrate:_",j)]
			}
			yvals = ts[,c(paste0("u",1:nfleets))]
#browser();return()
		}
		if (!is.element(subplot, c(1:15,101:103))) {
			stop("subplot should be a value from 1 to 15 (r4ss) or 101 to 103 (PBSsynth)")
		}
		main=ylab
		yrshift <- 0
		if (!is.null(birthseas) && max(birthseas) < spawnseas) {
			yrshift <- 1
		}
		if (!is.null(replist$recruitment_dist$recruit_dist) && "Age" %in% names(replist$recruitment_dist$recruit_dist)) {
			yrshift <- min(as.numeric(replist$recruitment_dist$recruit_dist$Age, na.rm=TRUE))
		}
		if (!is.null(birthseas) && nbirthseas > 1) {
			if (subplot == 11) {
				for (y in ts$Yr) {
					yvals[ts$Yr == y & ts$Seas == 1,] <- sum(yvals[ts$Yr == y,], na.rm=TRUE)
					yvals[ts$Yr == y & ts$Seas > 1,]  <- 0
				}
			}
			if (subplot == 15) {
				for (y in ts$Yr) {
					yvals[ts$Yr == y,] <- yvals[ts$Yr == y,]/sum(yvals[ts$Yr == y,], na.rm=TRUE)
				}
			}
			if (subplot %in% c(14, 15)) 
				main=paste(main, "by birth season")
		}
		if (nareas > 1) {
			if (subplot %in% c(2, 3, 5, 6, 8, 10, 12, 13)) {
				main=paste(main, "by area")
			}
			if (subplot %in% c(1, 4, 7, 11, 13)) {
				#yvals2 <- rep(NA, length(ts$YrSeas))
				yvals2 <- as.data.frame(array(NA, dim=c(length(ts$YrSeas),1), dimnames=list(rownames(ts),"sumting")))
				for (iyr in 1:nrow(yvals)) {
					y <- ts$YrSeas[iyr]
					yvals2[iyr,] <- sum(yvals[ts$YrSeas == y,])
				}
				if (subplot == 13) {
					yvals <- yvals/yvals2
				}
				else {
					yvals <- yvals2
				}
			}
			if (subplot == 9) {
				#yvals2 <- rep(NA, length(ts$YrSeas))
				yvals2 <- as.data.frame(array(NA, dim=c(length(ts$YrSeas),1), dimnames=list(rownames(ts),"sumting")))
				for (iyr in 1:nrow(yvals)) {
					y <- ts$YrSeas[iyr]
					yvals[iyr,] <- sum(ts$SpawnBio[ts$YrSeas == y])
				}
				yvals <- yvals/yvals[!is.na(yvals)][1]
			}
			ymax <- max(yvals, 1, na.rm=TRUE)
			if (subplot == 10) {
				for (iarea in 1:nareas) {
					yvals <- ts[ts$Area == iarea,"SpawnBio",drop=FALSE]/(ts$SpawnBio[ts$Area == iarea & ts$Seas == spawnseas][1])
					ymax <- max(yvals, na.rm=TRUE)
				}
			}
		}
		if (subplot == 10) {
			yvals[1,] <- NA
		}
		if (forecastplot) 
			main <- paste(main, "[ trajectory + forecast ]")
		if (uncertainty & subplot %in% c(7, 9, 11, 101)) {
			main <- paste(main, "with ~95% C.I.") #"with ~95% asymptotic intervals")
			if (!"SSB_Virgin" %in% derived_quants$Label) {
				warning("Skipping spawning biomass with uncertainty plot because 'SSB_Virgin' not in derived quantites.\n", 
					"  Try changing 'min yr for Spbio_sdreport' in starter file to -1.\n")
				stdtable <- NULL
			}
			else {
				if (subplot %in% c(7,101)) {
					stdtable <- derived_quants[grep("SSB_Virgin", derived_quants[, 1]):(grep("Recr_Virgin", derived_quants[, 1]) - 1), 1:3]
					stdtable$Yr <- substring(stdtable$Label, 5)
					stdtable$Yr[1:2] <- as.numeric(stdtable$Yr[3]) - (2:1) - yrshift
					stdtable$Yr <- as.numeric(stdtable$Yr)
				}
				if (subplot == 9) {
					stdtable <- derived_quants[substring(derived_quants$Label, 1, 6) == "Bratio", ]
					stdtable$Yr <- as.numeric(substring(stdtable$Label, 8))
					bioscale <- B_ratio_denominator
				}
				if (subplot == 11) {
					stdtable <- derived_quants[substring(derived_quants$Label, 1, 5) == "Recr_", ]
					stdtable <- stdtable[tolower(stdtable$Label) != "recr_unfished", ]
					stdtable$Yr <- substring(stdtable$Label, 6)
					stdtable$Yr[1:2] <- as.numeric(stdtable$Yr[3]) - (2:1)
					stdtable$Yr <- as.numeric(stdtable$Yr) + yrshift
					bioscale <- 1
				}
				v <- stdtable$Value * bioscale
				std <- stdtable$StdDev * bioscale
				if (subplot == 11) {
					stdtable$logint <- sqrt(log(1 + (std/v)^2))
					stdtable$lower <- qlnorm(p=0.025, meanlog=log(v), sdlog=stdtable$logint)
					stdtable$upper <- qlnorm(p=0.975, meanlog=log(v), sdlog=stdtable$logint)
				}
				else {
					stdtable$upper <- v + 1.96 * std
					stdtable$lower <- pmax(v - 1.96 * std, 0)
				}
				if (max(stdtable$Yr) < max(floor(ts$YrSeas))) {
					warning(max(stdtable$Yr), " is the last year with uncertainty in Report file, but ", 
					max(ts$YrSeas), " is last year of time series. ", "Consider changing starter file input for ", "'max yr for sdreport outputs' to -2")
				}
				stdtable <- stdtable[stdtable$Yr >= minyr & stdtable$Yr <= maxyr, ]
			}
		}
#browser();return()

		if (nareas == 1) {
			ymax <- max(yvals[plot1 | plot2 | plot3,], na.rm=TRUE)
		}
		if (subplot %in% c(13, 15)) 
			ymax <- 1
		if (uncertainty & subplot %in% c(7, 9, 11, 101)) {
			ymax <- max(ymax, stdtable$upper, na.rm=TRUE)
		}
		if (print) {
			if (missing(outnam)){
				filename <- main
				filename <- gsub(",", "", filename, fixed=TRUE)
				filename <- gsub("~", "", filename, fixed=TRUE)
				filename <- gsub("%", "", filename, fixed=TRUE)
				if (forecastplot) 
					filename <- paste(filename, "forecast")
				if (uncertainty & subplot %in% c(5, 7, 9)) 
					filename <- paste(filename, "intervals")
				filename <- paste0("ts", subplot, "_", filename, ".png")
				filename <- gsub(pattern=" ", replacement="_", x=filename, fixed=TRUE)
			} else
				filename = paste0(outnam, ".png")
			plotinfo <- pngfun(file=filename, caption=main, lang=lang)
		}
		ts$Yr[ts$Era == "VIRG"] <- ts$Yr[ts$Era == "VIRG"] + 1 + yrshift
		ts$YrSeas[ts$Era == "VIRG"] <- ts$YrSeas[ts$Era == "VIRG"] + 1 + yrshift
		sp = as.character(subplot)
		if (!add) {
			yrvals <- ts$YrSeas[plot1 | plot2 | plot3]
			xlim <- range(yrvals)
			if (!is.null(sobj)) {
				x2 = sobj$Year
				y2 = switch( sp, '7'=sobj$SB, '9'=sobj$SB/sobj$SB[1], '11'=sobj$R, rep(0,length(yrvals)) )
				use.y2 = !all(y2==0)
				if (use.y2)
					ymax  = max(ymax, max(y2))
			}
			else use.y2 = FALSE
			expandGraph(mfrow=c(1,1), mar=c(3,3,1,0.5))
			#plot(yrvals, yvals[plot1 | plot2 | plot3], type="n", xlab=xlab, xlim=xlim, ylim=c(0, 1.05 * ymax), yaxs="i", ylab=ylab, main=main, cex.main=cex.main, font.main=1)
			if (subplot %in% c(103)) ylim = c(-ymax*0.075, 1.02*ymax)
			else                     ylim = c(0, 1.05 * ymax)
			plot(0, 0, type="n", xlim=xlim, ylim=ylim, yaxs=ifelse(subplot%in%c(103),"i","i"), xlab=linguaFranca(xlab,l), ylab=linguaFranca(ylab,l), main=NULL, cex.main=cex.main, cex.lab=1.4, font.main=1)
#browser();return()
			axis(1, at=intersect(seq(1900,3000,5),xlim[1]:xlim[2]), tcl=-0.2, labels=FALSE)
		}
		if (subplot %in% c(9, 10)) {
			addtarg <- function() {
				if (btarg > 0 & btarg < 1) {
					abline(h=btarg, col="green4",lty=2)
					text(max(startyr, minyr) + 1, btarg + 0.02, linguaFranca(ifelse(subplot==9,paste0(btarg,"B0"),labels[10]),l), adj=0, col="green4")
				}
				if (all(minbthresh > 0) & all(minbthresh < 1)) {
					for (i in 1:length(minbthresh)) {
						ii = sort(minbthresh)[i]
#browser();return()
						icol = switch(i, "red", "blue", "green4")
						abline(h=ii, col=icol, lty=2)
						text(max(startyr, minyr) + 1, ii + 0.02, linguaFranca(ifelse(subplot==9,paste0(ii,"B0"),labels[10]),l), adj=0, col=icol)
					}
				}
			}
			addtarg()
		}
		if (subplot %in% 7:8) {
			addtarg <- function() {
				if (btarg > 1) {
					abline(h=btarg, col="red")
					text(max(startyr, minyr) + 4, btarg + 0.02 * diff(par()$usr[3:4]), linguaFranca(labels[10],l), adj=0)
				}
				if (minbthresh > 1) {
					abline(h=minbthresh, col="red")
					text(max(startyr, minyr) + 4, minbthresh + 0.02 * diff(par()$usr[3:4]), linguaFranca(labels[11],l), adj=0)
				}
			}
			addtarg()
		}
		if (subplot %in% 14:15) {
			for (iseas in 1:nbirthseas) {
				s <- birthseas[iseas]
				mycol <- seascols[iseas]
				mytype <- "o"
				plot1 <- ts$Seas == s & ts$Era == "VIRG"
				plot2 <- ts$Seas == s & ts$period == "time" & 
					ts$Era != "VIRG"
				plot3 <- ts$Seas == s & ts$period == "fore" & 
					ts$Era != "VIRG"
				points(ts$Yr[plot1], yvals[plot1,], pch=19, col=mycol)
				lines(ts$Yr[plot2], yvals[plot2,], type=mytype, col=mycol)
				points(ts$Yr[plot3], yvals[plot3,], pch=19, col=mycol)
			}
			#legend("topright", legend=linguaFranca(paste("Season", birthseas),l), lty=1, pch=1, col=seascols, bty="n")
			addLegend(0.975, 0.975, legend=linguaFranca(paste("Season", birthseas),l), lty=1, pch=1, col=seascols, bty="n", xjust=1, yjust=1)
		}
		else {
			if (subplot %in% c(1,4,7,9,11,14,15, 101:103)) 
				myareas <- 1
			else myareas <- areas
			for (iarea in myareas) {
				if (subplot == 10) {
					yvals <- ts[,"SpawnBio",drop=FALSE]/(ts$SpawnBio[ts$Area == iarea & ts$Seas == spawnseas][1])
				}
				if (subplot %in% c(3, 6, 7, 8, 9, 10)) {
					plot1 <- ts$Area == iarea & ts$Era == "VIRG" & ts$Seas == spawnseas
					plot2 <- ts$Area == iarea & ts$period == "time" & ts$Era != "VIRG" & ts$Seas == spawnseas
					plot3 <- ts$Area == iarea & ts$period == "fore" & ts$Era != "VIRG" & ts$Seas == spawnseas
				}
				else {
					yvals.vec = apply(yvals,1,sum,na.rm=T)
					plot1 <- yvals.vec > 0 & ts$Area == iarea & ts$Era == "VIRG"
					plot2 <- yvals.vec > 0 & ts$Area == iarea & ts$period == "time" & ts$Era != "VIRG"
					plot3 <- yvals.vec > 0 & ts$Area == iarea & ts$period == "fore" & ts$Era != "VIRG"

				}
				if (subplot %in% 9:10) {
					plot1 <- NULL
					#plot2[3] <- FALSE ## WTF?
				}
				mycol <- areacols[iarea]
				mytype <- "o"
				if (subplot == 11 & uncertainty) 
					mytype <- "p"
				if (!uncertainty) {
					legtxt = legcol = leglty = NULL
					if (use.y2) {
						if (subplot %in% c(11)) {
							x2 = c(x2[1]-1, x2[1:(length(x2)-1)])  ## PJS requested shifting Awatea age-1 recruits back 1 year to match SS age-0 recruits
						}
						lines(x2, y2, lty=1, lwd=2, col="yellow")
						lines(x2, y2, lty=2, lwd=1, col="orange")
						legtxt = c(legtxt, paste0("Awatea ", switch(sp, '7'="Bt", '9'="Bt/B0", '11'="age-1 recruits shifted", "sumtingwong")))
						leglty = c(leglty, 2)
						legcol = c(legcol, "darkgoldenrod1")
					}
					for (yy in 1:ncol(yvals)) {
						points(ts$YrSeas[plot1], yvals[plot1,yy], pch=19, col=mycol)
						lines(ts$YrSeas[plot2], yvals[plot2,yy], type=mytype, col=mycol)
						points(ts$YrSeas[plot3], yvals[plot3,yy], pch=19, col=mycol)
					}
#browser();return()
					legtxt = c(legtxt, paste0("SS ", switch(sp, '7'="Bt", '9'="Bt/B0", "age-0 recruits")))
					leglty = c(leglty, 1)
					legcol = c(legcol, mycol)
					addLegend (0.975, 0.975, legend=linguaFranca(legtxt,l), lty=leglty, col=legcol, lwd=2, seg.len=3, bty="n", xjust=1, yjust=1)
				}
				else {
					for (j in 1:ncol(yvals)) {
						jj = colnames(yvals)[j]
						if (grepl("SX:",jj)) {
							col.sex = ifelse(grepl("SX:1",jj),"orange",.colBlind["bluegreen"])
							points(ts$YrSeas[plot1], yvals[plot1,j], pch=22, col=col.sex, bg=colorspace::lighten(col.sex, amount=0.25)) #lucent(mycol,0.2))
							lines(ts$YrSeas[plot2|plot3], yvals[plot2|plot3,j], col=col.sex, lwd=2)
						}
						else {
							#col.pch = ifelse(grepl("Bio_all",jj),"black",mycol)
							col.fleet = c("blue","green3","red","purple") ## may need more colours
							col.pch = switch(jj, 'Bio_all'="black", 'V1'=col.fleet[1], 'V2'=col.fleet[2], 'V3'=col.fleet[3], 'V4'=col.fleet[4], 'u1'=col.fleet[1], 'u2'=col.fleet[2], 'u3'=col.fleet[3], 'u4'=col.fleet[4], mycol)
							points(ts$YrSeas[plot1], yvals[plot1,j], pch=22, col=col.pch, bg=colorspace::lighten(col.pch, amount=0.25)) #lucent(mycol,0.2))
							lines(ts$YrSeas[plot2], yvals[plot2,j], col="gainsboro", lwd=2)
							points(ts$YrSeas[plot2], yvals[plot2,j], pch=21, col=col.pch, bg=colorspace::lighten(col.pch, amount=0.25)) #lucent(mycol,0.2))
							points(ts$YrSeas[plot3], yvals[plot3,j], pch=24, cex=0.8, col=col.pch, bg=colorspace::lighten(col.pch, amount=0.25)) #lucent(mycol,0.2))
						}
						if (subplot %in% c(7,9,11) || colnames(yvals)[j] %in% c("SpawnBio")) {
							if (subplot == 7) {
								plot1 <- stdtable$Label == "SSB_Virgin"
								stdtable$Yr[plot1] <- stdtable$Yr[plot1] + yrshift
							}
							if (subplot == 9) {
								plot1 <- stdtable$Label == "Bratio_Virgin"
							}
							if (subplot == 11) {
								plot1 <- stdtable$Label == "Recr_Virgin"
								stdtable$Yr[plot1] <- stdtable$Yr[plot1] + 1
							}
							plot2 <- stdtable$Yr %in% ts$Yr[plot2]
							plot3 <- stdtable$Yr %in% ts$Yr[plot3]
							plotall <- plot1 | plot2 | plot3
						}
						if (subplot %in% c(7, 9) || colnames(yvals)[j] %in% c("SpawnBio")) {
							## virgin
							arrows(x0=rep(stdtable$Yr[plot1] + 1,2), x1=rep(stdtable$Yr[plot1] + 1,2),
								y0=rep(yvals[plot1,j],2), y1=c(stdtable$upper[plot1], stdtable$lower[plot1]), angle=90, length=0.05, col=mycol)
							## trajectory
							polygon(x=c(stdtable$Yr[plot2],rev(stdtable$Yr[plot2])), y=c(stdtable$lower[plot2],rev(stdtable$upper[plot2])), border=FALSE, col=lucent(mycol,0.2))
							lines(stdtable$Yr[plot2], stdtable$upper[plot2], lty=2, col=mycol)
							lines(stdtable$Yr[plot2], stdtable$lower[plot2], lty=2, col=mycol)
							## forecast
							if (any(plot3)) {
								plot33 = plot3 
								plot33[c(grep(TRUE,plot3)[1]-1,grep(TRUE,plot3))]=TRUE
								polygon(x=c(stdtable$Yr[plot33],rev(stdtable$Yr[plot33])), y=c(stdtable$lower[plot33],rev(stdtable$upper[plot33])), border=FALSE, col=lucent(mycol,0.10))
								lines(stdtable$Yr[plot33], stdtable$upper[plot33], lty=3, col=mycol)
								lines(stdtable$Yr[plot33], stdtable$lower[plot33], lty=3, col=mycol)
							}
						}
						if (subplot == 11) {
							old_warn <- options()$warn
							options(warn=-1)
							arrows(x0=stdtable$Yr[plotall], y0=stdtable$lower[plotall], y1=stdtable$upper[plotall], length=0.01, angle=90, code=3, col=mycol)
							options(warn=old_warn)
						}
					}
				}
			}
			if (nareas > 1 & subplot %in% c(2, 3, 5, 6, 8, 10, 12)) 
				addLegend(0.975, 0.975, legend=linguaFranca(areanames[areas],l), lty=1, pch=1, col=areacols[areas], bty="n", xjust=1, yjust=1)
			if (subplot %in% c(101:103)) {
				catch       = ts[,grep("retain\\(B)",colnames(ts))]
				catch$total = apply(catch,1,sum)
				#ts$catch = apply(ts[,grep("retain\\(B)",colnames(ts))],1,sum)
				base = 0
				if (subplot %in% c(103)){ 
					catch = sapply(catch, scaleVec, Tmin=ylim[1], Tmax=0)
					base = ylim[1]
				}
				#drawBars(ts$Yr[plot2|plot3], ts$catch[plot2|plot3], col="gainsboro", fill="hotpink", width=1, base=base)
				## Quick fix for now -- plot total catch then first biggest fleet catch
				drawBars(ts$Yr[plot2|plot3], catch[plot2|plot3,"total"], col="red", fill="red", width=1, base=base)
				drawBars(ts$Yr[plot2|plot3], catch[plot2|plot3,1], col="red", fill="pink", width=1, base=base)
#browser();return()
				legtxt = NULL
				if (subplot %in% 101) {
					legtxt = c("Total biomass","Female biomass", "Male biomass", "Spawning biomass", "Retained catch")
					legcol = col=c("black", "orange", .colBlind["bluegreen"], mycol, "pink")
				}
				else if (subplot %in% 102) {
					legtxt = c("Total biomass",paste0("Vulnerable biomass - fleet ",1:nfleets), "Retained catch")
					legcol = col=c("black", col.fleet[1:nfleets], "pink")
				}
				else if (subplot %in% 103) {
					legtxt = c(paste0("Harvest rate - fleet ",1:nfleets), "Retained catch" )
					legcol = c(col=col.fleet[1:nfleets], "pink")
				}
				if (!is.null(legtxt))
					addLegend(0.975, 0.975, legend=linguaFranca(legtxt,l), pch=22, col=legcol, pt.bg=colorspace::lighten(legcol,0.2), bty="n", xjust=1, yjust=1)
				box()
#browser();return()
			}
		}
#browser();return()
		if (verbose) {
			message("  finished time series subplot ", subplot, ": ", main)
		}
		if (print) 
			dev.off()
		attr(ts,"plotinfo") = plotinfo
		attr(ts,"category") = "Timeseries"
		return(ts)
	}
	skip <- FALSE
	if (nareas == 1 & subplot %in% c(2, 5, 8, 10, 12:13)) {
		skip <- TRUE; mess = paste0("subplot ", subplot, " not available for single area") }
	if (nseasons == 1 & subplot %in% c(3, 6)) {
		skip <- TRUE; mess = paste0("subplot ", subplot, " not available for single season") }
	if (subplot %in% c(14:15) & (is.null(birthseas) || nbirthseas == 1)) {
		skip <- TRUE; mess = paste0("subplot ", subplot, " not available for unspecified or single birth season") }
	if (!skip) {
		out <- biofunc(subplot=subplot, outnam=outnam, l=lang)
		return(invisible(out))
	} else {
		.flush.cat("Alert:", mess, "\n")
		return (mess)
	}
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~plotSS.ts

##strSpp="440"

## Compare to Awatea's selctivity
#if (strSpp %in% c("REBS","REBSN") && !exists("b46")) {
#	wd46 = "C:/Users/haighr/Files/GFish/PSARC20/REBS/Data/Awatea/BSR_2F/BSRrun46/MPD.46.01"
#	load(paste0(wd46,"/currentRes.rda"))
#	b46=currentRes$B
#}
#if (strSpp %in% c("440","YMR") && !exists("b29")) {  ## does not exist
#	wd29 = "C:/Users/haighr/Files/GFish/PSARC11/YMR/Awatea/YMRrun29/MPD.29.01"
#	if (file.exists(paste0(wd29,"/currentRes.rda"))) {
#		load(paste0(wd29,"/currentRes.rda"))
#		b29=currentRes$B
#	}
#}
#bawa = switch(strSpp, 'REBS'=b46, 'REBSN'=b46, '440'=b29, 'YMR'=b29)

#so("linguaFranca.r")
#so("clearFiles.r")
### Spawning biomass:
#out=plotSS.ts(replist, subplot=7, print=F, plotdir=getwd(), forecast=F, uncertainty=F, sobj=NULL, PIN=c(8,6), outnam="Bt", lang="e") 
#
### Depletion:  ## Taylor uses 'VIRG' biomass for B0 so I've fiddled with subplot 9
#out=plotSS.ts(replist, subplot=9, print=T, plotdir=getwd(), forecast=F, uncertainty=F, btarg=0.4, minbthresh=c(0.2,0.1), sobj=NULL, PIN=c(8,6), outnam="BtB0", lang=c("e"))
#
### Recruitment:
#out=plotSS.ts(replist, subplot=11, print=T, plotdir=getwd(), forecast=F, uncertainty=F, sobj=bawa, PIN=c(8,6), outnam="recruits", lang="f")

## Spawning Biomass + others
#out=plotSS.ts(replist, subplot=101, print=T, plotdir=getwd(), forecast=F, uncertainty=T, PIN=c(8,6), outnam="ts.spawning", lang="e")

## Vulnerable Biomass
#out=plotSS.ts(replist, subplot=102, print=T, plotdir=getwd(), forecast=F, uncertainty=T, PIN=c(8,6), outnam="ts.vulnerable", lang="e")

## Harvest Rate
#out=plotSS.ts(replist, subplot=103, print=T, plotdir=getwd(), forecast=F, uncertainty=T, PIN=c(8,6), outnam="ts.harvest", lang="e")

##if (subplot %in% 101) legtxt = c("Total biomass","Female biomass", "Male biomass", "Spawning biomass", "Retained catch")
##if (subplot %in% 102) legtxt = c("Total biomass",paste0("Vulnerable biomass - fleet ",1:nfleets), "Retained catch")
