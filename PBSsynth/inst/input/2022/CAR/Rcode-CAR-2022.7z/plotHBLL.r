plotHBLL = function(dat, xlim=c(-134.5,-122.5), ylim=c(48,54.8),
   png=FALSE, pngres=400, PIN=c(9,8.25), lang=c("f","e"))
{
	data("nepacLL",package="PBSmapping")
	data("major","isobath", "spongeCPZ", "spongeAMZ", package="PBSdata")
	ssid = unique(dat$survey_series_id)
	onam = "HBBL-Survey"

	## PJS wants PMFC areas labelled
	pmfc = as.EventData(data.frame( EID = 1:8,
		X   = c(-123.9151, -127.2, -128.8285, -130.3339, -131.4836, -130.5940, -131.3, -133.0712),
		Y   = c(49.34649, 48.51826, 49.70511, 50.84927, 51.61773, 52.69358, 53.82920, 52.83020),
		label = c("4B","3C","3D","5A","5B","5C","5D","5E")
	), projection="LL")

	## Create a subdirectory called `french' for French-language figures
	createFdir(lang)
	fout.e = onam
	for (l in lang) {
		fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
		changeLangOpts(L=l)
		if (png) {
			clearFiles(paste0(fout,".png"))
			png (filename=paste0(fout,".png"), width=PIN[1], height=PIN[2], units="in", res=pngres)
		}
		expandGraph(mfrow=c(1,1), mar=c(3,3,0.5,0.5), oma=c(0,0,0,0), mgp=c(2,0.5,0))
		plotMap(nepacLL, xlim=xlim, ylim=ylim, plt=NULL, border="gainsboro", cex.axis=1.2, cex.lab=1.5)
#browser();return()
		#addPolys(spongeAMZ, border="black", col="yellow")
		#addPolys(spongeCPZ, border="black", col="green")
		for (i in ssid){
			idat = dat[is.element(dat$survey_series_id, i),]
			points(idat$longitude, idat$latitude, pch=16, cex=0.6, col=lucent(switch(as.character(i), '22'="blue", '36'="red"),0.5))
		}
		itemp = clipLines(isobath[is.element(isobath$PID, c(100, 200, 300, 500)),],xlim=xlim,ylim=ylim)
		addLines(itemp, col="grey")
		addPolys(major, col="transparent", border="black", lwd=1)
		addPolys(nepacLL, col="lemonchiffon", border="grey")
		addLabels(pmfc, cex=1.5, col="black")
		addLegend(0.075,0.2, legend=linguaFranca(c("HBLL North","HBLL South"),l), pch=16, col=c("blue","red"), xjust=0, yjust=0, bty="n", cex=1.5)
		box(lwd=1)
		if (png) dev.off()
	}; eop()
}
so("linguaFranca.r")
load("hbll.rda")
plotHBLL(hbll,png=T,lang=c("f","e"))