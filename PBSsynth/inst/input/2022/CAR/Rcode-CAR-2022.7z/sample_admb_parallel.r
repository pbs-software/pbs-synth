## sample_admb_parallel-----------------2021-03-26
## adnuts Function: sample_admb_parallel
## --------------------------------------adnuts|RH
sample_admb_parallel = function (parallel_number, path, algorithm, ...) 
{
	olddir <- getwd()
	#newdir <- paste0(file.path(getwd(), path), "_chain_", parallel_number)  ## WTF
	newdir <- paste0(sub("/$","",file.path(path)), "/chain_", parallel_number) ## RH 201021
	adieu = function() {
		unlink(newdir, recursive=TRUE, force=TRUE)
		setwd(olddir)
	}
	on.exit(adieu())
	if (dir.exists(newdir)) {
		unlink(newdir, recursive=TRUE, force=TRUE)
		if (dir.exists(newdir)) 
			stop(paste("Could not remove folder:", newdir))
	}
	dir.create(newdir)
	f.need <- list.files(path, full.names=TRUE, pattern="\\.ss$|\\.cov$|\\.hes$")
	f.need <- grep("runnumber",f.need,invert=TRUE,value=TRUE)
	trash  <- file.copy(from=f.need, to=newdir, overwrite=TRUE, copy.date=TRUE)
	#trash  <- file.copy(from=list.files(path, full.names=TRUE), to=newdir, overwrite=TRUE, copy.date=TRUE)
	trash2 <- file.copy(from="C:/Users/haighr/Files/Archive/Bat/ss.exe", to=newdir, overwrite=TRUE, copy.date=TRUE) ## copy ss executable to temporary chain directories
#return(trash)
#browser();return()
	if (algorithm == "RWM") 
		fit <- sample_admb_rwm(path=newdir, chain=parallel_number, parallel=FALSE, ...)
	if (algorithm == "NUTS") 
		fit <- sample_admb_nuts(path=newdir, chain=parallel_number, parallel=FALSE, ...)
	#unlink(newdir, recursive=TRUE, force=TRUE)
	return(fit)
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~sample_admb_parallel
