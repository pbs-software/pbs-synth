## runADnuts----------------------------2020-11-11
##  Based on Chris Grandis' R code that was used to manually run adnuts.
##  adnuts needs serious path intervention (RH 201021)
## ------------------------------------------CG|RH
runADnuts=function(path=getwd(), stock="BSR", model="base", 
   rda_name, add2rda=FALSE, tag="REBSN", 
   parallel=TRUE, cores=6, syscall=rep(TRUE,5),
   iters=list(test=15,pilot=100,mle=500,update=1000),
   ssexe="ss", ssdir=getwd(), ssfiles=c("control.ss","data.ss"),
   stupid_shiny=FALSE)
{
	## Check to see if file exists and keep a copy if it does before removing it.
	sweep.files = function(x) {
		rubbish = 0
		for (i in x) {
			if (file.exists(i)) {
				fstamp = paste0(sub("[[:space:]]","(",gsub("[[:punct:]]","",substring(file.info(i)$ctime,3,16))),")")
				ext    = tools::file_ext(i)
				pre    = gsub(paste0("\\.",ext,"$"),"",i)
				backup = paste0(pre,"-",fstamp,".",ext)
				if (!file.exists(backup))
					file.copy(from=i, to=backup, overwrite=FALSE, copy.date=TRUE)
				file.remove(i)
				rubbish = rubbish +1
			}
		}
		invisible(paste0(rubbish, " files removed"))
	}

	start_time <- Sys.time()
	cwd <- getwd()
	on.exit(setwd(cwd))
	setwd(path); path=getwd(); setwd(cwd)  ## Just in case a relative path is specified
	
	d.stock  = file.path(path, stock)
	d.model  = file.path(d.stock, "models", model)
	d.mpd    = file.path(d.model, "mpd")
	d.mcmc   = file.path(d.model, "mcmc")
	if(missing(rda_name))
		rda_name = paste0(stock,".",model,".rda")
	rda_file = file.path(d.stock, rda_name)  ## store rda files in the stock directory
#browser();return()
	## Create subdirectories if needed
	if (!file.exists(d.stock)) 
		dir.create(d.stock)
	if (!file.exists(d.model)) 
		dir.create(d.model)
	if (!file.exists(d.mpd)) 
		dir.create(d.mpd)
	if (!file.exists(d.mcmc)) 
		dir.create(d.mcmc)
	ssfiles = unique(c("starter.ss","forecast.ss",ssfiles))
	if ( all(file.exists(paste0(ssdir,"/",ssfiles)))) {
		file.copy(from=paste0(ssdir,"/",ssfiles), to=paste0(d.model,"/",ssfiles), overwrite=TRUE, copy.date=TRUE)
		file.copy(from=paste0(ssdir,"/",ssfiles), to=paste0(d.mpd,"/",ssfiles),   overwrite=TRUE, copy.date=TRUE)
		file.copy(from=paste0(ssdir,"/",ssfiles), to=paste0(d.mcmc,"/",ssfiles),  overwrite=TRUE, copy.date=TRUE)
	} else
		stop("SS files: '", paste0(ssfiles,collapse="', '"),"'\n\tnot found in ", ssdir)

	setwd(d.mpd)

	## ----------------------------------------------------------------
	if (syscall[1]) {
		## This step is needed to create files like 'covar.sso' and 'ss_summary.sso'
		.flush.cat("Running MPD for best fits...\n")
		toast = setdiff(list.files("."),c(ssfiles))
		if (length(toast)>0)
			file.remove(toast)
		system(paste0(ssexe))
	}
	replist = SS_output(dir=d.mpd, verbose=FALSE)
	ttput(replist)
	vals.save = c("replist")

browser();return()

	setwd(d.model)

	## Chains to run in parallel
	reps  <- min(cores, parallel::detectCores() - 1)
	set.seed(352)
	seeds <- sample(1:1e4, size = reps)
	sweep.files(rda_file)
#browser();return()

	## ----------------------------------------------------------------
	if (syscall[2]) {
		## This step is needed before syscall 3
		.flush.cat("Running precursor mcmc test...\n")
		sweep.files("ss.psv")
		system(paste0(ssexe, " -nox -iprint 200 -mcmc ", iters$test))
	}

	## Then run parallel RWM chains as a first test to ensure
	## mcmc itself is working properly, or that model is converging in mcmc space
	thin   <- 10
	iter   <- iters$pilot * thin ## iter is per core !!!
	#warmup <- ceiling(iter/4)
	warmup <- ceiling(0.25*iter)
	inits  <- NULL               ## start chains from MLE
	vals.save = c(vals.save,c("seeds"))
#browser();return()

	## ----------------------------------------------------------------
	if (syscall[3]){
		.flush.cat("Running pilot RWM chains...\n")
		pilot  <- sample_admb(model=ssexe, path=d.model, iter=iter, init=inits, chains=reps, warmup=warmup, seeds=seeds, thin=thin, mceval=FALSE, duration=NULL, parallel=parallel, cores=reps, control=NULL, algorithm="RWM")
		ttput(pilot)
	}
		else ttget(pilot)
	
	## Check convergence and slow mixing parameters
	mon  <- rstan::monitor(pilot$samples, warmup=pilot$warmup, print=FALSE)
	## max(mon[,'Rhat'])
	## min(mon[,'n_eff'])
	## Examine the slowest mixing parameters
	slow <- names(sort(mon[,"n_eff"]))[1:8]
	vals.save = c(vals.save,c("pilot","mon","slow"))
#browser();return()
	#pairs_admb(fit=pilot, pars=slow, label.cex=1)
	#pairs_admb(fit = pilot, pars = c("MGparm[1]", "SR_parm[1]", "SR_parm[2]")) ## must be specific to Hake
	#pairs_admb(fit = pilot, pars = c("SR_parm[1]", "Q_parm[1]", "selparm[1]"), label.cex=1)
	
	## After regularizing run NUTS chains. First reoptimize to get the
	## correct mass matrix for NUTS. Note the -hbf 1 argument. This is a
	## technical requirement b/c NUTS uses a different set of bounding
	## functions and thus the mass matrix will be different.
	## ----------------------------------------------------------------
	if (syscall[4]) {
		.flush.cat("Reoptimize to get correct mass matrix...\n")
		system(paste0(ssexe, " -hbf 1 -nox -iprint 200 -mcmc ", iters$test))
	}
#browser();return()

	## Use default MLE covariance (mass matrix) and short parallel NUTS chains started from the MLE.
	## ----------------------------------------------------------------
	if (syscall[5]) {
		.flush.cat("Using MLE covariance and short parallel NUTS chains...\n")
		warmup   <- ceiling(0.2*iters$mle)  ## Monnahan et al. (2019)
		nuts.mle <-  sample_admb(model=ssexe, path=d.model, iter=iters$mle, init=NULL, chains=reps, warmup=warmup, seeds=seeds, thin=1, mceval=FALSE, duration=NULL, parallel=parallel, cores=reps, control=list(metric="mle", adapt_delta=0.8), algorithm="NUTS")
		ttput(nuts.mle)
	} else
		ttget(nuts.mle)
	vals.save = c(vals.save,c("nuts.mle"))
	## Check for issues like slow mixing, divergences, max treedepths with
	## ShinyStan and pairs_admb as above. Fix and rerun this part as needed.
	## launch_shinyadmb(nuts.mle)
#browser();return()
	
	## Once acceptable, run again for inference using updated mass matrix. Increase
	## adapt_delta toward 1 if you have divergences (runs will take longer).
	## Note this is in unbounded parameter space
	## The following, nuts.updated, was used for inferences in this appendix
	mass  <- nuts.mle$covar.est
	inits <- sample_inits(nuts.mle, reps)
	## ----------------------------------------------------------------
	if (syscall[6]) {
		.flush.cat("Run final NUTS MCMC using updated mass matrix...\n")
		sweep.files(c("ss.psv","unbounded.csv"))
		setwd(d.mcmc)
		## Check to see if psv file exists and keep a copy if it does
		sweep.files(c("ss.psv"))
		toast = setdiff(list.files("."),c(ssfiles,"mcmc",".RData"))
#browser();return()
		if (length(toast)>0)
			file.remove(toast)
		warmup = ceiling(0.2*iters$update)  ## Monnahan et al. (2019)
		butter = c("admodel.cov","admodel.hes","ss.par","ss.cor")
		if ( all(file.exists(paste0(d.model,"/",butter))) )
			zb = file.copy(from=paste0(d.model,"/",butter), to=paste0(d.mcmc,"/",butter), overwrite=TRUE, copy.date=TRUE)
		else
			stop("MPD precursor directory is missin:\n\t'",paste0(butter[!xb],collapse="', '"),"'")

		nuts.updated <- sample_admb(model=ssexe, path=d.mcmc, iter=iters$update, init=inits, chains=reps, warmup=warmup, seeds=seeds, thin=1, mceval=TRUE, duration=NULL, parallel=parallel, cores=reps, control=list(metric=mass, adapt_delta=0.9), algorithm="NUTS")
		ttput(nuts.updated)
	}
		else ttget(nuts.updated)

	vals.save = c(vals.save,c("nuts.updated","mass","inits"))

	tmpenv <- new.env()
	if (file.exists(rda_file) && add2rda) {
		load(rda_file, envir=tmpenv)
		oldtags = ls(envir=tmpenv)
	}
	mess = paste0(tag,"=list(",paste0(paste0(vals.save,"=",vals.save),collapse=","),"); ttput(", tag, "); tput(", tag, ",tenv=tmpenv); save(list=ls(tmpenv),file=\"",rda_file,"\", envir=tmpenv)")
	eval(parse(text=mess))
	end_time <- Sys.time()
	cat("Elapsed time: ", end_time - start_time, " hours\n")
#browser();return()

	## Have to get rid of column "lp__" to make shinyadmb work (bad programming in '.validate_sampler_params')
	if (stupid_shiny) {
		fit = nuts.updated
		tmp_params = fit$sampler_params
		nms_params = lapply(tmp_params,function(x){x[,setdiff(colnames(x),"lp__")]})
		fit$sampler_params = nms_params
		ttput(fit)
		launch_shinyadmb(fit)
	}
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~runADnuts

require(adnuts)
require(snowfall)
require(rstan)
require(shinystan)
require(matrixcalc)
require(r4ss)
d.synth = "C:/Users/haighr/Files/Projects/R/Develop/PBSsynth/Authors/Rcode/develop"
r.synth = c("plotFuns","utilFuns","overwriteFuns")
for (i in r.synth)
	source(paste0(d.synth,"/",i,".r"))
#so("plotFuns.r"); source("sample_admb_parallel.r"); source("pairs_admb.r")
#runADnuts(path=".", parallel=TRUE, syscall=c(F,F,F,F,F), iters=list(test=15,pilot=100,mle=60,update=100), tag="BSR_FU", add2rda=TRUE)
#runADnuts(path=".", parallel=TRUE, syscall=c(T,T,T,T,T), iters=list(test=15,pilot=100,mle=100,update=500), rda_name="BSR_2F.rda", tag="REBSN")
#runADnuts(path=".", stock="BSR", model="wong", parallel=TRUE, syscall=c(F,F,F,F,T), iters=list(test=15,pilot=100,mle=60,update=100), rda_name="sumtingwong.rda", tag="REBSN", ssfiles=c("rebsn.control.46.01.ss","rebsn.data.46.01.ss"))

## 1912 MCMC samples after 200 burn-in specified in starter file and 20% warmup for AD nuts using 6 cores
#runADnuts(path=".", stock="BSR", model="zanadu", parallel=TRUE, cores=6, syscall=c(F,F,F,F,T), iters=list(test=15,pilot=100,mle=500,update=(2200/6)*1.2), tag="rebsn", ssfiles=c("rebsn.control.46.01.ss","rebsn.data.46.01.ss"))

## 2000 MCMC samples after 400 burn-in specified in starter file and 20% warmup for AD nuts using 6 cores
runADnuts(path=".", stock="BSR", model="zebu", parallel=TRUE, cores=6, syscall=c(F,rep(T,5)), iters=list(test=15,pilot=100,mle=500,update=500), tag="rebsn", ssfiles=c("rebsn.control.46.01.ss","rebsn.data.46.01.ss"))


##==========================================================
## Determine number of iterations:
##  where a = desired # MCMC samples, b = burn-in speciefied in 'starter.ss', c = # cores, w = warmup used in AD nuts
icalc = function(a=2000,b=400,c=6,w=0.2){ (a+b)/(c*(1-w)) } ## icalc(b=400) = 500
## Determine number of final MCMC samples:
##  where i = number of iterations for AD nuts, b = burn-in speciefied in 'starter.ss', c = # cores, w = warmup used in AD nuts
acalc = function(i=500,b=400,c=6,w=0.2){ (1-w)*i*c-b }      ## acalc(i=500, b=400) = 2000
##==========================================================


