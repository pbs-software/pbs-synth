## convPN-------------------------------2022-06-15
##  Convert parameter names from SS to Awatea
## ---------------------------------------------RH
convPN = function(pnams) {
	cnams =
		sub("_steep","_h",
		sub("NatM_p_1_Fem_GP_1|NatM_uniform_Fem_GP_1|NatM_break_(\\d+)?_Fem_GP_1","M\\1_Female",
		sub("NatM_p_1_Mal_GP_1|NatM_uniform_Mal_GP_1|NatM_break_(\\d+)?_Mal_GP_1","M\\1_Male",
		sub("Early_RecrDev|Main_RecrDev|Late_RecrDev|ForeRecr","RecrDev",
		sub("FISHERY","", 
		sub("SYNOPTIC","",
		sub("HISTORIC(AL)?","",
		sub("TRIENNIAL","",
		sub("HBLL_NORTH","HBLLN_",
		sub("HBLL_SOUTH","HBLLS_",
		sub("^AgeSel_(\\d+)?(Male|Fem)_Scale","delta5(\\1)",
		sub("^AgeSel_(\\d+)?(Male|Fem)_Final","delta4(\\1)",
		sub("^AgeSel_(\\d+)?(Male|Fem)_Descend","delta3(\\1)",
		sub("^AgeSel_(\\d+)?(Male|Fem)_Ascend","delta2(\\1)",
		sub("^AgeSel_(\\d+)?(Male|Fem)_Peak","delta1(\\1)",
		sub("^Age_DblN_end_logit","beta6",
		sub("^Age_DblN_top_logit","beta2",
		sub("^Age_DblN_descend_se","varR",
		sub("^Age_DblN_ascend_se","varL",
		sub("^Age_DblN_peak","mu",
		sub("^SR_","",
		pnams)))))))))))))))))))))
		onams   = sapply(strsplit(cnams,"_"), function(x){
		if(length(x)==3 && x[1] %in% c("mu","beta2","varL","varR","beta6")) {
#browser();return()
			paste0(x[1],x[3],"_",x[2])
		} else {
			paste0(x,collapse="_")
		}
	})
	onams = sub("^M1_", "M_", onams)
	return(onams)
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~convPN

#parameters = replist$parameters
#pactive = parameters[!is.na(parameters$Active_Cnt) & parameters$Phase>0 & !is.element(parameters$Pr_type,"dev"),]
#fornow = convPN(pactive$Label)

#d.mcmc = SSgetMCMC(getwd()); test=colnames(d.mcmc)
#test = pactive$Label
#fornow = convPN(test)
#fornow = convPN(pactive$Label); print(fornow)

