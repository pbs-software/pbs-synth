plotHmean = function(replist, fleets.af)
{
	png("harmonica.png", units="in", res=400, width=8, height=6)
	expandGraph(mfrow=.findSquare(length(fleets.af)), mar=c(3,3,0.5,0.5), oma=c(0,0,0,0), mgp=c(1.75,0.5,0))
	plotSS.comps(replist,subplots=7,kind="AGE",fixdims=F,fitbar=T,fleets=fleets.af,showeffN=F,lwd=1.5,plot=T,print=F,lang="f")
	dev.off()
}
#require(r4ss)
#replist=SS_output(".")
run=75
fleets.af  = c(1:5); fleets.idx = ifelse(is.element(run,c(50:53,55:79,81:100))|run=="75a",1,2):5
so("plotSS.comps.r","synth"); so("linguaFranca.r")

plotHmean(replist, fleets.af=1)

