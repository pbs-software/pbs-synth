## sample_admb--------------------------2021-03-25
## adnuts Function: sample_admb
## --------------------------------------adnuts|RH
sample_admb = function (model, path=getwd(), iter=2000, init=NULL, chains=3, 
   warmup=NULL, seeds=NULL, thin=1, mceval=FALSE, duration=NULL, 
   parallel=FALSE, cores=NULL, control=NULL, algorithm="NUTS", ...) 
{
	stopifnot(thin >= 1)
	stopifnot(chains >= 1)
	if (is.null(seeds)) 
		seeds <- sample.int(1e+07, size=chains)
	if (iter < 10 | !is.numeric(iter)) 
		stop("iter must be > 10")
	stopifnot(is.character(path))
	stopifnot(is.character(model))
	if (!dir.exists(path)) 
		stop(paste("Folder", path, "does not exist. Check argument 'path'"))
	if (.Platform$OS.type == "windows") {
		sspath="C:/Users/haighr/Files/Archive/Bat"            ## RH 201021
		ff <- file.path(sspath, paste(sub("\\.exe$","",model), ".exe", sep=""))  ## RH 201021
	}
	else {
		ff <- file.path(path, paste("./", model, sep=""))
	}
	if (!file.exists(ff)) 
		stop(paste("File", ff, "not found. Check 'path' and 'model' arguments"))
	control <- adnuts:::.update_control(control)
#browser();return()
	if (is.null(warmup)) 
		warmup <- floor(iter/2)
	if (!(algorithm %in% c("NUTS", "RWM"))) 
		stop("Invalid algorithm specified")
	if (is.null(init)) {
		warning("Using MLE inits for each chain -- strongly recommended to use dispersed inits")
	}
	else if (is.function(init)) {
		init <- lapply(1:chains, function(x) init())
	}
	else if (!is.list(init)) {
		stop("init must be NULL, a list, or a function")
	}
	if (!is.null(init) & length(init) != chains) {
		stop("Length of init does not equal number of chains.")
	}
	trash <- file.remove(list.files()[grep(".psv", x=list.files())])
#browser();return()
	if (!parallel) {
		if (algorithm == "NUTS") {
			#mcmc.out <- lapply(1:chains, function(i) adnuts:::sample_admb_nuts(path=path, model=model, iter=iter, init=init[[i]], chain=i, thin=thin, warmup=warmup, seed=seeds[i], duration=duration, control=control, parallel=FALSE, ...))
			mcmc.out <- lapply(1:chains, function(i) sample_admb_nuts(path=path, model=model, iter=iter, init=init[[i]], chain=i, thin=thin, warmup=warmup, seed=seeds[i], duration=duration, control=control, parallel=FALSE, ...))
		}
		else {
			mcmc.out <- lapply(1:chains, function(i) sample_admb_rwm(path=path, model=model, iter=iter, thin=thin, warmup=warmup, init=init[[i]], chain=i, seed=seeds[i], control=control, duration=duration, parallel=FALSE, ...))
		}
	}
	else {
		if (!requireNamespace("snowfall", quietly=TRUE)) 
			stop("snowfall package not found")
		snowfall::sfInit(parallel=TRUE, cpus=cores)
		snowfall::sfExportAll()  ## export R objects like function 'sample_admb_parallel'
		on.exit(snowfall::sfStop())
		mcmc.out <- snowfall::sfLapply(1:chains, function(i){
			sample_admb_parallel(parallel_number=i, path=path, model=model, duration=duration, 
			algorithm=algorithm, iter=iter, init=init[[i]], warmup=warmup, seed=seeds[i],
			thin=thin, control=control, ...)})
	}
#browser();return()

	## Build output list
	warmup <- mcmc.out[[1]]$warmup
	mle <- adnuts:::.read_mle_fit(model=model, path=path)
	if (is.null(mle)) {
		par.names <- dimnames(mcmc.out[[1]]$samples)[[2]]
		par.names <- par.names[-length(par.names)]
	}
	else {
		par.names <- mle$par.names
	}
	iters <- unlist(lapply(mcmc.out, function(x) dim(x$samples)[1]))
	if (any(iters != iter/thin)) {
		N <- min(iters)
		warning(paste("Variable chain lengths, truncating to minimum=", N))
	}
	else {
		N <- iter/thin
	}
	samples <- array(NA, dim=c(N, chains, 1 + length(par.names)), dimnames=list(NULL, NULL, c(par.names, "lp__")))
	for (i in 1:chains) samples[, i, ] <- mcmc.out[[i]]$samples[1:N,]
	if (algorithm == "NUTS") 
		sampler_params <- lapply(mcmc.out, function(x) x$sampler_params[1:N,])
	else sampler_params <- NULL
	time.warmup <- unlist(lapply(mcmc.out, function(x) as.numeric(x$time.warmup)))
	time.total <- unlist(lapply(mcmc.out, function(x) as.numeric(x$time.total)))
	cmd <- unlist(lapply(mcmc.out, function(x) x$cmd))
	if (N < warmup) 
		warning("Duration too short to finish warmup period")
	message(paste("... Merging post-warmup chains into main folder:", path))
	samples2 <- do.call(rbind, lapply(1:chains, function(i) samples[-(1:warmup), i, -dim(samples)[3]]))
	adnuts:::.write_psv(fn=model, samples=samples2, model.path=path)
	unbounded <- do.call(rbind, lapply(mcmc.out, function(x) x$unbounded))
#browser();return()
	oldwd <- getwd()
	on.exit(setwd(oldwd))
	setwd(path)
	write.table(unbounded, file="unbounded.csv", sep=",", col.names=FALSE, row.names=FALSE)
	if (mceval) {
		message("... Running -mceval on merged chains")
		#system(paste(model, "-mceval -maxI 0 -nohess"), ignore.stdout=FALSE)  ## this only reports one sample of derived_paramters
		system(paste(model, "-mceval"), ignore.stdout=FALSE)
	}
	covar.est <- cov(unbounded)
	result <- list(samples=samples, sampler_params=sampler_params, time.warmup=time.warmup, time.total=time.total, algorithm=algorithm, warmup=warmup, model=model, max_treedepth=mcmc.out[[1]]$max_treedepth, cmd=cmd, covar.est=covar.est, mle=mle)
	attr(result,"class")=c("adfit","list")
	return(invisible(result))
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sample_admb

