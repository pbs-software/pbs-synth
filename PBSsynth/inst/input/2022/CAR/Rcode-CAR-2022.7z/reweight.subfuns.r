	##===== start subfuns =====

	## Normal residual for an observation (Coleraine Excel algorithm only)
	## (F.26 POP 2010 assessment)
	NRfun  = function(O,P,CV,maxR=0,logN=TRUE)  {
		if (logN) {
			num = log(O) - log(P) + 0.5*log(1+CV^2)^2
			den = sqrt(log(1+CV^2))
			NR  = num/den }
		else
			NR = (O-P)/CV
		if (round(maxR,6)!=0) {
			maxR = c(-abs(maxR),abs(maxR))
			NR[NR < maxR[1]] = maxR[1]
			NR[NR > maxR[2]] = maxR[2] }
		return(NR)
	}

	## Standard deviaton of observed proportion-at-ages (Coleraine Excel algorithm only)
	## (F.27 POP 2010 assessment)
	SDfun = function(p,N,A) {
		# p = observed proportions, N = sample size, A = no. sexes times number of age bins
		SD = sqrt((p * (1-p) + 0.1/A) / N) 
		SD[!is.finite(SD)] = NA
		return(SD)
	}

	## Re-weighted (effective) N for porportions-at-age (Coleraine Excel algorithm only)
	eNfun = function(S,Y,O,P,Nmax=200) {
		# S = Series, Y = Year, O = Observed proportions, P = Predicted (fitted) proportions, Nmax = maximum sample size allowed
		f   = paste(S,Y,sep="-")
		num = sapply(split(P,f),function(x) { sum( x * (1 - x) ) } )
		den = sapply(split(O-P,f),function(x){ sum( x^2 ) } )
		N  = pmin(num/den, Nmax)
		return( N )
	}

	## Mean age residuals (Chris Francis) (deprecated)
	MRfun = function(y,a,O,P)  {
		Oay = a * O; Pay = a * P
		mOy = sapply(split(Oay,y),sum,na.rm=TRUE)
		mPy = sapply(split(Pay,y),sum,na.rm=TRUE)
		ry  = mOy - mPy
		return(ry) 
	}

	## Correction factor based on mean age residuals (deprecated)
	CFfun = function(y,N,a,O,P) {
		Oay = a * O; OAy = a^2 * O
		mOy = sapply(split(Oay,y),sum,na.rm=TRUE)
		MOy = sapply(split(OAy,y),sum,na.rm=TRUE)
		Vy  = MOy - mOy^2  # variance of the age frequency in year y
		ry  = MRfun(y,a,O,P)
		CF  = 1 / var(ry*(N/Vy)^.5)
		return(CF) 
	}

	## Mean age function (Chris Francis, 2011, weighting assumption T3.4, p.1137)
	## MAfun now in `utilFuns.r` (because it is needed here and in `runSweave`).

	## Method TA1.8 Weigting assumption T3.4 in Francis (2011, CJFAS, p.1137) Table A1
	## See plotMeanAge.r for debugging
	wfun = function (MAlist) {
		# y=year, a=age bin, O=observed proportions, P=Predicted (fitted) proportions, N=sample size, J=series
		unpackList(MAlist,scope="L")
		w    = rep(1,length(J)); names(w)=J
		jvec = substring(names(N),1,nchar(names(N))-5)
		wN   = N
		for (j in 1:length(J)) {
			jj = J[j]
			z = is.element(jvec,jj); zNoVar = is.element(Vexp,0); zNoVal = is.element(MAexp,0) & zNoVar
			# Only use values in series jj with non-zero variance and with fitted values
			zUse = z&!zNoVar&!zNoVal
			if (!any(zUse) || sum(zUse)<=1) next
			## Method TA1.8 Weigting assumption T3.4 in Francis (2011) Table A1
			w[j] = 1 / var((MAobs[zUse]-MAexp[zUse])/((Vexp[zUse]/N[zUse])^0.5) )
			wN[zUse] = N[zUse] * w[j]
		}
		return(list(w=w,wN=wN))
	}
	##===== end subfuns =====

