## plotSS.rmcmc-------------------------2022-06-28
##  Plot routine output for MCMCs.
## ---------------------------------------------RH
plotSS.rmcmc = function(mcmcObj, mpdObj, ptypes, lang, pngres=400, PIN=c(9,9))
{
	so("linguaFranca.r")
	unpackList(mpdObj); unpackList(mcmcObj)

	## Pairs|density plot comparison among parameters
	plotSS.pairs(P.mpd, P.mcmc, ptypes=ptypes, lang=lang, pngres=pngres, PIN=c(10,10), type="image")

#return();

	## Parameter posteriors and priors
	for (l in lang) {
		plotSS.pars(replist, nrows=P.rc[1], ncols=P.rc[2], plot=F, print=T, fitrange=T, fitnudge=0.5, showpost=T, strings=names(P.mpd), exact=T, plotdir=getwd(), lang=l, outnam="pdfParameters")
	}

	## Snail plots of Bt/Bmsy and ut/umsy
	colnames(BoverBmsy) = sub("^SSB_","",colnames(BoverBmsy))
	colnames(UoverUmsy) = sub("^u_","",colnames(UoverUmsy))
	for (ptype in ptypes) {
		plotSnail(BoverBmsy, UoverUmsy, yrs=modYrs, p=tcall(quants3)[c(1,3)], xLim=NULL, yLim=NULL, ngear=ngear, assYrs=assYrs, outs=F, Cnames=fleets.lab[1:ngear], ptypes=ptype, outnam="snail", lang=l)
	}
}
#so("plotSS.pairs.r","synth")
#plotSS.rmcmc(mcmcObj=diag.mcmc, mpdObj=diag.mpd, ptypes="png", lang=c("e"))
#1.5,1.5,1.5,1.5
#so("plotSnail.r"); plotSS.rmcmc(mcmcObj=diag.mcmc, mpdObj=diag.mpd, ptypes="win", lang="e")
