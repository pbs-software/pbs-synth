## getHBLL------------------------------2022-06-15
## Outside HBLL Survey - Canary
## Code supplied by Dana Haggarty (2022-04-11)
## Includes hook competition adjustment.
## ------------------------------------------DH|RH
getHBLL = function(strSpp="437", spn="Canary Rockfish", timestamp="220615")
{
	#rm(list=setdiff(ls(all=T), c(".First",".SavedPlots","clr","clr.rgb","qu","so" )))  #Erase all previously saved objects

	library(dplyr)
	library(gfdata)

#browser();return()
	data <- gfdata::get_ll_hook_data(species = strSpp, ssid = c(22, 36))

	d2 <- gfdata::get_survey_sets(spn, ssid = c(22, 36))
	write.csv(d2, "Canary_outsideHBLL_220615.csv")

	## The following code should deal with the issue of 0 baited hooks being observed.
	adjust <- data %>%
		group_by(year, fishing_event_id) %>%
		mutate(total_hooks = count_target_species + count_non_target_species +
			count_bait_only + count_empty_hooks - count_bent_broken) %>%
		mutate(count_bait_only = replace(count_bait_only, which(count_bait_only == 0), 1)) %>%
		mutate(prop_bait_hooks = count_bait_only / total_hooks) %>%
		mutate(hook_adjust_factor = -log(prop_bait_hooks) / (1 - prop_bait_hooks)) %>%
		mutate(expected_catch = round(count_target_species * hook_adjust_factor))

	## find out which events are in hook data but not set data:
	setdiff(data$fishing_event_id, d2$fishing_event_id)

	hook_adjusted_data <- left_join(d2, adjust, by = c("fishing_event_id", "year"))
	saveRDS(hook_adjusted_data, file = "Canary_outsideHBLL_hook_adjusted_220615.rds")
	write.csv(hook_adjusted_data, "Canary_outsideHBLL_hook_adjusted_220615.csv")
	return(hook_adjusted_data)
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~getHBLL

hbll=getHBLL(strSpp="437")

