## plotSS.pmcmc-------------------------2022-07-27
##  Plot boxplots of quantiles for various MCMC parameters.
##  Modified from PBSawatea's 'plotBmcmcPOP' function.
##  Input comes from the output file 'derived.parameters.sso' (use r4ss::SSgetMCMC)
## -----------------------------------------AME|RH
plotSS.pmcmc=function(obj, p=tcall(quants5), xyType="quantBox",
   lineType=c(3,2,1,2,3), refLines=NULL, xLim=NULL, yLim=NULL,
   userPrompt=FALSE, save=TRUE, tcl.val=-0.2, yrs, y0=TRUE,
   pyrs=NULL, LRP=NULL, USR=NULL, catpol=NULL,
   yaxis.by, yLab="Recruitment", outnam, lang=c("e","f"), 
   ptypes="win", pngres=400, PIN=c(8,6), ...)
{
	# See plt.quantBio if want other xyTypes, as took out here:
	plt.qB <- function(obj, xyType="lines", new=TRUE, xLim, yLim, yrs, pyrs, LRP, USR, pvec, ...) {
		if ( new ) {
			plot(xLim, yLim, type="n", xlab=linguaFranca("Year",l), ylab=linguaFranca(yLab,l), ...)
			if (!y0) abline(h=0,col="gainsboro")
		}
#browser();return()
		#yrs <- as.numeric(dimnames(obj)[[2]])
		#yrs <- as.numeric(gsub("[^[:digit:]]","",dimnames(result1)[[2]]))

		# Quantile boxplots - assumes five quantiles.
		if ( xyType=="quantBox" ) {
			if(!is.null(USR))
				abline(h=c(USR), col=c("slategray"), lwd=1, lty=5)
			delta <- 0.25 ## width of half-box
			# Draw the outer whiskers.
			segments(yrs, obj[1,], yrs,obj[5,], lty=1,col=1 )
			# Overlay the box.
			for ( i in 1:length(yrs) )
				#rect( yrs[i]-delta,obj[2,i], yrs[i]+delta, obj[4,i],... ) ## AME
				polygon(x=c(rep(yrs[i]-delta,2),rep(yrs[i]+delta,2)), y=obj[c(2,4,4,2),i], border="black", col="gainsboro", ...) ## RH (190620)
			# Add the median.
			segments( yrs-delta,obj[3,],yrs+delta,obj[3,],lty=1,col=1 )
			if (!is.null(pyrs)){
				pp = as.character(pyrs)
				segments(pyrs, obj[1,pp], pyrs, obj[5,pp], lty=1,col="red" )
				for ( i in (length(yrs)-length(pyrs)+1):length(yrs) )
					polygon(x=c(rep(yrs[i]-delta,2),rep(yrs[i]+delta,2)), y=obj[c(2,4,4,2),i], border="red", col="pink", ...) ## RH (190620)
				segments( pyrs-delta, obj[3,pp], pyrs+delta, obj[3,pp], lty=1, col="red" )
			}
		}
		# Uncertainty envelope - assumes five quantiles.
		if ( xyType=="envelope" ) {
			if(!is.null(LRP) && !is.null(USR))
				abline(h=c(LRP,USR), col=c("red","green4"), lwd=1, lty=5)
			x  = setdiff(yrs,pyrs)
			xx = as.character(x)
			polygon(c(x,rev(x)), c(obj[1,xx],rev(obj[5,xx])), col=lucent("blue",0.05), border=FALSE)
			lines(x, obj[3,xx], lty=1, lwd=3, col="blue")
			lines(c(x,NA,x), c(obj[1,xx],NA,obj[5,xx]), lty=2, lwd=2, col="blue")
			lines(c(x,NA,x), c(obj[2,xx],NA,obj[4,xx]), lty=3, lwd=1, col="blue")

			if (!is.null(pyrs)){
				kcol = if (length(pvec)==1) "red" else c("green3","orange2","red")
				for (k in 1:length(pvec)) {
					x  = c(pyrs[1]-1,pyrs)
					xx = as.character(x)
					yy  = obj[,xx]
					pp  = pvec[[k]]
					yy[rownames(pp),colnames(pp)] = pp
					polygon(c(x,rev(x)), c(yy[1,xx],rev(yy[5,xx])), col=lucent(kcol[k],0.1), border=FALSE)
#browser();return()
					lines(x, yy[3,xx], lty=1, lwd=3, col=kcol[k])
					lines(c(x,NA,x), c(yy[1,xx],NA,yy[5,xx]), lty=2, lwd=2, col=kcol[k])
					lines(c(x,NA,x), c(yy[2,xx],NA,yy[4,xx]), lty=3, lwd=1, col=kcol[k])
				}
			}
		}
	}
	# Plot quantiles of biomass using the posterior densities.
	yrs1 = yrs2 = result1 = result2 = NULL
	if(is.null(p)) p = c(0.05, 0.25, 0.50, 0.75, 0.95)

	# Calculate the quantiles of the reconstructed biomass.
	result1 <- apply( obj, 2, quantile, probs=p, na.rm=T )
	yrs1 <- as.numeric(gsub("[^[:digit:]]","",dimnames(result1)[[2]]))
	if (!missing(yrs)) {
		zyrs = is.element(yrs1,c(yrs,pyrs))
		yrs1 = yrs1[zyrs]
		result1 = result1[,zyrs]
	}
#browser();return()
	if (!is.null(catpol)) {
		cpolnam = dimnames(catpol)[[4]]
		cpolcat = avgCP[1,1,cpolnam]
		projmat = apply(catpol[,,1,], 2:3, quantile, probs=p, na.rm=T )  ## this will need fixing
		projvec = lapply(1:dim(projmat)[3], function(k) {projmat[,,k]})
		names(projvec) = cpolcat
	} else {
		projvec = list('AC'=result1[,intersect(colnames(result1),as.character(pyrs))])
	}
	if ( is.null(yLim) )
		yLim <- c(ifelse(y0, 0, min(unlist(result1),unlist(projvec),na.rm=T)), max(unlist(result1),unlist(projvec),na.rm=T))
	if ( is.null(xLim) )
		xLim=range(yrs1)
	colnames(result1) = yrs1
#browser();return()

	createFdir(lang)
	if (missing(outnam))
		outnam=gsub("[[:space:]]+",".",tolower(yLab))
	fout = fout.e = outnam
	for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
		changeLangOpts(L=l)
		fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
		for (p in ptypes) {
			if (p=="eps")      postscript(paste0(fout,".eps"), width=PIN[1], height=PIN[2], horizontal=FALSE,  paper="special")
			else if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
			expandGraph(mar=c(3.5,3.75,1.5,0.75), mgp=c(2,0.5,0))
			plt.qB(result1, xLim=xLim, yLim=yLim, xyType=xyType, yrs=yrs1, pyrs=pyrs, LRP=LRP, USR=USR, pvec=projvec, ...)
			axis(1, at=intersect(seq(1900,3000,5), xLim[1]:xLim[2]), tcl=tcl.val, labels=FALSE)
			if (missing(yaxis.by)) {
				yint = diff(seq(par()$yaxp[1], par()$yaxp[2], len=par()$yaxp[3]+1))[1]
				ytck = seq(par()$yaxp[1]-yint, par()$yaxp[2]+yint, yint/ifelse(par()$yaxp[3]>6,2,4))
				axis(2, at=ytck, tcl=tcl.val, labels=FALSE)
			} else 
				axis(2, at=seq(par()$yaxp[1], par()$yaxp[2], by=yaxis.by), tcl=tcl.val, labels=FALSE)
			#axis(2, at=seq(0, yLim[2], by=yaxis.by), tcl=tcl.val, labels=FALSE)
			if (length(projvec)==3)
				addLegend(0.55,0.975,legend=paste0(names(projvec)," t"), lty=1, lwd=3, seg.len=3, col=c("green3","orange2","red"), bty="n", xjust=0, yjust=1,title=linguaFranca("Projected catch",l))
			if (p %in% c("eps","png")) dev.off()
		}
	}; eop()
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~plotSS.pmcmc


#plotSS.pmcmc(, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab="Recruitment deviations", outnam="recdevMCMC", ptypes=ptypes, y0=F)
#plotSS.pmcmc(BoverBmsy, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(B[t] / B[MSY]), outnam="boverbmsyMCMC", xyType="envelope", ptypes=ptypes, pyrs=proYrs, LRP=0.4, USR=0.8)
#plotSS.pmcmc(BoverBmsy.mcmc, yrs=1935:2020, lang="f", cex.axis=1.2, cex.lab=1.5, yLab=expression(B[t] / B[MSY]), outnam="boverbmsyMCMC", xyType="envelope", ptypes="win", pyrs=2021:2030, LRP=0.4, USR=0.8)

## Model composite
#plotSS.pmcmc(compo$avgTS[,,"BtBmsy"], yrs=1935:2021, lang="e", cex.axis=1.2, cex.lab=1.5, yLab=expression(B[t] / B[MSY]), outnam="compo.BtBmsy", xyType="envelope", ptypes="win", pyrs=2022:2031, LRP=0.4, USR=0.8)
#plotSS.pmcmc(compo$avgTS[,,"BtB0"], yrs=1935:2021, lang="e", cex.axis=1.2, cex.lab=1.5, yLab=expression(B[t] / B[0]), outnam="compo.BtB0", xyType="envelope", ptypes="win", pyrs=2022:2031, LRP=0.2, USR=0.4)
#plotSS.pmcmc(fornow$avgTS[,,"BtBmsy"], yrs=1935:2021, lang="e", cex.axis=1.2, cex.lab=1.5, yLab=expression(B[t] / B[MSY]), outnam="compo.BtBmsy", xyType="envelope", ptypes="win", pyrs=2022:2031, LRP=0.4, USR=0.8)

#plotSS.pmcmc(R.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab="Recruitment", outnam="recruitsMCMC", ptypes=ptypes)
#plotSS.pmcmc(ut.mcmc, yrs=modYrs, lang="f", cex.axis=1.2, cex.lab=1.5, yLab=expression(paste("Exploitation rate ", group("(",italic(u)[italic(t)],")"))), outnam="exploitMCMC", ptypes="win", USR=NULL)
