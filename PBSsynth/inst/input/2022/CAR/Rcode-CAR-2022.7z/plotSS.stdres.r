## plotSS.stdres------------------------2022-11-01
## Plot standardised residuals -- three plots on one page.
## Modified from PBSawatea code in 'PBSscape.r'.
## -----------------------------------------------
plotSS.stdres = function(replist, kind="AGE", fleets="all",
   fleetnames="default", sexes="all", datonly=FALSE, aggregates_by_mkt = FALSE,
   labels=c("Length (cm)", "Age (yr)", "Year", "Observed sample size",
   "Effective sample size", "Proportion", "cm", "Frequency", "Weight", "Length",
   "(mt)", "(numbers x1000)", "Stdev (Age)", "Conditional AAL plot, ", "Size bin"),
   plot=TRUE, print=FALSE, type="Multinomial",
   ptypes="png", pngres=400, PIN=c(7,9), outnam, lang="e", ...)
{
	oldpar = par(no.readonly=TRUE)
	fart = function(opar) { if (any("windows"%in%names(dev.list()))) par(opar); eop() }
	on.exit(fart(oldpar))
#	changeLangOpts(L=lang)
	if (missing(outnam))
		outnam = NULL
	ttput(outnam)

#	pngfun <- function(file, caption=NA) {
#		png(filename=file.path(plotdir, file), width=pwidth, 
#			height=pheight, units=punits, res=res, pointsize=ptsize)
#		plotinfo <- rbind(plotinfo, data.frame(file=file, caption=caption))
#		return(plotinfo)
#	}
	plotinfo <- NULL
	SS_versionNumeric <- replist$SS_versionNumeric
	agedbase          <- replist$agedbase
	nfleets           <- replist$nfleets
	nseasons          <- replist$nseasons
	seasfracs         <- replist$seasfracs
	FleetNames        <- replist$FleetNames
	nsexes            <- replist$nsexes
	accuage           <- replist$accuage
	titles            <- NULL
	titlemkt          <- ""
	if (fleets[1] == "all") {
		fleets <- 1:nfleets
	}
	else {
		if (length(intersect(fleets, 1:nfleets)) != length(fleets)) {
			stop("Input 'fleets' should be 'all' or a vector of values between 1 and nfleets.")
		}
	}
	if (fleetnames[1] == "default") {
		fleetnames <- FleetNames
	}
#browser();return()
	if (sexes[1] == "all") {
		sexes <- 0:nsexes
		titlesex <- "(sexes combined)"
	}
	if (nsexes == 1) {
		sexes <- 0:nsexes
	}
	if (nsexes == 1 && length(sexes) > 1) {
		titlesex <- ""
		filesex <- ""
	}
	if (nsexes > 1 && length(sexes) == 1) {
		if (sexes == 0) {
			titlesex <- "(sexes combined)"
			filesex <- "sex0"
		}
		if (sexes == 1) {
			titlesex <- "(female)"
			filesex <- "sex1"
		}
		if (sexes == 2) {
			titlesex <- "(male)"
			filesex <- "sex2"
		}
	}
	if (length(sexes)==2 && all(sexes %in% c(1:2))) {
		titlesex = "(M+F)"
		filesex <- "sex12"
	}
#browser();return()
	if (!(kind %in% c("LEN", "SIZE", "AGE", "cond", "GSTAGE", "GSTLEN", "L@A", "W@A"))) {
		stop("Input 'kind' to SSplotComps needs to be one of the following:\n  ", "'LEN','SIZE','AGE','cond','GSTAGE','GSTLEN','L@A','W@A'.")
	}
	#titlesex <- ifelse(printsex, titlesex, "")
	if (kind == "LEN") {
		dbase_kind <- lendbase
		kindlab=labels[1]
		if (datonly) {
			filenamestart <- "comp_lendat_"
			titledata <- "Length comp data, "
		}
		else {
			filenamestart <- "comp_lenfit_"
			titledata <- "Length comps, "
		}
	}
	if (kind == "GSTLEN") {
		dbase_kind       <- ghostlendbase
		kindlab=labels[1]
		if (datonly) {
			filenamestart <- "comp_gstlendat_"
			titledata     <- "Ghost length comp data, "
		}
		else {
			filenamestart <- "comp_gstlenfit_"
			titledata     <- "Ghost length comps, "
		}
	}
	if (kind == "SIZE") {
		dbase_kind       <- sizedbase[sizedbase$method == sizemethod,]
		if (!is.null(sizebinlabs)) {
			kindlab <- labels[15]
			axis1 <- sort(unique(dbase_kind$Bin))
			if (length(sizebinlabs) == length(axis1)) {
				axis1labs <- sizebinlabs
			}
			else {
				axis1labs <- axis1
				warning("Input 'sizebinlabs' differs in length from the unique Bin\n", "  values associated with sizemethod=", sizemethod, ". Using bin values instead.")
			}
		}
		else {
			sizeunits <- unique(dbase_kind$units)
			if (length(sizeunits) > 1) {
				stop("!error with size units in generalized size comp plots:\n", "   more than one unit value per method.\n")
			}
			if (sizeunits %in% c("in", "cm")) {
				kindlab <- paste(labels[10], " (", sizeunits, ")", sep="")
			}
			if (sizeunits %in% c("lb", "kg")) {
				kindlab <- paste(labels[9], " (", sizeunits, ")", sep="")
			}
		}
		if (datonly) {
			filenamestart <- "comp_sizedat_"
			titledata <- "Size comp data, "
		}
		else {
			filenamestart <- "comp_sizefit_"
			titledata <- "Size comps, "
		}
		if (length(unique(sizedbase$method)) > 1) {
			filenamestart <- paste0(filenamestart, "method", sizemethod, "_")
			titledata <- paste0(titledata, " size method ", sizemethod, ", ")
		}
	}
	if (kind == "AGE") {
		dbase_kind <- agedbase
		kindlab=labels[2]
		if (datonly) {
			filenamestart <- "comp_agedat_"
			titledata <- "Age comp data, "
		}
		else {
			filenamestart <- "comp_agefit_"
			titledata <- "Age comps, "
		}
	}
	if (kind == "cond") {
		dbase_kind <- condbase
		kindlab=labels[2]
		if (datonly) {
			filenamestart <- "comp_condAALdat_"
			titledata <- "Conditional age-at-length data, "
		}
		else {
			filenamestart <- "comp_condAALfit_"
			titledata <- "Conditional age-at-length, "
		}
	}
	if (kind == "GSTAGE") {
		dbase_kind <- ghostagedbase
		kindlab=labels[2]
		if (datonly) {
			filenamestart <- "comp_gstagedat_"
			titledata <- "Ghost age comp data, "
		}
		else {
			filenamestart <- "comp_gstagefit_"
			titledata <- "Ghost age comps, "
		}
	}
	if (kind == "GSTcond") {
		dbase_kind <- ghostagedbase
		kindlab=labels[2]
		if (datonly) {
			filenamestart <- "comp_gstCAALdat_"
			titledata <- "Ghost conditional age-at-length data, "
		}
		else {
			filenamestart <- "comp_gstCAALfit_"
			titledata <- "Ghost conditional age-at-length comps, "
		}
	}
	if (kind == "L@A") {
		dbase_kind <- ladbase[ladbase$Nsamp_adj != 0, ]
		kindlab=labels[2]
		if (datonly) {
			filenamestart <- "comp_LAAdat_"
			titledata <- "Mean length at age data, "
		}
		else {
			filenamestart <- "comp_LAAfit_"
			titledata <- "Mean length at age fit, "
		}
		dbase_kind$SD <- dbase_kind$Lbin_lo/dbase_kind$Nsamp_adj
	}
	if (kind == "W@A") {
		dbase_kind <- wadbase[wadbase$Nsamp_adj != 0, ]
		kindlab=labels[2]
		if (datonly) {
			filenamestart <- "comp_WAAdat_"
			titledata <- "Mean weight at age data, "
		}
		else {
			filenamestart <- "comp_WAAfit_"
			titledata <- "Mean weight at age fit, "
		}
		dbase_kind$SD <- dbase_kind$Lbin_lo/dbase_kind$Nsamp_adj
	}
	if (nrow(dbase_kind) > 0) {
		if (aggregates_by_mkt) {
			dbase_kind$Part_group <- dbase_kind$Part
		}
		else {
			dbase_kind$Part_group <- -1
		}
	}
	if (any(dbase_kind$SuprPer == "Sup" & dbase_kind$Used == "skip")) {
		cat("Note: removing super-period composition values labeled 'skip'\n", "   and designating super-period values with a '*'\n")
		dbase_kind <- dbase_kind[dbase_kind$SuprPer == "No" | dbase_kind$Used != "skip", ]
		dbase_kind$YrSeasName <- paste(dbase_kind$YrSeasName, ifelse(dbase_kind$SuprPer == "Sup", "*", ""), sep="")
	}
	ageerr_warning <- TRUE
	dbase_kind <- dbase_kind[dbase_kind$Fleet %in% fleets & dbase_kind$sex %in% sexes, ]
	if (nrow(dbase_kind)==0)
		stop ("Sum Ting Wong")

	## Replace std.res. generated by r4ss using calculation in function 'calcStdRes'
	## Note: Best to use r4ss calculation for Multinomial and Dirichlet-Multinomial
	#if (type %in% c("Multinomial","Fournier","Coleraine")) {
	if (type %in% c("Fournier","Coleraine")) {
		dbase_kind$Pearson_orig = dbase_kind$Pearson
		dbase_temp = calcStdRes(dbase_kind,type=type)
		dbase_kind$Pearson = dbase_temp$stdRes
	}

	for (f in fleets) {
		fdbase = dbase_kind[is.element(dbase_kind$Fleet,f),]
		## Already has Pearson residuals computed
		if (is.null(ttcall(outnam)))
			outnam = "ageresFleet"
		fnam = paste0(outnam,f,sub("mf$","",gsub("\\+","",tolower(extract.between(titlesex,"(",")")))))
		fout = fout.e = fnam
		for (l in lang) {
			changeLangOpts(L=l)
			fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
#browser();return()
			for (p in ptypes) {
				if (print && p=="eps") {
					clearFiles(paste0(fout,".eps"))
					postscript(paste0(fout,".eps"), width=PIN[1], height=PIN[2], horizontal=FALSE,  paper="special")
				} else if (print && p=="png"){
					clearFiles(paste0(fout,".png"))
					png(paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
				}
				par(mfrow=c(3,1), mai=c(0.45,0.3,0.1,0.1), omi=c(0,0.25,0.4,0), mgp=c(2,0.75,0))
				plt.ageResids(fdbase, main="", lang=l, ...)   ## by age class
				plt.yearResids(fdbase, lang=l, ...)           ## by year
				plt.cohortResids(fdbase, lang=l, ...)         ## by cohort (year of birth)
#browser();return()
				#title = paste(toUpper(tolower(gsub("[[:punct:]]+", " ", FleetNames[f]))),titlesex)
				#title = paste(gsub("URVEY", "urvey", gsub("ISHERY", "ishery", gsub("YNOPTIC", "ynoptic", gsub("[[:punct:]]+", " ", FleetNames[f])))),titlesex)
				title = paste(gsub("_", " ", FleetNames[f]),titlesex)
				mtext(linguaFranca(title,l), side=3, outer=TRUE, line=0.25, cex=1.5)
				mtext(linguaFranca("Standardised Residuals",l), side=2, outer=TRUE, line=0, cex=1.5)
				if (print && p %in% c("eps","png")) dev.off()
			} ## end p (ptypes) loop
		}; eop()
	}
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~plotSS.stdres

rerunfun=F
if (rerunfun) {
	run=24  ## CAR base run
	d.synth = "C:/Users/haighr/Files/Projects/R/Develop/PBSsynth/Authors/Rcode/develop/"
	r.synth = c("PBSsynth","plotSS.pars","plotSS.ts","plotSS.index","plotSS.francis", "plt.selectivity", "plotSS.selex", "make.multifig", "plotSS.comps", "plotSS.rdevs", "calcStdRes", "ptab", "convPN", "weightAF", "plt.cohortResids","initialise")
	for (i in r.synth) source(paste0(d.synth,i,".r"))
	so("clearFiles.r"); so("linguaFranca.r")
	
	#plotSS.stdres(replist, fleets=3, plot=T, print=F, sexes=1:2, cex.axis=1.2, cex.lab=1.5, PIN=c(8,9), outnam="ageresFleet", type="Multinomial", lang="e")
	#plotSS.stdres(replist, fleets=1, plot=T, print=F, sexes=1:2, cex.axis=1.2, cex.lab=1.5, PIN=c(8,9), outnam="AF.coleraine.fleet", type="Coleraine", lang="e")
	#plotSS.stdres(replist, fleets=5, plot=F, print=T, sexes=1:2, cex.axis=1.2, cex.lab=1.5, PIN=c(8,9), outnam="ageresFleet", lang="f")
	
	## Age compostion residuals (note: boxpars are put into .PBSmodEnv when PBSsynth.r is sourced
	##   but need to call 'plotss.rdevs' first to produce recdevs for coloured cohorts in 'plt.cohortResids')
	lang="f"
	plotSS.rdevs(replist, subplot=1, plot=T, print=F, plotdir=getwd(), outnam="recDev", lang=lang)  ## .
	plotSS.stdres(replist, fleets=fleets.af, plot=F, print=T, sexes=1:2, cex.axis=1.2, cex.lab=1.5, PIN=c(8,9), outnam="ageresFleet", lang=lang)
}
