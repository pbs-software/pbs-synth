plotPDOfit = function(dir="C:/Users/haighr/Files/GFish/PSARC22/CAR/Data/SS/Versions",
   run=38, ver=6:8, png=F, pngres=400, PIN=c(9,6), lang=c("f","e"))
{
	vlist = ttget(vlist)
	if (is.null(vlist)) {
		vlist=list()
		for (v in ver) {
			vdir = paste0(dir,"/Run", pad0(run,2), ".v", v, "/MPD.", run, ".01")
			replist = SS_output(dir=vdir)
			cpue    = replist$cpue
			pdo     = cpue[grep("PDO",cpue$Fleet_name),]
			vlist[[paste0("v",v)]] = pdo
		}
		ttput(vlist)
	}
	year = .su(unlist(lapply(vlist,function(x){x$Yr})))
	vars = c("Obs","Exp","Calc_Q")
	vmat = array(NA, dim=c(length(year),length(vlist),length(vars)), dimnames=list(year=year, vers=names(vlist), vars=vars))
	for (v in names(vlist)) {
		for (i in vars) {
			idat = vlist[[v]]
			if (!i %in% colnames(idat)) next
			ivar = idat[,i] ; names(ivar) = idat[,"Yr"]
			vmat[names(ivar),v,i] = ivar
		}
	}
	x = as.numeric(rownames(vmat))
	xlim = range(x)
	ylim = c(0, max(vmat, na.rm=T))

	createFdir(lang)
	fout.e = paste0("PDO-v(", paste0(ver,collapse="+"), ")")

	for (l in lang) {
		changeLangOpts(L=l)
		fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
		if (png) {
			clearFiles(paste0(fout,".png"))
			png(paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
		}
		expandGraph(mfrow=c(1,1), mar=c(3,3,1,1), mgp=c(2,0.5,0))
		plot(0,0, type="n", xlim=xlim, ylim=ylim, xlab="Year", ylab="PDO Index")
		axis(1, at=intersect(seq(1900,2050,5), ceiling(par()$usr[1]):floor(par()$usr[2])), tcl=-0.25, labels=F)
		abline(v=intersect(seq(1900,2050,10), ceiling(par()$usr[1]):floor(par()$usr[2])), col="gainsboro")
		for (v in dimnames(vmat)$vers ){
			iv = grep(v, dimnames(vmat)$vers)
			y = vmat[, v, ]
			lines (x, y[,"Exp"], col=lucent(switch(iv,"red","blue","green4"),0.75), lty=switch(iv,1,1,1), lwd=3)
			if (all(apply(vmat[,,"Obs"],1,diff)==0) && iv==dim(vmat)[2])
				points(x, y[,"Obs"], pch=21, cex=1.5, col="black",bg=lucent("yellow",0.75), lwd=2)
		}
		addLegend(0.05, 0.95, legend=c("Observed",paste0("Exp w/ cp=",c(0,0.3,0.8258), ";  Q=Exp/VB=", c(round(apply(vmat[,,"Calc_Q"],2,mean),5)))), pch=c(21,NA,NA,NA), pt.bg=c("yellow",NA,NA,NA), pt.cex=c(1.5,NA,NA,NA), lty=c(NA,1,1,1), lwd=c(NA,3,3,3), col=c("black","red","blue","green4"), bty="n")
		box()
		if (png) dev.off()
	}; eop()
#browser();return()
}
require(r4ss)
plotPDOfit(run=38, ver=6:8, lang="e",png=T)

