## tabSS.compo--------------------------2022-11-18
## Make Base Case Tables
## Note: u2023=u2022 (see 'gatherMCMC.r') so change 
##       labels here in rfpt tables to use 'prevYear'
## ---------------------------------------------RH
tabSS.compo = function(istock="CAR", prefix="car.", compo,
  useRlow=FALSE, qRlow=0.25, sigdig=4)
{
	on.exit(gc(verbose=FALSE))
	unpackList(stock[[istock]][["Controls"]])
	unpackList(compo)

	modYrs      = startYear:currYear
	modYrsChar  = as.character(modYrs)
	## Diagnostics for select parameters
	P.mpd       = ampdPA; storage.mode(P.mpd)="double"     ## For some reason, this matrix is stored as a list (maybe due to NA values?)
	P.names     = colnames(avgPA)
	P.runs      = as.numeric(sapply(strsplit(rownames(avgPA),"\\."),function(x){x[1]}))
	P.run.rwt   = sapply(strsplit(rownames(avgPA),"\\."),function(x){paste0(x[1],".",x[2])}) ## vector of Runs and Rwts
	P.run.ord   = unique(P.runs)
	P.run.nmc   = table(P.runs)[as.character(P.run.ord)]
	P.run.num   = rep(1:length(P.run.nmc), P.run.nmc)
	use.run.rwt = is.element(P.runs, P.run.ord) ## default use all runs but a subset might be used for management advice
	B.labs      = paste0(rep("B",NrefM),1:NrefM," (R",P.run.ord,")")
	if (spp.code %in% c("YMR"))
		P.ord=c(1,seq(2,10,2),seq(3,11,2))
	else
		P.ord = 1:ncol(ampdPA)

	##----------Table 1-----------
	## MCMC model parameters table
	##----------------------------
	tabPmed = t(apply(avgPA,2,quantile,tcall(quants5)))  ## arrays so cannot use sapply
	tabPmed = tabPmed[P.ord,]
	tabPmed = formatCatch(tabPmed,N=sigdig)

	names.pars = rownames(tabPmed)
	fixsub = grep("_",names.pars)
	fixnot = grep("Female|Male|BH|theta",names.pars)
#browser();return()
	names.pars[fixsub] = paste0(sub("_","~(",names.pars[fixsub]),")")
	names.pars = sub("varL\\(","\\\\log v(\\\\text{L}",names.pars)
	names.pars = gsub("\\(theta\\)","\\\\theta",names.pars)
	names.pars[grep("theta",names.pars)] = sub("ln\\(","\\\\log\\\\,[", sub("\\)","]", grep("theta",names.pars,value=T)))
	names.pars[setdiff(fixsub,fixnot)] = sub("\\(","_{", sub("\\)","}", names.pars[setdiff(fixsub,fixnot)]))
	names.pars = gsub("mu","\\\\mu",names.pars)
	names.pars = gsub("[Dd]elta","\\\\Delta",names.pars)
	names.pars = sub("LN\\(R0)","\\\\log R_{0}",names.pars)
	names.pars[setdiff(fixsub,fixnot)] = sub("\\(","(\\\\text{", sub("\\)","})", names.pars[setdiff(fixsub,fixnot)]))
	names.pars = sub("(M|BH)~","\\1~", names.pars)
	names.pars = sub("DM","\\\\text{DM}~", names.pars)
	names.pars = sub("(Male|Female|BH)","\\\\text{\\1}", names.pars)

	rownames(tabPmed) =  paste(rep("$",nrow(tabPmed)),names.pars,rep("$",nrow(tabPmed)),sep="")
	#colnames(tabPmed) =  gsub("\\%","\\\\%",colnames(tabPmed))

	xtab.compo.pars = xtable(tabPmed, align="lrrrrr",
		label   = paste0("tab:",prefix,"base.pars"), digits = if (exists("formatCatch")) NULL else sigdig,
		caption = paste0("Base run: the ", texThatVec(tcall(quants5)), " quantiles for ", ifelse(NrefM>1,"pooled",""),
		" model parameters (defined in \\AppEqn) from MCMC estimation of \\numberstringnum{", NrefM, "} ",
		ifelse(NrefM>1, "component model runs of \\Nmcmc{} samples each.", "base run of \\Nbase{} samples.") ) )
	xtab.compo.pars.out = capture.output(print(xtab.compo.pars,
		caption.placement="top", sanitize.rownames.function=function(x){x}, add.to.row =list(pos=list(-1), command=c("\\\\[-1.0ex]")) ) )
	tput(xtab.compo.pars.out)
#browser();return()

# \\hline\\\\[-2.2ex] CC & 2023 & 2024 & 2025 & 2026 & 2027 & 2028 & 2029 & 2030 & 2031 \\\\[0.2ex]\\hline\\\\[-1.5ex]
	##----------Table 2-----------
	## MCMC Derived Parameters
	##----------------------------
	yrsUse = modYrs[c(1,length(modYrs)+c(-1,0))]
	yrsChr = as.character(yrsUse)

	B.mcmc = data.frame (
		B0         = avgRP[,"B0"],
		Bcurr      = avgRP[,"Bcurr"],
		Bcurr.B0   = avgRP[,"Bcurr"] / avgRP[,"B0"],
		ucurr      = avgRP[,"ucurr"],
		umax       = apply(avgTS[,,"ut"],1,max), ## for each mcmc sample across the time series
		MSY        = avgRP[,"MSY"],
		Bmsy       = avgRP[,"Bmsy"],
		LRP        = avgRP[,"LRP"],
		USR        = avgRP[,"USR"],
		Bcurr.Bmsy = avgRP[,"Bcurr"] / avgRP[,"Bmsy"],
		Bmsy.B0    = avgRP[,"Bmsy"] / avgRP[,"B0"],
		umsy       = avgRP[,"umsy"],
		ucurr.umsy = avgRP[,"ucurr"] / avgRP[,"umsy"]
	)
	tabmsy = t(apply(B.mcmc,2,quantile,tcall(quants5))) 
	tabmsy = formatCatch(tabmsy, N=sigdig)
	#colnames(tabmsy) =  gsub("\\%","\\\\%",colnames(tabmsy))
	names.msy = rownames(tabmsy)

	names.msy =
		gsub("\\.(B|u)", "/\\1",
		gsub("_Trawl", "~(\\\\text{trawl})",
		gsub("_Other", "~(\\\\text{other})",
		gsub("msy", "_\\\\text{MSY}",
		gsub("LRP",  paste0("0.4B_{\\\\text{MSY}}"),
		gsub("USR",  paste0("0.8B_{\\\\text{MSY}}"),
		gsub("MSY",  paste0("\\\\text{MSY}"),
		gsub("VB",  "V",
		gsub("[Uu]max", "u_\\\\text{max}",
		gsub("ucurr",  paste0("u_{",prevYear,"}"),
		gsub("Bcurr",  paste0("B_{",currYear,"}"),
		gsub("B0", "B_{0}",
		names.msy))))))))))))
	rownames(tabmsy) =  paste(rep("$",nrow(tabmsy)),names.msy,rep("$",nrow(tabmsy)),sep="")
#browser();return()

	## Caption for MSY table
	cap.msy = paste0(
		"Base run: the ", texThatVec(tcall(quants5)), " quantiles of MCMC-derived quantities from \\Nbase{} samples ", 
		ifelse(NrefM>1,"pooled","")," from ", ifelse(NrefM>1, "component runs.", "a single base run."),
		" Definitions are: ",
		"$B_0$ -- unfished equilibrium spawning biomass (mature females), ",
		#"$V_0$ -- unfished equilibrium vulnerable biomass (males and females), ",
		"$B_{", currYear, "}$ -- spawning biomass at the beginning of ", currYear, ", ",
		#"$V_{", prevYear, "}$ -- vulnerable biomass in the middle of ", prevYear, ", ",
		"$u_{", prevYear, "}$ -- exploitation rate (ratio of total catch to vulnerable biomass) in the middle of ", prevYear, ", ",
		"$u_\\text{max}$ -- maximum exploitation rate (calculated for each sample as the maximum exploitation rate from ",
		modYrs[1], "-", prevYear, "), ",
		"$B_\\text{MSY}$ -- equilibrium spawning biomass at MSY (maximum sustainable yield), ",
		"$u_\\text{MSY}$ -- equilibrium exploitation rate at MSY, ",
		#"$V_\\text{MSY}$ -- equilibrium vulnerable biomass at MSY. ",
		"All biomass values (and MSY) are in tonnes. ", refCC.sentence
	)
	
	xtab.compo.rfpt = xtable(tabmsy, align="lrrrrr",
		label=paste0("tab:",prefix,"base.rfpt"), digits=if (exists("formatCatch")) NULL else sigdig, caption=cap.msy )
	xtab.compo.rfpt.out = capture.output( print(xtab.compo.rfpt,
		caption.placement="top", sanitize.rownames.function=function(x){x}, add.to.row=list(pos=list(-1,3,11), command=c("\\\\[-1.0ex]", "\\hdashline \\\\[-1.75ex]", "\\hdashline \\\\[-1.75ex]")), hline.after=c(-1,0,5,nrow(xtab.compo.rfpt)) ) )
	tput(xtab.compo.rfpt.out)
#browser();return()

	## Component run likelihoods
	## -------------------------
	tabll = formatCatch(avgLL)
	rownames(tabll) =
		sub("^Index$", "Abundance Index",
		sub("^Recruit$", "Recruitment",
		sub("^AF$", "Age Frequency",
		sub("BT$",  "Bottom Trawl",
		sub("TRI$", "Triennial",
		sub("HIS$", "Historical",
		sub("SYN$", "Synoptic",
		gsub("_", " ",
	rownames(tabll) ))))))))
#browser();return()
	
	xtab.cruns.ll = xtable(tabll, align=paste0("l", paste0(rep("r",dim(avgLL)[2]),collapse="")),
		label   = paste0("tab:",prefix,"log.likes"), digits=NULL, 
		caption = paste0("Log likelihood (LL) values reported by ", ifelse(NrefM>1, "component base runs", "the single base run"), " for survey indices, age composition (AF), recruitment, and total (not all LL components reported here)") )
	xtab.cruns.ll.out = capture.output(print(xtab.cruns.ll,  include.rownames=TRUE,
		caption.placement="top", sanitize.rownames.function=function(x){x}, add.to.row =list(pos = list(-1), command = c("\\\\[-1.0ex]")) ) )
	rowhead = grep("^\\s&",xtab.cruns.ll.out)
	if (length(rowhead)>0)
		xtab.cruns.ll.out[rowhead[1]] =  paste0(c("LL value", grep("^\\s&",xtab.cruns.ll.out,value=T)[1]), collapse="")
	tput(xtab.cruns.ll.out)
#browser();return()

	## PJS wants to see parmeter comparisons among component runs (of course he does)
	## ----------------------------------------------------------
	## Calculate quantiles for later (eventually make this function global)
	calcQs = function (dat, ivec, ovec, qval=quants3) {
		F.data = as.data.frame(dat)
		F.list = split(F.data, ivec)
		rr.ord = match(ovec, substring(names(F.list),1,2))  ## order not so important for sensitivities
		F.list = F.list[rr.ord]
		F.qnts = lapply(F.list,function(x){
			z = apply(x,2,function(xx){!any(is.na(xx))})
			out = apply(x[z],2,quantile,qval)
			return(out)
		}) ## lapply does not sort like split does
		return(F.qnts)
	}
	P.qnts = calcQs(avgPA, ivec=P.run.rwt, ovec=P.run.ord)
	P.med  = lapply(P.qnts,function(x){apply(x,2,function(xx){c(xx[2],xx[1],xx[3])})})
	P.mpd.mcmc = as.list(rownames(ampdPA)); names(P.mpd.mcmc) = rownames(ampdPA)
	for (i in names(P.mpd.mcmc)){
		P.mpd.mcmc[[i]] = rbind(ampdPA[i,P.ord,drop=FALSE], P.med[[i]][,P.ord])
	}
	P.vals = lapply(lapply(P.mpd.mcmc,t),formatCatch)
	P.tabs = lapply(P.vals, function(mat){
		out = t(t(apply(mat, 1, function(x) {
			paste0(c("|", c(x[1], "| ", x[2], " (", x[3],",",x[4],")")), collapse="")
			#paste0(c(x[1], " , ", x[2], " (", x[3],",",x[4],")"), collapse="")
		})))
		return(out)
	})
	P.tab = array(NA,dim=rev(dim(ampdPA)), dimnames=list(names.pars,names(P.qnts)))
	for (i in names(P.tabs)){
		P.tab[,i] = P.tabs[[i]]
	}
	## Strip out fleet names in parentheses:
	i.fleet = grep("TRAWL|QCS|WCVI|NMFS|HS|WCHG|HBLL|GIG", rownames(P.tab))
	rownames(P.tab)[i.fleet] =  gsub("\\s*~\\(.*?\\)$","",rownames(P.tab)[i.fleet])
	rownames(P.tab) = paste(rep("$",nrow(P.tab)),  rownames(P.tab), rep("$",nrow(P.tab)), sep="")
	colnames(P.tab) = B.labs

	xtab.cruns.pars = xtable(P.tab, align=paste0("l", paste0(rep("c",dim(P.tab)[2]),collapse="")),
		label   = paste0("tab:",prefix,"runs.pars"), digits = if (exists("formatCatch")) NULL else sigdig,
		caption = paste0("Base run: model parameter MPDs (delimited by `|') and MCMC medians (with 0.05 and 0.95 quantile limits) for ",
		ifelse(NrefM>1, paste0("each of the \\numberstringnum{", NrefM, "} component model runs of \\Nmcmc{} samples each."),
		"the base model run of \\Nbase{} samples.") ) )
	xtab.cruns.pars.out = capture.output(print(xtab.cruns.pars,
		caption.placement="top", sanitize.rownames.function=function(x){x}, add.to.row =list(pos = list(-1), command = c("\\\\[-1.0ex]")) ) )
	tput(xtab.cruns.pars.out)

	## PJS ALSO wants to see comparisons among derived quantities for component runs (of course he does)
	## ----------------------------------------------------------
	Q.qnts = calcQs(B.mcmc, ivec=P.run.rwt, ovec=P.run.ord)
	Q.med  = lapply(Q.qnts,function(x){apply(x,2,function(xx){c(xx[2],xx[1],xx[3])})})

	#Q.mpd.mcmc = as.list(colnames(B.mcmc)); names(Q.mpd.mcmc) = colnames(B.mcmc)  ## have not collected MPD estimates of 
	#for (i in names(Q.mpd.mcmc)){
	#	Q.mpd.mcmc[[i]] = rbind(ampdPA[i,,drop=FALSE], Q.med[[i]])
	#}
	#Q.vals = lapply(lapply(Q.mpd.mcmc,t),formatCatch)
	Q.vals = lapply(lapply(Q.med,t), formatCatch, N=2)
	Q.tabs = lapply(Q.vals, function(mat){
		t(t(apply(mat, 1, function(x) {
			paste0(c(x[1], " (", x[2],",",x[3],")"), collapse="")
			#paste0(c("|", c(x[1], "| ", x[2], " (", x[3],",",x[4],")")), collapse="")
			#paste0(c(x[1], " , ", x[2], " (", x[3],",",x[4],")"), collapse="")
		})))
	})
	Q.tab = array(NA,dim=c(ncol(B.mcmc),NrefM), dimnames=list( dimnames(B.mcmc)[[2]],names(Q.qnts)))
	for (i in names(Q.tabs)){
		Q.tab[,i] = Q.tabs[[i]]
	}
	rownames(Q.tab) = names.msy
	i.fleet = grep("TRAWL|QCS|WCVI|NMFS|HS|WCHG|HBLL|GIG", rownames(Q.tab))
	if (length(i.fleet)>0)
		rownames(Q.tab)[i.fleet] =  gsub("\\s*~\\(.*?\\)$","",rownames(Q.tab)[i.fleet])
	rownames(Q.tab) = paste(rep("$",nrow(Q.tab)),  rownames(Q.tab), rep("$",nrow(Q.tab)), sep="")
	colnames(Q.tab) = B.labs

	xtab.cruns.rfpt = xtable(Q.tab, align=paste0("l", paste0(rep("r",dim(Q.tab)[2]),collapse="")),
		label   = paste0("tab:",prefix,"runs.rfpt"), digits = if (exists("formatCatch")) NULL else sigdig,
		caption = paste0("Base run: MCMC median (with 0.05 and 0.95 quantile limits) for derived model quantities for ",
		ifelse(NrefM>1, paste0("each of the \\numberstringnum{", NrefM, "} component model runs of \\Nmcmc{} samples each."),
		"the base model run of \\Nbase{} samples.") ) )
	xtab.cruns.rfpt.out = capture.output(print(xtab.cruns.rfpt,
		caption.placement="top", sanitize.rownames.function=function(x){x}, add.to.row=list(pos=list(-1,3,11), command=c("\\\\[-1.0ex]", "\\hdashline \n", "\\hdashline \n")), hline.after=c(-1,0,5,nrow(xtab.cruns.rfpt)) ) )
	tput(xtab.cruns.rfpt.out)
#browser();return()

	save("xtab.compo.pars.out", "xtab.compo.rfpt.out", "xtab.cruns.pars.out", "xtab.cruns.rfpt.out", "xtab.cruns.ll.out", file=paste0(prefix,"compo.tabs", ifelse(useRlow, paste0(".Rlow(q=",pad0(qRlow*100,2),")"),""), ".rda") )
#browser();return()
return()
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~tabSS.compo


## Activate for debugging only:
so("load.preview.r","synth")
tabSS.compo(istock="CAR", compo=compo)

