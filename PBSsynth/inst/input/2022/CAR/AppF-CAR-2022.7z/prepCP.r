## prepCP-------------------------------2022-06-30
##  Prepare Catch Policies -- 'CC'=constant catch, 'HR'=harvest rate (not implemented yet)
##  fyrs includes the current year (e.g., 2022=beginning of 2022, end of 2021), which is treated as a projection
##  Update for Canary Rockfish 2022
## ---------------------------------------------RH
prepCP = function(run.rwt, cp=list('1'=800), d.cp="CC", tag="", #tag=".nuts4K", 
	fyrs=2023:2033, season=1, fleet=1:2, ## will need to alter if more than one fleet
	d.base = "C:/Users/haighr/Files/GFish/PSARC22/CAR/Data/SS/CAR2022",
	w=NULL, cvpro=NULL)
{
	padded = pad0(run.rwt,2)
	t.run=padded[1]; t.rwt=padded[2]
	tar.run.rwt = paste(t.run,t.rwt,sep=".")
	d.target = file.path(d.base, paste0("Run", t.run), paste0("MCMC.",tar.run.rwt,tag))
	poop = function(){ setwd(d.target); gdump = gc(verbose=FALSE) }
	on.exit(poop())
	
	## Check for same number of catch policies by fleet
	n.pol = sort(unique(sapply(cp,length)))
	if (length(n.pol)>1) stop("Revise catch policy input list to have equal numbers by fleet")

	need.files = c("starter.ss","forecast.ss",paste0(c("control","data"),".",tar.run.rwt,".ss"), "ss.par","ss.cor","ss.psv", paste0("admodel.",c("hes","cov")))
	for (i in 1:n.pol) {
		ii = sapply(cp,function(x,npol){return(x[i])},npol=i)
		iii = pad0(i,2)
		#d.catch.policy = file.path(d.target, d.cp, pad0(i,4))
		d.policy.type = file.path(d.target, d.cp)
		if (!file.exists(d.policy.type))
			dir.create(d.policy.type)
		d.catch.policy = file.path(d.policy.type, paste0("CP",iii))
		if (!file.exists(d.catch.policy)){
			dir.create(d.catch.policy)
		} else {
			clearFiles( setdiff(list.files(d.catch.policy,full.names=T),list.dirs(d.catch.policy)) )  ## need full names and explicit exclusion of directories
		}
		pee = file.copy(from=file.path(d.target,need.files), to=d.catch.policy, copy.date=T, overwrite=T)
		
		## Modify forecast file to reflect new catch policies
		forecast = readLines(file.path(d.catch.policy,"forecast.ss"))
#browser();return()

		fline    = grep("#_fcast_nyrs",forecast)
		forecast[fline] = sub(substring(forecast[fline],1,(regexpr(" #_fcast_nyrs",forecast[fline])-1)), length(fyrs), forecast[fline])
		fline    = grep("#_ctl_rule_ul",forecast)
		forecast[fline] = sub(substring(forecast[fline],1,(regexpr(" #_ctl_rule_ul",forecast[fline])-1)), 0.002, forecast[fline])
		fline    = grep("#_ctl_rule_ll",forecast)
		forecast[fline] = sub(substring(forecast[fline],1,(regexpr(" #_ctl_rule_ll",forecast[fline])-1)), 0.001, forecast[fline])
#_ctl_rule_ul
		fline    = grep("#_fcast_yr1",forecast)
		forecast[fline] = sub(substring(forecast[fline],1,4), fyrs[2] + 100, forecast[fline])
		f1     = grep("#_Yr Seas Fleet Catch",forecast)
		f2     = grep("#_end_catpols",forecast)
		nyrs   = length(fyrs)
		nfleet = length(fleet)
		newpol = data.frame(Yr=rep(fyrs,nfleet), Seas=rep(season,nyrs*length(fleet)), Fleet=rep(fleet,each=nyrs), Catch=rep(ii,each=nyrs))
		foopol = apply(newpol,1,paste0,collapse=" ")
		forecast = c(forecast[1:f1], foopol, forecast[f2:length(forecast)])
		writeLines(forecast, con=file.path(d.catch.policy,"forecast.ss"))
#		};
#browser();return()
#	{
		.flush.cat(paste0("CP = ", i, " -- run mceval to generate catch policies.\n"))
		setwd(d.catch.policy)
		gdump = gc(verbose=FALSE)
		syssy = system("ss -mceval", intern=TRUE)
		writeLines(syssy,paste0("./sys", pad0(i,4), ".txt"))
	}
	.flush.cat("C'est toute, folks\n")
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~prepCP

so("clearFiles.r")
## Need to make cp a list to accommodate multiple fisheries
## PJS: Other use 3% of total: c(0, 250, 500, 750, 1000, 1250, 1500, 1750, 2000)
cp = list(
	'1'=c(0, 242.5, 485, 727.5, 970, 1212.5, 1455, 1697.5, 1940),
	'2'=c(0, 7.5, 15, 22.5, 30, 37.5, 45, 52.5, 60) )

#d.base = "C:/Users/haighr/Files/GFish/PSARC22/CAR/Data/SS/Testing"
d.base = "C:/Users/haighr/Files/GFish/PSARC22/CAR/Data/SS/CAR2022"
prepCP(run.rwt=c(24,1), cp=cp, fyrs=2023:2033, d.base=d.base)
#prepCP(run.rwt=c(xx,1), cp=cp, fyrs=2023:2033, d.base=d.base)


