## tabSS.senso--------------------------2022-11-18
## Make Sensitivity Tables
## Note: u2023=u2022 (see 'gatherMCMC.r') so change 
##       labels here in rfpt tables to use 'prevYear'
## ---------------------------------------------RH
tabSS.senso = function(istock="CAR", prefix="car.", senso, sigdig=4)
{
	on.exit(gc(verbose=FALSE))
	unpackList(stock[[istock]][["Controls"]])
	unpackList(senso)

	## Use same preliminary code from 'plotSS.senso'
	## ---------------------------------------------
	modYrs      = startYear:currYear
	modYrsChar  = as.character(modYrs)
	## Diagnostics for select parameters
	P.names     = colnames(senPA) ## parameter names
	S.mpd       = smpdPA; storage.mode(S.mpd)="double"     ## For some reason, this matrix is stored as a list (maybe due to NA values?)
	S.runs      = as.numeric(sapply(strsplit(rownames(senPA),"\\."),function(x){x[1]})) ## vector of Runs
	S.run.rwt   = sapply(strsplit(rownames(senPA),"\\."),function(x){paste0(x[1],".",x[2])}) ## vector of Runs and Rwts
	S.run.ord   = unique(S.runs)                           ## unique Run numbers (1st is central run)
	S.run.nmc   = table(S.runs)[as.character(S.run.ord)]   ## vector of sensitivity runs ordered
	S.run.num   = rep(1:length(S.run.nmc), S.run.nmc) - 1  ## 1st run is Central Run
	S.num       = unique(S.run.num)
	## Look into subsetting later
	use.run.rwt = unique(S.run.rwt)
	#is.element(P.runs, P.run.ord) ## default use all runs but a subset might be used for management advice
	if (spp.code %in% c("YMR"))
		P.ord=c(1,seq(2,10,2),seq(3,11,2),12,13)
	else
		P.ord = 1:ncol(smpdPA)

	## Create Sensitivity labels
	S.prefix    = paste0("S",pad0(S.num,2)," (R", pad0(S.run.ord,2) ,") ")
	iCR         = grep(exp.run.rwt,unique(B.index))
	S.prefix[1] = paste0("B",iCR, " (R", strsplit(exp.run.rwt,"\\.")[[1]][1], ") ")
	S.labels    = paste0(S.prefix, gsub("\\_"," ", c("Central Run",sen.lab)))
	S.labels    = sub("\\\\pc", "%", S.labels)  ## just in case

	## Calculate quantiles for later (eventually make this function global)
	calcQs = function (dat, ivec, ovec) {
		F.data = as.data.frame(dat)
		F.list = split(F.data, ivec)
		rr.ord = match(ovec, substring(names(F.list),1,2))  ## oder not so important for sensitivities
		F.list = F.list[rr.ord]
		F.qnts = lapply(F.list,function(x){
			z = apply(x,2,function(xx){!any(is.na(xx))})
			out = apply(x[z],2,quantile,quants5)
			return(out)
		}) ## lapply does not sort like split does
		return(F.qnts)
	}
	P.qnts = calcQs(senPA, ivec=S.run.rwt, ovec=S.run.ord)

	##----------Table 1-----------
	## MCMC model parameters table
	##----------------------------
	tabPmed = array(NA, dim=c(length(P.names),length(use.run.rwt)), dimnames=list(P.names,use.run.rwt))
	for (k in 1:length(use.run.rwt)){
		kk = use.run.rwt[k]
		qq = P.qnts[[kk]]
		ii = qq[grep("50%", rownames(qq)),]
		tabPmed[names(ii), kk] = ii
	}
	tabPmed = tabPmed[P.ord,]
	tab.sens.pars = formatCatch(tabPmed,N=sigdig)
	colnames(tab.sens.pars) = gsub(" +","",S.prefix)

	names.pars = rownames(tab.sens.pars)
	names.pars = sub("\\(([0-9]+)?\\)","_{\\1}", names.pars)
	names.pars = sub("Male","{2}",sub("Female","{1}",names.pars))
	names.pars = sub("var(L|R)?_\\{", "\\\\log~v_{\\\\text{\\1}",names.pars)
	names.pars = sub("^mu","\\\\mu",names.pars)
	names.pars = sub("^delta","\\\\Delta",names.pars)
	names.pars = sub("^beta","\\\\beta",names.pars)
	names.pars = sub("ln\\(DM_theta\\)_([0-9]+)?", "\\\\log~(\\\\text{DM}~\\\\theta)_{\\1}", names.pars)
	names.pars = sub("LN\\(R0\\)", "\\\\log R_0", names.pars)
	names.pars = sub("BH_h", "\\\\text{BH}~h", names.pars)
	names.pars = sub("_(TRAWL$|QCS$|WCVI$|NMFS$|HS$|WCHG$|HBLLN$|HBLLS$|GIG$)", "~(\\\\text{\\1})", names.pars)

	rownames(tab.sens.pars) =  paste(rep("$", nrow(tab.sens.pars)), names.pars,rep("$",nrow(tab.sens.pars)), sep="")

	pars1 = c(1:(grep("M2",rownames(tab.sens.pars))[1]-1),grep("theta",rownames(tab.sens.pars))[1:4])
	pars2 = setdiff(1:nrow(tab.sens.pars), pars1)
	tab.sens.pars2 = tab.sens.pars[pars2,]
	psub = !apply(tab.sens.pars2,2,function(x){all(x=="---")})
	tab.sens.pars2 = tab.sens.pars2[,psub]
	tab.sens.pars = tab.sens.pars[pars1,]

	sen.leg = paste0("Sensitivity runs: ", paste0("S", formatC(S.num[-1], width=0, format="d", flag="0"),"~= ", gsub("\\%","\\\\%",gsub("_"," ",sen.lab)), collapse=", "))
	if (spp.code=="REBS") {  ## need to add Other fishery because it has ages but no CPUE index
		nseries = length(iseries)
		iseries[nseries] = paste0(iseries[nseries],"/Trawl fishery")
		iseries = c(iseries, "Other fishery")
	}
	cap.par = paste0(
		name, ": median values of MCMC samples for the primary estimated parameters, ",
		"comparing the ", ifelse(NrefM>1,"central","base"), " run to ", Nsens, " sensitivity runs (\\Nmcmc{} samples each). R~= Run, S~= Sensitivity. ",
		"Numeric subscripts other than those for $R_0$ and $M$ indicate the following gear types $g$: ",
		texThatVec(paste0(c(1, match(iseries,fleets)[-1]),"~= ",iseries),simplify=F), ". ", sen.leg
	)
	xtab.sens.pars = xtable(tab.sens.pars, align=paste0("c",paste0(rep("r",Nsens+1),collapse="")),
		label   = paste0("tab:",prefix,"sens.pars"), digits = if (exists("formatCatch")) NULL else sigdig,
		caption = cap.par )
	xtab.sens.pars.out = capture.output( print(xtab.sens.pars, caption.placement="top",
		sanitize.rownames.function=function(x){x},
		add.to.row =list(pos = list(-1), command = c("\\\\[-1.0ex]")),
		size = "\\usefont{\\encodingdefault}{\\familydefault}{\\seriesdefault}{\\shapedefault}\\footnotesize"
	) )
	tput(xtab.sens.pars.out)

	## Collect the sensitivity stragglers
	if (spp.code %in% c("CAR")) {
		jsens   = c(1,9,10,11)
		jseries = c(1,3,4,6,7,9,10)
	}
	sen.leg2 = paste0("Sensitivity runs: ", paste0("S", formatC(jsens, width=0, format="d", flag="0"),"~= ", gsub("\\%","\\\\%",gsub("_"," ",sen.lab[jsens])), collapse=", "))
	cap.par2 = paste0(
		name, ": median values of MCMC samples for remaining estimated parameters for ",
		ncol(tab.sens.pars2), " sensitivity runs (\\Nmcmc{} samples each). R~= Run, S~= Sensitivity. ",
		"Numeric subscripts other than those for $M2$ indicate the following gear types $g$: ",
		texThatVec(paste0(jseries, "~= ", fleets[jseries]),simplify=F), ". ", sen.leg2
	)
	xtab.sens.pars2 = xtable(tab.sens.pars2, align=paste0("c",paste0(rep("r",ncol(tab.sens.pars2)),collapse="")),
		label   = paste0("tab:",prefix,"sens.pars2"), digits = if (exists("formatCatch")) NULL else sigdig,
		caption = cap.par2 )
	xtab.sens.pars2.out = capture.output( print(xtab.sens.pars2, caption.placement="top",
		sanitize.rownames.function=function(x){x},
		add.to.row =list(pos = list(-1), command = c("\\\\[-1.0ex]")),
		size = "\\usefont{\\encodingdefault}{\\familydefault}{\\seriesdefault}{\\shapedefault}\\footnotesize"
	) )
	tput(xtab.sens.pars2.out)

#browser();return()

	## MCMC MSY-based quantities
	## -------------------------
	ls2df = function(x) {
		nn = as.character(substitute(x))
		xx = as.data.frame(x)
		colnames(xx) = paste(nn,colnames(xx),sep="_")
		return(xx)
	}
	#D.qnts = calcQs(senTS[,,"BtB0"], ivec=S.run.rwt, ovec=S.run.ord)
	#U.qnts = calcQs(senTS[,,"ut"], ivec=S.run.rwt, ovec=S.run.ord)
	#R.qnts = calcQs(senTS[,,"Rt"], ivec=S.run.rwt, ovec=S.run.ord)
	#RD.qnts = calcQs(senTS[,,"Rtdev"], ivec=S.run.rwt, ovec=S.run.ord)

	Q.mcmc = data.frame (
		B0         = senRP[,"B0"],
		Bcurr      = senRP[,"Bcurr"],
		Bcurr.B0   = senRP[,"Bcurr"] / senRP[,"B0"],
		ucurr      = senRP[,"ucurr"],
		umax       = apply(senTS[,,"ut"],1,max), ## for each mcmc sample across the time series
		MSY        = senRP[,"MSY"],
		Bmsy       = senRP[,"Bmsy"],
		LRP        = senRP[,"LRP"],
		USR        = senRP[,"USR"],
		Bcurr.Bmsy = senRP[,"Bcurr"] / senRP[,"Bmsy"],
		Bmsy.B0    = senRP[,"Bmsy"] / senRP[,"B0"],
		umsy       = senRP[,"umsy"],
		ucurr.umsy = senRP[,"ucurr"] / senRP[,"umsy"]
	)
	Q.mcmc.sens = split(Q.mcmc, S.run.rwt)
	tabQmed = sapply(Q.mcmc.sens, function(Q){
		sapply(Q, median)
	})
	tab.sens.rfpt = formatCatch(tabQmed,N=sigdig-1)  ## use 3 instead of 4
	colnames(tab.sens.rfpt) = gsub(" +","",S.prefix)

	names.rfpt = rownames(tab.sens.rfpt)
	## Use routine from 'make.base.tabs.r':
	names.rfpt =
		gsub("\\.(B|u)", "/\\1",
		gsub("_Trawl", "~(\\\\text{trawl})",
		gsub("_Other", "~(\\\\text{other})",
		gsub("msy", "_\\\\text{MSY}",
		gsub("LRP",  paste0("0.4B_{\\\\text{MSY}}"),
		gsub("USR",  paste0("0.8B_{\\\\text{MSY}}"),
		gsub("MSY",  paste0("\\\\text{MSY}"),
		gsub("VB",  "V",
		gsub("[Uu]max", "u_\\\\text{max}",
		gsub("ucurr",  paste0("u_{",prevYear,"}"),
		gsub("Bcurr",  paste0("B_{",currYear,"}"),
		gsub("B0", "B_{0}",
		names.rfpt))))))))))))
	rownames(tab.sens.rfpt) =  paste(rep("$",nrow(tab.sens.rfpt)),names.rfpt,rep("$",nrow(tab.sens.rfpt)),sep="")
#browser();return()

	cap.rfpt = paste0(
		name, ": medians of MCMC-derived quantities from the ", ifelse(NrefM>1,"central","base"), " run and ", Nsens,
		" sensitivity runs (\\Nmcmc{} samples each) from their respective MCMC posteriors. Definitions are: ",
		"$B_0$ -- unfished equilibrium spawning biomass (mature females), ",
		#"$V_0$ -- unfished equilibrium vulnerable biomass (males and females), ",
		"$B_{", currYear, "}$ -- spawning biomass at the end of ",currYear, ", ",
		#"$V_{", currYear, "}$ -- vulnerable biomass in the middle of ", currYear, ", ",
		"$u_{", currYear, "}$ -- exploitation rate (ratio of total catch to vulnerable biomass) in the middle of ", currYear, ", ",
		"$u_\\text{max}$ -- maximum exploitation rate (calculated for each sample as the maximum exploitation rate from ",
		startYear , " - ", currYear, "), ",
		"MSY -- maximum sustainable yield at equilibrium, ",
		"$B_\\text{MSY}$ -- equilibrium spawning biomass at MSY, ",
		"$u_\\text{MSY}$ -- equilibrium exploitation rate at MSY. ",
		#"$V_\\text{MSY}$ -- equilibrium vulnerable biomass at MSY. ",
		"All biomass values (and MSY) are in tonnes. ", sen.leg
	)
#browser();return()

	xtab.sens.rfpt = xtable(tab.sens.rfpt, align=paste0("l",paste0(rep("r",Nsens+1),collapse="")),
		label   = paste0("tab:",prefix,"sens.rfpt"), digits = if (exists("formatCatch")) NULL else sigdig,
		caption = cap.rfpt )
	xtab.sens.rfpt.out = capture.output( print(xtab.sens.rfpt, caption.placement="top",
		sanitize.rownames.function=function(x){x},
		add.to.row=list(pos=list(-1,3,11), command=c("\\\\[-1.0ex]", "\\hdashline \\\\[-1.75ex]", "\\hdashline \\\\[-1.75ex]")),
		hline.after =  c(-1,0,5,nrow(xtab.sens.rfpt)),
		size = "\\usefont{\\encodingdefault}{\\familydefault}{\\seriesdefault}{\\shapedefault}\\footnotesize"
	) )
	tput(xtab.sens.rfpt.out)
#browser();return()

	## Sensitivity run likelihoods
	## ---------------------------
	tab.sens.ll = formatCatch(senLL,N=sigdig)
	names.ll = rownames(senLL)
	names.ll = sub("_BT|_SYN|_TRI|_HIS","",names.ll)
	names.ll = sub("_NOR","N",names.ll)
	names.ll = sub("_SOU","S",names.ll)
	names.ll = sub("^Run","Sen.Run",names.ll)
	rownames(tab.sens.ll) = names.ll
	LL.senso = t(tab.sens.ll)
	LL.senso[,"Sen.Run"] = sub("\\s+$", "", S.prefix)
	LL.senso = data.frame(Sen.Run=LL.senso[,"Sen.Run"], Label = c("base run", gsub("_"," ",sen.lab)), LL.senso[,-c(1:2)])
#browser();return()

	xtab.sruns.ll = xtable(LL.senso, align=paste0("l", paste0(rep("r",dim(LL.senso)[2]),collapse="")),
		label   = paste0("tab:",prefix,"log.likes"), digits=NULL, 
		caption = paste0("Log likelihood (LL) values reported by ", ifelse(NrefM>1,"central","base"), " and sensitivity runs for survey indices, age composition (AF), recruitment, and total (not all LL components reported here)") )
	xtab.sruns.ll.out = capture.output(print(xtab.sruns.ll,  include.rownames=FALSE,
		caption.placement="top", sanitize.rownames.function=function(x){x}, add.to.row =list(pos = list(-1,1), command = c("\\\\[-0.5ex]", "\\hdashline \\\\[-1.75ex]")) ) )
	tput(xtab.sruns.ll.out)

	save("xtab.sens.pars.out", "xtab.sens.pars2.out", "xtab.sens.rfpt.out", "xtab.sruns.ll.out", file=paste0(prefix,"senso.tabs.rda"))

	collect=c("tab.sens.pars","tab.sens.rfpt")
	for (i in collect) 
		eval(parse(text=paste0("stock[[istock]][[\"Sens\"]][[\"",i,"\"]] = ",i)))
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~tabSS.senso

## Activate for debugging only:
so("load.preview.r","synth")
tabSS.senso(senso=senso) #, prefix="RER.")
