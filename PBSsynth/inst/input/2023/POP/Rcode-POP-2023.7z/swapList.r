		## Swap areas and parameters in list
		## Adapted from https://stackoverflow.com/questions/26890615/rearrange-hierarchy-in-a-list-of-lists-in-r
		swapList = function(x) {
			i <- 1:length(x); ii = names(x)
			j <- 1:length(x[[1]]); jj = names(x[[1]])
			swap <- lapply(j, function(jj) lapply(i, function(ii) {x[[ii]][[jj]]}))
			names(swap) = jj
			for (jjj in jj)
				names(swap[[jjj]]) = ii
			return(swap)
		}
		areas = names(areaTS)
		areaPJ.swap = swapList(areaPJ)
		
