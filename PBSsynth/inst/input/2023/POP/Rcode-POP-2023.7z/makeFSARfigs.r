makeFSARfigs = function (xTS, xRP, xPJ, years=1935:2023, TAC,
   png=F, pngres=400, PIN=c(10,7), lang="e", 
   fig.p4=TRUE, fig.snail=FALSE, fig.catch=FALSE, fig.hbar=FALSE, fig.proj=FALSE)
{
	par.old = par(no.readonly=TRUE)
	on.exit(par(par.old))
	col.area = c("blue","darkgreen","red","black")
	bg.area  = c("cyan","green","pink","gainsboro")
	lty.area = rep(1,4) #c(2, 3, 5, 1)
	pch.area = c(22:24, 21)# c(15,18,17,16) #
	col.refs = c(.colBlind[c("redpurple","bluegreen","skyblue")]) ## LRP, USR, RR
	lty.refs = c(4,5,2)

	## Get catch time series from the base run
	replist = SS_output(dir=central.mpd.dir, verbose=F, printstats=F)
	repcats = split(replist$catch, replist$catch$Fleet)
	fleetcat = lapply(repcats, function(x){x[,c("Obs")]})
	catch    = do.call("cbind", lapply(fleetcat, data.frame, stringsAsFactors=FALSE))
	rownames(catch) = .su(replist$catch$Yr)
	colnames(catch) = .su(replist$catch$Area)
	nyrs   = length(years)
	Cscale = 1.; catch = round(catch/Cscale,3)
	if (!missing(TAC))
		TAC[,-1] = TAC[,-1]/Cscale

	## Default figures (for POP 2023) -- 4-panel
	## -----------------------------------------
	if (fig.p4) {
		for (a in 1:ncol(catch)) {
			aa = colnames(TAC)[-1][a]
			fout.e = paste0("FSAR.4panel.", aa)
			for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
				changeLangOpts(L=l)
				fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
				if (png) png(paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
				expandGraph(mfrow=c(2,2), mar=c(2.75,3.75,0.5,0.5), oma=c(0,0,0,0), mgp=c(1.75,0.5,0))
   	
				## Plot 1 : catch (top left)
				plot(0,0, xlim=range(years), ylim=c(0,max(catch[,a],na.rm=T)), xlab=linguaFranca("Year",l), ylab="", cex.axis=1.0, cex.lab=1.2, las=1)
				axis(1, at=seq(1935,2025,5), labels=F, tcl=-.3)
				mtext(linguaFranca(paste0("Catch (", ifelse(Cscale==1000,"k",""), "t)"),l), side=2, line=2.5, cex=1.1)
				za = is.element(rownames(catch), years)
				lines(years, catch[za,a], col=col.area[a], lwd=2)
				points(TAC$Year, TAC[,aa], pch="-", col="black", lwd=2)
				addLegend(0.95, 0.975, col=c(col.area[a],"black"), lty=c("solid","dashed"), legend=linguaFranca(c(paste0("Catch (", ifelse(Cscale==1000,"kilo",""), "tonnes)"), paste0("TAC (", ifelse(Cscale==1000,"kilo",""), "tonnes)")),l), bty="n", xjust=1, lwd=1.5, seg.len=3)
				addLabel(0.05, 0.95, "(A)", cex=1.5, col="black", adj=c(0,1))
				addLabel(0.05, 0.85, aa, cex=1.5, col=col.area[a], adj=c(0,1))
#browser();return()

#				## Plot 2 : biomass (top right)
#				yy = as.character(years)
#				Bscale = 1000.
#				B.qts   = apply(xTS[,yy,"B",aa],2, quantile, probs=ttcall(quants3), na.rm=T) / Bscale
#				BRP.qts = apply(xRP[,c("LRP","USR"),aa], 2, quantile, probs=ttcall(quants3), na.rm=T) / Bscale
#				plot(0,0, xlim=range(years), ylim=c(0,max(B.qts,na.rm=T)), xlab="Year", ylab="", cex.axis=1.0, cex.lab=1.2, las=1)
#				axis(1, at=seq(1935,2025,5), labels=F, tcl=-.3)
#				mtext(paste0("Female Spawning Biomass (", ifelse(Bscale==1000,"k",""), "t)"), side=2, line=2.2, cex=1.1)
#				polygon(c(years[c(1,nyrs)], years[c(nyrs,1)]), c(BRP.qts[c(1,1),"LRP"],BRP.qts[c(3,3),"LRP"]), col=lucent(col.refs[1],0.35), border=FALSE)
#				lines(years, rep(BRP.qts[2,"LRP"],length(years)), col="black", lwd=1, lty=4)
#				polygon(c(years[c(1,nyrs)], years[c(nyrs,1)]), c(BRP.qts[c(1,1),"USR"],BRP.qts[c(3,3),"USR"]), col=lucent(col.refs[2],0.35), border=FALSE)
#				lines(years, rep(BRP.qts[2,"USR"],length(years)), col="black", lwd=1, lty=5)
#				lines(years, B.qts[1,], col="gainsboro", lwd=1, lty=1) ## just to add a bit more emphasis
#				lines(years, B.qts[1,], col=col.area[a], lwd=1, lty=3)
#				lines(years, B.qts[3,], col="gainsboro", lwd=1, lty=1) ## just to add a bit more emphasis
#				lines(years, B.qts[3,], col=col.area[a], lwd=1, lty=3)
#				lines(years, B.qts[2,], col=col.area[a], lwd=2)
#				addLegend(0.95, 0.975, col=c(rep(col.area[a],2),rep("black",2)), lty=c(1,3,lty.refs[2:1]), legend=c("Median biomass","90% credibility envelope", "Median USR","Median LRP"), bty="n", xjust=1)
#				addLabel(0.05, 0.95, "(B)", cex=1.5, col="black", adj=c(0,1))

				## Plot 2 : biomass relative to Bmsy (top right)
				yy = as.character(years)
				B.qts   = apply(xTS[,yy,"BtBmsy",aa],2, quantile, probs=ttcall(quants3), na.rm=T) 
				plot(0,0, xlim=range(years), ylim=c(0,max(B.qts,na.rm=T)), xlab=linguaFranca("Year",l), ylab="", cex.axis=1.0, cex.lab=1.2, las=1)
				axis(1, at=seq(1935,2025,5), labels=F, tcl=-.3)
				mtext(linguaFranca(paste0("Spawning Biomass relative to BMSY"),l), side=2, line=2.3, cex=1.1)
				lines(years, rep(0.4,length(years)), col=col.refs[1], lwd=1.5, lty=4)
				lines(years, rep(0.8,length(years)), col=col.refs[2], lwd=1.5, lty=5)
				lines(years, B.qts[1,], col="gainsboro", lwd=1, lty=1) ## just to add a bit more emphasis
				lines(years, B.qts[1,], col=col.area[a], lwd=1, lty=3)
				lines(years, B.qts[3,], col="gainsboro", lwd=1, lty=1) ## just to add a bit more emphasis
				lines(years, B.qts[3,], col=col.area[a], lwd=1, lty=3)
				lines(years, B.qts[2,], col=col.area[a], lwd=2)
				addLegend(0.95, 0.975, col=c(rep(col.area[a],2),col.refs[2:1]), lty=c(1,3,lty.refs[2:1]), legend=linguaFranca(c("Median relative biomass","90% credibility envelope", "USR","LRP"),l), bty="n", xjust=1, lwd=1.5, seg.len=3)
				addLabel(0.05, 0.95, "(B)", cex=1.5, col="black", adj=c(0,1))
#browser();return()

				## Plot 3 : exploitation (bottom left)
				yy = as.character(years)
				u.qts   = apply(xTS[,yy,"u",aa],2, quantile, probs=ttcall(quants3), na.rm=T)
				URP.qts = apply(xRP[,c("Fmsy","umsy"),aa], 2, quantile, probs=ttcall(quants3), na.rm=T)
				plot(0,0, xlim=range(years), ylim=c(0,max(u.qts,na.rm=T)), xlab=linguaFranca("Year",l), ylab="", cex.axis=1.0, cex.lab=1.2, las=1)
				axis(1, at=seq(1935,2025,5), labels=F, tcl=-.3)
				mtext(linguaFranca("Exploitation rate (per year)",l), side=2, line=2.5, cex=1.1)
				## Credibility envelope seems way too broad
#				polygon(c(years[c(1,nyrs)], years[c(nyrs,1)]), c(URP.qts[c(1,1),"umsy"],URP.qts[c(3,3),"umsy"]), col=lucent(col.refs[3],0.35), border=FALSE)
#				lines(years, rep(URP.qts[2,"umsy"],length(years)), col="black", lwd=1, lty=lty.refs[3])
				lines(years, u.qts[1,], col="gainsboro", lwd=1, lty=1) ## just to add a bit more emphasis
				lines(years, u.qts[1,], col=col.area[a], lwd=1, lty=3)
				lines(years, u.qts[3,], col="gainsboro", lwd=1, lty=1) ## just to add a bit more emphasis
				lines(years, u.qts[3,], col=col.area[a], lwd=1, lty=3)
				lines(years, u.qts[2,], col=col.area[a], lwd=2)
				addLegend(0.95, 0.975, col=c(rep(col.area[a],2)), lty=c(1,3), legend=linguaFranca(c("Median exploitation","90% credibility envelope"),l), bty="n", xjust=1, lwd=1.5, seg.len=3)
				addLabel(0.05, 0.95, "(C)", cex=1.5, col="black", adj=c(0,1))
#browser();return()

				## Plot 4 : recruitment (bottom right)
				yy = as.character(years)
				Rscale = 1000.
				R.qts   = apply(xTS[,yy,"R",aa],2, quantile, probs=ttcall(quants3), na.rm=T) / Rscale
				plot(0,0, xlim=range(years), ylim=c(0,max(R.qts,na.rm=T)), xlab=linguaFranca("Year",l), ylab="", cex.axis=1.0, cex.lab=1.2, las=1)
				axis(1, at=seq(1935,2025,5), labels=F, tcl=-.3)
				mtext(linguaFranca(paste0("Recruitment (", ifelse(Rscale==1000,"millions","1000s"), " age-0 fish)"),l), side=2, line=2.3, cex=1.1)
				lines(years, R.qts[1,], col="gainsboro", lwd=1, lty=1) ## just to add a bit more emphasis
				lines(years, R.qts[1,], col=col.area[a], lwd=1, lty=3)
				lines(years, R.qts[3,], col="gainsboro", lwd=1, lty=1) ## just to add a bit more emphasis
				lines(years, R.qts[3,], col=col.area[a], lwd=1, lty=3)
				lines(years, R.qts[2,], col=col.area[a], lwd=2)
				addLegend(0.95, 0.975, col=c(rep(col.area[a],2)), lty=c(1,3), legend=linguaFranca(c("Median recruitment","90% credibility envelope"),l), bty="n", xjust=1, lwd=1.5, seg.len=3)
				addLabel(0.05, 0.95, "(D)", cex=1.5, col="black", adj=c(0,1))
				if (png) dev.off()
			}; eop()
#browser();return()
		}
	} ## end include 4 panel
#browser();return()

	## Stock status 4-panel plot for GMU
	## ---------------------------------
	if(fig.snail) {
		fout.e = paste0("FSAR.4GMU.subareas")
		for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
			changeLangOpts(L=l)
			fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
			if (png) png(paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
			expandGraph(mfrow=c(2,2), mar=c(2.75,3.75,0.5,0.5), oma=c(0,0,0,0), mgp=c(1.75,0.5,0))
	
			## Panel 1 -- stock status (taken from 'plotSS.compo.r')
			load("Bbase.for.FSAR.rda")
			subs = 1:length(Mnams)
			rm.cst = T
			if (rm.cst) {
				subs  = 2:4
				Bbase = lapply(Bbase,function(x){x[subs]})
			}
			out = compBmsy(Bspp=Bbase, spp=L1, boxwidth=0.4, medcol=col.area[subs-1], boxfill=boxfill[subs], boxlim=boxlim, whisklwd=2, staplelwd=3, Mnams=gsub("\\s+","\n",Mnams[subs]), figgy=list(win=TRUE), pngres=pngres, spplabs=F, t.yr=currYear, left.space=20, top.space=1, fout="base.subarea.status", calcRat=F, lang=l, add=T, cex.lab=0.8, rlty=c(4,2))
			addLabel(0.975, 0.975, "(A)", cex=1.5, col="black", adj=c(1,1)) 
	#browser();return()
	
			## Panel 2-4 -- phase plots for 5ABC, 3CD, 5DE
			yy = as.character(years)
			## Need to recreate object found in 'mcmc.quants.rda' from 'load_extra_mcmc.r")
			BtBmsy = apply(xTS[,yy,"BtBmsy",,drop=FALSE], c(2,4), quantile, probs=ttcall(quants5), na.rm=T)
			utumsy = apply(xTS[,yy,"utumsy",,drop=FALSE], c(2,4), quantile, probs=ttcall(quants5), na.rm=T)
			BtBmsy.qmcmc = utumsy.qmcmc = list()
			for (a in 1:dim(BtBmsy)[3]) {
				aa = dimnames(BtBmsy)$area[a]
				BtBmsy.qmcmc[[aa]] = BtBmsy[,,aa]
				utumsy.qmcmc[[aa]] = utumsy[,,aa]
			}
	#browser();return()
			for (i in 1:dim(BtBmsy)[3]) {
				#ii = switch(i, "5ABC", "3CD", "5DE")
				ii = dimnames(BtBmsy)$area[i]
				plotSnail(BtBmsy.qmcmc, utumsy.qmcmc, yrs=1935:2023, p=c(0.05,0.95), xLim=NULL, yLim=NULL, ngear=NULL, assYrs=assYrs, outs=F, Cnames=NULL, Lwd=2, ptypes="win", outnam=paste0("snail.",ii), lang=l, labYrs=c(1950,seq(1960,1975,5), assYrs), onepanel=F, subarea=i, add=T)
				addLabel(0.975, 0.975, paste0("(",LETTERS[i+1],")"), cex=1.5, col="black", adj=c(1,1))
			}
	#browser();return()
			if (png) dev.off()
		}; eop()
	}

	## Catch all in one for catch section (proposal)
	## ---------------------------------------------
	if (fig.catch) {
		catch$'4' = apply(catch,1,sum,na.rm=T)
		aa = c(colnames(TAC)[-1],"Coast")
		fout.e = "FSAR.Catch.All"
		for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
			changeLangOpts(L=l)
			fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
			if (png) png(paste0(fout,".png"), units="in", res=pngres, width=12, height=6)
			expandGraph(mfrow=c(1,1), mar=c(2.75,3.75,0.5,0.5), oma=c(0,0,0,0), mgp=c(1.75,0.5,0))
			plot(0,0, xlim=range(years), ylim=c(0,max(catch,na.rm=T)), xlab="Year", ylab="", cex.axis=1.0, cex.lab=1.2, las=1)
			axis(1, at=seq(1935,2025,5), labels=F, tcl=-.3)
			axis(2, at=seq(1,50,1), labels=F, tcl=-.2)
			mtext(paste0("Catch (", ifelse(Cscale==1000,"k",""), "t)"), side=2, line=2.2, cex=1.2)
			for (a in 1:ncol(catch)) {
				za = is.element(rownames(catch), years)
				lines(years, catch[za,a], col=col.area[a], lty=lty.area[a], lwd=2)
				points(years, catch[za,a], col=col.area[a], bg=bg.area[a], pch=pch.area[a], lwd=0.75, cex=0.8)
				#points(years, catch[za,a], col="gainsboro", bg=col.area[a], pch=pch.area[a], lwd=0.5, cex=0.9) #col.area[a]
				#points(years, catch[za,a], col="gainsboro", bg=bg.area[a], pch=pch.area[a], lwd=0.5, cex=1) #col.area[a]
				#points(years, catch[za,a], col=bg.area[a], pch=pch.area[a], lwd=0.5, cex=1) #col.area[a]
			}
			addLegend(0.95, 0.975, pch=pch.area, col=col.area, pt.bg=bg.area, lty=lty.area, legend=aa, bty="n", xjust=1, seg.len=3)
			if (png) dev.off()
		}; eop()
	}

	## Merged stock status for PJS
	## ---------------------------
	if (fig.hbar) {
		for (ss.type in c(1,2,3)[3]) {
			Mnams.all = character()
			## Load stock status choice
			if (ss.type %in% c(1,3)) {
				load("Bbase.for.FSAR.rda")
				Bss = Bbase
				Mnams.all = c(Mnams.all, Mnams)
			}
			## Splice together another stock status set
			if (ss.type %in% c(2,3)) {
				if (!"Bsens.for.PJS.rda" %in% list.files())
					stop("Need 'Bsens.for.PJS.rda' from AppF")
				load("Bsens.for.PJS.rda")
				Bss = Bsens
				Mnams.all = c(Mnams.all, Mnams)
			}
			if (ss.type %in% c(3)) {
				Bss = Bbase
				Bss[[1]] = c(Bss[[1]], Bsens[[1]])  ## merge
				boxfill  = rep(boxfill,2)
				medcol   = rep(medcol,2)
			}
			fout.e = paste0("PJS.SS.", switch(ss.type, "subareas", "single.areas", "both.areas"))
			for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
				changeLangOpts(L=l)
				fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
				if (png) png(paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
				expandGraph(mfrow=c(1,1), mar=c(3.5,6,0.5,0.5), oma=c(0,0,0,0), mgp=c(1.75,0.5,0))

				subs = 1:length(Mnams)
				rm.cst = T
				if (rm.cst) {
					subs  = grep("CST|Base",names(Bss[[1]]),invert=T)
					Bss = lapply(Bss, function(x){ x[subs] })
				}
#browser();return()
				Mnams = gsub("\\s+", "\n", sub("A[0-9]\\s+\\(R\\d+\\)\\ss+", "S", Mnams.all[subs]))
				out = compBmsy(Bspp=Bss, spp=L1, boxwidth=0.4, medcol=medcol[subs], boxfill=boxfill[subs], boxlim=c(0,6.25), whisklwd=2, staplelwd=3, Mnams=Mnams, figgy=list(win=TRUE), pngres=pngres, spplabs=F, t.yr=currYear, left.space=20, top.space=1, fout="stock.status", calcRat=F, lang=l, add=T, cex.axis=1.2, cex.lab=1.5, rlty=c(4,2))
				#addLabel(0.975, 0.975, "(A)", cex=1.5, col="black", adj=c(1,1)) 
				if (png) dev.off()
			}; eop()
#browser();return()
		}
	}

	## Spawning biomass with projections
	## --------------------
	if (fig.proj) {
		tsfld   = "BtBmsy" #"B"  ## BtBmsy for TSC report 2023
		is.biomass = tsfld %in% c("B","V")
		catpol3 = c("CC.01","CC.03","CC.07")  ## POP 2023
		cpcol   = c("green3","orange","red")
		yr.proj = dimnames(xPJ)$year
		yr.late = 2015:2023
		yr.main = setdiff(dimnames(xTS)$year, c(yr.late, yr.proj)) 
		## Adjust periods by adding a year for connection in plots
		yr.main = c(yr.main, yr.late[1])
		yr.late = c(yr.late, yr.proj[1])
#browser();return()
		Bscale = ifelse (is.biomass, 1000., 1.)
		Qmain   = apply(xTS[,yr.main,tsfld,], c("year","area"), quantile, probs=ttcall(quants3), na.rm=T) / Bscale
		Qlate   = apply(xTS[,yr.late,tsfld,], c("year","area"), quantile, probs=ttcall(quants3), na.rm=T) / Bscale
		Qproj   = apply(xPJ[,yr.proj,tsfld,,catpol3], c("year","area","proj"), quantile, probs=ttcall(quants3), na.rm=T) / Bscale
		#BRP.qts = apply(xRP[,c("LRP","USR"),], c("area"), quantile, probs=ttcall(quants3), na.rm=T) / Bscale   ## LRP|USR not used
		areas   = dimnames(Qmain)$area
		narea   = length(areas)
		myrs    = as.numeric(yr.main)
		pyrs    = as.numeric(yr.proj)
		ayrs    = .su(c(myrs,pyrs))
		nyrs    = length(ayrs)
		## ----------------------------
		## Subroutine to plot envelopes
		## ----------------------------
		addEnvelope = function(mat,ecol) {
			xx   = rownames(mat)
			yy   = colnames(mat)
			yrs  = as.numeric(yy)
			nyrs = length(yrs)
#browser();return()
			polygon(c(yrs,rev(yrs)), c(mat["5%",yy],rev(mat["95%",yy])), col=ifelse(ecol=="black","ghostwhite",lucent(ecol,0.10)), border=FALSE)
			lines(yrs, mat["5%",yy], col="gainsboro", lwd=1, lty=1) ## just to add a bit more emphasis
			lines(yrs, mat["5%",yy], col=ecol, lwd=1, lty=3)
			lines(yrs, mat["95%",yy], col="gainsboro", lwd=1, lty=1) ## just to add a bit more emphasis
			lines(yrs, mat["95%",yy], col=ecol, lwd=1, lty=3)
			lines(yrs, mat["50%",yy], col=ecol, lwd=2)
		}
		fout.e = paste0("FSAR.", tsfld, ".proj.subarea")
		if (diff(PIN)<0)      { orient="landscape"; rc=c(1,narea) }
		else if(diff(PIN)>=0) { orient="portrait" ; rc=c(narea,1) }
		fout.e = paste0(fout.e, ".", orient)
		for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
			changeLangOpts(L=l)
			fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
			if (png) png(paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
			expandGraph(mfrow=rc, mar=c(2.75,3.75,0.5,0.5), oma=c(0,0,0,0), mgp=c(1.75,0.5,0))

			for (a in 1:narea) {
				aa = areas[a]
				plot(0,0, xlim=range(ayrs), ylim=c(0,max(Qmain[,,aa],na.rm=T)), xlab=linguaFranca("Year",l), ylab="", cex.axis=1.2, cex.lab=1.5, las=1)
				axis(1, at=seq(1935,max(years),5), labels=F, tcl=-.3)
				if ((orient=="portrait" && a==2) || (orient=="landscape")){
					if (is.biomass)
						mtext(linguaFranca(paste0("Spawning Biomass (", ifelse(Bscale==1000,"k",""), "t)"), l), side=2, line=2.2, cex=1.1)
					else {
						ylab = "Spawning Biomass italic(B)[italic(t)] relative to italic(B)[MSY]"
						ylab = linguaFranca(ylab,l)
						mtext(eval(parse(text=paste0("expression(",gsub(" ","~",ylab),")"))), side=2, line=1.75, cex=1.1)
					}
				}
				## Skip LRP|USR envelopes
				#polygon(c(years[c(1,nyrs)], years[c(nyrs,1)]), c(BRP.qts[c(1,1),"LRP"],BRP.qts[c(3,3),"LRP"]), col=lucent(col.refs[1],0.35), border=FALSE)
				#lines(years, rep(BRP.qts[2,"LRP"],length(years)), col="black", lwd=1, lty=4)
				#polygon(c(years[c(1,nyrs)], years[c(nyrs,1)]), c(BRP.qts[c(1,1),"USR"],BRP.qts[c(3,3),"USR"]), col=lucent(col.refs[2],0.35), border=FALSE)
				#lines(years, rep(BRP.qts[2,"USR"],length(years)), col="black", lwd=1, lty=5)
				addEnvelope(Qmain[,,aa], ecol="black")
				addEnvelope(Qlate[,,aa], ecol="black")
				cp = numeric()
				for (p in 1:length(catpol3)) {
					pp = catpol3[p]
					cp = c(cp, xavgCP[,aa,pp][1])
					addEnvelope(Qproj[,,aa,pp], ecol=cpcol[p])
				}
				## Add reference points if appropriate
				if (tsfld %in% "BtBmsy")
					abline(h=c(0.4,0.8), lty=c(4,5), col=.colBlind[c("redpurple","bluegreen")])
				cpleg = paste0(cp," t")
				#if (a==1)
					#addLegend(0.01, ifelse(orient=="portrait",0.975,0.2), col=c("black","blue"), lty=1, lwd=2, legend=paste0(c("Main","Late")," recruitment"), title=linguaFranca("Reconstruction",l), bty="n", xjust=0, cex=1.1)
				addLegend(0.75, 0.975, col=cpcol, lty=1, lwd=2, legend=cpleg, title=linguaFranca("Projected catch",l), bty="n", xjust=1, cex=1.2)
				addLabel(0.95, 0.95, aa, cex=1.5, col=col.area[a], adj=c(1,1))
			}
#browser();return()
			if (png) dev.off()
		}; eop()
#browser();return()
	} ## end fig.proj


}
require(r4ss)
so("load.preview.r","synth")
so("plotSnail.r","tools")
so("compBmsy.r","tools")
so("linguaFranca.r","tools")
## POP 2023
TAC.POP = data.frame(
	Year  = c(1979, 1980, 1981, 1982, 1983, 1984, 1985, 1986, 1987, 1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023),
	'5ABC'= c(2000, 2200, 3300, 3000, 3000, 2800, 2850, 2500, 2500, 3700, 3850, 3300, 3000, 3250, 3250, 3284, 3070, 5503, 5176, 4887, 4887, 4888, 4888, 4588, 4888, 4888, 4888, 4188, 4188, 4188, 4188, 4188, 3929, 3670, 3219, 3231, 3231, 3231, 3231, 3231, 3231, 3242, 3242, 3242, 3242),
	'3CD' = c(50, 600, 500, 750, 750, 750, 650, 450, 450, 450, 550, 550, 400, 400, 550, 1380, 620, 655, 661, 530, 530, 530, 530, 530, 530, 530, 530, 530, 530, 530, 530, 530, 530, 530, 750, 750, 750, 750, 750, 750, 750, 750, 750, 750, 750),
	'5DE' = c(600, 800, 800, 800, 0, 0, 0, 0, 0, 0, 400, 400, 400, 400, 400, 253, 544, 726, 644, 730, 730, 730, 730, 730, 730, 730, 730, 730, 730, 730, 730, 730, 730, 730, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200),
	check.names=FALSE, fix.empty.names=FALSE)
#makeFSARfigs(xTS=xavgTS, xRP=xavgRP, TAC=TAC.POP, PIN=c(10,8), png=T, lang=c("f","e"))
#makeFSARfigs(xTS=xavgTS, xRP=xavgRP, TAC=TAC.POP, PIN=c(8,6), png=F, lang=c("e"), fig.p4=F, fig.hbar=T)  ## PJS figure merges bars from subareas and single-area models
#makeFSARfigs(xTS=xavgTS, xRP=xavgRP, xPJ=xavgPJ, PIN=c(6,8), png=T, lang=c("e"), fig.p4=F, fig.proj=T)  ## Projection figures for GMU (portrait)
#makeFSARfigs(xTS=xavgTS, xRP=xavgRP, xPJ=xavgPJ, PIN=c(10,4), png=T, lang=c("e"), fig.p4=F, fig.proj=T)  ## Projection figures for GMU (landscape)
makeFSARfigs(xTS=xavgTS, xRP=xavgRP, xPJ=xavgPJ, PIN=c(10,4), png=T, lang=c("e"), fig.p4=F, fig.proj=T, years=1935:2035)  ## Projection figures for TSC 2023

