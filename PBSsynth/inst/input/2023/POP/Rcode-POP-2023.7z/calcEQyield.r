## calcEQyield--------------------------2023-04-04
##  Ian Taylor's suggestion for MSY by area (230404)
##  Works for MPD but not MCMC samples because 
##    'equil_yield' table missing from sample replists.
##  Conversation with PJS 230413: use proportions from
##    area-specific B0 to allocate MSY, etc.
## ------------------------------------------IT|RH
calcEQyield = function(replist, areas=c("5ABC","3CD","5DE"))
{
	equil_yield = replist$equil_yield
	parameters  = replist$parameters

	## Exclude SPRloop number 3 as it has different fleet allocations
	EQY_table   = equil_yield[!is.element(equil_yield$SPRloop,3),]
	msy.idx     = which.max(EQY_table$Tot_Catch)
	MSY_area    = EQY_table[msy.idx, grep("Dead",colnames(EQY_table))]
	MSY_prop    = MSY_area / sum(MSY_area)

	Rdist  = parameters$Value[grep("^RecrDist.+month_1$",parameters$Label)]
	Rdexp  = exp(Rdist)
	Rprop  = Rdexp / sum(Rdexp)

	Rdevnam = grep("^RecrDist.+DEVadd",parameters$Label,value=T)
	yrs     = as.numeric(substring(Rdevnam,nchar(Rdevnam)-3,nchar(Rdevnam)))
	ayrs    = split(yrs, cumsum(c(1, diff(yrs) != 1)))
	uyrs    = .su(yrs)
	Rdevadd = array(0, dim=c(length(uyrs),length(areas)), dimnames=list(year=uyrs,area=areas))
	Rdevval = parameters$Value[grep("^RecrDist.+DEVadd",parameters$Label)]
	names(Rdevval) = yrs
	Adevval = split(Rdevval, cumsum(c(1, diff(yrs) != 1)))
	for (i in 1:length(Adevval)) {
		ival = Adevval[[i]]
		Rdevadd[names(ival),i] = ival
	}
	Rdevse   = c(parameters$Value[grep("^RecrDist.+dev_se$",parameters$Label)], 1)
	Rdevadj  = sweep(Rdevadd,2,Rdevse,"*")
	Rdistyr  = sweep(Rdevadj,2,Rdist,"+")
	Rdexpyr  = exp(Rdistyr)
	Rpropyr  = t(apply(Rdexpyr,1,function(x){x/sum(x)}))
#browser();return()
	return(EQY_area)
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~calcEQyield

calcEQyield(replist)

##      TRAWL_FISHERY_5ABC(1)Dead TRAWL_FISHERY_3CD(2)Dead TRAWL_FISHERY_5DE(3)Dead
## MSY multi-area         3394.15                  700.107                  1420.13
## MSY single-area        3343.4                   751.771                  1657.78

