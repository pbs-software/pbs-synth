## plt.ageResids------------------------2020-11-04
## AME changing for POP, just plotting age class resids here,
## not qq-plot. Moving that to new function (so can do 4 on page).
## See popScape.r for original.
## -----------------------------------------AME|RH
plt.ageResids <- function( obj, ages=NULL, main=NULL, lang="e", yrs, ...)
{
	## par( oma=c(2,1,1,1), mar=c(2,2,2,1), mfrow=c(2,1) )
	## Subset to required ages.
	if (!is.null(ages))
		obj <- obj[ (obj$Bin >= ages[1]) & (obj$Bin <=ages[2]), ]
	else
		ages = range(obj$Bin)
	if( max(diff(sort(unique(obj$Bin)))) > 1) {
		allAges=min(obj$Bin):max(obj$Bin)
		nodataAges=allAges[ !(allAges %in% obj$Bin)]
		xx=split(c(obj$Pearson, rep(NA, length(nodataAges))), c(obj$Bin, nodataAges))
		#xpos <- boxplot( xx, whisklty=1, xlab="", ylab="", outline=FALSE )     #AME outline=FALSE removes outliers
		xpos = quantBox(xx, xaxt="n", yaxt="n", xlab="", ylab="", pars=tcall(boxpars))
		xage = setdiff(allAges, nodataAges)
		if (length(xage)>20)
			xage = sort(unique(ceiling(xage/5)*5))
		axis(1, at=match(xage,as.numeric(xpos$names)), labels=xage, ..., mgp=c(2,0.5,0))
	} else {
		#xpos <- boxplot( split( obj$Pearson, obj$Bin ), whisklty=1, xlab="", ylab="", outline=FALSE )     #AME outline=FALSE removes outliers
		xpos = quantBox(split(obj$Pearson,obj$Bin), xaxt="n", yaxt="n", xlab="", ylab="", pars=tcall(boxpars))
		xage = sort(unique(ceiling(obj$Bin/5)*5))
		axis(1, at=match(xage,as.numeric(xpos$names)), labels=xage, ..., mgp=c(2,0.5,0))
	}
	abline( h=0, lty=2, col="red" )
	axis(2, ...)
	mtext( side=1, line=2, ..., text=linguaFranca("Age class",lang) )
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~plt.ageResids
