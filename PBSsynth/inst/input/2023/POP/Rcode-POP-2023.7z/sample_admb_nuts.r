## sample_admb_nuts---------------------2021-07-06
##  Sample ADMB using NUTS (No U-Turn Sampling) algorithm
## --------------------------------------adnuts|RH
sample_admb_nuts = function (path, model, iter=2000, init=NULL, chain=1, thin=1, 
   warmup=ceiling(iter/2), seed=NULL, duration=NULL, control=NULL, 
   skip_optimization=TRUE, verbose=TRUE, admb_args=NULL, parallel=FALSE) 
{
	wd.old <- getwd()
	on.exit(setwd(wd.old))
	setwd(path)
	control <- adnuts:::.update_control(control)
	eps <- control$stepsize
	stopifnot(iter >= 1)
	stopifnot(warmup <= iter)
	stopifnot(duration > 0)
	stopifnot(thin >= 1)
	if (is.null(warmup)) 
		stop("Must provide warmup")
	if (thin < 1 | thin > iter) 
		stop("Thin must be >1 and < iter")
	max_td <- control$max_treedepth
	adapt_delta <- control$adapt_delta
	model2 <- adnuts:::.update_model(model)
	if (skip_optimization) {
		cmd <- paste(model2, "-nox -nohess -maxfn 0 -phase 1000 -nuts -mcmc ", iter)
	}
	else {
		cmd <- paste(model2, "-hbf -nuts -mcmc ", iter)
	}
	cmd <- paste(cmd, "-warmup", warmup, "-chain", chain)
	if (!is.null(seed)) 
		cmd <- paste(cmd, "-mcseed", seed)
	if (!is.null(duration)) 
		cmd <- paste(cmd, "-duration", duration)
	cmd <- paste(cmd, "-max_treedepth", max_td, "-adapt_delta", adapt_delta)
	if (!is.null(eps)) 
		cmd <- paste(cmd, "-hyeps", eps)
	if (!is.null(control$adapt_init_buffer)) 
		cmd <- paste(cmd, "-adapt_init_buffer", control$adapt_init_buffer)
	if (!is.null(control$adapt_term_buffer)) 
		cmd <- paste(cmd, "-adapt_term_buffer", control$adapt_term_buffer)
	if (!is.null(control$adapt_window)) 
		cmd <- paste(cmd, "-adapt_window", control$adapt_window)
	if (!is.null(control$refresh)) 
		cmd <- paste(cmd, "-refresh", control$refresh)
	if (control$adapt_mass) 
		cmd <- paste(cmd, "-adapt_mass")
	if (control$adapt_mass_dense) 
		cmd <- paste(cmd, "-adapt_mass_dense")
	metric <- control$metric
	stopifnot(!is.null(metric))
	if (is.matrix(metric)) {
		if (!requireNamespace("matrixcalc", quietly = TRUE)) 
			stop("Package 'matrixcalc' is required to pass a matrix.\n Install it and try again.")
		cor.user <- metric/sqrt(diag(metric) %o% diag(metric))
		if (!matrixcalc::is.positive.definite(x = cor.user)) 
			stop("Invalid mass matrix passed: it is not positive definite.\n Check 'metric' argument or use different option.")
		adnuts:::.write.admb.cov(metric, hbf = 1)
		warning("admodel.cov overwritten, revert admodel_original.cov if needed")
	}
	else if (is.character(metric) && metric == "unit") {
		cmd <- paste(cmd, "-mcdiag")
	}
	else if (is.character(metric) && metric == "mle") {
	}
	else {
		stop("Invalid metric option")
	}
	if (!is.null(init)) {
		cmd <- paste(cmd, "-mcpin init.pin")
		write.table(file = "init.pin", x = unlist(init), row.names = F, col.names = F)
	}
	else {
	}
	if (!is.null(admb_args)) 
		cmd <- paste(cmd, admb_args)
	model2 <- adnuts:::.update_model(model)
	console <- adnuts:::.check_console_printing(parallel)
	progress <- NULL
#browser();return()
	if (console) {
		time <- system.time(system2(model2, cmd, stdout = ifelse(verbose, "", FALSE)))[3]
	}
	else {
		fn <- "mcmc_progress.txt"
		if (file.exists(fn)) 
			file.remove(fn)
		time <- system.time(system2(model2, cmd, stdout = ifelse(verbose, fn, FALSE)))[3]
		if (file.exists(fn)) {
			progress <- readLines("mcmc_progress.txt")
		}
		else {
			warning("Progress output file not found. Try troubleshooting in serial model")
		}
	}
	if (!file.exists("adaptation.csv") | !file.exists("unbounded.csv")) 
		stop(paste0("NUTS failed to run. Command attempted was:\n", cmd))
	sampler_params <- as.matrix(read.csv("adaptation.csv"))
	unbounded <- as.matrix(read.csv("unbounded.csv", header = FALSE))
	dimnames(unbounded) <- NULL
	pars <- adnuts:::.get_psv(model)
	par.names <- names(pars)
	if (!"lp__" %in% dimnames(sampler_params)[[2]]) {
		pars[, "log-posterior"] <- sampler_params[, "energy__"]
	}
	else {
		pars[, "log-posterior"] <- sampler_params[, "lp__"]
		sampler_params <- sampler_params[, -7]
	}
	pars <- as.matrix(pars)
	pars <- pars[seq(1, nrow(pars), by = thin), ]
	unbounded <- unbounded[seq(1, nrow(unbounded), by = thin), ]
	sampler_params <- sampler_params[seq(1, nrow(sampler_params), by = thin), ]
	time.total <- time
	time.warmup <- NA
	warmup <- warmup/thin
	gdump = gc(verbose=FALSE)
	return(list(samples = pars, sampler_params = sampler_params, 
		time.total = time.total, time.warmup = time.warmup, warmup = warmup, 
		max_treedepth = max_td, model = model, par.names = par.names, 
		cmd = cmd, unbounded = unbounded, progress = progress))
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sample_admb_nuts
