## doRetros-----------------------------2023-09-21
##  Basically a wrapper for the r4ss' function 'retro'.
## ---------------------------------------------RH
doRetros = function(strSpp="396", assyr=2023, stock="5ABC", newsubdir="retros")
{
	if (strSpp %in% c("437","CAR") && assyr %in% c(2022)){
		basedir = "C:/Users/haighr/Files/GFish/PSARC/PSARC_2020s/PSARC22/CAR/Data/SS/CAR2022"
		years=0:-10; run=24; rwt=1
	}
	if (strSpp %in% c("396","POP") && assyr %in% c(2023)){
		basedir = "C:/Users/haighr/Files/GFish/PSARC23/POP/Data/SS/POP2023"
		switch(stock,
			'5ABC' = { years=0:-13;  run=24; rwt=1; ver="1"},  ## go back to 2010 for all areas
			'3CD'  = { years=0:-13; run=25; rwt=1; ver="1" },
			'5DE'  = { years=0:-13; run=26; rwt=1; ver="1" }
		)
	}
	## Generic for all species
	mpddir = paste0(basedir, "/Run", pad0(run,2), "/MPD.", pad0(run,2), ".", pad0(rwt,2), ".v", ver )
	retdir = paste0(basedir, "/Run", pad0(run,2), "/Retro.", pad0(run,2), ".", pad0(rwt,2), ".v", ver )
	if (!dir.exists(retdir)) 
		dir.create(retdir)
	## Grab the input files:
	inputs = list.files(mpddir, pattern="(^control|^data|^forecast|^starter).*\\.ss$")
	file.copy(from=paste0(mpddir,"/",inputs), to=retdir, overwrite=T, copy.date=T)
#browser();return()
	retro(dir=retdir, years=years, newsubdir=newsubdir)
	retroModels = SSgetoutput( dirvec=file.path(retdir, newsubdir, paste("retro",years,sep="") ) )
	save("retroModels","strSpp","assyr","stock","years","run","rwt","retdir", file=paste0(retdir,"/retroModels.rda"))
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~doRetros

require(r4ss)
#doRetros(strSpp="396", assyr=2023, stock="5ABC")
#doRetros(strSpp="396", assyr=2023, stock="3CD")
doRetros(strSpp="396", assyr=2023, stock="5DE")
## Run 'plotSS.comparisons' to plot results


