##==========================================================
## PBS Stock Synthesis engine functions:
## ---------------------------------------
## runADnuts.............Based on Chris Grandis' R code to manually run adnuts
## runSS.................Run Stock Synthesis code using ADMB
## readSS................Read the ADMB input file and create an SS class object
## setMethod.view........Set the method for 'view' when using an SS class.
## setMethod.fix.........Set the method for 'fix' when using an SS class.
## setMethod.write.......Set the method for 'write' when using an SS class.
## setMethod.reweight....Set the method for 'reweight' when using an SS class.
##==========================================================

setClass ("SSdata", 
   representation( ssfiles="list", cordat="list", evadat="list", pardat="list", stddat="list", reweight="list") )
   #, resdat="list" , likdat="list", pardat="list", stddat="list",
   #  cordat="list", evadat="list", reweight="list", controls="list") )


## runADnuts----------------------------2020-11-11
##  Based on Chris Grandis' R code that was used to manually run adnuts.
##  adnuts needs serious path intervention (RH 201021)
## ------------------------------------------CG|RH
runADnuts=function(path=getwd(), stock="BSR", model="base", 
   rda_name, add2rda=FALSE, tag="REBSN", 
   parallel=TRUE, cores=6, syscall=rep(TRUE,5),
   iters=list(test=15,pilot=100,mle=500,update=1000),
   ssexe="ss", ssdir=getwd(), ssfiles=c("control.ss","data.ss"),
   stupid_shiny=FALSE)
{
	## Check to see if file exists and keep a copy if it does before removing it.
	sweep.files = function(x) {
		rubbish = 0
		for (i in x) {
			if (file.exists(i)) {
				fstamp = paste0(sub("[[:space:]]","(",gsub("[[:punct:]]","",substring(file.info(i)$ctime,3,16))),")")
				ext    = tools::file_ext(i)
				pre    = gsub(paste0("\\.",ext,"$"),"",i)
				backup = paste0(pre,"-",fstamp,".",ext)
				if (!file.exists(backup))
					file.copy(from=i, to=backup, overwrite=FALSE, copy.date=TRUE)
				file.remove(i)
				rubbish = rubbish +1
			}
		}
		invisible(paste0(rubbish, " files removed"))
	}

	start_time <- Sys.time()
	cwd <- getwd()
	on.exit(setwd(cwd))
	setwd(path); path=getwd(); setwd(cwd)  ## Just in case a relative path is specified
	
	d.stock  = file.path(path, stock)
	d.model  = file.path(d.stock, "models", model)
	d.mpd    = file.path(d.model, "mpd")
	d.mcmc   = file.path(d.model, "mcmc")
	if(missing(rda_name))
		rda_name = paste0(stock,".",model,".rda")
	rda_file = file.path(d.stock, rda_name)  ## store rda files in the stock directory
#browser();return()
	## Create subdirectories if needed
	if (!file.exists(d.stock)) 
		dir.create(d.stock)
	if (!file.exists(d.model)) 
		dir.create(d.model)
	if (!file.exists(d.mpd)) 
		dir.create(d.mpd)
	if (!file.exists(d.mcmc)) 
		dir.create(d.mcmc)
	ssfiles = unique(c("starter.ss","forecast.ss",ssfiles))
	if ( all(file.exists(paste0(ssdir,"/",ssfiles)))) {
		file.copy(from=paste0(ssdir,"/",ssfiles), to=paste0(d.model,"/",ssfiles), overwrite=TRUE, copy.date=TRUE)
		file.copy(from=paste0(ssdir,"/",ssfiles), to=paste0(d.mpd,"/",ssfiles),   overwrite=TRUE, copy.date=TRUE)
		file.copy(from=paste0(ssdir,"/",ssfiles), to=paste0(d.mcmc,"/",ssfiles),  overwrite=TRUE, copy.date=TRUE)
	} else
		stop("SS files: '", paste0(ssfiles,collapse="', '"),"'\n\tnot found in ", ssdir)

	setwd(d.mpd)

	## ----------------------------------------------------------------
	if (syscall[1]) {
		## This step is needed to create files like 'covar.sso' and 'ss_summary.sso'
		.flush.cat("Running MPD for best fits...\n")
		toast = setdiff(list.files("."),c(ssfiles))
		if (length(toast)>0)
			file.remove(toast)
		system(paste0(ssexe))
	}
	replist = SS_output(dir=d.mpd, verbose=FALSE)
	ttput(replist)
	vals.save = c("replist")

#browser();return()

	setwd(d.model)

	## Chains to run in parallel
	reps  <- min(cores, parallel::detectCores() - 1)
	set.seed(352)
	seeds <- sample(1:1e4, size = reps)
	sweep.files(rda_file)
#browser();return()

	## ----------------------------------------------------------------
	if (syscall[2]) {
		## This step is needed before syscall 3
		.flush.cat("Running precursor mcmc test...\n")
		sweep.files("ss.psv")
		system(paste0(ssexe, " -nox -iprint 200 -mcmc ", iters$test))
	}

	## Then run parallel RWM chains as a first test to ensure
	## mcmc itself is working properly, or that model is converging in mcmc space
	thin   <- 10
	iter   <- iters$pilot * thin ## iter is per core !!!
	#warmup <- ceiling(iter/4)
	warmup <- ceiling(0.25*iter)
	inits  <- NULL               ## start chains from MLE
	vals.save = c(vals.save,c("seeds"))
#browser();return()

	## ----------------------------------------------------------------
	if (syscall[3]){
		.flush.cat("Running pilot RWM chains...\n")
		pilot  <- sample_admb(model=ssexe, path=d.model, iter=iter, init=inits, chains=reps, warmup=warmup, seeds=seeds, thin=thin, mceval=FALSE, duration=NULL, parallel=parallel, cores=reps, control=NULL, algorithm="RWM")
		ttput(pilot)
	}
		else ttget(pilot)
	
	## Check convergence and slow mixing parameters
	mon  <- rstan::monitor(pilot$samples, warmup=pilot$warmup, print=FALSE)
	## max(mon[,'Rhat'])
	## min(mon[,'n_eff'])
	## Examine the slowest mixing parameters
	slow <- names(sort(mon[,"n_eff"]))[1:8]
	vals.save = c(vals.save,c("pilot","mon","slow"))
#browser();return()
	#pairs_admb(fit=pilot, pars=slow, label.cex=1)
	#pairs_admb(fit = pilot, pars = c("MGparm[1]", "SR_parm[1]", "SR_parm[2]")) ## must be specific to Hake
	#pairs_admb(fit = pilot, pars = c("SR_parm[1]", "Q_parm[1]", "selparm[1]"), label.cex=1)
	
	## After regularizing run NUTS chains. First reoptimize to get the
	## correct mass matrix for NUTS. Note the -hbf 1 argument. This is a
	## technical requirement b/c NUTS uses a different set of bounding
	## functions and thus the mass matrix will be different.
	## ----------------------------------------------------------------
	if (syscall[4]) {
		.flush.cat("Reoptimize to get correct mass matrix...\n")
		system(paste0(ssexe, " -hbf 1 -nox -iprint 200 -mcmc ", iters$test))
	}
#browser();return()

	## Use default MLE covariance (mass matrix) and short parallel NUTS chains started from the MLE.
	## ----------------------------------------------------------------
	if (syscall[5]) {
		.flush.cat("Using MLE covariance and short parallel NUTS chains...\n")
		warmup   <- ceiling(0.2*iters$mle)  ## Monnahan et al. (2019)
		nuts.mle <-  sample_admb(model=ssexe, path=d.model, iter=iters$mle, init=NULL, chains=reps, warmup=warmup, seeds=seeds, thin=1, mceval=FALSE, duration=NULL, parallel=parallel, cores=reps, control=list(metric="mle", adapt_delta=0.8), algorithm="NUTS")
		ttput(nuts.mle)
	} else
		ttget(nuts.mle)
	vals.save = c(vals.save,c("nuts.mle"))
	## Check for issues like slow mixing, divergences, max treedepths with
	## ShinyStan and pairs_admb as above. Fix and rerun this part as needed.
	## launch_shinyadmb(nuts.mle)
#browser();return()
	
	## Once acceptable, run again for inference using updated mass matrix. Increase
	## adapt_delta toward 1 if you have divergences (runs will take longer).
	## Note this is in unbounded parameter space
	## The following, nuts.updated, was used for inferences in this appendix
	mass  <- nuts.mle$covar.est
	inits <- sample_inits(nuts.mle, reps)
	## ----------------------------------------------------------------
	if (syscall[6]) {
		.flush.cat("Run final NUTS MCMC using updated mass matrix...\n")
		sweep.files(c("ss.psv","unbounded.csv"))
		setwd(d.mcmc)
		## Check to see if psv file exists and keep a copy if it does
		sweep.files(c("ss.psv"))
		toast = setdiff(list.files("."),c(ssfiles,"mcmc",".RData"))
#browser();return()
		if (length(toast)>0)
			file.remove(toast)
		warmup = ceiling(0.2*iters$update)  ## Monnahan et al. (2019)
		butter = c("admodel.cov","admodel.hes","ss.par","ss.cor")
		if ( all(file.exists(paste0(d.model,"/",butter))) )
			zb = file.copy(from=paste0(d.model,"/",butter), to=paste0(d.mcmc,"/",butter), overwrite=TRUE, copy.date=TRUE)
		else
			stop("MPD precursor directory is missin:\n\t'",paste0(butter[!xb],collapse="', '"),"'")

		nuts.updated <- sample_admb(model=ssexe, path=d.mcmc, iter=iters$update, init=inits, chains=reps, warmup=warmup, seeds=seeds, thin=1, mceval=TRUE, duration=NULL, parallel=parallel, cores=reps, control=list(metric=mass, adapt_delta=0.9), algorithm="NUTS")
		ttput(nuts.updated)
	}
		else ttget(nuts.updated)

	vals.save = c(vals.save,c("nuts.updated","mass","inits"))

	tmpenv <- new.env()
	if (file.exists(rda_file) && add2rda) {
		load(rda_file, envir=tmpenv)
		oldtags = ls(envir=tmpenv)
	}
	mess = paste0(tag,"=list(",paste0(paste0(vals.save,"=",vals.save),collapse=","),"); ttput(", tag, "); tput(", tag, ",tenv=tmpenv); save(list=ls(tmpenv),file=\"",rda_file,"\", envir=tmpenv)")
	eval(parse(text=mess))
	end_time <- Sys.time()
	cat("Elapsed time: ", end_time - start_time, " hours\n")
#browser();return()

	## Have to get rid of column "lp__" to make shinyadmb work (bad programming in '.validate_sampler_params')
	if (stupid_shiny) {
		fit = nuts.updated
		tmp_params = fit$sampler_params
		nms_params = lapply(tmp_params,function(x){x[,setdiff(colnames(x),"lp__")]})
		fit$sampler_params = nms_params
		ttput(fit)
		launch_shinyadmb(fit)
	}
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~runADnuts


#require(PBSmodelling)
#source("utilFuns.r",local=FALSE)

## runSS--------------------------------2020-09-02
## Run Stock Synthesis code using ADMB
## ---------------------------------------------RH
runSS = function(
   data.file, control.file, wd=getwd(), strSpp="XYZ",
   runNo=1, rwtNo=0,
   doMPD      = FALSE,
   N.reweight = 1,  ## number of reweight iterations
   A.reweight = 1,  ## abundance reweight method 0=no reweight, 1=add pocess error, 2=SDNR
   C.reweight = 1,  ## composition reweight method: 0=no reweight, 1=Francis (2011) mean age, 2=SDNR
   A.cvpro    = 0,  ## if Ncpue>0 then cvpro lists cvpro for CPUE after those for surveys
   doMCMC     = FALSE, 
   mcmc       = 1e6, mcsave=1e3, ADargs=NULL, verbose=FALSE, 
   doMSY      = FALSE, 
   msyMaxIter = 15000., msyTolConv=0.01, endStrat=0.301, stepStrat=0.001,
   delim      = ".", clean=FALSE, locode=FALSE, 
   synthPath  = "C:/Users/haighr/Files/Archive/Bat",
   codePath   = "C:/Users/haighr/Files/Projects/R/Develop/PBSsynth/Authors/Rcode/develop",
   exefile    = "ss_opt.exe",
   ...)
{
	ciao = function(){setwd(cwd); Sys.setenv(PATH=syspath0); gc(verbose=FALSE)} # exit function
	cwd  = getwd(); syspath0  = Sys.getenv()["PATH"]
	on.exit(ciao())

	debug = T  ## turn on while debugging to bypass functions that take forever...

	if (!doMPD)
		cvpro = tcall(PBSsynth)$cvpro  ## retain cvpro from initially run MPD
	if (locode) { 
		#ici = sys.frame(sys.nframe())
		#load(paste0(system.file("data",package="PBSsynth"),"/gfcode.rda"), envir=ici)
		eval(parse(text="require(PBStools, quietly=TRUE, warn.conflicts=FALSE)"))
		eval(parse(text="require(r4ss, quietly=TRUE, warn.conflicts=FALSE)"))
		#source(paste(codePath,"PBSscape.r",sep="/"),local=FALSE)
		#source(paste(codePath,"runSweave.r",sep="/"),local=FALSE)
		#source(paste(codePath,"runSweaveMCMC.r",sep="/"),local=FALSE)
		source(paste(codePath,"plotFuns.r",sep="/"),local=FALSE)
		source(paste(codePath,"utilFuns.r",sep="/"),local=FALSE)
		#source(paste(codePath,"menuFuns.r",sep="/"),local=FALSE)
	}
	synthPath = gsub("/","\\\\",synthPath)
	syspath   = paste(syspath0,synthPath,sep=";")
	Sys.setenv(PATH=syspath)
	# Be careful when using this that it doesn't destroy files other than those from Awatea
	if (clean) {
		junkpat = c("^admodel", "^ss\\.", "\\.sso$", "\\.ss_new$", "\\.bak$", "\\.log$","\\.pst$", "\\.out$", "\\.rpt$", "\\.tmp$", "^gradient", "^variance$", "^results.dat$", "^likelihood.dat$")
		junkit  = sapply(junkpat,function(x){list.files(pattern=x)})
		junkit  = sapply(junkit,setdiff,"SS.exe")
		junk    = sapply(junkit,function(x){ if (length(x)>0) for (i in x) if (file.exists(i)) file.remove(i)})
	}
	runNoStr = pad0(runNo,2)
	runname  = paste(strSpp,"run",runNoStr,sep="")
	rundir   = paste(wd,runname,sep="/")

	ssfiles = list()
	for (ss in c("starter","forecast","control","data")) {
		if (ss %in% c("starter","forecast"))
			ssfiles[[ss]][["name"]] = paste0(ss,".ss")
		else {
			sfile = switch(ss, 'control'=control.file, 'data'=data.file)
#browser();return()
			ssfiles[[ss]][["name"]] = sfile
			abits = strsplit(sfile,"")[[1]]  ## all characters
			puncs = abits[grep("[[:punct:]]",abits)]
			fbits = strsplit(sfile,split="[[:punct:]]")[[1]]
			if (!is.element(runNoStr, fbits)) {
				if (!getYes("Input file appears mismatched with Run specified. Continue?"))
					stop("Resolve run number with name of input file")
			}
			ssfiles[[ss]][["prefix"]] = paste0(fbits[-length(fbits)],c(puncs[-length(puncs)],""),collapse="") ## a bit excessive but wtf
			ssfiles[[ss]][["ext"]]    = rev(fbits)[1]
		}
		ssfiles[[ss]][["nvars"]] = numeric()
		ssfiles[[ss]][["input"]] = character()
		ssfiles[[ss]][["gcomm"]] = character()
		ssfiles[[ss]][["vcomm"]] = character()
		ssfiles[[ss]][["vdesc"]] = character()
		ssfiles[[ss]][["dnam"]] = character()
		ssfiles[[ss]][["vlst"]] = list()
		ssfiles[[ss]][["vars"]] = list()
		ssfiles[[ss]][["objs"]] = list()
	}
	## Use data file for prefix
	ext     = ssfiles$data$ext
	prefix  = paste0(setdiff(fbits,c(ext,runNoStr,"data","control")), collapse=delim)
	argsMPD = argsMCMC = NULL
	if (!is.null(ADargs)) {
		if(!is.list(ADargs)) stop("'ADargs' must be either a list or NULL")
		for (i in ADargs) {
			if (!grepl("mc",i))     argsMPD = c(argsMPD,list(i)) 
			if (!grepl("nohess",i) & !grepl("mcmc",i) & !grepl("mcsave",i)) argsMCMC = c(argsMCMC,list(i)) 
		}
	}	
	argsMPD  = paste(paste(" ",unlist(argsMPD),sep=""),collapse="")
	argsMCMC = paste(paste(" ",unlist(argsMCMC),sep=""),collapse="")
	stuff=c("synthPath", "codePath", "wd", "data.file", "control.file", "ssfiles", "strSpp", "runNo", "N.reweight", "cvpro", "runname", "rundir")
	packList(stuff, target="PBSsynth")
#browser();return()

	if (doMPD) {
		if (!all(sapply(ssfiles, function(x){file.exists(x$name)})))
			stop("Specified input file does not exist")
		.flash.cat(paste0("\nRunning MPD on ", data.file, "...\n"))
		SSobj = readSS(ssfiles)
		#view(SSobj, sublist=c(T,F))
		#view(SSobj, file="starter", chunk="vdesc")
		#view(SSobj, file="control", chunk="dnam")
		Ncpue = length(view(SSobj,file="data",chunk="objs",pat="CPUE",see=F))
		Nsurv = length(view(SSobj,file="data",chunk="objs",pat="INDEX",see=F))
		cvpro = view(SSobj,file="control",chunk="objs",pat="var_adj_CV",see=F)
		cvpro = sapply(cvpro,function(x){rev(x)[1]}) ## get last value
		sdnrfile = paste(prefix,runNoStr,"sdnr",sep=".")
		hline  = paste0("## ", paste0(rep("=",52),collapse=""),"\n")
		header = paste0(hline, "## SDNR -- ", ifelse(Nsurv>0,paste0("Surveys(",Nsurv,"), "),""), ifelse(Ncpue>0,paste0("CPUE(",Ncpue,"), "),""), "CAsurv, CAcomm, devSDNR\n## wj   -- AF(comm), AF(surv)\n",hline,"\n")  ## RH 200417
		cat(header,file=sdnrfile)
		cat("CVpro:",cvpro,"\n",file=sdnrfile,append=TRUE,sep=" ")
#browser();return()
		#f.sta = paste0("starter",  delim, runNoStr, delim, "00", delim, ext)  ## starter.ss  cannot have another name
		#f.for = paste0("forecast", delim, runNoStr, delim, "00", delim, ext)  ## forecast.ss cannot have another name
		f.dat = paste0(prefix,delim,ifelse(prefix=="data","",paste0("data",delim)),runNoStr,delim,"00.", ext)
		f.ctl = paste0(prefix,delim,ifelse(prefix=="control","",paste0("control",delim)),runNoStr,delim,"00.", ext)
		fileX = paste("ss",c("cor","eva","par","rep","std"),sep=".") ## extra files to save
		## Better to read in results using r4ss' function: replist <- SS_output(dir='.') (line 219) than to save.sso files (but this may change with use)
		f.sso = grep(list.files(pattern="\\.sso$"),patter="warn|echo",invert=T,value=T)
		f.sso = f.sso[file.info(f.sso)["size"]>2]
		#fileX = c(fileX, f.sso)
		fileA = character(0) # All accumulated files

		## New concept on reweighting (RH 1904043) -- treat reweighting of abundance (A) and composition (C) separate
		A.reweight = rep(A.reweight,N.reweight)[1:N.reweight]
		C.reweight = rep(C.reweight,N.reweight)[1:N.reweight]

		for (i in 0:N.reweight) {
			ii = pad0(i,2)
			inam = paste0(gsub("[[:punct:]]",delim,basename(cwd)),delim,runNoStr,delim,ii)

			## Either start with initial file or apply reweights to previous file
			if (i==0) {
				fileN = c(f.ctl, f.dat)
				file.copy(from=data.file, to=f.dat, overwrite=TRUE)
				file.copy(from=control.file, to=f.ctl, overwrite=TRUE)
			} else {
				f.dat   = paste0(prefix,delim,ifelse(prefix=="data","",paste0("data",delim)),runNoStr,delim,ii,".",ext)
				f.ctl   = paste0(prefix,delim,ifelse(prefix=="control","",paste0("control",delim)),runNoStr,delim,ii,".",ext)
				fileN   = c(f.ctl, f.dat)
				C.objs  = SSobj@ssfiles$control$objs
				D.objs  = SSobj@ssfiles$data$objs
				C.vdesc = SSobj@ssfiles$control$vdesc
				C.vars  = SSobj@ssfiles$control$vars
				Vnew    = SSobj@reweight$Vnew
				rvars   = names(findPat("var_adj",C.vdesc))
				SSobjRW = fix(SSobj, slot="ssfiles", file="control", varN=rvars, xnew=Vnew)
				slot="ssfiles";tput(slot);sfile="control";tput(sfile)
				write(SSobjRW,file=f.ctl)
browser();return()

				#desc = SSobj@vdesc; dat = SSobj@vars; newdat=SSobj@reweight
				### Collect pointers to abundance and composition data to populate with re-weighted values
				#rvar1 = names(findPat("Survey abundance indices",desc))
				#rvar2 = names(findPat("CPUE \\(Index",desc))
				#rvar3 = names(findPat("Commercial catch at age data",desc))
				#rvar4 = names(findPat("Survey C@A data",desc))
				#if (length(c(rvar1,rvar2,rvar3,rvar4))!=4)
				#	stop ("INPUT -- Someone has changed at least one header name for abundance/composition data !!!!")

				#survey = dat[[rvar1]]; #dimnames(index) = list(1:nrow(index),c("series","year","obs","CV"))
				#survey[,4] = newdat$survey$CVnew
				#cpue = dat[[rvar2]]
				#if (!is.null(newdat$cpue))
				#	cpue[,5] = newdat$cpue$CVnew
				#CAc = dat[[rvar3]]
				#if (is.vector(CAc)) CAc = makeRmat(CAc,rowname=names(newdat$wNcpa))
				#CAc[,3] = newdat$wNcpa  ## No. of commercial age samples
				#CAs = dat[[rvar4]]
				#if (is.vector(CAs)) CAs = makeRmat(CAs,rowname=names(newdat$wNspa))
				#CAs[,3] = newdat$wNspa  ## No. of survey age samples

				#Robjnew = fix(SSobj,c(rvar1,rvar2,rvar3,rvar4),list(survey,cpue,CAc,CAs))
				##hh=pad0(i-1,3); fileN = gsub(hh,ii,fileN)
				#fileN = paste(prefix,runNoStr,ii,"txt",sep=".")
				#write(Robjnew,fileN)
			}
			fileA = c(fileA,fileN)

			## Update 'starter.ss' with revised input files (control and data)
			desc.start = SSobj@ssfiles$starter$vdesc
			rvar1 = names(findPat("data file name",desc.start))
			rvar2 = names(findPat("control file name",desc.start))
			SSobj = fix(SSobj,slot="ssfiles", file="starter", varN=c(rvar1,rvar2), xnew=list(f.dat,f.ctl))
			slot="ssfiles";tput(slot);sfile="starter";tput(sfile)
			write(SSobj,file="starter.ss")
#browser();return()

			## Run the MPD
			if (i==0) .flash.cat("\nProcessing initial MPD fit without reweighting...\n")
			else      .flash.cat(paste0("\n","Processing MPD fit for Rwt ", i, "...\n"))
			expr = paste0("mess = shell(cmd=\"", exefile, " -ind ", grep("data",fileN,value=T), argsMPD,"\", wait=TRUE, intern=TRUE)")
#browser();return()
			if (debug)
				mess =rep("Temporary insanity",10)
			else
				eval(parse(text=expr))
			if (verbose)  .flash.cat(mess, sep="\n")
			if (length(mess)<10) stop("Abnormal program termination")

			## Copy results of MPD
			for (jfile in fileX){
				if (file.exists(jfile)){
					if (substring(jfile,1,3)=="ss.") {
						#suffix  = sapply(strsplit(jfile,"\\."),tail,1)
						fileS = sub("^ss",inam,jfile)
					} else if (jfile=="likelihood.dat")
						fileS = paste0(inam,".lik") ## leftover from Awatea but could be adapted for individual sso files
					else if (jfile=="results.dat")
						fileS = paste0(inam,".res") ## leftover from Awatea
					else
						fileS = paste0(inam,".tmp")
					file.copy(jfile, fileS, overwrite=TRUE)
					fileA = c(fileA,fileS)
				}
			}
			fileR   = paste0("replist",delim,inam,".rda")
			fileA   = c(fileA, fileR)
			if (!debug) {
				replist = SS_output(dir=cwd, verbose=FALSE)
				save("replist", file=fileR)
			}

			## Reweight the input files until N.reweight-1
			if (i <= N.reweight) {
				inext = i + 1
				SSobj = readSS(ssfiles)
				if (i < N.reweight) {
					.flash.cat("\nReweighting abundance (comm & surv) and composition (proportions-at-age)...\n")
					SSobj@reweight = list(nrwt=inext)
					SSobj = reweight(SSobj, A.rwt=A.reweight[inext], C.rwt=C.reweight[inext], cvpro=A.cvpro, sfile=sdnrfile, fileN=fileN)
#browser();return()
				} else {
					## Send an artificial reweight to get SDNRs for the final reweight
					SSobj@reweight = list(nrwt=0)
					dummy = reweight(SSobj, A.rwt=0, C.rwt=0, cvpro=A.cvpro, sfile=sdnrfile, fileN=fileN)
				}
			}
			#SSobj = reweight(SSobj, cvpro=cvpro, mean.age=mean.age, sfile=sdnrfile, fileN=fileN) ## old call
		} ## end reweight loop

		if (!file.exists(rundir)) dir.create(rundir)
		#fileA = paste(prefix,runNoStr,rep(pad0(0:N.reweight,2),each=length(suffix)+2),rep(c(ext,"res",suffix),N.reweight+1),sep=".")
#browser();return()
		file.copy(paste(wd,c("starter.ss","forecast.ss",control.file,data.file,fileA,sdnrfile),sep="/"),rundir,overwrite=TRUE)
		file.remove(paste(wd,c(fileA,sdnrfile),sep="/"))
	}
	if (doMCMC | doMSY) {
		rwtNoStr = pad0(rwtNo,2)
		fileN    = paste(prefix,runNoStr,rwtNoStr,ext,sep=".")
		mcname   = paste("MCMC",runNoStr,rwtNoStr,sep=".")
	}
	if (doMCMC) {
		.flash.cat(paste("Running",mcmc,"MCMC iterations...\n"))
		mcdir    = paste(wd,runname,mcname,sep="/")
		if (!file.exists(mcdir)) dir.create(mcdir)
		fileA = paste(prefix,runNoStr,rwtNoStr,c(ext,"res"),sep=".")
		file.copy(paste(rundir,fileA,sep="/"),mcdir,overwrite=TRUE); setwd(mcdir)
		expr=paste0("shell(cmd=\"", exefile, " -ind ",fileN," -mceval\" , wait=TRUE, intern=FALSE)")
		.flash.cat(expr, sep="\n")
		eval(parse(text=expr))
		
		SSobj="dummy4now"
	}
	if (doMSY) {
		.flash.cat(paste("Running MSY yield calculations...\n"))
		msyname  = paste("MSY",runNoStr,rwtNoStr,sep=".")
		msydir   = paste(wd,runname,mcname,msyname,sep="/")
		if (!file.exists(msydir)) dir.create(msydir)
		fileN = paste(prefix,runNoStr,rwtNoStr,ext,sep=".")
		fileA = c(paste(wd,runname,mcname,fileN,sep="/"),paste(wd,runname,mcname,"Awatea.psv",sep="/")) ## RH 200416
#browser();return()
		file.copy(fileA,msydir,overwrite=TRUE); setwd(msydir)
		ctlfile  = paste(c("#MSY control file",
			"#Maximum number of iterations",format(msyMaxIter,scientific=FALSE),
			"#Tolerance for convergence",format(msyTolConv,scientific=FALSE) ), collapse="\n")
		cat(ctlfile,"\n",sep="",file="Yields.ctl")

		infile = readSS(fileN)
		strategy = view(infile,pat=c("Strategy","End year"),see=FALSE)
		## Reset the strategy and express in terms of U
		strategy[[grep("Strategy Type",names(strategy))]] = 2
		strategy[[grep("End year of projections",names(strategy))]]  = -99
		strategy[[grep("End Strategy",names(strategy))]]  = endStrat
		strategy[[grep("Step Strategy",names(strategy))]] = stepStrat
		vnam = substring(names(strategy),1,4)
		infile = fix(infile,vnam,strategy) ## replace the contents of infile with updated strategy
		write(infile,fileN)                ## overwrite the input file for MSY calculations
		expr=paste("shell(cmd=\"", exefile, " -ind ",fileN," -mceval\" , wait=TRUE, intern=FALSE)",sep="")
		.flash.cat(expr, sep="\n")
		eval(parse(text=expr))
		
		SSobj=list(ctlfile,strategy)
	}
	if (exists(".PBSmodEnv")) packList(stuff=c("SSobj"), target="PBSsynth")
	invisible(SSobj)
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~runSS


## readSS-------------------------------2020-11-03
## Read the ADMB input file and create an AWATEA class object.
## ---------------------------------------------RH
readSS = function(ssfiles, pre.def="")
{
	## Following if loop only used for reading in specific files for viewing
	read.only = FALSE
	if (!is.list(ssfiles)) {
		read.only = TRUE
		ssnames   = ssfiles
		ss.ext    = tools::file_ext(ssnames)
		ss.prefix = sub(paste0("\\.",ss.ext,"$"),"",ssnames)
		ssfiles   = list()
		#for (ss in ssnames) {
		for (s in 1:length(ssnames)) {
			ss = ss.prefix[s]
			if (ss %in% c("starter","forecast"))
				ssfiles[[ss]][["name"]] = paste0(ss,".",ss.ext[s])
			else {
				ssfiles[[ss]][["name"]] = paste0(ss,".",ss.ext[s])
				ssfiles[[ss]][["prefix"]] = ss
				ssfiles[[ss]][["ext"]]    = ss.ext[s]
			}
			ssfiles[[ss]][["nvars"]] = numeric()
			ssfiles[[ss]][["input"]] = character()
			ssfiles[[ss]][["gcomm"]] = character()
			ssfiles[[ss]][["vcomm"]] = character()
			ssfiles[[ss]][["vdesc"]] = character()
			ssfiles[[ss]][["dnam"]] = character()
			ssfiles[[ss]][["vlst"]] = list()
			ssfiles[[ss]][["vars"]] = list()
			ssfiles[[ss]][["objs"]] = list()
		}
	}
	for (ss in names(ssfiles)) {  ## usually c("starter","forecast","control","data")
		#if (ss!="starter") next
		sfile = ssfiles[[ss]][["name"]]
		otxt  = readLines(sfile) # original text
#browser();return()
		utxt  = otxt[!is.element(substring(otxt,1,3),"####")] ## use text (remove data not comments)
		xlst  = strsplit(utxt,"")
		xlst  = xlst[sapply(xlst,length)>0]  ## remove blank lines
		input = sapply(xlst,function(x){paste(clipVector(x,clip="\t",end=2),collapse="")})
		input = gsub("\\\t\\\t","\t",input)   ## internal cleanup

		## vlst = variable list; vcom = variable comments by line number; acom = non-variable comments by line number
		vlst=vars=list(); vcom=NULL; acom=NULL

		if (ss=="starter" && !read.only) {
			input = sub("^data\\.ss", ssfiles$data$name, input)
			input = sub("^control\\.ss", ssfiles$control$name, input)
		}
		dnum = 0 ## count number of data items
		
		for (i in 1:length(input)) {
			if (substring(input[i],1,1)=="#") {
				expr = paste0("vlst[[\"L",pad0(i,3),":Comment\"]] = ", deparse(input[i], width.cutoff=500))
				comm = sub("^#(_| +)?","",input[i]) ; names(comm) = i  ## Note: (_| +)? optional underscore or spaces after leading hatch
				acom = c(acom,comm)
			} else {
				dnum = dnum + 1
				vnum = paste0("v",pad0(dnum,3))
				dlen = if (is.numStr(input[i]) || !grepl("#",input[i])) nchar(input[i]) else regexpr(" +#",input[i])-1

#if(!is.numStr(input[i]) && !grepl("#",input[i])) {browser();return()}
				if (dlen<0 || dlen==nchar(input[i]))
					comm = paste0("prev_tag: ", sub("^prev_tag: ","",comm))
					#comm = paste0("value ", dnum)
				else
					comm = sub(" +#(_| +)?","",substring(input[i], dlen+1))
				names(comm) = i
				vcom = c(vcom,comm)
				dval = substring(input[i],1,dlen)
				expr = paste0("vlst[[\"L",pad0(i,3),":Data(",vnum,") tag={",comm,"}\"]] = ")
				## L33 of 'data' mixture of numeric and character data (treat as character for now)
				if (is.numStr(dval)) {
					dval.num = paste0("c(", gsub(" +",",",dval), ")")
					vars[[vnum]] = eval(parse(text=dval.num))
					expr = paste0(expr, dval.num )
				} else {
					dval.str = deparse(dval, width.cutoff=500)
					vars[[vnum]] = eval(parse(text=dval.str))
					expr = paste0(expr, dval.str)
				}
#if (i==416) {browser();return()}  
			}
			eval(parse(text=expr))
#if(i==337) {browser();return()}
		}
		## description of variables with inputs
		#vdesc = unique(vcom)  ## won't work in SS
		vdesc = vcom
		nvars = length(vdesc)
		if (nvars != dnum) { .flush.cat("DEBUG: Mismatch in count of number of variables\n\n"); browser();return() }
		## The next two lines from 'readAD' in PBSawatea only make sense if 'acom' = all comments (lines were either comments or data, not a mixture)
		#gcomm = acom[!is.element(acom,vdesc)] ## general comments
		#vcomm = acom[is.element(acom,vdesc)]  ## variable comments (may be duplicated)
		names(vdesc) = paste("v",pad0(1:nvars,3),sep="")
		gcomm = acom  ## originally 'all comments' but now 'general non-variable comments'
		vcomm = vcom
		#vars  = as.list(vdesc)  ## initialise for replacement (no longer needed)

		dnam  = names(vlst); names(dnam)=1:length(dnam)
		dnam  = dnam[grep("Data",dnam)]
		dnam  = extract.between(dnam,"{","}")
		
		## Go through variable lines and consolidate records into data frames for objects bigger than vectors.
		objs = list()
		utags = vdesc[!duplicated(vdesc)]
		ntags = table(vdesc)[utags]
		for (i in 1:length(utags)) {
			pre = switch(ss, 'control'="ctl", 'data'="dat", 'forecast'="fcs", 'starter'="str", pre.def)
			ii  = utags[i]
			iii = names(ii)
			iv  = paste0(iii,": ",pre,ifelse(pre=="","","_"),ii)
#browser();return()
			#if (!grepl("prev_tag:",iv))
				iv  = paste0(iii,": ",pre,ifelse(pre=="","","_"),sub("[[:punct:]]+$","",strsplit(ii,"[[:space:]]+")[[1]][1]))
			nn = ntags[ii]
			if (nn==1) {
				objs[[iv]] = vars[[iii]]
			} else {
				v = as.numeric(sub("[a-z]","",iii))
				ivars = vars[v:(v+(nn-1))]
				idf   = data.frame(matrix(unlist(ivars), nrow=nn, byrow=T),stringsAsFactors=FALSE)
#if (v==14) {browser();return()}
				if (grepl("Year Season Fleet Catch SE",ii))
					iv = sub("prev_tag","dat_catch",iv)
				if (grepl("year month fleet sex part ageerr",ii))
					iv = sub("prev_tag","dat_age_props",iv)
				if (grepl("Fleet Units Err_Dist SD_Rep",ii))
					iv = sub("prev_tag","dat_sd_reports",iv)
				#{browser();return()}
				cnams = strsplit(sub("prev_tag: ","",ii),split="[ +]")[[1]]
				cnams = cnams[!duplicated(cnams)]
				## Abundance Indices
				if (any(grepl("_INDEX$|_index$",cnams))) {
					cnams = c("Year", "Month", "Fleet", "Obs", "SE")
				}
				## Age Proportions:
				if("Nsamp" %in% cnams && any(grepl("1,...,",cnams))){
					ages = cnams[grep("1,...,",cnams)]
					amat = sapply (ages, function(x) {
						acap = gsub("[^[:upper:]]","",x)
						xx   = gsub("[[:alpha:]]|\\]|\\[|\\_","",x)
						avec = as.vector(sapply(strsplit(xx,",...,"), function(xxx){seq(xxx[1],xxx[2],1)}))
						astr = paste0(acap, pad0(avec,2))
						return(astr)
					})
					avec  = as.vector(amat)
					cnams = c(setdiff(cnams,ages), avec)
				}
				cnams = sub("prev_tag: ","",cnams)
				if (length(cnams)==ncol(idf))
					colnames(idf) = cnams
				objs[[iv]] = idf
			}
		}
#print("shaboom")
#browser();return()
		## Populate the ssfiles list object for each SS file
		ssfiles[[ss]][["nvars"]]  = nvars  ## number of variable lines in the input file
		ssfiles[[ss]][["input"]]  = input  ## contents of text file
		ssfiles[[ss]][["gcomm"]]  = acom   ## general (non-variable) comments by line number
		ssfiles[[ss]][["vcomm"]]  = vcom   ## variable comments by line number
		ssfiles[[ss]][["vdesc"]]  = vdesc  ## vector of variable descriptions named by variable number
		ssfiles[[ss]][["dnam"]]   = dnam   ## data tags
		ssfiles[[ss]][["vlst"]]   = vlst   ## list of input lines
		ssfiles[[ss]][["vars"]]   = vars   ## list of variable values by variable number (one per record)
		ssfiles[[ss]][["objs"]]   = objs   ## list of objects by first non-duplicated variable number
	}

browser();return()
	## use r4ss funtion:  rlist <- SS_output(dir='.')


	suffix = c("cor","eva","par","std")
	for (j in suffix) {
		jnam = paste0("ss.",j)
		#do.call("assign", args=list(x=paste0(j,"nam"), value=jnam))
		if (!file.exists(jnam)) do.call("assign", args=list(x=paste0(j,"dat"), value=list()))
		else {
			mess = paste0(j,"dat = import",toupper(substring(j,1,1)),substring(j,2,3),"(",j,".file=\"", jnam, "\")")
			eval(parse(text=mess))
		}
#if (j=="cor") {browser();return()}
	}
browser();return()
#	## Gather some control variables from original text (otxt)
#	## -------------------------------------------------------
#	ctllabs=list(Nsex="Number of sexes", Nsurv="Number of survey series", Ncpue="Number of CPUE series",
#	likeCPUE="CPUE likelihood Type",
#	NsurvDP="Number of survey data points \\(all series\\)", NcpueDP="Number of CPUE data points \\(all series\\)",
#	NyrCAs="Number of years with survey C@A data", NyrCAc="Number of years with commercial C@A data", 
#	Nmethod="Number of commercial fishing gears", gear="Initial gear",
#	ageMax="Max age in model", ageFullMat = "Age at full maturity",
#	YrStart="Start year of model",YrEnd="End year of model",YrProj="End year of projections",
#	strategy="Strategy Type", Usplit="Strategy U")
#
#	controls=sapply(ctllabs,function(x){
#		strval = gsub("#","",otxt[grep(x,otxt)[1]+1])
#		# sometimes need to get rid of pesky tab characters
#		strvec = strsplit(strval,"\t")[[1]]
#		strvec = strvec[strvec!="" & !is.na(strvec)]
#		as.numeric(strvec)
#	},simplify=FALSE)
#
#	if (all(controls$likeCPUE==0)) controls$Ncpue=0   # discount dummy CPUE data if likelihood type = 0
#	cvpro = if (exists(".PBSmodEnv")) tcall(PBSsynth)$cvpro else PBSsynth$cvpro
#	Nsc   = controls$Nsurv + controls$Ncpue      # Ncpue always at least 1, even if just dummy data (Awatea quirk)
#	controls[["cvpro"]] = rep(cvpro,Nsc)[1:Nsc]  # expand cvpro to accommodate all series (user may only specify one value, or underestimate number of series)

	Data = new("SSdata", ssfiles=ssfiles, cordat=cordat, evadat=evadat, pardat=pardat, stddat=stddat, reweight=list(nrwt=0))
		#, resdat=resdat, likdat=likdat, controls=controls)
	return(Data)
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~readSS


## setMethod.view-----------------------2020-09-17
## Set the method for 'view' when using an SS class.
## ---------------------------------------------RH
view = PBSmodelling::view
setMethod("view", signature(obj = "SSdata"),
   function (obj, n=5, last=FALSE, random=FALSE, print.console=TRUE, see=TRUE, ...)
{
	#dat = obj@vars; desc= obj@vdesc; nvars=obj@nvars
	dots = list(...)
	if (is.null(dots$slot))  dat   = obj@ssfiles
	else                     dat   = eval(parse(text=paste0("dat=obj@",dots$slot)))
	if (is.null(dots$file))  file  = "data"
	else                     file  = dots$file
	if (is.null(dots$chunk)) chunk = "objs"
	else                     chunk = dots$chunk

#last=T
#random=T
#dots$pat="random"

	if (is.null(dat[[file]][[chunk]])) stop ("Choose another 'slot|file|chunk'")
	lump = dat[[file]][[chunk]]
	nrec = length(lump)

	if (is.null(dots$sublist)) sublist = c(TRUE,TRUE)
	else                       sublist = dots$sublist

	if (!is.null(dots$pat)) {
		patty = findPat(dots$pat,vec = if(is.list(lump)) names(lump) else lump)
		if (length(patty)==0) stop("Specified pattern not found")
		else {
			lump.old =  lump
			lump = if (is.list(lump)) lump[patty] else lump[names(patty)] ##; names(nugget) = paste(names(patty),patty,sep=": ")
		}
	}

	if (is.list(lump) && sublist[1]) {
		clump = lapply(lump,function(x){
			if (is.data.frame(x) || is.matrix(x))
				xdim = dim(x)
			else
				xdim = length(x)
			#.flush.cat(dim(x),"\n")
			mess = paste0("out=x[",paste0("1:",pmin(xdim,n),collapse=","),"]")
#if (any(xdim>5)) {browser();return()}
			if (last)
				mess = paste0("out=x[",paste0(paste(c(pmax(1,xdim-n+1)), c(xdim),sep=":"),collapse=","),"]")
			if (random) {
				idx = sapply(lapply(xdim,function(i){sample(1:i,pmin(i,n))}),function(r){paste0("c(",paste0(r,collapse=","),")")})
				mess = paste0("out=x[",paste0(idx,collapse=","),"]")
			}
			eval(parse(text=mess))
			return(out)
		})
#browser();return()
	} else {
		## Use code below for both vectors and lists because list components may have already been subset above
		clump = lump
	}
	if (!is.list(clump) || (is.list(clump) && sublist[2]) ) {
		xdim = length(clump)
		mess = paste0("nugget=clump[",paste0("1:",pmin(xdim,n),collapse=","),"]")
		if (last)
			mess = paste0("nugget=clump[",paste0(paste(c(pmax(1,xdim-n+1)), c(xdim),sep=":"),collapse=","),"]")
		if (random) {
			idx = sapply(lapply(xdim,function(i){sample(1:i,pmin(i,n))}),function(r){paste0("c(",paste0(r,collapse=","),")")})
			mess = paste0("nugget=clump[",paste0(idx,collapse=","),"]")
		}
		eval(parse(text=mess))
	} else {
		nugget = clump
	}
	if (see) print(nugget)
	else invisible(nugget)
} )
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~setMethod.view


## setMethod.fix------------------------2020-09-22
## Set the method for 'fix' when using an SS class.
## ---------------------------------------------RH
setMethod("fix", signature(x = "SSdata"),
   function (x, slot="ssfiles", file="starter", varN, xnew, ...)
{
	eval(parse(text=paste0("dat=x@",slot,"[[\"",file,"\"]]")))
	unpackList(dat)
	#vars = dat$vars
	#desc = dat$vdesc
	dots = list(...)
	nvar = length(varN)
	if (nvar>1 & !is.list(xnew) && length(xnew)!=nvar)
		stop("'xnew' must be a list of objects to match multiple 'varN'")
	for ( i in 1:nvar) {
		if (nvar==1 & !is.list(xnew)) oo = xnew
		else oo = xnew[[i]]
		odim = if (is.data.frame(oo) || is.matrix(oo)) dim(oo) else length(oo)
		ii = varN[i]
		for (v in c("vlst","vars","objs")) {
			eval(parse(text=paste0("vee=",v)))
			if (any(grepl(ii,names(vee)))) {
				vv   = vee[[grep(ii,names(vee))]]
				vdim = if (is.data.frame(vv) || is.matrix(vv)) dim(vv) else length(vv)
				if (odim==vdim) {
					vee[[grep(ii,names(vee))]] = oo
					eval(parse(text=paste0(v,"=vee")))
				}
			}
		}
	}
#browser();return()
	mess = paste0("x@",slot,"[[\"",file,"\"]][[\"vlst\"]] = vlst; ")
	mess = c(mess, paste0("x@",slot,"[[\"",file,"\"]][[\"vars\"]] = vars; "))
	mess = c(mess, paste0("x@",slot,"[[\"",file,"\"]][[\"objs\"]] = objs"))
	eval(parse(text=paste0(mess,collapse="")))
	return(x)
} )
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~setMethod.fix


## setMethod.write----------------------2020-09-22
## Set the method for 'write' when using an SS class.
## ---------------------------------------------RH
setMethod("write", signature(x = "SSdata"),
   function(x, file="something.ss", ncolumns = if(is.character(x)) 1 else 5,
   append = FALSE, sep = "\t")
{
	tget(slot); tget(sfile)
	eval(parse(text=paste0("dat=x@",slot,"[[\"",sfile,"\"]]")))
	unpackList(dat)
	#vlst=x@vlst; dnam=x@dnam; vdesc=x@vdesc; vars=x@vars; gcomm=x@gcomm; vcomm=x@vcomm
	olst = list()
	for (i in 1:length(vlst)) {
		ii = as.character(i); iii=as.character(i+1)
#if(i==337) {browser();return()}
		if (is.element(ii,names(gcomm)))
			olst[[ii]] = paste0(ifelse(grepl("^#",gcomm[ii]),"#","#_"),gcomm[ii])
		else if (is.element(ii,names(vcomm))) {
			tag = if (grepl("^prev_tag",vcomm[ii])) "" else paste0(" #_",vcomm[ii])
			olst[[ii]] = paste0(paste0(vlst[[i]],collapse=" "), tag)
#if(i==337) {browser();return()}
			#if (is.na(dnam[iii])) next  ## if variable header is duplicated and one is commented out
			#olst[[iii]] = vars[[names(vdesc[is.element(vdesc,dnam[iii])])]]
		}
		else next
	}
	nlin = sum(sapply(olst,function(x){if(is.matrix(x)) nrow(x) else 1}))
	nvec = rep("",nlin)
	ii   = 0
	for (i in 1:length(olst)) {
		oo = olst[[i]]
		ii = ii + 1
		if (is.matrix(oo)) {
			for (j in 1:nrow(oo)) {
				ii = ii + ifelse(j==1,0,1)
				nvec[ii] = paste(oo[j,],collapse=sep)
			}
		}
		else if (is.numeric(oo)) 
			nvec[ii] = paste(oo,collapse=sep)
		else
			nvec[ii] = oo
	}
#browser();return()
	writeLines(nvec,con=file)
	invisible(nvec) } )
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~setMethod.write


## setMethod.reweight-------------------2020-09-22
## Set the method for 'reweight' when using an AWATEA class.
## Calculates reweighted values and populates S4 object.
## ---------------------------------------------RH
#reweight <- function(obj, cvpro=FALSE, mean.age=TRUE, ...) return(obj) ## old function
reweight <- function(obj, A.rwt=1, C.rwt=1, cvpro=0, ...) return(obj)

setMethod("reweight", signature="SSdata",
   #definition = function (obj, cvpro=FALSE,  mean.age=TRUE, ...) ## old method
   definition = function (obj, A.rwt=1, C.rwt=1, cvpro=0, ...)
{
	dots=list(...)
	nrwt = obj@reweight$nrwt;
#browser();return()
	C.objs = obj@ssfiles$control$objs
	D.objs = obj@ssfiles$data$objs
	C.var.adj = C.objs[findPat("var_adj",names(C.objs))]
	if (length(C.var.adj)==0) return()

	## Replace variance adjustments
	V  = Vnew = C.var.adj
	## Abundance weighted by CV process error
	iA = sapply(V,function(x){x[1]==1})
	if (any(iA)) {
		VA = V[iA]
		if (A.rwt==1) {
			c_p = cvpro^(1/nrwt)
			for (i in 1:length(c_p))
				VA[[i]][3] = c_p[i]
		}
		Vnew[names(VA)] = VA
	}
	## Composition weighted by Francis mean weights
	iC = sapply(V,function(x){x[1]==5})
	if (any(iC)) {
		VC = V[iC]
		if (C.rwt) {
			#w_j = c(4.03066,2.32338,0.45375) ## figure out r4ss calculation
			w_j    = numeric()
			Nfleet = length(replist$FleetNames)
			for(j in 1:Nfleet) {
				w_j[j] = SSMethod.TA1.8(replist,"age",fleet=j,plotit=F,printit=F)[1]
				VC[[j]][3] = w_j[j]
			}
		}
		Vnew[names(VC)] = VC
	}
	obj@reweight = list(nrwt=nrwt, next.rwt=nrwt+1, c_p=c_p, w_j=w_j, Vnew=Vnew)
	return(obj)

## *****TO HERE
browser();return()

	##===== start main =====
	#do.cvpro = if (is.numeric(cvpro[1])) TRUE else do.cvpro=cvpro[1]
	#if (do.cvpro && is.logical(cvpro[1]) && cvpro[1]==TRUE)
	#	cvpro = rep(0.2, length(cvpro))

	## Abundance data -- Surveys
	## Reweight methods: 0=no reweight, 1=add/subtract pocess error, 2=SDNR
	survey    =  res$Survey[!is.na(res$Survey[,"Obs"]),]
	Sseries   = sort(unique(survey[,"Series"]))
	SDNR      = rep(0,length(Sseries)); names(SDNR) = Sseries
	survey$NR = NRfun(survey$Obs,survey$Fit,survey$CV)
	survey$CVnew = rep(0,nrow(survey))

	for (s in Sseries) {
		## single event by Sseries s
		ss = as.character(s)
		zs = is.element(survey$Series,s)
		sser = survey[zs,]
		SDNR[ss] = sd(sser$NR)

		## Check that this routine is repeated for the CPUE series below

		if (A.rwt==1) {  ## add specified process error
			.flash.cat(paste0("   CV reweight ", nrwt, " -- survey ", s, " with CVpro=",cvpro[s]),"\n")
			## Need to subtract if cvpro < 0
			if (cvpro[s] >= 0)
				survey$CVnew[zs] = sqrt(survey$CV[zs]^2 + cvpro[s]^2)
			else
				survey$CVnew[zs] = sqrt(survey$CV[zs]^2 - cvpro[s]^2)

		} else if (A.rwt==2) { ## use SDNR method
			.flash.cat(paste0("   CV reweight ", nrwt, " -- survey ", s, " with SDNR=",SDNR[ss]), "\n")
			survey$CVnew[zs] = sser$CV * SDNR[ss]

		} else { ## no reweight or no defined method
			#.flash.cat(paste0("   CV reweight ", nrwt, " not performed -- survey ", s), "\n")
			survey$CVnew[zs] = survey$CV[zs]
		}
	}

	## Abundance data -- CPUE indices
	## Reweight methods: 0=no reweight, 1=add/subtract pocess error, 2=SDNR
	if (all(view(obj,pat="CPUE likelihood",see=FALSE)[[1]]==0)) {
		cpue = NULL
	} else {
		cpue =  res$CPUE[!is.na(res$CPUE[,"Obs"]),]
		Utmp = sort(unique(cpue[,"Series"])); Useries = gsub("Series","cpue",Utmp); names(Useries) = Utmp
		sdnr = rep(0,length(Useries)); names(sdnr) = Useries; SDNR = c(SDNR,sdnr)
		cpue$NR = NRfun(cpue$Obs,cpue$Fit,cpue$CV)
		cpue$CVnew = rep(0,nrow(cpue))
		for (u in names(Useries)) {
			s  = s + 1  ## to index cvpro for CPUE; s continued from surveys above
			uu = as.character(u)
			zu = is.element(cpue$Series,u)
			user = cpue[zu,]
			SDNR[Useries[uu]] = sd(user[,"NR"])

			if (A.rwt==1) {  ## add specified process error
				.flash.cat(paste0("   CV reweight ", nrwt, " -- CPUE ", u, " with CVpro=", cvpro[s]), "\n")
				## Need to subtract if cvpro < 0
				if (cvpro[s] >= 0)
					cpue$CVnew[zu] = sqrt(cpue$CV[zu]^2 + cvpro[s]^2)
				else
					cpue$CVnew[zu] = sqrt(cpue$CV[zu]^2 - cvpro[s]^2)

			} else if (A.rwt==2) { ## use SDNR method
				.flash.cat(paste0("   CV reweight ", nrwt, " -- CPUE ", u, " with SDNR=", SDNR[Useries[uu]]), "\n")
				cpue$CVnew[zu] = user$CV * SDNR[Useries[uu]]

			} else { ## no reweight or no defined method
				#.flash.cat(paste0("   CV reweight ", nrwt, " not performed -- CPUE ", u), "\n")
				cpue$CVnew[zu] = cpue$CV[zu]
			}
		}
	}
	sdnr = rep(0,2); names(sdnr) = c("spa","cpa"); SDNR = c(SDNR,sdnr,dev=sum(abs(1-SDNR)))
	wj   = NULL

	## Composition data -- Commercial proportions-at-age
	## Reweight methods: 0=no reweight, 1=Francis (2011) mean age, 2=SDNR
	CAc  = res$CAc
	cpa  = CAc[!is.na(CAc$SS),]
	## SD and NR not used by Francis' mean weighting but calculated for SDNR reporting anyway
	## No formulae appropriate for composition-data likelihoods due to correlations (Francis 2011, Appendix B, CJFAS)
	cpa$SD = SDfun(cpa$Obs, cpa$SS, A=length(unique(cpa$Sex))*length(unique(cpa$Age)) )
	cpa$NR = NRfun(cpa$Obs, cpa$Fit, cpa$SD, maxR=3, logN=FALSE)

	if (C.rwt==1) {  ## Francis mean age
		.flash.cat(paste0("   AF SS reweight ", nrwt, " using mean age -- commercial"), "\n") ## age frequency sample size
		MAc   = MAfun(cpa) ## commercial mean ages
		Wc    = wfun(MAc)
		wNcpa = Wc$wN
		wtemp = Wc$w
		if (obj@controls$NyrCAc==0)  wtemp[names(wtemp)] = 1
		names(wtemp) = paste0("cpa-",names(wtemp))
		wj = c(wj,wtemp)
#browser();return()

	} else if (C.rwt==2) { ## use SDNR method
		.flash.cat(paste0("   AF SS reweight ", nrwt, " using SDNRs -- commercial"), "\n")
		.flash.cat("   AF reweight by SDNRs -- commercial\n")
		wNcpa = eNfun(cpa$Series,cpa$Year,cpa$Obs,cpa$Fit)

	} else { ## no reweight or no defined method
		#.flash.cat(paste0("   AF SS reweight ", nrwt, " not performed -- commercial"), "\n")
		cpa.tmp = cpa
		cpa.tmp$index = paste(cpa$Series,cpa$Year,sep="-")
		wNcpa = sapply(split(cpa.tmp$SS,cpa.tmp$index),unique)
	}

	SDNR["cpa"] = sd(cpa$NR,na.rm=TRUE)
	if (obj@controls$NyrCAc == 0) SDNR["cpa"] = 0

	## Composition data -- Survey proportions-at-age
	## Reweight methods: 0=no reweight, 1=Francis (2011) mean age, 2=SDNR
	CAs = res$CAs
	spa = CAs[!is.na(CAs$SS),]
	## SD and NR not used by Francis' mean weighting but calculated for SDNR reporting anyway
	## No formulae appropriate for composition-data likelihoods due to correlations (Francis 2011, Appendix B, CJFAS)
	spa$SD = SDfun(spa$Obs, spa$SS, A=length(unique(spa$Sex))*length(unique(spa$Age)) )
	spa$NR = NRfun(spa$Obs, spa$Fit, spa$SD, maxR=3, logN=FALSE)

	if (C.rwt==1) {  ## Francis mean age
		.flash.cat(paste0("   AF SS reweight ", nrwt, " using mean age -- survey"), "\n") ## age frequency sample size
		MAs   = MAfun(spa) ## survey mean ages
		Ws    = wfun(MAs)
		wNspa = Ws$wN
		wtemp = Ws$w
		if (obj@controls$NyrCAs==0) wtemp[names(wtemp)] = 1 
		names(wtemp)=paste("spa-",names(wtemp),sep="")
		wj = c(wj,wtemp)
	} else if (C.rwt==2) { ## use SDNR method
		.flash.cat(paste0("   AF SS reweight ", nrwt, " using SDNRs -- survey"), "\n")
		wNspa = eNfun(spa$Series,spa$Year,spa$Obs,spa$Fit)

	} else { ## no reweight or no defined method
		#.flash.cat(paste0("   AF SS reweight ", nrwt, " not performed -- survey"), "\n")
		spa.tmp = spa
		spa.tmp$index = paste(spa$Series,spa$Year,sep="-")
		wNspa = sapply(split(spa.tmp$SS,spa.tmp$index),unique)
	}

	SDNR["spa"] = sd(spa$NR,na.rm=TRUE)
	if (obj@controls$NyrCAs == 0) SDNR["spa"] = 0

	if (!is.null(dots$sfile)) {
		sfile=dots$sfile
		.flash.cat(paste("\n",dots$fileN," (",paste(names(SDNR),collapse=", "),")\n",sep=""))
		.flash.cat(paste(round(SDNR,5),collapse="\t"),"\n",sep="")  # cat to console
		cat("\n",dots$fileN,"\n",file=sfile,append=TRUE,sep="")
		cat("SDNR: ",paste(round(SDNR,5),collapse="\t"),"\n",file=sfile,append=TRUE,sep="")
		if (!is.null(wj)) {
			.flash.cat(paste("\n","wj (",paste(names(wj),collapse=", "),")\n",sep=""))
			.flash.cat(paste(round(wj,5),collapse="\t"),"\n",sep="")  # cat to console
			cat("wj:   ",paste(round(wj,5),collapse="\t"),"\n",file=sfile,append=TRUE,sep="")
		}
	} 
	#sMAR = MRfun(spa$Year,spa$Age,spa$Obs,spa$Fit) # srvey mean age residuals
	#w = c((1/SDNR)[as.character(c(Sseries,Useries))],(1/SDNR^2)[c("cpa","spa")]) # lognormal and multinomial (Francis)
	#f = c( cpa=CFfun(cpa$Year,cpa$SS,cpa$Age,cpa$Obs,cpa$Fit), spa=CFfun(spa$Year,spa$SS,spa$Age,spa$Obs,spa$Fit) )
	obj@reweight = list(nrwt=nrwt+1,survey=survey,cpue=cpue,wNcpa=wNcpa,wNspa=wNspa,SDNR=SDNR,wj=wj)
	return(obj)
} )
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~setMethod.reweight


##================================================
#out = readSS("input.txt")
#nvec = write(out)

##=== REBS north 2020 ===
## Run46 -- Central run for REBS north (aka BSR).
#outADM=runSS("rebsn_data-46.ss", "rebsn_control-46.ss", strSpp="BSR", runNo=46, doMPD=T, N.reweight=2, A.reweight=c(1,0), C.reweight=c(1,1), A.cvpro=c(0.2759,0.25), clean=F, locode=T)

