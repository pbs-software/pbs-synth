## plotSS.index-------------------------2023-02-17
##  Plot SS model fit to abundance index series
##  Code based on r4ss function 'SSplotIndices'.
## ----------------------------------------r4ss|RH
plotSS.index = function (replist, subplots=c(1:10, 12), plot=TRUE, print=FALSE, 
   fleets="all", fleetnames="default", smooth=TRUE, add=FALSE, 
   datplot=TRUE, labels=list("Year", "Index", "Observed index", 
   "Expected index", "Log index", "Log observed index", 
   "Log expected index", "Standardized index", "Catchability (Q)", 
   "Time-varying catchability", "Vulnerable biomass", "Catchability vs. vulnerable biomass", 
   "Residual", "Deviation"), col1="default", col2="default", 
   col3="blue", col4="red", pch1=21, pch2=16, cex=1, 
   bg="white", legend=TRUE, legendloc="topright", seasnames=NULL, 
   pwidth=9, pheight=7, punits="in", res=400, ptsize=10, PIN=c(9,9),
   cex.main=1, mainTitle=FALSE, plotdir="default", minyr=NULL, 
   maxyr=NULL, maximum_ymax_ratio=Inf, show_input_uncertainty=TRUE, 
   verbose=TRUE, onepage=FALSE, outnam, lang="e", ...) 
{
	oldpar=par(no.readonly=TRUE)
	fart=function(opar) { if (any("windows"%in%names(dev.list()))) par(opar) }
	on.exit(fart(oldpar))

	cpue <- replist$cpue
	SS_versionNumeric <- replist$SS_versionNumeric
	if (is.null(dim(cpue))) {
		message("skipping index plots: no index data in this model")
		return()
	}
	pngfun <- function(file, caption=NA, lang="e") {
		createFdir(lang, dir=plotdir)
		changeLangOpts(L=lang)
		fout = switch(lang, 'e' = file.path(plotdir, file), 'f' = file.path(plotdir,"french", file) )
		clearFiles(fout)
		png(filename=fout, width=pwidth, height=pheight, units=punits, res=res, pointsize=ptsize)
		if (onepage)
			expandGraph(mfrow=rc, mar=c(3,3.5,0.5,0.5), oma=c(0,0,0,0), mgp=c(2,0.5,0))
		else 
			expandGraph(mfrow=c(1,1), mar=c(3,3,1,1), oma=c(0,0,0,0), mgp=c(2,0.5,0))
		plotinfo <- rbind(plotinfo, data.frame(file=file, caption=caption))
		return(plotinfo)
	}
	## Deal with messy label details neglected by original program
	labels.default=list("Year", "Index", "Observed index", "Expected index", "Log index", "Log observed index", "Log expected index", "Standardized index", "Catchability (Q)", "Time-varying catchability", "Vulnerable biomass", "Catchability vs. vulnerable biomass", "Residual", "Deviation")
	names(labels.default)=1:length(labels.default)
	if (is.null(names(labels)))
		names(labels)=1:length(labels)
	labels.new=labels.default
	labels.new[names(labels)]=labels
	labels=labels.new
	nlabs =sapply(labels,countVec) ## how many labels are available
#browser();return()
	get.lab = function(i, j, k=nlabs)
	{
		labels[[i]][min(j,k[i])]
	}
	plotinfo <- NULL

	index.fn <- function(addexpected=TRUE, log=FALSE, l="e", ...) {
		if (error == -1 & log == TRUE) {
			return()
		}
		if (error == 0) {
			if (!log) {
				lower_total <- qlnorm(0.025, meanlog=log(y[include]), sdlog=cpueuse$SE[include])
				upper_total <- qlnorm(0.975, meanlog=log(y[include]), sdlog=cpueuse$SE[include])
			}
			else {
				lower_total <- qnorm(0.025, mean=log(y[include]), sd=cpueuse$SE[include])
				upper_total <- qnorm(0.975, mean=log(y[include]), sd=cpueuse$SE[include])
			}
		}
		if (error == -1) {
			lower_total <- qnorm(0.025, mean=y[include], sd=cpueuse$SE[include])
			upper_total <- qnorm(0.975, mean=y[include], sd=cpueuse$SE[include])
		}
		if (error > 0) {
			lower_total <- log(y[include]) + qt(0.025, df=error) * cpueuse$SE[include]
			upper_total <- log(y[include]) + qt(0.975, df=error) * cpueuse$SE[include]
			if (!log) {
				lower_total <- exp(lower_total)
				upper_total <- exp(upper_total)
			}
		}
		if (max(upper_total) == Inf) {
			warning("Removing upper interval on indices with infinite upper quantile values.\n", 
				"Check the uncertainty inputs for the indices.")
			upper_total[upper_total == Inf] <- 100 * max(cpueuse$Obs[upper_total == 
				Inf])
		}
		main <- paste0(get.lab(2,ifleet), Fleet)
		if (log) {
			main <- paste0(get.lab(5,ifleet), Fleet)
		}
		if (!mainTitle) {
			main <- ""
		}
		xlim <- c(max(minyr, min(x)), min(maxyr, max(x)))
		if (legend & length(colvec1) > 1) {
			xlim[2] <- xlim[2] + 0.25 * diff(xlim)
		}
		if (!add) {
			zmax <- NULL
			if (addexpected) {
				zmin <- min(z, na.rm=TRUE)
			}
			logzrange <- range(log(z))
			if (!log) {
				#ylim <- c(0, 1.05 * min(max(upper_total, zmax, na.rm=TRUE), max(maximum_ymax_ratio * y)))
				ylim <- c(0, 1.05 * min(max(upper_total, max(z), na.rm=TRUE), max(maximum_ymax_ratio * y)))
			}
			if (log) {
				ylim <- range(c(lower_total, upper_total), na.rm=TRUE)
			}
			plot(x=x[include], y=y[include], type="n", xlim=xlim, ylim=ylim, yaxs=ifelse(log, "r", "i"), 
				xlab=linguaFranca(get.lab(1,ifleet),l), ylab=linguaFranca("Abundance Index",l), main=linguaFranca(main,l), cex.main=cex.main, cex.axis=1.2, cex.lab=1.5, ...)
			panlab = ifelse(!log, get.lab(2,ifleet), get.lab(5,ifleet))
			addLabel(0.925, 0.975, linguaFranca(panlab,l), adj=c(1,1), cex=1.5, col="blue")
		}
		if (show_input_uncertainty && any(!is.null(cpueuse$SE_input[include]))) {
			if (error == 0) {
				if (!log) {
					lower_input <- qlnorm(0.025, meanlog=log(y[include]), 
					sdlog=cpueuse$SE_input[include])
					upper_input <- qlnorm(0.975, meanlog=log(y[include]), 
					sdlog=cpueuse$SE_input[include])
				}
				else {
					lower_input <- qnorm(0.025, mean=log(y[include]), 
					sd=cpueuse$SE_input[include])
					upper_input <- qnorm(0.975, mean=log(y[include]), 
					sd=cpueuse$SE_input[include])
				}
			}
			if (error == -1) {
				lower_input <- qnorm(0.025, mean=y[include], 
					sd=cpueuse$SE_input[include])
				upper_input <- qnorm(0.975, mean=y[include], 
					sd=cpueuse$SE_input[include])
			}
			if (error > 0) {
				lower_total <- log(y[include]) + qt(0.025, df=error) * 
					cpueuse$SE_input[include]
				upper_total <- log(y[include]) + qt(0.975, df=error) * 
					cpueuse$SE_input[include]
				if (!log) {
					lower_total <- exp(lower_total)
					upper_total <- exp(upper_total)
				}
			}
			segments(x[include], lower_input, x[include], upper_input, col=colvec1[s], lwd=3, lend=1)
		}
		#arrows(x0=x[include], y0=lower_total, x1=x[include], y1=upper_total, length=0.03, angle=90, code=3, col=colvec1[s])
		arrows(x0=x[include], y0=lower_total, x1=x[include], y1=upper_total, length=0.03, angle=90, code=3, col="black", lwd=2)
		if (!log) {
			#points(x=x[include], y=y[include], pch=pch1, cex=cex, bg=bg, col=colvec1[s])
			points(x=x[include], y=y[include], pch=15, cex=1.2, col="red")
#browser();return()
			if (addexpected) {
				lines(x, z, lwd=2, col=col3)
			}
#browser();return()
		}
		else {
			points(x=x[include], y=log(y[include]), pch=pch1, cex=cex, bg=bg, col=colvec1[s])
			if (addexpected) {
				lines(x, log(z), lwd=2, col=col3)
			}
		}
		if (legend & length(colvec1) > 1) {
			legend(x=legendloc, legend=seasnames, pch=pch1, col=colvec1, cex=cex)
		}
	}

	index_resids.fn <- function(option=1, l="e", ...) {
		if (option == 1) {
			ylab <- get.lab(13,ifleet)
			y <- (log(cpueuse$Obs) - log(cpueuse$Exp))/cpueuse$SE
		}
		if (error == 0 & option == 2) {
			ylab <- get.lab(13,ifleet)
			y <- (log(cpueuse$Obs) - log(cpueuse$Exp))/cpueuse$SE_input
		}
		if (option == 3) {
			ylab <- get.lab(14,ifleet)
			y <- cpueuse$Dev
		}
		main <- paste(ylab, Fleet)
		if (!mainTitle) {
			main <- ""
		}
		xlim <- c(max(minyr, min(x)), min(maxyr, max(x)))
		if (legend & length(colvec1) > 1) {
			xlim[2] <- xlim[2] + 0.25 * diff(xlim)
		}
		#ylim <- c(-1.05, 1.05) * max(abs(y[include]))
		ylim <- c(1.1,1.4) * c(pmin(-1, min(y[include])), pmax(1, max(y[include])))
		if (!add) {
			plot(x=x[include], y=y[include], type="n", xlim=xlim, ylim=ylim, yaxs="i", xlab=linguaFranca(get.lab(1,ifleet),l), ylab=linguaFranca(ylab,l), main=linguaFranca(main,l), cex.main=cex.main, cex.axis=1.25, cex.lab=1.5, ...)
		}
#browser();return()
		ii = grep(ifleet,fleetvec)
		#points(x=x[include], y=y[include], pch=pch1, cex=cex, bg=adjustcolor(colvec1[s], alpha.f=0.7), col=adjustcolor(colvec1[ii], alpha.f=0.7))
		nx = length(x[include])
		abline(h=-10:10, lty=3, col="gainsboro")
		segments (x0=x[include], y0=rep(0,nx), x1=x[include], y1=y[include], lty=5, col="black", lwd=1)
		abline(h=0, lty=1, col="grey60")
		points(x=x[include], y=y[include], pch=21, cex=1.5, col=colvec1[ii], bg=colvec2[ii])
		addLabel(0.975, 0.95, linguaFranca(gsub("_+","  ",fleetnames[ifleet]),l), col="grey30", cex=1.25, adj=c(1,0.25))
#if(ifleet==4) {browser();return()}
		if (legend & length(colvec1) > 1) {
			legend(x=legendloc, legend=linguaFranca(seasnames,l), pch=pch1, pt.bg=colvec1, col=colvec1, cex=cex)
		}
	} ## end index_resids.fn

	obs_vs_exp.fn <- function(log=FALSE, l="e", ...) {
		main <- paste(get.lab(2,ifleet), Fleet, sep=" ")
		if (!mainTitle) {
			main <- ""
		}
		if (!add) {
			if (!log) {
				plot(y[include], z[include], type="n", xlab=linguaFranca(get.lab(3,ifleet),l), 
					ylab=linguaFranca(get.lab(4,ifleet),l), main=linguaFranca(main,l), cex.main=cex.main, 
					ylim=c(0, 1.05 * max(z)), xlim=c(0, 1.05 * max(y)), xaxs="i", yaxs="i", ...)
			}
			else {
				plot(log(y[include]), log(z[include]), type="n", cex.main=cex.main, 
					xlab=linguaFranca(get.lab(6,ifleet),l), ylab=linguaFranca(get.lab(7,ifleet),l), main=linguaFranca(main,l) )
			}
		}
		if (!log) {
			points(y[include], z[include], col=colvec2[s], pch=pch2, cex=cex)
		}
		else {
			points(log(y[include]), log(z[include]), col=colvec2[s], pch=pch2, cex=cex)
		}
		abline(a=0, b=1, lty=3)
		if (smooth && npoints > 6 && diff(range(y)) > 0) {
			if (!log) {
				psmooth <- loess(z[include] ~ y[include], degree=1)
				lines(psmooth$x[order(psmooth$x)], psmooth$fit[order(psmooth$x)], lwd=1.2, col=col4, lty="dashed")
			}
			else {
				psmooth <- loess(log(z[include]) ~ log(y[include]), degree=1)
				lines(psmooth$x[order(psmooth$x)], psmooth$fit[order(psmooth$x)], lwd=1.2, col=col4, lty="dashed")
			}
		}
		if (legend & length(colvec2) > 1) {
			legend(x=legendloc, legend=linguaFranca(seasnames,l), pch=pch2, col=colvec2, cex=cex)
		}
	}

	timevarying_q.fn <- function(l="e") {
		main <- paste(get.lab(10,ifleet), Fleet, sep=" ")
		if (!mainTitle) 
			main <- ""
		q <- cpueuse$Calc_Q
		if (!add) 
			plot(x, q, type="o", cex.main=cex.main, col=colvec2[1], pch=pch2,
				xlab=linguaFranca(get.lab(1,ifleet),l), ylab=linguaFranca(get.lab(9,ifleet),l), main=linguaFranca(main,l) )
	}

	q_vs_vuln_bio.fn <- function(l="e") {
		main <- paste(get.lab(12,ifleet), Fleet, sep=" ")
		if (!mainTitle) 
			main <- ""
		v <- cpueuse$Vuln_bio
		q1 <- cpueuse$Calc_Q
		q2 <- cpueuse$Eff_Q
		if (all(q1 == q2)) 
			ylab <- get.lab(9,ifleet)
		else ylab <- "Effective catchability"
		if (!add) 
			plot(v, q2, type="o", cex.main=cex.main, col=colvec2[1], pch=pch2,
				xlab=linguaFranca(get.lab(11,ifleet),l), ylab=linguaFranca(ylab,l), main=linguaFranca(main,l) )
	}

	if (length(grep("supr_per", cpue$Supr_Per))) {
		warning("Some indices have superperiods. Values will be plotted\n", 
			"in year/season associated with data in report file.")
		cpue <- cpue[!is.na(cpue$Dev), ]
	}
	FleetNames <- replist$FleetNames
	nfleets <- replist$nfleets
	nseasons <- replist$nseasons
	parameters <- replist$parameters
	Q_extraSD_info <- parameters[grep("Q_extraSD", parameters$Label), ]
	nSDpars <- nrow(Q_extraSD_info)
	if (nSDpars > 0) {
		Q_extraSD_info$Fleet <- NA
		for (ipar in 1:nSDpars) {
			if (SS_versionNumeric >= 3.3) {
				num <- strsplit(Q_extraSD_info$Label[ipar], split="[()]", fixed=FALSE)[[1]][2]
			}
			else {
				num <- strsplit(substring(Q_extraSD_info$Label[ipar], nchar("Q_extraSD_") + 1), split="_", fixed=TRUE)[[1]][1]
			}
			Q_extraSD_info$Fleet[ipar] <- as.numeric(num)
		}
	}
	if (nseasons > 1) {
		cpue$YrSeas <- cpue$Yr + (cpue$Seas - 0.5)/nseasons
	}
	else {
		cpue$YrSeas <- cpue$Yr
	}
	if (plotdir == "default") 
		plotdir <- replist$inputs$dir
	if (fleetnames[1] == "default") 
		fleetnames <- FleetNames
	if (fleets[1] == "all") {
		fleets <- 1:nfleets
	}
	else {
		if (length(intersect(fleets, 1:nfleets)) != length(fleets)) {
			return("Input 'fleets' should be 'all' or a vector of values between 1 and nfleets.")
		}
	}
	fleetvec <- intersect(fleets, unique(as.numeric(cpue$Fleet)))
	allcpue <- data.frame()
	any_negative <- FALSE
	
	for (j in subplots) {
		jj  =switch(j,
			"cpuedata", "cpuefit", "obs.vs.exp", "log.cpuedata", "log.cpuefit",
			"log.obs.vs.exp", "time.varying.q", "q.vs.vuln.bio", "stand.cpue.all", "resids.se.total",
			"resids.se.input", "resids.se.total" )
		if (missing(outnam))
			onefile=paste0("index", j, ".", jj, ".", ifelse(j==9,"","fleets"), ".png")
		else
			onefile = paste0(outnam, ".png")
		if (onepage) {
			if (print) {
				createFdir(lang, dir=plotdir)
				changeLangOpts(L=lang)
				fout = switch(lang, 'e' = file.path(plotdir, onefile), 'f' = file.path(plotdir,"french", onefile) )
				clearFiles(fout)
				png(filename=fout, units="in", res=res, width=PIN[1], height=PIN[2])
			}
			rc=.findSquare(length(fleetvec))
			expandGraph(mfcol=rc, mar=c(3,3.5,0.5,1), oma=c(1,0,0,0), mgp = c(2,0.5,0))
			#expandGraph(mfrow=c(length(fleetvec),1), mar=c(3,3,1,1), oma=c(0,0,0,0))
		}
		## Loops through by fleet making it tricky to have multipanel plot
		for (ifleet in fleetvec) {
			usecol <- FALSE
			if (length(unique(cpue$Seas[cpue$Fleet == ifleet])) > 1) {
				usecol <- TRUE
			}
			if (!usecol) {
				legend <- FALSE
			}
			if (col1[1] == "default") {
				colvec1 <- "black"
				if (usecol & nseasons == 4) {
					colvec1 <- c("blue4", "green3", "orange2", "red3")
				}
				if (usecol & !nseasons %in% c(1, 4)) {
					colvec1 <- rich.colors.short(nseasons)
				}
			}
			else {
				colvec1 <- rep(col1,length(fleetvec))[1:length(fleetvec)]
				if (length(colvec1) < nseasons) {
					colvec1 <- rep(col1, nseasons)
				}
			}
			if (col2[1] == "default") {
				colvec2 <- "blue"
				if (usecol & nseasons == 4) {
					colvec2 <- c("blue4", "green3", "orange2", "red3")
				}
				if (usecol & !nseasons %in% c(1, 4)) {
					colvec2 <- rich.colors.short(nseasons)
				}
			}
			else {
				colvec2 <- rep(col2,length(fleetvec))[1:length(fleetvec)]
				if (length(colvec1) < nseasons) {
					colvec1 <- rep(col1, nseasons)
				}
			}
			if (is.null(seasnames)) 
				seasnames <- paste("Season", 1:nseasons, sep="")
			Fleet <- fleetnames[ifleet]
			error <- replist$survey_error[ifleet]
			if (error == 0) {
				error_caption <- "lognormal error"
			}
			if (error == -1) {
				error_caption <- "normal error"
			}
			if (error == 1) {
				error_caption <- paste0("T-distributed error with ", 
					error, " degree of freedom")
			}
			if (error > 1) {
				error_caption <- paste0("T-distributed error with ", 
					error, " degrees of freedom")
			}
			cpueuse <- cpue[cpue$Fleet == ifleet, ]
			cpueuse <- cpueuse[order(cpueuse$YrSeas), ]
			time <- diff(range(cpueuse$Calc_Q)) > 0
			time2 <- diff(range(cpueuse$Eff_Q)) > 0
			if (is.na(time2)) {
				time2 <- FALSE
			}
#browser();return()
			if (exists("Q_extraSD_info") && ifleet %in% Q_extraSD_info$Fleet) {
				cpueuse$SE_input <- cpueuse$SE - Q_extraSD_info$Value[Q_extraSD_info$Fleet == ifleet]
			}
			else {
				cpueuse$SE_input <- NULL
			}
			x <- cpueuse$YrSeas
			y <- cpueuse$Obs
			z <- cpueuse$Exp
			npoints <- length(z)
			include <- !is.na(cpueuse$Like)
#browser();return()
			if (any(include)) {
				if (usecol) {
					s <- cpueuse$Seas[which(include)]
				}
				else {
					s <- 1
				}
				if (datplot) {
					if (min(cpueuse$Obs >= 0)) {
						cpueuse$Index <- rep(ifleet, length(cpueuse$YrSeas))
						cpueuse$stdvalue <- cpueuse$Obs/mean(cpueuse$Obs)
						tempcpue <- cbind(cpueuse$Index, cpueuse$YrSeas, 
						cpueuse$Obs, cpueuse$stdvalue)
						colnames(tempcpue) <- c("Index", "year", "value", "stdvalue")
						allcpue <- rbind(allcpue, tempcpue)
					}
					else {
						if (verbose) {
						message("Excluding fleet ", ifleet, " from index comparison figure because it has negative values")
						}
						any_negative <- TRUE
					}
				}
				addlegend <- function(pch, colvec) {
					names <- paste(seasnames, "observations")
				}
				if (plot) {
					if (1 %in% subplots & datplot)
						index.fn(addexpected=FALSE, l=lang)
					if (2 %in% subplots) 
						index.fn(l=lang)
					if (3 %in% subplots) 
						obs_vs_exp.fn(l=lang)
				}
				if (print && !onepage) {
					if (1 %in% subplots & datplot) {
						file=sub("fleets", tolower(gsub("[[:punct:]]+",".",Fleet)), onefile)
						#file <- paste0("index1_cpuedata_", Fleet, ".png")
						caption <- paste0("Index data for ", Fleet, 
						". ", "Lines indicate 95% uncertainty interval around index values ", 
						"based on the model assumption of ", error_caption, 
						". ", "Thicker lines (if present) indicate input uncertainty before addition of ", 
						"estimated additional uncertainty parameter.")
						plotinfo <- pngfun(file=file, caption=caption, lang=lang)
						index.fn(addexpected=FALSE, l=lang)
						dev.off(); eop()
					}
					if (2 %in% subplots) {
						file <- paste0("index2_cpuefit_", Fleet, ".png")
						caption <- paste0("Fit to index data for ", 
						Fleet, ". ", "Lines indicate 95% uncertainty interval around index values ", 
						"based on the model assumption of ", error_caption, 
						". ", "Thicker lines (if present) indicate input uncertainty before addition of ", 
						"estimated additional uncertainty parameter.")
						plotinfo <- pngfun(file=file, caption=caption, lang=lang)
						index.fn(l=lang)
						dev.off(); eop()
					}
					if (3 %in% subplots) {
						file <- paste0("index3_obs_vs_exp_", Fleet, 
						".png")
						caption <- paste("Observed vs. expected index values with smoother for", 
						Fleet)
						plotinfo <- pngfun(file=file, caption=caption, lang=lang)
						obs_vs_exp.fn(l=lang)
						dev.off(); eop()
					}
				}
				if (error != -1) {
					if (plot) {
						if (4 %in% subplots & datplot) {
						index.fn(log=TRUE, addexpected=FALSE, l=lang)
						}
						if (5 %in% subplots) {
						index.fn(log=TRUE, l=lang)
						}
						if (6 %in% subplots) {
						obs_vs_exp.fn(log=TRUE, l=lang)
						}
					}
					if (print) {
						if (4 %in% subplots & datplot) {
						file <- paste0("index4_logcpuedata_", Fleet, 
							".png")
						caption <- paste0("Log index data for ", 
							Fleet, ". ", "Lines indicate 95% uncertainty interval around index values ", 
							"based on the model assumption of ", error_caption, 
							". ", "Thicker lines (if present) indicate input uncertainty before addition of ", 
							"estimated additional uncertainty parameter.")
						plotinfo <- pngfun(file=file, caption=caption, lang=lang)
						index.fn(log=TRUE, addexpected=FALSE, l=lang)
						dev.off(); eop()
						}
						if (5 %in% subplots) {
						file <- paste0("index5_logcpuefit_", Fleet, 
							".png")
						caption <- paste0("Fit to log index data on log scale for ", 
							Fleet, ". ", "Lines indicate 95% uncertainty interval around index values ", 
							"based on the model assumption of ", error_caption, 
							". ", "Thicker lines (if present) indicate input uncertainty before addition of ", 
							"estimated additional uncertainty parameter.")
						plotinfo <- pngfun(file=file, caption=caption, lang=lang)
						index.fn(log=TRUE, l=lang)
						dev.off(); eop()
						}
						if (6 %in% subplots) {
						file <- paste0("index6_log_obs_vs_exp_", 
							Fleet, ".png")
						caption <- paste("log(observed) vs. log(expected) index values with smoother for", 
							Fleet)
						plotinfo <- pngfun(file=file, caption=caption, lang=lang)
						obs_vs_exp.fn(log=TRUE, l=lang)
						dev.off(); eop()
						}
					}
				}
				if (plot) {
					if (7 %in% subplots & time) {
						timevarying_q.fn(l=lang)
					}
					if (8 %in% subplots & time2) {
						q_vs_vuln_bio.fn(l=lang)
					}
				} ## end plot
				if (print) {
					if (7 %in% subplots & time) {
						file <- paste0("index7_timevarying_q_", Fleet, 
						".png")
						caption <- paste("Timeseries of catchability for", 
						Fleet)
						plotinfo <- pngfun(file=file, caption=caption, lang=lang)
						timevarying_q.fn(l=lang)
						dev.off(); eop()
					}
					if (8 %in% subplots & time2) {
						file <- paste0("index8_q_vs_vuln_bio_", Fleet, ".png")
						caption <- paste0("Catchability vs. vulnerable biomass for fleet ", 
						Fleet, "<br> \n", "This plot should illustrate curvature of nonlinear catchability relationship<br> \n", 
						"or reveal patterns associated with random-walk catchability.")
						plotinfo <- pngfun(file=file, caption=caption, lang=lang)
						q_vs_vuln_bio.fn(l=lang)
						dev.off(); eop()
					}
				} ## end print
				if (plot) {
					if (10 %in% subplots) {
						index_resids.fn(option=1, l=lang)
					}
					if (11 %in% subplots) {
						index_resids.fn(option=2, l=lang)
					}
					if (12 %in% subplots) {
						index_resids.fn(option=3, l=lang)
					}
				} ## edn plot
				if (print) {
					if (10 %in% subplots && !onepage) {
						file <- paste0("index10_resids_SE_total_", Fleet, ".png")
						caption <- paste0("Residuals of fit to index for ", Fleet, ".")
						if (error == 0) {
							caption <- paste0(caption, "<br>Values are (log(Obs) - log(Exp))/SE ", 
							"where SE is the total standard error including any ", "estimated additional uncertainty.")
						}
						else {
							caption <- paste0(caption, "<br>Values are based on the total standard error ", 
							"including any estimated additional uncertainty.")
						}
						plotinfo <- pngfun(file=file, caption=caption, lang=lang)
						index_resids.fn(option=1, l=lang)
						dev.off(); eop()
					} else if (10 %in% subplots && onepage) {
						index_resids.fn(option=1, l=lang)
					}
					if (11 %in% subplots & show_input_uncertainty && 
						any(!is.null(cpueuse$SE_input[include])) && 
						any(cpueuse$SE_input > cpueuse$SE)) {
						file <- paste0("index11_resids_SE_input_", 
						Fleet, ".png")
						caption <- paste0("Residuals for fit to index for ", 
						Fleet, ".")
						if (error == 0) {
						caption <- paste0(caption, "<br>Values are (log(Obs) - log(Exp))/SE_input ", 
							"where SE_input is the input standard error", 
							"excluding any estimated additional uncertainty.")
						}
						else {
						caption <- paste0(caption, "<br>Values are based on the input standard error ", 
							"excluding any estimated additional uncertainty.")
						}
						plotinfo <- pngfun(file=file, caption=caption, lang=lang)
						index_resids.fn(option=2, l=lang)
						dev.off(); eop()
					}
					if (12 %in% subplots) {
						file <- paste0("index12_resids_SE_total_", Fleet, ".png")
						caption <- paste0("Deviations for fit to index for ", 
						Fleet, ".")
						if (error != -1) {
						caption <- paste0(caption, "<br>Values are log(Obs) - log(Exp) ", 
							"and thus independent of index uncertainty.")
						}
						if (error == -1) {
						caption <- paste0(caption, "<br>Values are Obs - Exp ", 
							"and thus independent of index uncertainty.")
						}
						plotinfo <- pngfun(file=file, caption=caption, lang=lang)
						index_resids.fn(option=3, l=lang)
						dev.off(); eop()
					}
				} ## end print
			} ## end include
		} ## end ifleet
		if (onepage && print) {dev.off(); eop()}
	} ## end j in  subplots
	if (datplot == TRUE & nrow(allcpue) > 0) {
		all_index.fn <- function(l="e") {
			main <- "All index plot"
			if (!mainTitle) {
				main <- ""
			}
			xlim <- c(min(allcpue$year, na.rm=TRUE) - 1, max(allcpue$year, na.rm=TRUE) + 1)
			xlim[1] <- max(xlim[1], minyr)
			xlim[2] <- min(xlim[2], maxyr)
			ylim <- c(range(allcpue$stdvalue, na.rm=TRUE))
			usecols <- rich.colors.short(max(allcpue$Index, na.rm=TRUE), alpha=0.7)
			if (max(allcpue$Index, na.rm=TRUE) >= 2) {
				usecols <- rich.colors.short(max(allcpue$Index, na.rm=TRUE) + 1, alpha=0.7)[-1]
			}
			if (!add) 
				plot(0, type="n", xlab=get.lab(1,ifleet), main=main, cex.main=cex.main, col=usecols[1], ylab=get.lab(8,ifleet), xlim=xlim, ylim=ylim)
			for (ifleet in fleetvec) {
				points(x=allcpue$year[allcpue$Index == ifleet], 
					y=allcpue$stdvalue[allcpue$Index == ifleet], 
					pch=pch2, col=usecols[ifleet], cex=cex, 
					lwd=1, lty="dashed", type="o")
			}
		}
		if (plot & (9 %in% subplots)) {
			all_index.fn(l=lang)
		}
		if (print & (9 %in% subplots)) {
			file <- paste0("index9_standcpueall", ".png")
			caption <- paste("Standardized indices overlaid.", 
				"Each index is rescaled to have mean observation=1.0.")
			if (any_negative) {
				caption <- paste(caption, "Indices with negative observations have been excluded.")
			}
			plotinfo <- pngfun(file=file, caption=caption, lang=lang)
			all_index.fn(l=lang)
			dev.off(); eop()
		}
	}
	if (!is.null(plotinfo)) 
		plotinfo$category <- "Index"
	return(invisible(plotinfo))
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~plotSS.index

## NOTE!!!! Must include a label for every fleet, regardless of whether it has an index series or not.

#plotSS.index(replist, subplots=2, onepage=F, print=T, plotdir=getwd(), labels=list("Year",c("Trawl Fishery","Other Fishery","WCHG Synoptic Survey")), fleets=1)
#for (l in c("f")) {
#	if (strSpp %in% c("440","YMR")) {
#		if (assyr==2011)
#			plotSS.index(replist, subplots=2, onepage=T, print=T, plotdir=getwd(), labels=list("Year",c("Trawl Fishery", "GIG Historical", "QCS Synoptic", "QCS Shrimp", "WCHG Synoptic", "WCVI Synoptic")), fleets=2:6, pwidth=5, pheight=6.5, outnam="survIndSer", lang=l)
#		else 
#			plotSS.index(replist, subplots=2, onepage=T, print=T, plotdir=getwd(), labels=list("Year",c("Trawl+ Fishery","QCS Synoptic","WCVI Synoptic","WCHG Synoptic","GIG Historical")), fleets=2:5, pwidth=5, pheight=6.5, outnam="survIndSer", lang=l)
#	}
#	if (strSpp %in% c("REBS","REBSN")) {
#		plotSS.index(replist, subplots=2, onepage=T, print=T, plotdir=getwd(), labels=list("Year",c("Trawl Fishery","Other Fishery","WCHG Synoptic")), fleets=1:3, pwidth=5, pheight=6.5, outnam="survIndSer", lang=l)
#	}
#}

#plotSS.index(replist, subplots=2, onepage=T, plot=T, print=F, plotdir=getwd(), labels=list("Year",fleets.lab), fleets=fleets.idx, PIN=c(9,9), outnam="test", lang="e")
#plotSS.index(replist, subplots=2, onepage=T, print=T, plotdir=getwd(), labels=list("Year",fleets.lab), fleets=9, PIN=c(9,7), outnam="PDO.as.Abundance", lang="e")
#plotSS.index(replist, subplots=10, onepage=T, print=T, plot=F, plotdir=getwd(), labels=list("Year",fleets.lab), fleets=fleets.idx, PIN=c(9,9), lang="e", col1=c("red","green4","blue","red","green4","green4"), col2=c("pink","green","cyan","pink","green","green"), outnam="survRes")

