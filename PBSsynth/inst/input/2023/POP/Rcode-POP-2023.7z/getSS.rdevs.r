## getSS.rdevs-------------------------2023-10-13
##  Get reruitment deviations from replist
## ----------------------------------------r4ss|RH
getSS.rdevs = function (replist, forecast=FALSE, minyr=-Inf, maxyr=Inf) 
{
	parameters    <- replist$parameters
	recruit       <- replist$recruit
	startyr       <- replist$startyr
	endyr         <- replist$endyr
	sigma_R_in    <- replist$sigma_R_in
	recdevEarly   <- parameters[substring(parameters$Label, 1, 13) %in% c("Early_RecrDev"), ]
	early_initage <- parameters[substring(parameters$Label, 1, 13) %in% c("Early_InitAge"), ]
	main_initage  <- parameters[substring(parameters$Label, 1, 12) %in% c("Main_InitAge"), ]
	recdev        <- parameters[substring(parameters$Label, 1, 12) %in% c("Main_RecrDev"), ]
	recdevFore    <- parameters[substring(parameters$Label, 1, 8) == "ForeRecr", ]
	recdevLate    <- parameters[substring(parameters$Label, 1, 12) == "Late_RecrDev", ]
	ttput(recruit)
#browser();return()

	recdev$Yr <- as.numeric(substring(recdev$Label, 14))
	if (nrow(recdevEarly) > 0) {
		recdevEarly$Yr <- as.numeric(substring(recdevEarly$Label, 15))
	}
	else {
		recdevEarly$Yr <- integer(0)
	}
	if (nrow(early_initage) > 0) {
		early_initage$Yr <- startyr - as.numeric(substring(early_initage$Label, 15))
		recdevEarly <- rbind(early_initage, recdevEarly)
	}
	if (nrow(main_initage) > 0) {
		main_initage$Yr <- startyr - as.numeric(substring(main_initage$Label, 14))
		recdev <- rbind(main_initage, recdev)
	}
	if (nrow(recdevFore) > 0) {
		recdevFore$Yr <- as.numeric(substring(recdevFore$Label, 10))
	} else {
		recdevFore$Yr <- NULL
	}
	if (nrow(recdevLate) > 0) {
		recdevLate$Yr <- as.numeric(substring(recdevLate$Label, 14))
		recdevFore <- rbind(recdevLate, recdevFore)
	}
	Yr <- c(recdevEarly$Yr, recdev$Yr, recdevFore$Yr)
	if (forecast) {
		goodyrs <- ifelse(Yr >= minyr & Yr <= maxyr, TRUE, FALSE)
	} else {
		goodyrs <- Yr <= endyr + 1 & Yr >= minyr & Yr <= maxyr
	}
	alldevs <- rbind(recdevEarly, recdev, recdevFore)[goodyrs,]
	recdevs =  alldevs[,c("Yr","Value","Parm_StDev")]
#browser();return()
	ttput(recdevs)
	return(invisible(recdevs))
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~getSS.rdevs

#require(r4ss)
#replist.21v3a = SS_output(dir="C:/Users/haighr/Files/GFish/PSARC23/POP/Data/SS/POP2023/Run21/MPD.21.01.v3")
#getSS.rdevs(replist.21v3a)
#R21v3a = ttget(recruit)
#replist.21v5a = SS_output(dir="C:/Users/haighr/Files/GFish/PSARC23/POP/Data/SS/POP2023/Run21/MPD.21.01.v5")
#getSS.rdevs(replist.21v5a)
#R21v5a = ttget(recruit)



