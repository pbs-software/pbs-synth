## calcMA-------------------------------2023-08-31
## Calculate indicators for fits to mean age data.
## -----------------------------------------PJS|RH
calcMA = function(runs=1, rwts=0:1, vers=1, overwrite=FALSE, fleets.lab, fleets.af,
   cwd="C:/Users/haighr/Files/GFish/PSARC23/POP/Data/SS/POP2023")
{
	so("plotSS.francis.r","synth")
	require(r4ss)
	mean.age.ind = list()
	for (i in runs) {
		ii = pad0(i,2)
		for (j in rwts) {
			jj = pad0(j,2)
			for (k in vers) {
				kk =paste0("v",k)
				setwd(paste0(cwd, "/Run", ii, "/MPD.", ii, ".", jj, ".", kk))
				replist=SS_output(dir=getwd(), verbose=F, printstats=F)
				francis = plotSS.francis(replist, "age", fleet=fleets.af, printit=F, plotit=F, png=F, outnam="rubbish", lang="e")  ##bt_cpue, qcs_syn, wcvi_syn, nmfs_tri

				if (overwrite)
					write.csv(francis$agedat, file=paste0("mean.ages.",ii,".",jj,".",kk,".csv"))
				sum.res.flt = sapply(split(francis$agedat$Std.res,francis$agedat$Fleet),sum)
				sum.res.tot = sum(sum.res.flt)
#browser();return()
				pjs.res.flt = sapply(split(francis$agedat,francis$agedat$Fleet),function(x){sum(abs(x$Obsmn-x$Expmn))})
				pjs.res.tot = sum(pjs.res.flt)
				age.ind = data.frame(Run_Rwt_Ver=paste0("R.",ii,".",jj,".",kk), Fleet=c(fleets.lab[fleets.af],"Total"), Sum_Std_Res=c(sum.res.flt,sum.res.tot), Sum_PJS_Res=c(pjs.res.flt,pjs.res.tot))
				mean.age.ind = rbind(mean.age.ind, age.ind)
			}  ## end i loop
		}  ## end j loop
	}  ## end k loop
	return(mean.age.ind)
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~calcMA
#mean.age.index = calcMA(runs=1:14,rwts=1, fleets.lab=c("Trawl Fishery","Other Fishery","QCS Synoptic","WCVI Synoptic","NMFS Triennial","HS Synoptic","WCHG Synoptic","GIG Historical"), fleets.af=c(1,3:5))
#mean.age.index = calcMA(runs=34,rwts=0, fleets.lab=c("Trawl Fishery","Other Fishery","QCS Synoptic","WCVI Synoptic","NMFS Triennial","HS Synoptic","WCHG Synoptic","GIG Historical"), fleets.af=c(1,3:7))
#out = calcMA(runs=run, rwts=rwt, overwrite=TRUE, fleets.lab=fleets.lab, fleets.af=fleets.af)
#tab6  = calcMA(runs=run, rwts=rwt, overwrite=TRUE, fleets.lab=fleets.lab, fleets.af=fleets.af)
