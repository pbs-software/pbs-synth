## agileDT------------------------------2023-09-28
##  Produce agile decision tables for projections 
##  compared to reference points (using function 'findTarget')
## ---------------------------------------------RH
agileDT =function(compo, currYear=2024, projYear=2034, Ngen=3, gen1=25,
   area=c("5ABC","3CD","5DE"), cp=paste0("CC.", pad0(1:3,2)), 
   onepage=TRUE, tables.per.page=3, outnam, sigdig=2 )
{
	unpackList(compo, scope="L")
	is.good = apply(xavgRP,1,function(x){all(is.finite(x))})
	if (sum(is.good)!=nrow(xavgRP))
		.flush.cat(paste0(nrow(xavgRP)-sum(is.good)," unsuitable records dropped."), "\n")
	xavgRP = xavgRP[is.good,,area,drop=FALSE]
	xavgPJ = xavgPJ[is.good,,,area,,drop=FALSE]
	xavgTS = xavgTS[is.good,,,area,drop=FALSE]
	Nmcmc  = nrow(xavgRP)

	## All B targets include area dimension
	subarray = function(arr, ipos, inam, kpos) {  ## kpos = keep these dimension positions
		adim  = dim(arr)
		anam  = dimnames(arr)
		apos  = 1:length(adim)
		inam  = paste0("^",inam,"$")  ## to get exact match
		if (any(grepl(inam,anam[[ipos]]))) {
			indx = grep(inam,anam[[ipos]])
			if (length(indx)!=1) { message("Fix 'ipos'"); browser(); return() }
			if (missing(kpos)) kpos = apos[-ipos]
			nnam = anam[kpos]           ## new dimnames
			ndim = sapply(nnam, length) ## new dimension
			mess = rep("",length(adim))
			mess[ipos] = indx
			mess = paste0("arr[",paste0(mess,collapse=","),"]")
			mess = paste0("out = array(", mess, ", dim=ndim, dimnames=nnam)")
#browser();return()
			eval(parse(text=mess))
			return(out)
		} else {
			return(arr)
		}
	}
	#Bmsy  = xavgRP[,"Bmsy",area]
	#Bcurr = xavgPJ[,as.character(currYear),"B",area,1,drop=FALSE]
	#B0    = xavgRP[,"B0",area]
	#Umsy  = xavgRP[,"umsy",area]
	#Ucurr = xavgPJ[,as.character(currYear),"u",area,1]
	Bmsy  = subarray(xavgRP,2,"Bmsy")
	B0    = subarray(xavgRP,2,"B0")
	Umsy  = subarray(xavgRP,2,"umsy")
	Bcurr = subarray(xavgPJ[,as.character(currYear),,,1,drop=FALSE], ipos=3, inam="B", kpos=c(1,4))
	Ucurr = subarray(xavgPJ[,as.character(currYear),,,1,drop=FALSE], ipos=3, inam="u", kpos=c(1,4))

	#Btab  = xavgPJ[,as.character(currYear:projYear),"B",area,cp,drop=FALSE]
	#Utab  = xavgPJ[,as.character(currYear:projYear),"u",area,cp,drop=FALSE]
	Btab  = subarray(xavgPJ[,as.character(currYear:projYear),,,cp,drop=FALSE], ipos=3, inam="B", kpos=c(1,2,4,5))
	Utab  = subarray(xavgPJ[,as.character(currYear:projYear),,,cp,drop=FALSE], ipos=3, inam="u", kpos=c(1,2,4,5))
	if (length(cp)==1 && all(cp=="AC.00"))
		cvec  = as.vector(t(compo$xavgCP[1,1:length(area),1]))
	else
		cvec  = as.vector(t(compo$xavgCP[1,1:length(area),(1:length(cp))+1]))
	#cvec  = as.vector(t(compo$xavgCP[1,1:length(area),dim(compo$xavgCP)[3]]))
	big.mark = ifelse(is.null(options()$big.mark), ",", options()$big.mark)
	Cvec  = formatC(cvec, digits=0, format="f", big.mark=big.mark)
#browser();return()

	## List of targets:
	Blst = list(
	  list(ratio=0.4,target=Bmsy),
	  list(ratio=0.8,target=Bmsy),
	  list(ratio=1.0,target=Bmsy),
	  list(ratio=1.0,target=Bcurr),
	  list(ratio=0.2,target=B0),
	  list(ratio=0.4,target=B0),
	  ##---COSEWIC---
	  list(ratio=0.5,target=B0),
	  list(ratio=0.7,target=B0),
	  list(ratio=0.3,target=xavgTS[,,"B",]),
	  list(ratio=0.5,target=xavgTS[,,"B",])
	)
	names(Blst)=c("0.4Bmsy","0.8Bmsy","Bmsy","Bcurr","0.2B0","0.4B0","0.5B0","0.7B0","0.3Gen","0.5Gen")

	## Populate BRP -- P(B > RPs)
	for (i in 1:length(area)) {
		ii = area[i]
		for (j in 1:length(cp)) {
			jj = cp[j]
			ijBRP = sapply(Blst,function(x,aa,pp){
#if(length(dim(x$target))>2) {browser();return() }
				targ = if (length(dim(x$target))==2) x$target[,aa] else x$target[,,aa]
#.flush.cat(x$ratio, "\n")
				out = findTarget(Btab[,,aa,pp], ratio=x$ratio, target=targ, retVal="p.hi", op=">", yrG=Ngen*gen1)
				return(out)
				}, aa=ii, pp=jj, simplify=FALSE)
			if (i==1 && j==1) {
				BRP = array(NA, dim=c(length(cp), length(names(ijBRP[[1]])), length(area), length(ijBRP)), dimnames=list(cp=cp, year=names(ijBRP[[1]]), area=area, refpt=names(ijBRP) ) )
			}
			sapply(names(ijBRP), function(xx){BRP[jj,,ii,xx] <<- ijBRP[[xx]] })
		} ## end j loop (catch policy)
	}  ## end i loop (area)

	lsum = 0; lout = character(); agile=list()
	for (l in 1:length(dimnames(BRP)$refpt)) {
		ll = dimnames(BRP)$refpt[l]
		#prb  = BRP[,,,ll,drop=F]
		prb  = subarray(BRP, ipos=4, inam=ll, kpos=1:3)
		dns  = dimnames(prb); dns[[2]] = c("CC(t/y)",dns[[2]])
		prb2 = array(NA, dim=sapply(dns,length), dimnames=dns)
		prb2[,-1,] = prb
		prb2[,1,]  = cvec  ## insert catches for each policy by area
		lll = sub("Gen", paste0("B_{0,\\\\text{G}=",Ngen,"}"), sub("curr", paste0("_{",currYear,"}"), sub("B0", "B_0", sub("msy","_\\\\text{MSY}", sub("USR", "0.8Bmsy", sub("LRP", "0.4Bmsy", ll ))))))
		lll = paste0("$", lll, "$")
		tabcap = paste0("Probability $B_t$ > ", lll)
		tex = texArray(prb2, sigdig=sigdig, use.round=T, zero="0", use.row.names=F, name.row.names="", add.header.column=T, new.header=area, outnam=ll, table.caption=tabcap)
		agile[[ll]] = tex
		lout = c(lout, paste0(ll, c(".tex","+.tex")))
#browser();return()
		## Aside: Geometry can be changed
		#texfile = readLines(paste0(ll, "+.tex"))
		#gline = grep("geometry",texfile)
		#texfile[gline] = sub("\\]\\{geometry\\}", ", paperheight=3in]{geometry}", texfile[gline])
		#writeLines(texfile, con="test.tex")
		#cmd1 = paste0("pdflatex.exe -quiet test.tex")
		#cmd2 = paste0("latexmk.exe  -c test.tex")
		if (onepage) {
			## Collect tex code to display decision tables in one pdf
			if (l==1) {
				onefile = tex$texfile
				onefile = onefile[-length(onefile)]  ## get rid of \\end{document}
			} else {
				onefile = c(onefile, ifelse(l%%tables.per.page==1, "\\clearpage", "\\bigskip"), tex$tabfile)
				#onefile = c(onefile, ifelse(l%%3==1, "\\clearpage", "\\bigskip"), tex$tabfile)
			}
		} else {
			cmd1 = paste0("pdflatex.exe -quiet ", ll, "+.tex")
			cmd2 = paste0("latexmk.exe  -c ", ll, "+.tex")
			system(command=cmd1, intern=TRUE, wait=TRUE)
			system(command=cmd2, intern=TRUE, wait=TRUE)
		}  ## end if onepage
		lsum =lsum + 1
	}  ## end l loop through BRP

	## And have to do separately for u_t < u_MSY:
	Ulst = list(
	  list(ratio=1, target=Umsy),
	  list(ratio=1, target=Ucurr)
	)
	names(Ulst) = c("umsy","ucurr")

	## Populate URP -- P(u < RPs)
	for (i in 1:length(area)) {
		ii = area[i]
		for (j in 1:length(cp)) {
			jj = cp[j]
			ijURP = sapply(Ulst,function(x,aa,pp){
				targ = if (length(dim(x$target))==2) x$target[,aa] else x$target[,,aa]
				findTarget(Utab[,,aa,pp], ratio=x$ratio, target=targ, retVal="p.hi", op="<", yrG=Ngen*gen1)
				}, aa=ii, pp=jj, simplify=FALSE)
			if (i==1 && j==1) {
				URP = array(NA, dim=c(length(cp), length(names(ijURP[[1]])), length(area), length(ijURP)), dimnames=list(cp=cp, year=names(ijURP[[1]]), area=area, refpt=names(ijURP) ) )
			}
			sapply(names(ijURP), function(xx){URP[jj,,ii,xx] <<- ijURP[[xx]] })
		} ## end j loop (catch policy)
	}  ## end i loop (area)

	for (l in 1:length(dimnames(URP)$refpt)) {
		ll = dimnames(URP)$refpt[l]
		#prb  = URP[,,,ll]
		prb  = subarray(URP, ipos=4, inam=ll, kpos=1:3)
		dns  = dimnames(prb); dns[[2]] = c("CC(t/y)",dns[[2]])
		prb2 = array(NA, dim=sapply(dns,length), dimnames=dns)
		prb2[,-1,] = prb
		prb2[,1,]  = cvec  ## insert catches for each policy by area
		lll = sub("curr", paste0("_{",currYear,"}"), sub("msy","_\\\\text{MSY}", ll))
		lll = paste0("$", lll, "$")
		tabcap = paste0("Probability $u_t$ < ", lll)
		tex = texArray(prb2, sigdig=sigdig, use.round=T, zero="0", use.row.names=F, name.row.names="", add.header.column=T, new.header=area, outnam=ll, table.caption=tabcap)
		agile[[ll]] = tex
		lout = c(lout, paste0(ll, c(".tex","+.tex")))
		if (onepage) {
			## Collect tex code to display decision tables in one pdf
#.flush.cat(ll, (lsum+l)%%tables.per.page, "\n", sep=", ")
			onefile = c(onefile, ifelse((lsum+l)%%tables.per.page==1, "\\clearpage", "\\bigskip"), tex$tabfile)
		} else {
			cmd1 = paste0("pdflatex.exe -quiet ", ll, "+.tex")
			cmd2 = paste0("latexmk.exe  -c ", ll, "+.tex")
			system(command=cmd1, intern=TRUE, wait=TRUE)
			system(command=cmd2, intern=TRUE, wait=TRUE)
		}  ## end if onepage
	}  ## end l loop through URP

	## Compile one-page pdf with multiple decision tables
	if (onepage) {
		onefile = c(onefile, "\\end{document}")
		if (missing(outnam))
			outnam =  paste0("DT-(",currYear,"-",projYear,")-(",paste0(area,collapse=","),")")
		writeLines(onefile, con=paste0(outnam,".tex"))
		cmd1 = paste0("pdflatex.exe -quiet ", outnam, ".tex")
		cmd2 = paste0("latexmk.exe  -c ", outnam, ".tex")
		system(command=cmd1, intern=TRUE, wait=TRUE)
		system(command=cmd2, intern=TRUE, wait=TRUE)
#browser();return()
	}

	ttput(agile) ## save tex table results for use by other programs
	ttput(Nmcmc)
	save("agile", "is.good", "Nmcmc", file=paste0(outnam, ".rda"))

	lout.remove = paste0(lout, collapse=" ")
	system(command=paste0("rm -f ", lout.remove), intern = TRUE)
#browser();return()
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~agileDT

so("formatCatch.r"); so("texArray.r"); so("findTarget.r","synth")
#load("compo.230907.rda")  ## R21v2a
#load("compo.230908.rda")  ## R17v17a
#load("compo.230925.rda")  ## R21v3a
#currYear=2024
#agileDT(compo=compo, onepage=T, cp="AC.00", tables.per.page=6)
#agileDT(compo=compo, onepage=T, cp=paste0("CC.", pad0(1:7,2)), tables.per.page=2)