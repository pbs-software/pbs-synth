## convPN-------------------------------2023-02-14
##  Convert SS3 parameter names to Awatea (or simpler) names.
##  2023 modification for 3-area POP.
## ---------------------------------------------RH
convPN = function(pnams) {
	cnams =
		sub("RecrDist_GP_(\\d+)_area_(\\d+)_month_(\\d+)","Rdist_area(\\2)",
		sub("\\)_Age_P(\\d+)","_\\1)",
		sub("_steep","_h",
		sub("NatM_break_(\\d+)?_Fem_GP_(\\d+)","M\\1_Female_GP\\2",
		sub("NatM_break_(\\d+)?_Mal_GP_(\\d+)","M\\1_Male_GP\\2",
		sub("NatM_p_1_Fem_GP_(\\d+)|NatM_uniform_Fem_GP_(\\d+)", "M_Female_gp(\\1\\2)",
		sub("NatM_p_1_Mal_GP_(\\d+)|NatM_uniform_Mal_GP_(\\d+)", "M_Male_gp(\\1\\2)",
		sub("Early_RecrDev|Main_RecrDev|Late_RecrDev|ForeRecr","RecrDev",
		sub("(_TRAWL|_OTHER)?_FISHERY(_5ABC|_3CD|_5DE)?","\\1\\2", 
		sub("SYNOPTIC","",
		sub("HISTORIC(AL)?","",
		sub("TRIENNIAL","",
		sub("HBLL_NORTH","HBLLN_",
		sub("HBLL_SOUTH","HBLLS_",
		sub("^AgeSel_(\\d+)?(Male|Fem)_Scale","delta5(\\1)",
		sub("^AgeSel_(\\d+)?(Male|Fem)_Final","delta4(\\1)",
		sub("^AgeSel_(\\d+)?(Male|Fem)_Descend","delta3(\\1)",
		sub("^AgeSel_(\\d+)?(Male|Fem)_Ascend","delta2(\\1)",
		sub("^AgeSel_(\\d+)?(Male|Fem)_Peak","delta1(\\1)",
		sub("^Age_DblN_end_logit","beta6",
		sub("^Age_DblN_top_logit","beta2",
		sub("^Age_DblN_descend_se","varR",
		sub("^Age_DblN_ascend_se","varL",
		sub("^Age_DblN_peak","mu",
		sub("^SR_","",
		pnams)))))))))))))))))))))))))
		onams   = sapply(strsplit(cnams,"_"), function(x){
		if(length(x)==3 && x[1] %in% c("mu","beta2","varL","varR","beta6")) {
			if (grepl("5ABC|3CD|5DE", x[3])) {
				paste0(x[1], sub("5ABC|3CD|5DE","",x[3]), "_", x[2], "_", sub("\\(\\d+\\)","",x[3]))
#browser();return()
			} else {
				paste0(x[1],x[3],"_",x[2])
			}
		} else {
			paste0(x,collapse="_")
		}
	})
#browser();return()
	onams = sub("^M1_", "M_", onams)
	return(onams)
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~convPN

#parameters = replist$parameters
#pactive = parameters[!is.na(parameters$Active_Cnt) & parameters$Phase>0 & !is.element(parameters$Pr_type,"dev"),]
#fornow = convPN(pactive$Label)

#d.mcmc = SSgetMCMC(getwd()); test=colnames(d.mcmc)
#test = pactive$Label
#fornow = convPN(test)
#fornow = convPN(pactive$Label); print(fornow)

#fornow = convPN(c("NatM_uniform_Fem_GP_1", "NatM_uniform_Fem_GP_2", "NatM_uniform_Fem_GP_3", "NatM_uniform_Mal_GP_1", "NatM_uniform_Mal_GP_2", "NatM_uniform_Mal_GP_3")); print(fornow)


