## repeatMPD----------------------------2022-05-26
## Repeat MPDs for axes of uncertainty to visualise likelihood density.
## Need to run from a specific Likelihood directory withing RunNN.
## ---------------------------------------------RH
repeatMPD = function(Pfix=list(FFF=seq(0.05,0.06,0.01), MMM=seq(0.05,0.06,0.01), RRR=NULL), A=60, 
   dir=getwd(), dir.pro, prefix="control.MMM.", clean=FALSE, 
   strSpp="CAR", argsMPD="")
{
	## Start subfunctions
	## Determine number of decimal places with non-trailing zeroes
	## See user 'darocsig' @ https://stackoverflow.com/questions/5173692/how-to-return-number-of-decimal-places-in-r
	decimalplaces <- function(x) {
		dc = as.character(); dp = as.numeric()
		for (xx in x) {
#if(xx==0.10) {browser();return()}
			if (abs(xx - round(xx)) > .Machine$double.eps^0.5) {
				dc = c(dc, strsplit(sub('0+$', '', as.character(xx)), ".", fixed = TRUE)[[1]][2] )
				dp = c(dp, nchar(strsplit(sub('0+$', '', as.character(xx)), ".", fixed = TRUE)[[1]][2]) )
			} else {
				dc = c(dc, NA)
				dp = c(dp, 0)
			}
		}
		## Automatically determine minimum number of decimal places to yield unique values
		udp = max(dp) + 1
		for (i in max(dp):1){
			#print(length(unique(round(x,i)))==length(x))
			if (length(unique(round(x,i))) == length(x) && !any(round(x,i)==0))
				udp = udp - 1
		}
#browser() ;return()
		return(list(dc=dc, dp=dp, mindp=udp))
	}
	cleanup = function(){
		junkpat = c("^admodel","^ss\\.","\\.log$","\\.sso$","\\.ss_new$","\\.png$","\\.bak$","\\.old$","runnumber\\.ss")
		junkit  = sapply(junkpat,function(x){list.files(pattern=x)})
		junkit  = sapply(junkit,setdiff,"SS.exe")
		junk    = sapply(junkit,function(x){ if (length(x)>0) for (i in x) if (file.exists(i)) file.remove(i)})
	}
	## End subfunctions

	ncA   = max(nchar(A))
	Pfix = Pfix[ sapply(Pfix,function(x){!is.null(x) & all(!is.na(x)) }) ]
	if ( !all(diff(sapply(Pfix,length))==0) )
		stop("Pfix list elements must be vectors of equal length")

	Y = Ydec = Yval = Pfix
	Yvar  = names(Pfix)
	Ypref = paste0(substring(Yvar,1,2),"\\.")
	dcY   = lapply(Pfix, decimalplaces)
	dpY   = sapply(dcY,function(x){x$mindp})
	ipY   = sapply(Y,function(x){ max(0,ceiling(log10(x + 0.00001))) })  ## integer places

#browser() ;return()

	#if (!is.null(M)) {
	#	Y = Ydec = Yval = M; Ypref="MM\\."; Yvar="MMM"
	#} else if (!is.null(R0)) {  ## R0 expressed as log(R0)
	#	Y = R0; Ydec=Y/100; Yval=exp(Y); Ypref="RR\\."; Yvar="RRR"
	#}
	#
	#dcY = decimalplaces(Ydec)
	#dpY = dcY$mindp

	keep  = c("admodel.hes",paste0(c("Report","CompReport","covar","warning"),".sso"), paste("ss",c("cor","eva","par","rep","std","mpd"),sep="."), "data.ss_new") ## MPD files to save
	Nprof = length(Y[[1]]) * length(A)
	Iprof = 0
	if (missing(dir.pro)){
		fornow  = lapply(Y,function(x){ paste0("(", paste0(range(x),collapse="-"),")")})
		dir.sub =  paste0(c("Prof",paste0(substring(names(fornow),1,1),fornow)),collapse=".")
		#dir.sub =  paste0("pro.M(",paste0(range(M),collapse="-"),").A(",paste0(A,collapse=","),")")
		dir.pro = file.path(dir,dir.sub)
	} else {
		if (basename(dir.pro)==dir.pro || !grepl("^\\./|^[[:alpha:]]:/",dir.pro))  ## accept proper relative paths or those starting from a root
			dir.pro = file.path(dir,sub("^/","",dir.pro))
	}

	if (!file.exists(dir)) dir.create(dir)
	if (!file.exists(dir.pro)) dir.create(dir.pro)

	for (a in A){
		## Look for ss files
		afile = file.path(dir,paste0(prefix,"A",pad0(a,ncA),".ss"))
		sfile = file.path(dir,c("starter.base.ss", "forecast.ss", paste0(sub("Like","data",basename(dir)),".ss")))
		for (bfile in c(afile,sfile)) {
			if(!file.exists(bfile)) {
				if (file.exists(sub("/Like\\.","/MPD.",bfile)))
					file.copy(sub("/Like\\.","/MPD.",bfile), dir, copy.date=T)
				else
					stop(paste0("Cannot find file\n\t'", bfile, "'"))
			}
		}
		aline = readLines(afile)
		#grep(paste0(Yvar,collapse="|"),aline)

		for (i in 1:Nprof){
			Iprof = Iprof + 1
			yval = sapply(Y,function(x){x[i]})
			ychr = sapply(Ydec,function(x){x[i]})
			ychr = sapply(1:length(ychr),function(f){
				if(ipY[f]==0) ochr = show0(x=round(ychr[f],dpY[f]), n=dpY[f]) 
				else          ochr = pad0(x=ychr[f], n=ipY[f]+dpY[f], f=dpY[f])
			return(ochr)
#browser() ;return()
			})

## ipref need serious debugging
			#ipref = paste0(sub(Ypref,paste0(sub("0\\.","",show0(ychr,dpY)),"."),prefix),"A",pad0(a,ncA))
			ipref = paste0("control.",substring(gsub("control|\\.","",prefix),1,1), paste0(sub("^0\\.","",ychr),collapse=""),".A",pad0(a,ncA),collapse="")
#browser() ;return()
			.flush.cat(paste0("Processing run '", ipref, "' ..."), "\n")
			ifile = paste0(ipref,".ss")
			## for some reason, certain combos of M & A do not converge unless M is nudged
			if (strSpp=="WWR" && M==0.03 && A==45) smudge = 0.00001 ## necessary for WWR
			else smudge = 0 
			iline = aline
			for (l in 1:length(yval))
				iline = gsub(Yvar[l], yval[l]+smudge, iline)
			writeLines(iline, con=file.path(dir,ifile))

			## Modify starter file to reflect new run
			starter = readLines(file.path(dir,"starter.base.ss"))
			#dline   = grep(paste("data",pre.run.rwt,sep="."),starter)
			cline   = grep("^control",starter)
			#starter[dline] = sub(paste0("data\\.",l.run,"\\.",l.rwt),paste0("data.",new.run.rwt),starter[dline])
			starter[cline] = sub("^control.+\\.ss",paste0(ipref,".ss"),starter[cline])
			writeLines(starter, con=file.path(dir,"starter.ss"))
#browser();return()

			#expr = paste("mess = shell(cmd=\"awatea -ind ",mfile,argsMPD,"\", wait=TRUE, intern=TRUE)",sep="")
			setwd(dir)
			if (clean) cleanup()
			expr = paste("mpd = shell(cmd=\"ss\", wait=TRUE, intern=TRUE)",sep="")
			.flush.cat("   ", expr, "\n")
			eval(parse(text=expr))
			writeLines(mpd ,con=file.path(dir,"ss.mpd"))

			for (jfile in keep){
				if (file.exists(file.path(dir,jfile))){
					if (jfile=="ss.par"){
						## r4ss' SS_profile seems to rename ss.par; repeat here but still copy ss.par below
						kfile = paste0(jfile,"_",Iprof,".sso")
						file.copy(from=file.path(dir,jfile), to=file.path(dir.pro,kfile), overwrite=TRUE, copy.date=TRUE)
					}
					#else {
					jbits = strsplit(jfile,"\\.")[[1]]
					#jbits = c(jbits,"sumtingwong")  ## just for testing
					jlen  = length(jbits)-1
					jbits[jlen] = paste0(jbits[jlen],Iprof)
					kfile = paste0(jbits,collapse=".")
					#}
					file.copy(from=file.path(dir,jfile), to=file.path(dir.pro,kfile), overwrite=TRUE, copy.date=TRUE)
				}
			}
			if (clean) cleanup()
			rubbish = gc(verbose=FALSE)
		} ## end m loop (natural mortality)
	} ## end a loop (maximum age for plus class)
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~repeatMPD

#out = repeatMPD(M=seq(0.08,0.15,0.01), clean=T)
#argsMPD = paste0(" -crit", paste0(rep(" 1e-8",5),collapse=",")) ## need one value for each phase
#argsMPD = " -crit 0.001, 0.001, 0.001, 0.001, 0.000001"
#out = repeatMPD(M=seq(0.02,0.10,0.005), A=60, clean=T, dir.pro="Prof.M") #, argsMPD=argsMPD) 

## NOTE: If fixing R0 you need to specify at least one parameter to be estimated in phase 1
#Rvals = c(seq(1000,6000,500),seq(6500,24500,1000))
#cwd   = "C:/Users/haighr/Files/GFish/PSARC21/YMR/Data/SS/YMR2021/Run22/Like.22.01"
#cwd   = "C:/Users/haighr/Files/GFish/PSARC21/YMR/Data/SS/YMR2021/Run52/Like.52.01"
#cwd   = "C:/Users/haighr/Files/GFish/PSARC21/YMR/Data/SS/YMR2021/Run53/Like.53.01"
#cwd   = "C:/Users/haighr/Files/GFish/PSARC21/YMR/Data/SS/YMR2021/Run54/Like.54.01"
#out   = repeatMPD(M=NULL, A=c(60), R0=log(Rvals), dir=cwd, dir.pro="Prof.R0", prefix="control.RRR.", clean=TRUE)

## CAR - Canary
## ------------
cwd = "C:/Users/haighr/Files/GFish/PSARC22/CAR/Data/SS/CAR2022/Run24/Like.24.01"
#out = repeatMPD(Pfix=list(FFF=seq(0.05,0.15,0.01),MMM=seq(0.02,0.12,0.01),RRR=NULL), A=60, dir=cwd, dir.pro="Prof.M", prefix="control.MMM.", clean=T)
#test = repeatMPD(Pfix=list(FFF=seq(0.05,0.06,0.01),MMM=NULL,RRR=NULL), A=60, dir=cwd, dir.pro="LL.f.M", prefix="control.FFF.", clean=T)

## Fix M for females
#out = repeatMPD(Pfix=list(FFF=seq(0.04,0.15,0.01),MMM=NULL,RRR=NULL), A=60, dir=cwd, dir.pro="LL.f.M", prefix="control.FFF.", clean=T)

## Fix M for males
#out = repeatMPD(Pfix=list(FFF=NULL,MMM=seq(0.02,0.13,0.01),RRR=NULL), A=60, dir=cwd, dir.pro="LL.m.M", prefix="control.MMM.", clean=T)

## Fix R0
out = repeatMPD(Pfix=list(FFF=NULL,MMM=NULL,RRR=seq(5,10.5,0.5)), A=60, dir=cwd, dir.pro="LL.R0", prefix="control.RRR.", clean=T)
