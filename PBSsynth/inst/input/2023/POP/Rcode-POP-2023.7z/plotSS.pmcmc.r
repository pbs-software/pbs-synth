## plotSS.pmcmc-------------------------2023-09-15
##  Plot boxplots of quantiles for various MCMC parameters.
##  Modified from PBSawatea's 'plotBmcmcPOP' function.
##  Input comes from the output file 'derived.parameters.sso' (use r4ss::SSgetMCMC)
## -----------------------------------------AME|RH
plotSS.pmcmc=function(obj, pqs=tcall(quants5), xyType="quantBox",
   lineType=c(3,2,1,2,3), refLines=NULL, xLim=NULL, yLim=NULL,
   userPrompt=FALSE, save=TRUE, tcl.val=-0.2, yrs, y0=TRUE,
   pyrs=NULL, LRP=NULL, USR=NULL, catpol=NULL,
   yaxis.by, yLab="Recruitment", outnam, lang=c("e","f"), 
   ptypes="win", pngres=400, PIN=c(8,6), ...)
{
	# See plt.quantBio if want other xyTypes, as took out here:
	plt.qB <- function(qobj, xyType="lines", new=TRUE, xLim, yLim, yrs, pyrs, LRP, USR, pvec, ...)
	{
		if ( new ) {
			plot(xLim, yLim, type="n", xlab=linguaFranca("Year",l), ylab=linguaFranca(yLab,l), ...)
			if (!y0) abline(h=0,col="gainsboro")
			if (!is.null(LRP)) abline(h=LRP, col="red", lty=5)
			if (!is.null(USR)) abline(h=USR, col="green4", lty=5)
		}
#browser();return()
		#yrs <- as.numeric(dimnames(qobj)[[2]])
		#yrs <- as.numeric(gsub("[^[:digit:]]","",dimnames(result1)[[2]]))

		# Quantile boxplots - assumes five quantiles.
		if ( xyType=="quantBox" ) {
			colvec      <- c(rep("green3",nrow(recdevEarly)), rep("black",nrow(recdevMain)), rep("blue",nrow(recdevLate)), rep("red", nrow(recdevFore)))
			bgvec       <- c(rep("green",nrow(recdevEarly)), rep("gainsboro",nrow(recdevMain)), rep("cyan",nrow(recdevLate)), rep("pink", nrow(recdevFore)))

#browser();return()
			if ("afR.mcmc" %in% fnam) { ## Rdist only occurs during recdevMain
				areacol = switch(area,'5ABC'="blue",'3CD'="green4",'5DE'="red","black")
				areabg  = switch(area,'5ABC'="cyan",'3CD'="green",'5DE'="pink","gainsboro")
				colvec  = rep(areacol,length(yrs))
				bgvec   = rep(areabg,length(yrs))
				medval  = mean(qobj[3,])
				abline(h=medval, col=areacol, lty=3)
				addLabel(0.02,0.02,paste0("mean of medians = ",show0(round(medval,3),3)), col=areacol, adj=c(0,0),cex=1)
			}
			#if(!is.null(USR)) abline(h=c(USR), col=c("slategray"), lwd=1, lty=5)  ## already covered by common frame above
			delta <- 0.25 ## width of half-box
			# Draw the outer whiskers.
			segments(yrs, qobj[1,], yrs,qobj[5,], lty=1, col="black", lwd=ifelse(narea==1,1,0.5))
			# Overlay the box.
			for ( i in 1:length(yrs) ) {
				#rect( yrs[i]-delta,qobj[2,i], yrs[i]+delta, qobj[4,i],... ) ## AME
				#polygon(x=c(rep(yrs[i]-delta,2),rep(yrs[i]+delta,2)), y=qobj[c(2,4,4,2),i], border="black", col="gainsboro", ...) ## RH (190620)
				polygon(x=c(rep(yrs[i]-delta,2),rep(yrs[i]+delta,2)), y=qobj[c(2,4,4,2),i], border=colvec[i], col=bgvec[i], lwd=ifelse(narea==1,1,0.5)) ## RH (230816)
			}
			# Add the median.
			segments(yrs-delta, qobj[3,], yrs+delta, qobj[3,], lty=1, col=colvec, lwd=ifelse(narea==1,1,0.5))
#browser();return()

			## Revised handling of projections to fix Rdev plot (RH 230809)
			addyrs = setdiff(allyrs,yrs)
			prjyrs = as.character(pyrs)
#browser();return()
			if (!is.null(pyrs) && all(prjyrs %in% colnames(qobj)) ) {
				## Following now handled above (RH 230816)
				#pyrs = sort(unique(c(addyrs,pyrs)))
				#pp   = as.character(pyrs)
				#segments(pyrs, qobj[1,pp], pyrs, qobj[5,pp], lty=1,col="red" )
				#for ( i in (length(yrs)-length(pyrs)+1):length(yrs) )
				#	polygon(x=c(rep(yrs[i]-delta,2),rep(yrs[i]+delta,2)), y=qobj[c(2,4,4,2),i], border="red", col="pink", ...) ## RH (190620)
				#segments( pyrs-delta, qobj[3,pp], pyrs+delta, qobj[3,pp], lty=1, col="red" )
			} else {
				if (fnam %in% c("Rdev.mcmc","Rtdev.mcmc")) {  ## messy and may be prone to error
					#parameters <- replist$parameters
					#recdevEarly <- parameters[substring(parameters$Label, 1, 13) %in% c("Early_RecrDev"), ]
					#recdev <- parameters[substring(parameters$Label, 1, 12) %in% c("Main_RecrDev"), ]
					#recdevFore <- parameters[substring(parameters$Label, 1, 8) == "ForeRecr", ]
					#recdevLate <- parameters[substring(parameters$Label, 1, 12) == "Late_RecrDev", ]
					colvec <- c(rep("blue",nrow(recdevLate)), rep("red", nrow(recdevFore)))
					points(addyrs, rep(0,length(addyrs)), pch=20, col=colvec, cex=1)
				}
			}
		}

		# Uncertainty envelope - assumes five quantiles.
		if ( xyType=="envelope" ) {
			if(!is.null(LRP) && !is.null(USR))
				abline(h=c(LRP,USR), col=c("red","green4"), lwd=1, lty=5)
			x  = setdiff(yrs,pyrs)
			x.late = NULL
			if (nrow(recdevLate)>0) {  ## (RH 230821)
				xx.late = c(sub("Late_RecrDev_","",rownames(recdevLate)), as.character(currYr))
				x.late  = as.numeric(xx.late)
				## currYr goes into projections, extend main to start of late period
				x = setdiff(x,.su(c(x.late[-1],currYr)))
			}
			xx = as.character(x)
			col.main = "black"
			polygon(c(x,rev(x)), c(qobj[1,xx],rev(qobj[5,xx])), col=lucent(col.main,0.05), border=FALSE)
			lines(x, qobj[3,xx], lty=1, lwd=ifelse(narea==1,3,2), col=col.main)
			lines(c(x,NA,x), c(qobj[1,xx],NA,qobj[5,xx]), lty=2, lwd=ifelse(narea==1,2,1), col=col.main)
			lines(c(x,NA,x), c(qobj[2,xx],NA,qobj[4,xx]), lty=3, lwd=ifelse(narea==1,1,1), col=col.main)
#browser();return()
			if (!is.null(x.late)) {  ## (RH 230821)
				col.late = "blue"
				polygon(c(x.late,rev(x.late)), c(qobj[1,xx.late],rev(qobj[5,xx.late])), col=lucent(col.late,0.05), border=FALSE)
				lines(x.late, qobj[3,xx.late], lty=1, lwd=ifelse(narea==1,3,2), col=col.late)
				lines(c(x.late,NA,x.late), c(qobj[1,xx.late],NA,qobj[5,xx.late]), lty=2, lwd=ifelse(narea==1,2,1), col=col.late)
				lines(c(x.late,NA,x.late), c(qobj[2,xx.late],NA,qobj[4,xx.late]), lty=3, lwd=ifelse(narea==1,1,1), col=col.late)
			}
			if (!is.null(pyrs)){
				kcol = if (length(pvec)==1) "red" else c("green3","orange2","red")
				for (k in 1:length(pvec)) {
					x.proj  = c(pyrs[1]-1,pyrs)
					xx.proj = as.character(x.proj)
					yy  = qobj[,xx.proj]
					pp  = pvec[[k]]
					yy[rownames(pp),colnames(pp)] = pp
					polygon(c(x.proj,rev(x.proj)), c(yy[1,xx.proj],rev(yy[5,xx.proj])), col=lucent(kcol[k],0.1), border=FALSE)
					lines(x.proj, yy[3,xx.proj], lty=1, lwd=ifelse(narea==1,3,2), col=kcol[k])
					lines(c(x.proj,NA,x.proj), c(yy[1,xx.proj],NA,yy[5,xx.proj]), lty=2, lwd=ifelse(narea==1,2,1), col=kcol[k])
					lines(c(x.proj,NA,x.proj), c(yy[2,xx.proj],NA,yy[4,xx.proj]), lty=3, lwd=ifelse(narea==1,1,1), col=kcol[k])
#abline(v=c(2015,2024)) ## just checking start years for late and proj
#browser();return()
				}
			}
		}
	}
	## Save all years to counteract r4ss' propensity to choose available data
#browser();return()
	allyrs = c(yrs, pyrs)
	fnam   = as.character(substitute(obj))

	## Need to get the various classifications for recdevs (and other parameters) for PJS (RH 230816)
	if (!exists("replist")) {
		if (exists("central.mpd.dir") && dir.exists(central.mpd.dir)) {
			assign("replist", SS_output(central.mpd.dir, verbose=FALSE, printstats=FALSE), envir=.GlobalEnv)
		} else {
			message ("sumtingwong with replist")
			#browser();return()
		}
	}
	parameters  <- replist$parameters
	recdevEarly <- parameters[substring(parameters$Label, 1, 13) %in% c("Early_RecrDev"), ]
	recdevMain  <- parameters[substring(parameters$Label, 1, 12) %in% c("Main_RecrDev"), ]
	recdevFore  <- parameters[substring(parameters$Label, 1, 8) == "ForeRecr", ]
	recdevLate  <- parameters[substring(parameters$Label, 1, 12) == "Late_RecrDev", ]

	narea = 1 
	if (inherits(obj,"list") &&  is.null(dim(obj)))
		narea = length(obj)
	createFdir(lang)
	if (missing(outnam))
		outnam = gsub("[[:space:]]+",".",tolower(yLab))
	fout.e = outnam
	for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
		changeLangOpts(L=l)
		fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
		for (p in ptypes) {
			if (p=="eps")      postscript(paste0(fout,".eps"), width=PIN[1], height=PIN[2], horizontal=FALSE,  paper="special")
			else if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
			rc = if(narea==3) c(3,1) else .findSquare(narea)
			expandGraph(mfrow=rc, mar=c(3.0,3.5,0.75,0.5), oma=c(0,0,0,0), mgp=c(1.75,0.5,0))
			for (i in 1:narea) {
				if (narea==1) {
					area = if (length(area.names)>1) "Coast" else area.names  ## get area name from 'initialise.r' (RH 230915)
					aobj = obj
					acatpol = catpol  ## could be NULL
				} else {
					area = names(obj)[i]
					aobj = obj[[i]]
					acatpol = catpol[[i]]
				}
				# Plot quantiles of biomass using the posterior densities.
				yrs1 = yrs2 = result1 = result2 = NULL
				if(is.null(pqs)) pqs = c(0.05, 0.25, 0.50, 0.75, 0.95)
		
				# Calculate the quantiles of the reconstructed biomass.
				result1 <- apply( aobj, 2, quantile, probs=pqs, na.rm=T )
				yrs1 <- as.numeric(gsub("[^[:digit:]]","",dimnames(result1)[[2]]))
				if (!missing(yrs)) {
					zyrs = is.element(yrs1,c(yrs,pyrs))
					zyrs = zyrs & apply(result1,2,function(x){!all(is.na(x))})  ## to emulate original input
					yrs1 = yrs1[zyrs]
					result1 = result1[,zyrs]
				}
				if (!is.null(pyrs)) {
					if (!is.null(acatpol)) {
						cpolnam = dimnames(acatpol)$proj
						if (narea==1)
							cpolcat = avgCP[1,1,cpolnam]
						else
							cpolcat = xavgCP[1,sub("CST","total",area),cpolnam]
						projmat = apply(acatpol, 2:3, quantile, probs=pqs, na.rm=T )
						projvec = lapply(1:dim(projmat)[3], function(k) {projmat[,,k]})
						names(projvec) = cpolcat
					} else {
						projvec = list('AC'=result1[,intersect(colnames(result1),as.character(pyrs))])
					}
				} else {
					projvec = NA
				}
				if ( is.null(yLim) || narea>1 )
					yLim <- c(ifelse(y0, 0, min(unlist(result1),unlist(projvec),na.rm=T)), max(unlist(result1),unlist(projvec),na.rm=T))
				if ( is.null(xLim) || narea>1 )
					xLim = range(allyrs) #range(yrs1)
				colnames(result1) = yrs1
	
				plt.qB(qobj=result1, xLim=xLim, yLim=yLim, xyType=xyType, yrs=yrs1, pyrs=pyrs, LRP=LRP, USR=USR, pvec=projvec, ...)
				axis(1, at=intersect(seq(1900,3000,5), xLim[1]:xLim[2]), tcl=tcl.val, labels=FALSE)
				if (missing(yaxis.by)) {
					yint = diff(seq(par()$yaxp[1], par()$yaxp[2], len=par()$yaxp[3]+1))[1]
					yint.char = as.character(yint) ## becasue comparing numerics is flaky
					#ytck = seq(par()$yaxp[1]-yint, par()$yaxp[2]+yint, yint/ifelse(par()$yaxp[3]>6,2,4))
					if ( yint.char %in% as.character(5*10^(-10:10)) ) by = yint/5
					else if ( yint.char %in% as.character(4*10^(-10:10)) ) by = yint/4
					else if ( yint.char %in% as.character(2*10^(-10:10)) ) by = yint/2
					else if ( yint.char %in% as.character(1*10^(-10:10)) ) by = yint/5
					else { message("stupid tick checker has failed"); browser(); return() }
					ytck = seq(par()$yaxp[1]-yint, par()$yaxp[2]+yint, by=by)
					axis(2, at=ytck, tcl=tcl.val, labels=FALSE)
				} else 
					axis(2, at=seq(par()$yaxp[1], par()$yaxp[2], by=yaxis.by), tcl=tcl.val, labels=FALSE)
				#axis(2, at=seq(0, yLim[2], by=yaxis.by), tcl=tcl.val, labels=FALSE)
				if (length(projvec)==3)
					addLegend(0.5,0.975,legend=paste0(names(projvec)," t"), lty=1, lwd=ifelse(narea==1,3,2), seg.len=3, col=c("green3","orange2","red"), bty="n", xjust=0, yjust=1,title=linguaFranca("Projected catch",l), cex=ifelse(narea==1,1,0.8))
				addLabel(0.975, 0.975, area, adj=c(1,1), font=2, cex=ifelse(narea==1,1.2,1.2), col=switch(area,'5ABC'="blue",'3CD'="green4",'5DE'="red","black") )
			}  ## end i loop (area)
			if (p %in% c("eps","png")) dev.off()
		}
#browser();return()
	}; eop()  ## end language loop
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~plotSS.pmcmc


#plotSS.pmcmc(, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab="Recruitment deviations", outnam="recdevMCMC", ptypes=ptypes, y0=F)
#plotSS.pmcmc(BoverBmsy, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(B[t] / B[MSY]), outnam="boverbmsyMCMC", xyType="envelope", ptypes=ptypes, pyrs=proYrs, LRP=0.4, USR=0.8)
#plotSS.pmcmc(BoverBmsy.mcmc, yrs=1935:2020, lang="f", cex.axis=1.2, cex.lab=1.5, yLab=expression(B[t] / B[MSY]), outnam="boverbmsyMCMC", xyType="envelope", ptypes="win", pyrs=2021:2030, LRP=0.4, USR=0.8)

## Model composite
#plotSS.pmcmc(compo$avgTS[,,"BtBmsy"], yrs=1935:2021, lang="e", cex.axis=1.2, cex.lab=1.5, yLab=expression(B[t] / B[MSY]), outnam="compo.BtBmsy", xyType="envelope", ptypes="win", pyrs=2022:2031, LRP=0.4, USR=0.8)
#plotSS.pmcmc(compo$avgTS[,,"BtB0"], yrs=1935:2021, lang="e", cex.axis=1.2, cex.lab=1.5, yLab=expression(B[t] / B[0]), outnam="compo.BtB0", xyType="envelope", ptypes="win", pyrs=2022:2031, LRP=0.2, USR=0.4)
#plotSS.pmcmc(fornow$avgTS[,,"BtBmsy"], yrs=1935:2021, lang="e", cex.axis=1.2, cex.lab=1.5, yLab=expression(B[t] / B[MSY]), outnam="compo.BtBmsy", xyType="envelope", ptypes="win", pyrs=2022:2031, LRP=0.4, USR=0.8)

## Envelope:
## Adjust for current 
#plotSS.pmcmc(BoverBmsy, yrs=modYrs, pyrs=proYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(italic(B)[italic(t)]/italic(B)[MSY]), outnam="boverbmsyMCMC", xyType="envelope", ptypes="png", LRP=0.4, USR=0.8)
#plotSS.pmcmc(UoverUmsy, yrs=modYrs, pyrs=proYrs, lang="e", cex.axis=1.2, cex.lab=1.5, yLab=expression(italic(u)[italic(t)]/italic(u)[MSY]), outnam="uoverumsyMCMC", xyType="envelope", ptypes="png", USR=1)
## quantBox:
#plotSS.pmcmc(B.mcmc, yrs=modYrs, pyrs=proYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(Spawning~biomass~(italic(B)[italic(t)])), outnam="sbiomassMCMC", ptypes="win")
#plotSS.pmcmc(R.mcmc, yrs=modYrs, pyrs=proYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab="Recruitment", outnam="recruitsMCMC", ptypes="win") #ptypes)
#plotSS.pmcmc(u.mcmc, yrs=modYrs, pyrs=proYrs, lang="f", cex.axis=1.2, cex.lab=1.5, yLab=expression(paste("Exploitation rate ", group("(",italic(u)[italic(t)],")"))), outnam="exploitMCMC", ptypes="win", USR=NULL)
#plotSS.pmcmc(D.mcmc, yrs=modYrs, pyrs=proYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(Depletion~(italic(B)[italic(t)]/italic(B)[0])), outnam="depleteMCMC", ptypes="win", LRP=0.2, USR=0.4)
#plotSS.pmcmc(Rdev.mcmc, yrs=modYrs, pyrs=proYrs, lang="e", cex.axis=1.2, cex.lab=1.5, yLab="Recruitment deviations", outnam="recdevMCMC", ptypes="win", y0=F)
#plotSS.pmcmc(D.mcmc, yrs=modYrs, pyrs=proYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(Depletion~(italic(B)[italic(t)]/italic(B)[0])), outnam="depleteMCMC", xyType="quantBox", ptypes="win", LRP=0.2, USR=0.4)

## For POP webpage (Stephanie Sardelis)
#plotSS.pmcmc(D.mcmc, yrs=modYrs, pyrs=proYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(Relative~Biomass~(italic(B)[italic(t)]/italic(B)[1935])), outnam="BrelativeMCMC", xyType="quantBox", ptypes="png", LRP=0.2, USR=0.4)

#afR.mcmc = list()
#for (a in 1:narea) {
#	aa  = area.names[a]
#	afR = fR.mcmc[,grep(paste0("Rprop\\_area\\(",a,")"), colnames(fR), value=T)]
#	aYrs = as.numeric(revStr(substring(revStr(colnames(afR)),1,4)))
#	colnames(afR) = aYrs
#	afR.mcmc[[aa]] = afR
#}
#plotSS.pmcmc(afR.mcmc, yrs=aYrs, pyrs=NULL, lang="e", cex.axis=1.2, cex.lab=1.5, yLab="Proportion Recruitment", outnam="pRecsMCMC", xyType="quantBox", ptypes="win",  PIN=c(7,8))

