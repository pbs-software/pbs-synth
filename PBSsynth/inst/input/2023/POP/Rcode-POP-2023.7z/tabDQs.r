## tabDQs-------------------------------2023-10-17
##  Tables of Derived Quantities
## ---------------------------------------------RH
tabDQs = function(xavgRP, xavgTS, csv=TRUE)
{
	areaRPL = areaRPL.pjs = areaRPQ = areaRPQ.pjs = list()
	for (a in dimnames(xavgRP)$area) {
		areaRP    = xavgRP[,,a]
		#areaTS    = xavgTS[,as.character(c(startYear,prevYear,currYear)),c("B","u"),a]
		areaTS    = xavgTS[,as.character(startYear:currYear),c("B","u","fR"),a]
		areaRPtab = data.frame(
			B0        = areaRP[,"B0"],
			Bcurr     = areaTS[,as.character(currYear),"B"],
			BcurrB0   = areaTS[,as.character(currYear),"B"] / areaTS[,as.character(startYear),"B"],
			Uprev     = areaTS[,as.character(prevYear),"u"],
			Umax      = apply(areaTS[,,"u"],1,max,na.rm=T), ## for each mcmc sample across the time series,
			MSY       = areaRP[,"MSY"],
			Bmsy      = areaRP[,"Bmsy"],
			LRP       = 0.4 * areaRP[,"Bmsy"],
			USR       = 0.8 * areaRP[,"Bmsy"],
			BcurrBmsy = areaTS[,as.character(currYear),"B"] / areaRP[,"Bmsy"],
			BmsyB0    = areaRP[,"Bmsy"] / areaRP[,"B0"],
			Umsy      = areaRP[,"umsy"],
			UprevUmsy = areaTS[,as.character(prevYear),"u"] / areaRP[,"umsy"],
			pR        = areaTS[,as.character(prevYear),"fR"],
			pVB       = areaRP[,"pVB"]
		)
#browser();return()
		areaRPtab.pjs = data.frame(
			B0        = areaRP[,"B0"],
			Bcurr     = areaTS[,as.character(currYear),"B"],
			BcurrB0   = areaTS[,as.character(currYear),"B"] / areaTS[,as.character(startYear),"B"],
			Fprev     = -log(1-areaTS[,as.character(prevYear),"u"]),
			Uprev     = areaTS[,as.character(prevYear),"u"],
			MSY       = areaRP[,"MSY"],
			Bmsy      = areaRP[,"Bmsy"],
			BcurrBmsy = areaTS[,as.character(currYear),"B"] / areaRP[,"Bmsy"],
			BmsyB0    = areaRP[,"Bmsy"] / areaRP[,"B0"],
			Fmsy      = areaRP[,"Fmsy"],
			Umsy      = areaRP[,"umsy"],
			UprevUmsy = areaTS[,as.character(prevYear),"u"] / areaRP[,"umsy"]
		)
		areaRPL[[a]]     = areaRPtab
		areaRPL.pjs[[a]] = areaRPtab.pjs
		areaRPQ[[a]]     = apply(areaRPtab, 2, function(x){quantile(x, probs=quants5, na.rm=T)})
		areaRPQ.pjs[[a]] = apply(areaRPtab.pjs, 2, function(x){quantile(x, probs=quants5, na.rm=T)})
		write.csv(areaRPQ[[a]], paste0("subarea", a ,".csv"))
	}
	return(list(areaRPL=areaRPL, areaRPL.pjs=areaRPL.pjs, areaRPQ=areaRPQ, areaRPQ.pjs=areaRPQ.pjs))
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~tabDQs
require(r4ss)
sumting = FALSE
if (sumting) {
	so("load.preview.r","synth")
	if (exists("xavgRP")) {
		areaDQ = tabDQs(xavgRP, xavgTS, csv=T)
		save("areaDQ", file="areaDQ.rda")
	}
	
	## Probability of being in the PA zones
	load("areaDQ.rda"); unpackList(areaDQ)
	pPAzones = lapply(areaRPL, function(x){
		good=!is.na(x$Bmsy); 
		xgood=x$Bcurr[good]/x$Bmsy[good];
		return(c(healthy=sum(xgood>0.8)/length(xgood), cautious=sum(xgood>0.4 & xgood<=0.8)/length(xgood), critical=sum(xgood<=0.4)/length(xgood)))
	})
}



