## calcMSY------------------------------2023-03-29
## method = method of fishing (e.g., trawl, other, hook and line, midwater trawl, etc.)
## ------------------------------------------AH|RH
calcMSY = function(replist, strategy, method=1, proj_gears=TRUE)
{
	## Subfunctions -----------------------------------------

	MSY = function(MSY.in)
	{
		##****************************************************
		## Calculates MSY (MSYtab stored in .PBStoolEnv)
		## Modified from Allan Hicks' Awatea code in ModelParams.cpp
		##****************************************************
		dIC.out  = determInitCond(dIC.in=MSY.in); ##//deterministic initial conditions
		unpackList(dIC.out)
		Nmat  = Ninit
		#SBold = SBnew = SB0;
		#Nold  = Nnew  = sum(Nmat);
		theCatch = 0;
		oYDP.start = c(MSY.in, list(Catch=theCatch, Nmat=Nmat, VB=VB0, SSB=SB0, alpha=alpha, beta=beta))

		for (theCatch in seq(StartStrategy, EndStrategy, StepStrategy)) {
			if(StrategyType == 2) {
				harvRate = theCatch; ## because working over harvest rates and theCatch is changed below, save for output later
			}
			oYDP.out = oneYearDetermProj(oYDP.start);
			unpackList(oYDP.out, scope="L")
			Nold     = sum(N2)
			oYDP.in  = c(MSY.in, list(Catch=theCatch, Nmat=N2, VB=VB, SSB=SSB, alpha=alpha, beta=beta))
			oYDP.out = oneYearDetermProj(oYDP.in);
			unpackList(oYDP.out, scope="L")
			Nnew     = sum(N2) #Nnew = sum(Nmat);
			diffN    = abs(Nold-Nnew);
			nproj=1;
#browser();return()
			while(diffN > MSYtol && nproj < MSYmaxIter) {
				Nold = Nnew;
				if(StrategyType == 2) {
					theCatch = harvRate; ## //because working over harvest rates and theCatch is changed by reference
				}
				unpackList(oYDP.out, scope="L")
				oYDP.in  = c(MSY.in, list(Catch=theCatch, Nmat=N2, VB=VB, SSB=SSB, alpha=alpha, beta=beta))
				oYDP.out = oneYearDetermProj(oYDP.in);
				unpackList(oYDP.out, scope="L")
				Nnew     = sum(N2) 
				diffN    = abs(Nold-Nnew);
				nproj = nproj + 1
			}
			ttget(MSYtab)
			iii = MSY.in$nmcmc
			kkk = ifelse(harvRate==0, "0", show0(harvRate,3))  ## theCatch = harvest rate
			MSYtab[iii,,kkk] = c(harvRate*VB,VB,SSB,nproj) ## c("Yield","VB","SB","Niter")
			ttput(MSYtab)
		}
	} ## end subfun MSY

	## Strategy selectivity (uses EndYear selectivity only)
	strategySelect = function(va, u, method, year, Nsexes, Nages)  # void model_parameters::strategySelect() {
	{
		##*******************************************************
		## finds the selectivity for projections and yields
		## fills in strategyva
		## Modified from Allan Hicks' Awatea code in ModelParams.cpp
		##*******************************************************
		unpackList(sS.in)
		strategyva = array(0, dim=c(Nsexes,Nages), dimnames=list(sex=1:Nsexes, age=1:Nages));
		endyear    = as.character(year)
		Nmethods   = length(method)

		sumu = 0;
		## // selectivity at age for the projections
		for (midx in 1:Nmethods) {
			meth = as.character(method[midx])
			for (sex in 1:Nsexes) {
				for (age in 1:Nages) {
					if (proj_gears) {
						## Use end-year harvest rates by method
						strategyva[sex,age] = strategyva[sex,age] + u[meth,endyear] * va[meth,endyear,sex,age];
					} else {
						## Use user-supplied harvest rate proportions
						strategyva[sex,age] = strategyva[sex,age] + strategyuproportion[meth] * va[meth,endyear,sex,age];
					}
				} ## end age loop
			} ## end sex loop
			sumu = sumu + u[meth,endyear];
		} ## end method loop
		if (proj_gears)
			strategyva = strategyva/sumu
		return(strategyva)
	} ## end subfun strategySelect

	determInitCond = function(dIC.in)  ## dmatrix model_parameters::determInitCond(double& VB0, double& SSB0)
	{
		## Modified from Allan Hicks' Awatea code in ModelParams.cpp
		unpackList(dIC.in, scope="L")
		## // Weight and Fecundity for the projection --> EndYear +1 (from setup_variable_parameters)
		wProj    = w[as.character(endyr+1),,]
		fecProj  = fec[as.character(endyr+1),]
		survival = aperm(survVec, c(2,1));
		vuln     = strategyva;
		h        = SR[grep("steep",names(SR))]
		R0       = exp(SR[grep("R0",names(SR))])
		if ( any(grepl("Rprop",names(SR))) )
			R0    = R0 * SR[grep("Rprop",names(SR))]  ## Allocation of recruitment by area
#browser();return()

		Ninit = array(0, dim=c(Nsexes, Nages), dimnames=list(sex=1:Nsexes, age=0:(Nages-1)))  ## Ninit.initialize();
		VB0 = TB0 = 0;

		## From the Appendix E:
		A3 = 3 * A - 1
		for (sex in 1:Nsexes) {
			Na0 = RecFraction[sex] * R0 * exp(-(0:A3) * M[sex])  ## start using App E equations
			NA0 = sum( Na0[(A+1):A3] + (Na0[A3] * exp(-M[sex])) / (1 - exp(-M[sex])) )
			N0  = c( Na0[1:A], NA0)  ## Adjusted for 0-age 
			Ninit[sex,] = N0
			## Difference between reported fecundity and calculated fecundity f=w*m*eggs. Why?
			if (sex==1) { ## females
				SB0 = sum( fec[as.character(startyr),] * N0 )  ## closer to SS3 calculation but doesn't make sense; however f=w*m*eggs) so perhaps is good
			}
			TB0 = TB0 + sum( w[as.character(startyr),sex,] * maturity[,1] * N0 )  ## use same maturity?
			VB0 = VB0 + sum( w[as.character(startyr),sex,] * maturity[,1] * N0 * vuln[sex,] )  ## use same maturity?
		} ## end sex loop

		## //Compute Recruitment Parameters
		alpha = (SB0/R0) * (1-((h-0.2) / (0.8*h)));
		beta  = (5*h-1) / (4*h*R0);

		## Update MSYtab with virgin VB and SSB
		ttget(MSYtab)
		MSYtab[nmcmc,,"Init"] = c(0,VB0,SB0,0)
		ttput(MSYtab)
		return( list(Ninit=Ninit, SB0=SB0, VB0=VB0, TB0=TB0, alpha=alpha, beta=beta) );
	} ## end subfun determInitCond

	oneYearDetermProj = function(oYDP.in) 
	{
		##*******************************************************
		## projects the population one year for a certain catch or harvest rate
		##   if StrategyType is 2, then it is a harvest rate
		## uses same selectivity as projections (strategySelect function)
		## this function was written by Allan Hicks on 3/DEC/07
		## Modified from Allan Hicks' Awatea code in ModelParams.cpp
		##*********************************************************
		unpackList(oYDP.in, scope="L")

		## Weight and Fecundity for the projection --> EndYear +1 (from setup_variable_parameters)
		wProj   = w[as.character(endyr+1),,] #w[EndYear+1];
		fecProj = fec[as.character(endyr+1),]  #fec[EndYear+1];

		## Survival curve
		survVec   = aperm(survVec, c(2,1));  ## to make consistent with code below
		survVec05 = aperm(survVec05, c(2,1));

		## Recruitment
		rec = SSB / (alpha + beta*SSB); # value(SSB/(alpha+beta*SSB));

		if (StrategyType == 2) {  ## hr = harvest rate
			hr = Catch;
			Catch = VB*hr;
		}
		else {
			if(VB>0) { hr=Catch/VB; }
			else     { hr=0; }
			if(hr>1) { hr=1; }
		}

		SSB  = VB = 0;
		Z    = M + hr ## there must be natural mortality as time progresses
		Z    = rep(Z,length(Nsexes))[1:Nsexes] 
		N2   = Nmat
		aa   = 2:(Nages-1)
		aaa  = 2:Nages
		for (sex in 1:Nsexes) {
			N2[sex, aa] = N2[sex, aa-1] * exp(-Z[sex])  ## assumes no time-varying F or M
			N2[sex, Nages] = N2[sex, Nages-1] * exp(-Z[sex]) + N2[sex, Nages] * exp(-Z[sex])
			N2[sex,aaa][N2[sex,aaa]<0] = 0
			VB = VB + sum( N2[sex,aaa] * wProj[sex,aaa] * strategyva[sex,aaa] ) ## * survVec05[sex,Nages];
			if (sex==1) ## females
				SSB = SSB + sum( N2[sex,aaa] * fecProj[aaa] )
			N2[sex,1] = rec * RecFraction[sex];
			N2[sex,1][N2[sex,1]<0] = 0
			VB = VB + sum( N2[sex,1] * wProj[sex,1] * strategyva[sex,1] ) ## * survVec05[sex,Nages];
			if (sex==1) ## females
				SSB = SSB + sum( N2[sex,1] * fecProj[1] )
		} ## end sex loop
		return( list(N2=N2, VB=VB, SSB=SSB) )
	} ## end subfun oneYearDetermProj

	## End subfunctions--------------------------------------

	## Main function calcMSY
	## ======================================================
	if (missing(strategy)) {
		strategy = list(
			StrategyType  = 2,     ## Strategy Type (1=constant catch; 2=harvest rate)
			MSYmaxIter    = 15000, ## Maximum number of iterations
			MSYtol        = 0.01,  ## Tolerance for convergence
			StartStrategy = 0,     ## Start Strategy (lower bound of catch for projections)
			EndStrategy   = 0.200, ## End Strategy (upper bound of catch for projections)
			StepStrategy  = 0.001  ## Step Strategy (interval to use for catch projections)
		)
	}
	unpackList(strategy)
	StartYear  = 1935
	EndYear    = 2023   ## -99 for MSY : if(ProjectYear>EndYear) MSYsetup()  in 'ModelParams.cpp'
	A          = 60     ## Age of plus class

	parameters = replist$parameters
	## Determine recruitment distribution by area
	Rdist      = parameters[grep("RecrDist.+month_1$",parameters$Label),"Value"]
	Rprop      = if (length(Rdist)==0) 1 else exp(Rdist)/sum(exp(Rdist))
	## For now, set U strategy to Rprop
	strategyuproportion = Rprop
	## Grab stock Recruitment pars R0 and h (and perhaps others)
	SRpars     = parameters[grep("R0|steep",parameters$Label),c("Label","Value")]
	SR         = apply(SRpars, 1, function(x) { par=x["Value"]; names(par)=x["Label"]; return(as.numeric(par)) })
	SR         = c(SR, 'Rprop'=sum(Rprop[method]))

	## Exploitation -- limit methods to commercial fleets
	fmeths   = grep("FISHERY",replist$FleetNames)
	fnames   = grep("FISHERY",replist$FleetNames,value=TRUE)
	names(fmeths) = fnames
	Nmethods = length(fmeths)
	exploit  = replist$exploitation
	fyears   = .su(exploit$Yr)  # .su(x) = sort(unique(x))
	u        = array(0, dim=c(length(fmeths),length(fyears)), dimnames=list(method=fmeths,year=fyears));
	for (i in fmeths) {
		ii  = as.character(i)
		iii = names(fmeths)[i]
		for (j in fyears) {
			jj = as.character(j)
			u[ii,jj] = unlist(exploit[exploit$Yr%in%j, iii])
		}
	}

	agesel = replist$ageselex  ## contains various Factors
	agesel.byfac = split(agesel, agesel$Factor)

	## Selectivity
	Asel   = agesel.byfac[["Asel"]]
	Asel   = Asel[is.element(Asel$Fleet, fmeths),]
	ameths = .su(Asel$Fleet)
	ayears = .su(Asel$Yr)   ; Nyears   = length(ayears)
	asexes = .su(Asel$Sex) ; Nsexes   = length(asexes)
	fage   = colnames(Asel)[-(1:grep("Label",colnames(Asel)))]
	ages   = as.numeric(fage); Nages = length(ages)
	va     = array(0, dim=c(Nmethods,Nyears,Nsexes,Nages), dimnames=list(method=ameths, year=ayears, sex=asexes, age=ages));
	for (i in ameths) {
		ii = as.character(i)
		for (j in ayears) {
			jj = as.character(j)
			for (k in asexes) {
				kk = as.character(k)
				va[ii,jj,kk,fage] = unlist(Asel[Asel$Fleet%in%i & Asel$Yr%in%j & Asel$Sex%in%k, fage])
			}
		}
	}

	## Body Weight
	bodywt = agesel.byfac[["bodywt"]]
	bodywt = bodywt[is.element(bodywt$Fleet, fmeths),]
	bmeths = .su(bodywt$Fleet)
	byears = .su(bodywt$Yr)  ; Nyears = length(byears)  ## overwrite previous value
	bsexes = .su(bodywt$Sex) ; Nsexes = length(bsexes)
	fage   = colnames(bodywt)[-(1:grep("Label",colnames(bodywt)))]
	ages   = as.numeric(fage); Nages = length(ages)
	w      = array(0, dim=c(Nmethods,Nyears,Nsexes,Nages), dimnames=list(method=bmeths, year=byears, sex=bsexes, age=ages));
	for (i in bmeths) {
		ii = as.character(i)
		for (j in byears) {
			jj = as.character(j)
			for (k in bsexes) {
				kk = as.character(k)
				w[ii,jj,kk,fage] = unlist(bodywt[bodywt$Fleet%in%i & bodywt$Yr%in%j & bodywt$Sex%in%k, fage])
			}
		}
	}

	## Fecundity (females, no specific fleet)
	fecund = agesel.byfac[["Fecund"]]
	fyears = .su(fecund$Yr)
	fage   = colnames(fecund)[-(1:grep("Label",colnames(fecund)))]
	ages   = as.numeric(fage)
	fec    = array(0, dim=c(length(fyears),length(ages)), dimnames=list(year=fyears, age=ages));
	for (i in fyears) {
		ii = as.character(i)
		fec[ii,fage] = unlist(fecund[fecund$Yr%in%i, fage])
	}

	## Natural Mortality and Survival (assume not time-varying)
	natM   = replist$Natural_Mortality  ## contains M by area and growth pattern (which can be area-specific)
	mareas = .su(natM$Area);        Nareas = length(mareas)
	mgpats = .su(natM$Bio_Pattern); Ngpats = length(mgpats)  ## growth patterns
	msexes = .su(natM$Sex);         Nsexes = length(msexes)
	mage   = colnames(natM)[-(1:grep("Era",colnames(natM)))]
	mages  = as.numeric(mage);      Nages = length(mages)
	Mvec   = array(0, dim=c(Nareas,Nsexes,Nages), dimnames=list(area=mareas, sex=msexes, age=mages));  ## assume one growth pattern for now
	for (i in mareas) {
		ii = as.character(i)
		for (j in msexes) {
			jj = as.character(j)
			Mvec[ii,jj,mage] = unlist(natM[natM$Area%in%i & natM$Sex%in%j & natM$Yr%in%EndYear, mage])
		}
	}
	sumting = apply(Mvec,1:2, function(y) {
		x = as.numeric(names(y)); #browser();return(); 
		S = if (all(diff(y)==0)) exp(-y * (x-x[1])) else exp(-y) ## not sure if this is right if M is calculated by age (or even if SS3 can calculate M by age)
		return(S)
	})
	sumtinghalf = apply(Mvec,1:2, function(y) {
		x = as.numeric(names(y)); #browser();return(); 
		S = if (all(diff(y)==0)) exp(-0.5*y * (x-x[1])) else exp(-0.5*y) ## not sure if this is right if M is calculated by age (or even if SS3 can calculate M by age)
		return(S)
	})
	## I prefer dim order to be age, sex, area 
	## https://stackoverflow.com/questions/10679131/how-to-change-order-of-array-dimensions
	Svec   <- aperm(sumting, c(1,3,2))
	Svec05 <- aperm(sumtinghalf, c(1,3,2))
	Mvec   <- aperm(Mvec, c(3,2,1))

	## Maturity
	control  = list.files(".", pattern="control.+ss$")
	cfile    = r4ss::SS_readctl(control)
	maturity = t(cfile$Age_Maturity)
	rownames(maturity) = sub("Age_","",rownames(maturity))
	colnames(maturity) = "Mat"

	## Objects for functions:
	sS.in      = list(va=va, u=u, method=method, year=EndYear, Nsexes=Nsexes, Nages=Nages)
	strategyva = strategySelect(sS.in)

	MSY.in = list(startyr=StartYear, endyr=EndYear, Nsexes=Nsexes, Nages=Nages, w=w[method,,,], fec=fec, survVec=Svec[,,method], survVec05=Svec05[,,method], strategyva=strategyva, SR=SR, RecFraction = c(0.5,0.5), maturity=maturity, M=Mvec[1,,method])

	## Setup MSY collection array
	U       = seq(StartStrategy, EndStrategy, StepStrategy)
	nProj   = length(U)
	collect = c("Yield","VB","SB","Niter")
	Nmcmc   = 10
	Npad0   = floor(log10(Nmcmc))+1
	MSYtab = array(NA, dim=c(Nmcmc,length(collect),nProj+1), dimnames=list(mcmc=1:Nmcmc, val=collect, U=c("Init",show0(U,3))) )
	ttput(MSYtab) ## store in .PBStoolEnv

	MSY.in = c(MSY.in, list(nmcmc=0))
	
	for (i in 1:1){ #Nmcmc) {  ## replaced by list.files for Report_mce_xxxx.sso
		MSY.in$nmcmc = i
		sumting = MSY(MSY.in)
	}
	ttget(MSYtab)
	msy.idx = which.max(MSYtab[1,"Yield",])
	MSY = MSYtab[1,,msy.idx]

#browser();return()

	return(list(MSYtab=MSYtab, MSY=MSY, msy.idx=msy.idx))
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~calcMSY
require(r4ss)
#if(!exists("replist")) replist=SS_output(".")
replist=SS_output(".")
MSY.area = list()
## POP : 1=5ABC, 2=3CD, 3=5DE
Nareas = 1; AreaNum = 1
for (a in 1:Nareas) {
	aa = AreaNum[a]
	MSY.area[[switch(aa,"5ABC","3CD","5DE")]] = calcMSY(replist, method=a)  ## method = commercial fleet (usually trawl but might refer to trawl in multiple areas)
}
doPlot = T
if (doPlot) {
	expandGraph(mfrow=c(Nareas,1), mar=c(3,3,1,1))
	for (a in 1:Nareas){
		aa   = AreaNum[a]
		acol = switch(aa,"blue","green4","red")
		area = switch(aa,"5ABC","3CD","5DE")
		unpackList(MSY.area[[area]], scope="L")
		x = as.numeric(dimnames(MSYtab)$U[-1])
		y = MSYtab[1,"Yield",][-1]
		plot(x,y, type="n", xlab="Harvest Rate", ylab="Yield", cex.axis=1.2, cex.lab=1.5)
		#abline(v=as.numeric(names(msy.idx)), col="slategray", lwd=2)
		segments(x0=as.numeric(names(msy.idx)), y0=0, x1=as.numeric(names(msy.idx)), y1=y[msy.idx-1], col="slategray", lwd=2)
		lines(x,y, col=acol, lwd=2)
		addLabel(0.95, 0.95, adj=c(1,1), txt=area, col=acol, cex=1.5)
	}
}



