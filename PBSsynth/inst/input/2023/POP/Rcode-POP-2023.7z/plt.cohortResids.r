## plt.cohortResids---------------------2023-05-02
## Plot age residuals by cohort.
## Removed multiple calls to quantBox when colouring by recdevs (RH 230502)
## -----------------------------------------AME|RH
plt.cohortResids <- function( obj, ages=NULL, main=NULL, lang="e", use.rdevs=T, ...)
{
	## Input is the CAc object from a Awatea res file. Ages to 59 as
	##  plus-age class will mess up year-of-birth calculation. Not automated.
	## par( oma=c(2,1,1,1), mar=c(2,2,2,1), mfrow=c(2,1) )
	## Subset to required ages - still do as don't want age 1 or 60 for cohorts
	if (!is.null(ages))
		obj <- obj[ (obj$Bin >= ages[1]) & (obj$Bin <=ages[2]), ]
	## obj$Pearson has residuals for each age, year and both sexes. Need
	##  to assign a year of birth for each age as an extra column, then
	##  presumably just do the boxplot split using that.
	obj$birthyr = obj$Yr - obj$Bin

	upar = tcall(boxpars)
	if (use.rdevs) {
		recdevs = getSS.rdevs(replist)
		#if (!is.null(ttcall(recdevs))){ ## created by function 'getSS.rdevs'
		if (!is.null(recdevs)){ ## created by function 'getSS.rdevs'
			#ttget(recdevs)
			ayrs = recdevs$Yr
			zyrs = recdevs$Yr[recdevs$Value<=0]
			medcol = rep("green4",length(ayrs)); names(medcol) = ayrs
			medcol[as.character(zyrs)] = "red"
			boxfill = rep(lucent("green",0.25),length(ayrs)); names(boxfill) = ayrs
			boxfill[as.character(zyrs)] = lucent("red",0.25)
			upar$medcol = medcol
			upar$boxfill = boxfill
		}
	}
	if( max(diff(sort(unique(obj$birthyr)))) > 1) {
		allYears = min(obj$birthyr):max(obj$birthyr)
		nodataYears = allYears[ !(allYears %in% obj$birthyr)]
		xx = split(c(obj$Pearson, rep(NA, length(nodataYears))), c(obj$birthyr, nodataYears))
		#xpos <- boxplot( xx, whisklty=1, xlab="", ylab="", outline=FALSE )     #AME outline=FALSE removes outliers
		#xpos = quantBox(xx, xaxt="n", yaxt="n", xlab="", ylab="", pars=tcall(boxpars), add=FALSE)
		xpos = quantBox(xx, xaxt="n", yaxt="n", xlab="", ylab="", pars=upar, add=FALSE)
		xyrs = setdiff(allYears, nodataYears)
		if (length(xyrs)>20)
			xyrs = sort(unique(ceiling(xyrs/5)*5))
		axis(1, at=match(xyrs,as.numeric(xpos$names)), labels=xyrs, ..., mgp=c(2,0.5,0))
	} else {
		#xpos=boxplot( split( obj$Pearson, obj$birthyr ), whisklty=1, xlab="", ylab="", outline=FALSE )     #AME outline=FALSE removes outliers
		#xpos = quantBox(split(obj$Pearson,obj$birthyr), xaxt="n", yaxt="n", xlab="", ylab="", pars=tcall(boxpars), add=FALSE)
		xpos = quantBox(split(obj$Pearson,obj$birthyr), xaxt="n", yaxt="n", xlab="", ylab="", pars=upar, add=FALSE)
		xyrs = sort(unique(ceiling(obj$birthyr/5)*5))
		axis(1, at=match(xyrs,as.numeric(xpos$names)), labels=xyrs, ..., mgp=c(2,0.5,0))
	}
#browser();return()
	#if (use.rdevs) {
	#	plotSS.rdevs(replist, subplot=1, plot=F, print=F)
	#	if (!is.null(ttcall(recdevs))){ ## created by function 'plotSS.rdevs'
	#		ttget(recdevs)
	#		zyrs = recdevs$Yr[recdevs$Value>0]
	#		zpar = upar = tcall(boxpars)
	#		zpar$boxfill=lucent("green",0.25); zpar$medcol="green4"
	#		upar$boxfill=lucent("red",0.25); upar$medcol="red"
	#		#zpar$boxfill=lucent("red",0.5)
	#		zbox = ubox = split(obj$Pearson,obj$birthyr)
	#		zbox[!is.element(names(zbox),zyrs)] = NA
	#		ubox[is.element(names(zbox),zyrs)] = NA
	#		quantBox(zbox, xaxt="n", yaxt="n", xlab="", ylab="", pars=zpar, add=TRUE)  ## this only seems to work if there are no more frames available
	#		quantBox(ubox, xaxt="n", yaxt="n", xlab="", ylab="", pars=upar, add=TRUE)
	#	}
	#}
	abline( h=0, lty=2, col="blue" )
	axis(2, ...)
	mtext( side=1, line=2, ..., text=linguaFranca("Year of birth",lang) )
	if ( !is.null(main) )
		mtext( side=3, line=-0.5, ..., outer=TRUE, text=linguaFranca(main,lang) )
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~plt.cohortResids
so("getSS.rdevs.r","synth")
