## plt.yearResids-----------------------2019-07-18
## AME adding to plot age residuals by year. Is called for comm and survs.
##  fill.in=TRUE is to add the missing years for boxplot
##  ..POP does not do qq plot. See popScape.r for previous.
## -----------------------------------------AME|RH
plt.yearResids <- function(obj, ages=NULL, main=NULL, fill.in=TRUE, lang="e", ...)
{
	# Subset to required ages - still do as don't want age 1.
	if (!is.null(ages))
		obj <- obj[ (obj$Bin >= ages[1]) & (obj$Bin <=ages[2]), ]
	if(fill.in) {
		allYears = min(obj$Yr):max(obj$Yr)
		nodataYears = allYears[ !(allYears %in% obj$Yr)]
		xx = split(c(obj$Pearson, rep(NA, length(nodataYears))), c(obj$Yr, nodataYears))
		#xpos <- boxplot( xx, whisklty=1, xlab="", ylab="", outline=FALSE, ... )     #AME outline=FALSE removes outliers
		xpos = quantBox(xx, xaxt="n", yaxt="n", xlab="", ylab="", pars=tcall(boxpars), ...)
		xyrs = setdiff(allYears, nodataYears)
		axis(1, at=match(xyrs,as.numeric(xpos$names)), labels=xyrs, ..., mgp=c(2,0.5,0))
#browser();return()
	} else {
		#xpos <- boxplot( split( obj$Pearson, obj$Yr ), whisklty=1, xlab="", ylab="", outline=FALSE, ... ) #AME outline=FALSE removes outliers
		xpos = quantBox( split(obj$Pearson,obj$Yr), xaxt="n", yaxt="n", xlab="", ylab="", pars=tcall(boxpars), ...)
		xyrs = sort(unique(ceiling(obj$Yr/5)*5))
		axis(1, at=match(xyrs,as.numeric(xpos$names)), labels=xyrs, ..., mgp=c(2,0.5,0))
	}
	abline( h=0, lty=2, col="red" )
	axis(2, ...)
	mtext( side=1, line=2, ..., text=linguaFranca("Year",lang) )
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~plt.yearResids
