## First set up workspace:

#run=21; rwt=1; ver="3a"  ## CST
run=24; rwt=1; ver="1a"  ## 5ABC
#run=25; rwt=1; ver="1a"  ## 3CD
#run=26; rwt=1; ver="1a"   ## 5DE
redoFigs = F
so("initialise.r","synth")

if (!grepl(ver,getwd())) {.flush.cat("Appears to be version msismatch: ",ver," not in ",basename(getwd()),"\n",sep=""); browser();return()}

type = "MCMC"
require(r4ss)
require(xtable)
options(scipen=10)
lang=c("e")

d.tools = "C:/Users/haighr/Files/Projects/R/Develop/PBStools/Authors/Rcode/develop/"
r.tools = c("linguaFranca", "clearFiles","extractAges","calcStockArea","texArray","plotSnail")
for (i in r.tools) source(paste0(d.tools,i,".r"))

d.synth = "C:/Users/haighr/Files/Projects/R/Develop/PBSsynth/Authors/Rcode/develop/"
## Current repository
R.synth = c("plotFuns","utilFuns","zzz")
for (i in R.synth) source(paste0(d.synth,"current/",i,".r"))
## Development repository
r.synth = c("calcStdRes", "ptab", "convPN", "plotSS.pars", "plotSS.pairs", "weightAF", "plotSS.ts", "plotSS.rdevs")
for (i in r.synth) source(paste0(d.synth,i,".r"))

d.awatea = "C:/Users/haighr/Files/Projects/R/Develop/PBSawatea/Authors/Rcode/develop/"
r.awatea = c("mochaLatte","panelBoxes","panelChains","panelTraces","plotACFs","plotTraj")
for (i in r.awatea) source(paste0(d.awatea,i,".r"))

if (exists("SS_output", envir=.GlobalEnv, inherits=FALSE))
	rm ("SS_output", envir=.GlobalEnv, inherits=FALSE)
# mpd.dir = sub("\\.mh.+","",sub("\\.hm.+","",sub("\\.nuts.+","",sub("MCMC","MPD",getwd()))))
mpd.dir = sub("[a-z]$", "", sub("\\.mh.+", "", sub("\\.hm.+", "", sub("\\.nuts.+", "", sub("MCMC","MPD",getwd())))))

if (!file.exists(paste0(mpd.dir,"/Report.sso"))) {
	alt.dir = rev(sort(grep("MPD.+v\\d",dir(dirname(mpd.dir)),value=T)))
	mpd.dir = paste0(dirname(mpd.dir),"/", alt.dir[1])
}
#replist = SS_output(dir=sub("\\.mh.+","",sub("\\.hm.+","",sub("\\.nuts.+","",sub("MCMC","MPD",getwd())))))
replist = SS_output(dir=mpd.dir)

B.mpd = replist$timeseries$SpawnBio
R.mpd = replist$timeseries$Recruit_0
names(B.mpd) = names(R.mpd) = replist$timeseries$Yr

parameters   = replist$parameters
pactive = parameters[!is.na(parameters$Active_Cnt) & parameters$Phase>0 & !is.element(parameters$Pr_type,"dev"),]
pactive$Label = convPN(pactive$Label)

P.mpd   = pactive$Value; names(P.mpd)=pactive$Label
P.rc    = .findSquare(length(P.mpd))

## Get MCMC values -------------------------------
if (dir.exists("./sso")) {
	mcmc.dir="./sso"; mcmc.linux=TRUE
} else {
	mcmc.dir="."; mcmc.linux=FALSE
}
d.mcmc = SSgetMCMC(dir=mcmc.dir)
colnames(d.mcmc) = convPN(colnames(d.mcmc))
replist$mcmc = d.mcmc
n.mcmc = nrow(d.mcmc)
#browser();return()

P.mcmc    = d.mcmc[,names(P.mpd)]
B.mcmc    = d.mcmc[,grep("^SSB_[12]",colnames(d.mcmc))]
##D.mcmc    = d.mcmc[,grep("^Bratio_[12]",colnames(d.mcmc))]  ## Bratio is not depletion in our terms
D.mcmc    = B.mcmc/B.mcmc[,1]
R.mcmc    = d.mcmc[,grep("^Recr_[12]",colnames(d.mcmc))]
Rdev.mcmc = d.mcmc[,grep("^RecrDev_[12]",colnames(d.mcmc))]
SPR.mcmc  = d.mcmc[,grep("^SPRratio_[12]",colnames(d.mcmc))]
if (replist$F_method==1) {
	## Pope's approximation (discrete)
	u.mcmc = d.mcmc[,grep("^F_[12]",colnames(d.mcmc))]; colnames(u.mcmc) = sub("^F_","u_",colnames(u.mcmc))
	F.mcmc = -log(1-u.mcmc)
	umsy.mcmc = d.mcmc[,"annF_MSY"]
	Fmsy.mcmc = -log(1-umsy.mcmc)
} else {
	## Baranov or Hybrid (continuous)
	F.mcmc = d.mcmc[,grep("^F_[12]",colnames(d.mcmc))]
	u.mcmc = 1-exp(-F.mcmc); colnames(u.mcmc) = sub("^F_","u_",colnames(u.mcmc))
	Fmsy.mcmc = d.mcmc[,"annF_MSY"]
	umsy.mcmc = 1-exp(-Fmsy.mcmc)
}
MSY.mcmc  = d.mcmc[,"Dead_Catch_MSY"]
Bmsy.mcmc = d.mcmc[,"SSB_MSY"]
BoverBmsy = B.mcmc/Bmsy.mcmc
UoverUmsy = u.mcmc/umsy.mcmc

## Calculate proportion allocation of R0 by area (and year)
fR.mcmc = NA
if (narea>1) {
	fR = d.mcmc[,grep("Rdist\\_area\\(\\d)$", colnames(d.mcmc),value=T)]
	missRdist = setdiff (1:narea, gsub("[^0-9.-]", "", colnames(fR)) )
	fR[,gsub("\\d", missRdist, colnames(fR)[1])] = rep(0,nrow(fR))
	RdistDev = setdiff(grep("Rdist",colnames(d.mcmc),value=T), colnames(fR))
	RdistYrs = .su(as.numeric(revStr(substring(revStr(RdistDev),1,4))))
	fR.names = colnames(fR)
	for (i in RdistYrs) {
		dev.name = paste0(fR.names,"_DEVadd_",i)
		fR[,dev.name] = 0
		for (j in dev.name) {
			if(!j %in% colnames(d.mcmc)) next
			fR[,j] = d.mcmc[,j]
		}
	}
	calcParea = function(Rdist, tvRdev=1, Rdev) {
		Narea  = length(Rdist)
		Rdist.adj = Rdist + tvRdev * Rdev
		for (a in 1:Narea) {
			parea = exp(Rdist.adj[,a]) / t(t(apply(exp(Rdist.adj),1,sum)))
			if (a==1) Parea = parea
			else      Parea = cbind(Parea, parea)
		}
		colnames(Parea) = gsub("\\_DEVadd","",gsub("Rdist","Rprop",colnames(Rdev)))
		return(Parea)
	}
	for (i in RdistYrs) {
		dev.name = paste0(fR.names,"_DEVadd_",i)
		iRdist   = fR[,fR.names]
		iRdev    = fR[,dev.name]
		parea    = calcParea(Rdist=iRdist, Rdev=iRdev)
		fR       = cbind(fR, parea)
	}
	fR.mcmc = fR
#browser();retun()
} ## end calculation of Rprop

diag.mpd  = list(B=B.mpd, R=R.mpd, P=P.mpd)
diag.mcmc = list(B=B.mcmc, R=R.mcmc, P=P.mcmc)
#browser();return()

#save("P.mpd", "P.mcmc", "B.mcmc", "D.mcmc", "R.mcmc", "Rdev.mcmc", "F.mcmc", "u.mcmc", "MSY.mcmc", "Bmsy.mcmc", "Fmsy.mcmc", "umsy.mcmc", "BoverBmsy", "UoverUmsy", file=paste0("MCMC.", paste0(pad0(run,2),".",pad0(rwt,2)), ".rda"))

## --------SET VALUES-------------------
#pfigs = if(mcmc.linux) c("pmcmc","dmcmc","rmcmc") else c("dmcmc","rmcmc")    #"nada" #"dmcmc" #
pfigs  = c("pmcmc","dmcmc","rmcmc")
ptypes = "png";  lang=lang
if (all(pfigs=="nada")){
	ptypes = "win"; lang=c("e")
}
do.call("assign", args=list(x="quants3", value=c(0.05,0.50,0.95), envir=.PBSmodEnv))
do.call("assign", args=list(x="quants5", value=c(0.05,0.25,0.50,0.75,0.95), envir=.PBSmodEnv))

run.rwt = paste0(pad0(run,2),".",pad0(rwt,2))
run.rwt.ver = paste0(run.rwt,".v",ver)
currYr  = 2024
modYrs  = 1935:currYr
proYrs  = (currYr+1):(currYr+10)
#assYrs  = c(2001,2010,2012,2017)  ## moved to 'initialise.r'
#ngear   = 3  ## number of commercial fisheries (now handled by 'initialise.r')
#nfleet  = 9  ## number of fleets (fisheries + surveys) (now handled by 'initialise.r')

if (redoFigs && "pmcmc" %in% pfigs) { ## Parameter MCMC quantile plots
	so("plotSS.pmcmc.r","synth")
	plotSS.pmcmc(R.mcmc, yrs=modYrs, pyrs=proYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(Recruitment~(italic(R)[italic(t)])), outnam="recruitsMCMC", ptypes=ptypes)
	plotSS.pmcmc(F.mcmc, yrs=modYrs, pyrs=proYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(Fishing~mortality~(italic(F)[italic(t)])), outnam="fishmortMCMC", ptypes=ptypes)
	plotSS.pmcmc(u.mcmc, yrs=modYrs, pyrs=proYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(Exploitation~rate~(italic(u)[italic(t)])), outnam="exploitMCMC", ptypes=ptypes)
	plotSS.pmcmc(D.mcmc, yrs=modYrs, pyrs=proYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(Depletion~(italic(B)[italic(t)]/italic(B)[0])), outnam="depleteMCMC", ptypes=ptypes, LRP=0.2, USR=0.4)
	plotSS.pmcmc(B.mcmc, yrs=modYrs, pyrs=proYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(Spawning~biomass~(italic(B)[italic(t)])), outnam="sbiomassMCMC", ptypes=ptypes)
	plotSS.pmcmc(SPR.mcmc, yrs=modYrs, pyrs=proYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab="Spawners per recruit", outnam="sprMCMC", ptypes=ptypes)
	plotSS.pmcmc(Rdev.mcmc, yrs=modYrs, pyrs=proYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab="Recruitment deviations", outnam="recdevMCMC", ptypes=ptypes, y0=F)
	plotSS.pmcmc(BoverBmsy, yrs=modYrs, pyrs=proYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(italic(B)[italic(t)]/italic(B)[MSY]), outnam="boverbmsyMCMC", xyType="envelope", ptypes=ptypes, LRP=0.4, USR=0.8)
	plotSS.pmcmc(UoverUmsy, yrs=modYrs, pyrs=proYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(italic(u)[italic(t)]/italic(u)[MSY]), outnam="uoverumsyMCMC", xyType="envelope", ptypes=ptypes, USR=1)
}
if (redoFigs && "dmcmc" %in% pfigs) { ## Diagnostic for MCMCs
	so("plotSS.dmcmc.r","synth")
	plotSS.dmcmc(mcmcObj=diag.mcmc, mpdObj=diag.mpd, ptypes=ptypes, lang=lang)
}
if (redoFigs && "rmcmc" %in% pfigs) { ## Routine output for MCMCs
	so("plotSS.rmcmc.r","synth")
	plotSS.rmcmc(mcmcObj=diag.mcmc, mpdObj=diag.mpd, ptypes=ptypes, lang=lang)
}
if (redoFigs) { resetGraph(); expandGraph(); eop() }

##---Tables 3-5 -------------------------
## Likelihoods Used from replist
## Get numbers from chunk above

##----------Table 1-----------
xtab1  = t(sapply(P.mcmc,quantile,tcall(quants5)))
colnames(xtab1) =  gsub("\\%","\\\\%",colnames(xtab1))
xtabL1 = texArray(xtab1, table.label="tab:pars.mcmc", sigdig=4, zero="0", use.row.names=T, name.row.names="Parameters", tablewidth=6, table.caption="Parameter quantiles." )

ttabL1 = xtabL1$tabfile
cat(ttabL1, sep="\n")

##----------Table 2-----------

yrsUse = modYrs[c(1,length(modYrs)+c(-1,0))]
yrsChr = as.character(yrsUse)  ## !!!! currYear = prevYear for F and u 

B.tab      = d.mcmc[,findPat(paste0("^SSB_",yrsChr[c(1,3)]),colnames(d.mcmc)),drop=F];
	colnames(B.tab)=gsub("SSB","B",colnames(B.tab))
D.tab      = d.mcmc[,findPat(paste0("^SSB_",yrsChr[c(3)]),colnames(d.mcmc)),drop=F] /
	B.tab[,findPat(paste0("^B_",yrsChr[c(1)]),colnames(B.tab)),drop=F] 
	colnames(D.tab)=paste0(gsub("SSB","B",colnames(D.tab)),"/B_0")
F.tab      = d.mcmc[,findPat(paste0("^F_",yrsChr[c(3)]),colnames(d.mcmc)),drop=F]
	## use same year as B but B's start year denotes u's previous year (mid-way) so adjust name:
	dimnames(F.tab)[[2]] = sub(yrsChr[3],yrsChr[2],dimnames(F.tab)[[2]])
u.tab      = 1-exp(-F.tab); colnames(u.tab)=gsub("F","u",colnames(u.tab))
MSY.tab    = d.mcmc[,"Dead_Catch_MSY",drop=F] ; colnames(MSY.tab)=gsub("Dead_Catch_","",colnames(MSY.tab))
Bmsy.tab   = d.mcmc[,"SSB_MSY",drop=F] ; colnames(Bmsy.tab)=gsub("SSB","B",colnames(Bmsy.tab))
B.Bmsy.tab = B.tab[,2,drop=F]/Bmsy.tab ; colnames(B.Bmsy.tab)=paste0(colnames(B.Bmsy.tab),"/B_MSY")
Bmsy.B0.tab = Bmsy.tab/B.tab[,1,drop=F] ; colnames(Bmsy.B0.tab)="B_MSY/B_0"
Fmsy.tab   = d.mcmc[,"annF_MSY",drop=F]; colnames(Fmsy.tab)=gsub("ann","",colnames(Fmsy.tab))
umsy.tab   = 1-exp(-Fmsy.tab)          ; colnames(umsy.tab)=gsub("F","u",colnames(umsy.tab))
u.umsy.tab = u.tab/umsy.tab            ; colnames(u.umsy.tab)=paste0(colnames(u.umsy.tab),"/u_MSY")

A.mcmc   = cbind(B.tab, D.tab, F.tab, u.tab, MSY.tab, Bmsy.tab, B.Bmsy.tab, Bmsy.B0.tab, Fmsy.tab, umsy.tab, u.umsy.tab)
subs     = grep("^MSY$",colnames(A.mcmc),invert=TRUE)
colnames(A.mcmc)[1] = "B_0"
colnames(A.mcmc) = gsub("MSY","\\\\text{MSY}",gsub("/","}/",gsub("_","\\_{",colnames(A.mcmc))))
colnames(A.mcmc)[subs] = paste0("$",colnames(A.mcmc)[subs],"}$")

#eval(parse(text=deparse("\u{005F}")))

xtab2  = t(sapply(A.mcmc,quantile,tcall(quants5), na.rm=TRUE))
colnames(xtab2) =  gsub("\\%","\\\\%",colnames(xtab2))
xtabL2 = texArray(xtab2, table.label="tab:dpars.mcmc", sigdig=4, zero="0", uscore="_", use.row.names=T, name.row.names="Derived parameters", tablewidth=6, table.caption="Derived parameter quantiles." ) ## Specify underscore character in texArray!!!

ttabL2 = xtabL2$tabfile
cat(ttabL2, sep="\n")


