## prepMPD------------------------------2023-09-05
##  Prepare MPD runs from previous runs for analysis.
## ---------------------------------------------RH
prepMPD = function(run.rwt.ver,
	d.base = "C:/Users/haighr/Files/GFish/PSARC23/POP/Data/SS/POP2023",
	w=NULL, cvpro=NULL, modify=TRUE)
{
	padded = pad0(run.rwt.ver[c(1,2,4,5)],2)
	vers   = paste0("v",run.rwt.ver[c(3,6)])
	n.run=padded[1]; n.rwt=padded[2]; l.run=padded[3]; l.rwt=padded[4]
	pre.run.rwt = paste(l.run, l.rwt, vers[2], sep=".")
	new.run.rwt = paste(n.run, n.rwt, vers[1], sep=".")
	## Destination directories
	#d.cwd = getwd(); on.exit(setwd(d.cwd))
	d.run = file.path(d.base,paste0("Run",n.run))
	d.mpd = file.path(d.run,paste("MPD",new.run.rwt,sep="."))

	## Previous run from which to poach ssfiles
	if (run.rwt.ver[4]==0 && run.rwt.ver[5]==0) {
		## Preliminary run so get files from d.base
		p.run = p.mpd = d.base
	} else {
		p.run = file.path(d.base,paste0("Run",l.run))
		p.mpd = file.path(p.run,paste("MPD",pre.run.rwt,sep="."))
	}
	if (!all(file.exists(c(p.run,p.mpd))))
		stop("Previous Run directory and/or MPD directory does not exist")
	if (!file.exists(d.run)) dir.create(d.run)
	if (!file.exists(d.mpd)) dir.create(d.mpd)
	p.ss  = setdiff(list.files(p.mpd, pattern="\\.ss$"),"runnumber.ss")
	if (length(p.ss)!=4) {
		.flush.cat("Need 4 distinct ss files----------","\n"); browser(); return() }
	for (fnam in c("starter","forecast")) {
		pnam  = paste0(fnam, ".ss")
		pee   = file.copy(from=file.path(p.mpd,pnam), to=d.mpd, copy.date=T, overwrite=T)
	}
	for (fnam in c("data","control")) {
		from = file.path(p.mpd,paste(fnam,l.run,l.rwt,"ss",sep="."))
		to   = file.path(d.mpd,paste(fnam,n.run,n.rwt,"ss",sep="."))
		if (file.exists(from)) {
			poo   = file.copy(from=from, to=to, copy.date=T, overwrite=T)
		} else {
			.flush.cat("sumtingwong", "\n"); browser(); return()
		}
	}
	d.ss    = file.path(d.mpd, list.files(d.mpd, pattern="\\.ss$"))
	sfile   = d.ss[grep("/starter\\.",d.ss)]
	ffile   = d.ss[grep("/forecast\\.",d.ss)]
	dfile   = d.ss[grep("/data\\.",d.ss)]
	cfile   = d.ss[grep("/control\\.",d.ss)]
#browser();return()
	## Modify starter file to reflect new run
	#starter = readLines(file.path(d.mpd,"starter.ss"))
	#dline   = grep(paste("data", pre.run.rwt,sep="."), starter)
	#cline   = grep(paste("control", pre.run.rwt, sep="."), starter)
	#starter[dline] = sub(paste0("data\\.",l.run,"\\.",l.rwt),paste0("data.",new.run.rwt),starter[dline])
	#starter[cline] = sub(paste0("control\\.",l.run,"\\.",l.rwt),paste0("control.",new.run.rwt),starter[cline])
	#writeLines(starter, con=file.path(d.mpd,"starter.ss"))
#browser();return()
	starter = readLines(sfile)
	dline   = grep("(\\s+)?data\\.", starter)
	cline   = grep("(\\s+)?control\\.", starter)
	starter[dline] = sub(grep("data",p.ss,value=TRUE), basename(dfile), starter[dline])
	starter[cline] = sub(grep("control",p.ss,value=TRUE), basename(cfile), starter[cline])
	writeLines(starter, con=sfile)

	## Modify data file to add cvpro using the Francis method
	#data = readLines(file.path(d.mpd,paste0("data.",new.run.rwt,".ss")))
	data = readLines(dfile)
	if (!is.null(cvpro)){
		data = gsub("^\\s+|\\s+$", "", data)  ## get rid of leading and trailing spaces
		vline = intersect(grep("_index$",data), grep("^#",data,invert=TRUE))
		if (length(vline)==0) {
			.flush.cat("Cannot identify index data----------","\n"); browser(); return() }
		vbits = strsplit(data[vline], split="\\s+")
		if (length(.su(sapply(vbits,function(x){x[3]}))) != length(cvpro)){
			.flush.cat("User inputs for cvpro do not match indices in data file\n")#; browser();return()
		}
		vdump = sapply(1:length(vbits),function(i){vbits[[i]][5] <<- sqrt(as.numeric(vbits[[i]][5])^2 + cvpro[vbits[[i]][3]]^2) })
		vnew  = sapply(vbits,function(x){ paste0(x,collapse=" ")})
		data[vline] = vnew
		#writeLines(data, con=file.path(d.mpd,paste0("data.",new.run.rwt,".ss")))
		writeLines(data, con=dfile)
	}
	## Modify control file to add Francis reweights
	#control = readLines(file.path(d.mpd,paste0("control.",new.run.rwt,".ss")))
	control = readLines(cfile)
	if (!is.null(w)){
		control = gsub("^\\s+|\\s+$", "", control)  ## get rid of leading and trailing spaces
		fline = intersect(grep("vadj_af",control), grep("^#",control,invert=TRUE))
		if (length(fline)==0) {
			.flush.cat("Cannot identify variance adjustment factors for AFs----------","\n"); browser(); return() }
#browser();return()
		if (length(fline)!=length(w)){
			.flush.cat("Francis reweights do not match control lines\n"); browser();return()
		}
		fbits = strsplit(control[fline], split="\\s+")
		wdump = sapply(1:length(fbits),function(i){fbits[[i]][3] <<- w[fbits[[i]][2]] }) #w[i]})
		fnew  = sapply(fbits,function(x){ paste0(x,collapse=" ")})
		control[fline] = fnew
		#writeLines(control, con=file.path(d.mpd,paste0("control.",new.run.rwt,".ss")))
		writeLines(control, con=cfile)
	}
	if (modify) {
		.flush.cat(paste0("***Edit the ss files in\n\t",d.mpd,"\nbefore proceeding with an MPD fit in SS."),"\n\n")
	} else {
		p.all  = list.files(p.mpd,full.names=F)
		p.copy = grep("\\.png$|\\.ss$|\\.bak$|french",p.all,value=T,invert=T)
		n.copy = sub(pre.run.rwt,new.run.rwt,p.copy)  ## change names of files sporting previous run.rwt.ver
		file.copy(from=file.path(p.mpd,p.copy), to=file.path(d.mpd,n.copy), copy.date=T, overwrite=T)
#browser();return()
		##file.copy sumting
	}
#	if (!is.null(w) || !is.null(cvpro)){
#	}
	setwd(d.mpd)
	return(invisible(list(starter=starter, data=data, control=control)))
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~prepMPD

#prepMPD(run.rwt=c(7,0,6,0))
#prepMPD(run.rwt=c(7,1,7,0))
#prepMPD(run.rwt=c(run,rwt,run,rwt-1),w=ttcall(w.francis)$w)
#prepMPD(run.rwt=c(run,rwt,2,0), d.base = "C:/Users/haighr/Files/GFish/PSARC23/PEL/Data/SS/PEL2023") ## new run, new reweight, like run, like reweight
#prepMPD(run.rwt=c(run,rwt,run,rwt-1),w=wtemp,cvpro=cvpro, d.base = "C:/Users/haighr/Files/GFish/PSARC23/PEL/Data/SS/PEL2023")
#prepMPD(run.rwt.ver=c(run,rwt,ver,17,0,17), modify=FALSE) ## new run, new reweight, new version,  like run, like reweight, like version

