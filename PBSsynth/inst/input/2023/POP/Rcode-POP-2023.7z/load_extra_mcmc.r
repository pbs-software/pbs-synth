## load_extra_mcmc----------------------2023-09-05
##  Load extra MCMC information from Report files 
##  generated for every sample.
##  Only use for area-based models at this point.
## 'run' is only used as a tag in this function.
## ------------------------------------------CG|RH
load_extra_mcmc <- function(dir.mcmc=".", dir.extra="./sso", 
   quants5=c(0.05,0.25,0.5,0.75,0.95),  RC=c(TRUE,FALSE), loadCP=FALSE,
   startyr=1935, run="17v17a", areas=c("5ABC","3CD","5DE"), Fmethod=3, 
   plot=TRUE, png=FALSE, pngres=400, PIN=c(9,9), lang="e",
   show.combo=TRUE, vertical=FALSE)
{
	cwd = getwd()
	on.exit(setwd(cwd))

	## RC = boolean to use Reports and/or CompReports (comps not really needed)
	# on.exit(gc(verbose=FALSE))  ## garbage collection is a painfully slow process

	## Subfunctions--------------------------------
	## Extract a table from the report file
	makeRepTab = function(dat, pat1, pat2, off1=2, off2=2, hup=1)
	{
		begin.idx = grep(pat1, dat) + off1
		end.idx   = grep(pat2, dat) - off2
		head.idx  = begin.idx - hup
#browser();return()
		head.dat   = gsub("^\\s+|\\s+$","",dat[head.idx])  ## get rid of leading and trailing whitespace
		col.nams  = strsplit(head.dat, split="\\s+")[[1]]
		dat.idx    = begin.idx:end.idx
		data.dat   = gsub("^\\s+|\\s+$","",dat[dat.idx])  ## get rid of leading and trailing whitespace
		data.tmp  = strsplit(data.dat, split="\\s+")
		data.tab  = do.call("rbind", lapply(data.tmp, function(x) {
			if(is.null(dim(x))) x=t(x)
			data.frame(x, stringsAsFactors=FALSE)
			}) )
		colnames(data.tab) = col.nams
		rownames(data.tab) = dat.idx
		return(data.tab)
	}
	orderRuns = function(rnames, get0pad.only=FALSE) {
		rdir   = dirname(rnames)
		rnames = basename(rnames)
		rlens  = regexpr("\\d+", rnames)
		oldnum = as.numeric(substring(rnames, rlens, rlens + attributes(rlens)$match.length - 1))
		npad0  = floor(log10(max(oldnum))) + 1
		if (get0pad.only)
			return(npad0)
		newnum = pad0(oldnum, n=npad0)
		outnam = paste0(rdir, "/", rnames[order(newnum)])
		attr(outnam,"npad0") = npad0
		return(outnam)
	}
	## Pad individula run based on names of all runs
	padRun = function(onefile, allfiles) {
		bname  = basename(onefile)
		z      = regexpr("\\d+", bname)
		npad0  = orderRuns(allfiles, get0pad.only=TRUE)
		outnam = pad0(substring(bname, z, z + attributes(z)$match.length - 1), npad0)  ## check that order of reps makes sense
		return(outnam)
	}
	## End subfunctions----------------------------

	## Extract relevant subset of time series values, if they exist, and bypass reconstruction
	dir.output = ifelse(loadCP, dir.extra, dir.mcmc)  ## if using CPs, change the output target directory
	setwd (dir.output)
	if (file.exists(paste0(dir.output, "/mcmc.ts.sub.rda"))) {  ## always load it to be safe
		#if (!exists("mcmc.ts.sub", envir=.GlobalEnv) || run!=srun) {
		.flush.cat("Loading mcmc.ts.sub object from saved binary\n")
		tic(); load("mcmc.ts.sub.rda", envir=.GlobalEnv); toc()
		#}
	} else {
		if (file.exists(paste0(dir.output, "/mcmc.ts.rda"))) {
			if (exists("mcmc.ts.sub", envir=.GlobalEnv))
				rm("mcmc.ts.sub", envir=.GlobalEnv)
			.flush.cat("Loading mcmc.ts object from saved binary\n")
			tic(); load("mcmc.ts.rda", envir=.GlobalEnv); toc()
		} else {
			## Start the reconstruction
			## r4ss outputs names with non-sequential numbers if #iterations > 9999 (fixes padding of zeroes to 4)
			## Re-order extra files just in case (e.g., # iterations = 20,000):
			## Get the number of Report.sso files in the directory
			dir_list  = dir(dir.extra, full.names = TRUE)
			repfiles  = grep("/Report_mce_.*$", dir_list, value = TRUE)
			if (length(repfiles)==0)
				stop("Need the set of extra report files (on Linux)")
			repfiles  = orderRuns(grep("/Report_mce_.*$", dir_list, value = TRUE))
			## Get the number of CompReport.sso files in the directory
			compfiles  = grep("/CompReport_mce_.*$", dir_list, value = TRUE)
			if (RC[2]) {
				if (length(compfiles)==0)
					stop("Need the set of extra composition report files (on Linux)")
				else
					compfiles = orderRuns(grep("/CompReport_mce_.*$", dir_list, value = TRUE))
			}
			replist   = complist = list()
			#dump = gc(verbose=FALSE)

			## Only do this once for gawd's sake
			if (!file.exists("reps.rda") && length(repfiles)>0)  ## check for need to start from scratch
				RC[1] = TRUE
			#if (!RC[1] && !file.exists("reps.rda") && !exists("reps", envir=.GlobalEnv) && length(repfiles)>0)  ## check for need to start from scratch
				#RC[1] = TRUE
			if (RC[1]) {  ## Reports files
				.flush.cat(paste0("Reading ", length(repfiles), " 'Reports' (ascii files)"), "\n")
				for (i in 1:length(repfiles)) {
				#for (i in c(1,10,100,1000,2000)) {
					ii = padRun(repfiles[i], repfiles)
					replist[[ii]] = Kmisc::read(repfiles[i])  ## Kmisc::readlines crashes R
				}
				dump = gc(verbose=FALSE)
				tic(); reps = lapply(replist, function(x) { strsplit(x,split=ifelse(grepl("\\r\\n",x), "\\r\\n", "\\n"))[[1]] }); toc()
				#tic(); reps = mclapply(replist, function(x) { strsplit(x,split="\\r\\n")[[1]] }); toc()            ## 66.81 secs
				#tic(); reps = lapply(replist, function(x) { stringr::str_split(x, pattern="\\r\\n")[[1]] }); toc() ## 83.22 secs
				dump = gc(verbose=FALSE)
				rrun = run  ## reps run
				save("reps", "rrun", file="reps.rda")
			} else {
				if (!file.exists("mcmc.ts.rda")){
					if (!exists("reps", envir=.GlobalEnv) || run!=rrun) {
						.flush.cat("Loading Reports object from saved binary\n")
						tic(); load("reps.rda", envir=.GlobalEnv); toc()
					}	
				}
			}
			## Only do this once for gawd's sake (but really don't need it for POP)
			if (RC[2]) {
				if (!file.exists("comps.rda") && length(compfiles)>0)  ## check for need to start from scratch
					RC[2] = TRUE
				if (RC[2]) {  ## CompReports files
					.flush.cat(paste0("Reading ", length(compfiles), " 'CompReports' (ascii files)"), "\n")
					for (i in 1:length(compfiles)) {
						ii = padRun(compfiles[i], compfiles)
						complist[[ii]] = Kmisc::read(compfiles[i])  ## Kmisc::readlines crashes R
					}
					dump = gc(verbose=FALSE)
					tic(); comps = lapply(complist, function(x) { strsplit(x,split="\\r\\n")[[1]] }); toc() 
					dump = gc(verbose=FALSE)
					crun = run  ## comps run
					save("comps", "crun", file="comps.rda")
				} else {
					if (!exists("comps", envir=.GlobalEnv) || run!=crun) {
						.flush.cat("Loading CompReports object from saved binary\n")
						tic(); load("comps.rda", envir=.GlobalEnv); toc()
					}
				}
			}
		## Gather the time series elements
		## Aside: parallel processing much slower than lapply
		# require(snow)
		# cl <- makeCluster(spec=detectCores()-1, type="SOCK")
		# tic(); out=clusterApply(cl, reps, function(x) {makeRepTab(dat=x, pat1="^TIME_SERIES", pat2="^SPR_SERIES")} ); toc() ## 635.52 sec = 10.6 min
		# stopCluster(cl)
	
		## Make time series object
		#if (!file.exists("mcmc.ts.rda") || RC[1]) {
			.flush.cat("Extracting 'mcmc.ts' object from 'reps' object\n")
			tic(); mcmc.ts = lapply(reps, function(x) { makeRepTab(dat=x, pat1="^TIME_SERIES", pat2="^SPR_SERIES") }); toc()  ## ~5 min for 2000 MCMC samples
			#mcmc.exp = lapply(reps, function(x) { makeRepTab(dat=x, pat1="^EXPLOITATION report:14", pat2="^CATCH report:15", off1=13, hup=5) })
#browser();return()

			trun = run  ## time series run
			save("mcmc.ts", "trun", file="mcmc.ts.rda")
		#} else {
		#	## Should reload it in case a previous MCMC object sits in memory
		#	if (!exists("mcmc.ts", envir=.GlobalEnv) || run!=trun) {
		#		.flush.cat("Loading mcmc.ts object from saved binary\n")
		#		tic(); load("mcmc.ts.rda", envir=.GlobalEnv); toc()
		}
		#}
		nmcmc = length(mcmc.ts)
		npad0 = floor(log10(nmcmc))+1   ## for actual number of MCMC samples
		#npad0 = floor(log10(max(as.numeric(names(reps)))))+1

#		## Make MSY object (report 54 missing from Report_mcs*.sso files!)
#		if (!file.exists("mcmc.msy.rda")) {
#			.flush.cat("Extracting 'mcmc.msy' object from 'reps' object\n")
#			tic(); mcmc.msy = lapply(reps, function(x) { makeRepTab(dat=x, pat1="^TIME_SERIES", pat2="^SPR_SERIES") }); toc()  ## ~5 min for 2000 MCMC samples
#			save("mcmc.msy", file="mcmc.msy.rda")
#		} else {
#			if (!exists("mcmc.msy", envir=.GlobalEnv)) {
#				.flush.cat("Loading mcmc.msy object from saved binary\n")
#				tic(); load("mcmc.msy.rda", envir=.GlobalEnv); toc()
#			}
#		}
	
		## Extract time series values
		if (file.exists("mcmc.ts.sub.rda")) {
			## Should reload it in case a previous MCMC object sits in memory
			if (!exists("mcmc.ts.sub", envir=.GlobalEnv) || run!=srun) {
				.flush.cat("Loading mcmc.ts.sub object from saved binary\n")
				tic(); load("mcmc.ts.sub.rda", envir=.GlobalEnv); toc()
			}
		} else {
			.flush.cat("Deriving 'mcmc.ts.sub' from 'mcmc.ts'\n")
			mcmc.ts.sub = list()
			cpats.ts = c("^SpawnBio$", "Bio_smry", "Recruit", "dead\\(B", "Hrate|^F", "sel\\(B")  ## Appears to be no area-specific recdev

			for (i in 1:length(cpats.ts)) {
				ival = cpats.ts[i]
				ipos = grep(ival,colnames(mcmc.ts[[1]]))
				ii   = colnames(mcmc.ts[[1]])[ipos]  ## get all columns with label pattern
				iii  = sub(":_[1-9]", "", ii[1])     ## just getting one label for a later merge
				if (iii=="F" && Fmethod>1) {         ## convert to a harvest rate
					ilst = lapply(mcmc.ts, function(x) {
						xtab = apply(x[,ii,drop=FALSE], 2, function(xchr){
							xval = as.numeric(xchr); u = 1 - exp(-xval); return(u) })  ## F is a character at this point
 						rownames(xtab) = rownames(x)
						colnames(xtab) = gsub("F_apical","Hrate",colnames(xtab))
						return(as.data.frame(xtab))
					})
					iii = "Hrate_apical"
				} else {
					## everything else
					ilst = lapply(mcmc.ts, function(x) { x[,ii,drop=FALSE] })
				}
				if (all(sapply(sapply(ilst,dim),is.null))) {
					ilst = lapply(ilst,as.numeric)
				} else {
					ilst = lapply(ilst, function(x) { #if (i==4) {browser();return()};
						apply(sapply(x,as.numeric),1,sum) 
					})
				}
				cols.init = mcmc.ts[[1]][,1:4]
				cols.init[,c(1,2,4)] = sapply(cols.init[,c(1,2,4)], as.numeric)
				idat = data.frame(cols.init, do.call("cbind",lapply(ilst, data.frame, stringsAsFactors=FALSE)))
				colnames(idat)[-(1:4)] = paste0("s", pad0(1:nmcmc, npad0))
				zbad = is.na(idat[,-(1:4)])
				idat[,-(1:4)][zbad] = NA
				mcmc.ts.sub[[iii]] = idat
#browser();return()
			}
			## Vulnerable Biomass & Exploitation rate
			#VB  = data.frame(cols.init, mcmc.ts.sub[['sel(B)']][,-(1:4)]/mcmc.ts.sub[['Hrate']][,-(1:4)])
			VB  = data.frame(cols.init, mcmc.ts.sub[['Bio_smry']][,-(1:4)])
			u  = data.frame(cols.init, mcmc.ts.sub[['sel(B)']][,-(1:4)] / mcmc.ts.sub[['Bio_smry']][,-(1:4)])
			zbad = is.na(VB[,-(1:4)])
			VB[,-(1:4)][zbad] = NA
			mcmc.ts.sub[["VB"]] = VB
			zbad = is.na(u[,-(1:4)])
			u[,-(1:4)][zbad] = NA
			mcmc.ts.sub[["u"]] = u
			F = u
			F[,-(1:4)] = -log(1-F[,-(1:4)])
#browser();return()

			## Gather catch for later
			selB   = mcmc.ts.sub[['sel(B)']]
			zcat   = is.element(selB$Era,c("TIME","FORE"))
			catlst = split(selB[zcat,min(nmcmc,100)], selB[zcat,"Area"])  ## need to make sure that simulation catch is not reduced
			cattab = do.call("cbind", lapply(catlst, data.frame, stringsAsFactors=FALSE))
#browser();return()
			colnames(cattab) = areas
			rownames(cattab) = .su(selB$Yr[zcat])
			cattab$total = apply(cattab,1,sum)

			## Depletion (B/B0, where B0=B1935)
			SB = DB = mcmc.ts.sub[["SpawnBio"]]
			B0 = SB[is.element(SB$Yr,startyr),]  ## use startyr (1935) not VIRG
			for (i in unique(SB$Area)) {
				z  = is.element(SB$Area,i) & is.element(SB$Era,c("VIRG","INIT","TIME","FORE"))
				z0 = is.element(B0$Area,i) & is.element(B0$Era,"TIME")
				SBmat = as.matrix(DB[z,-(1:4)])  ## matrix
				B0vec = unlist(B0[z0,-(1:4)])    ## vector
				DBmat = sweep(SBmat, 2, B0vec, "/")
				DB[z,-(1:4)] = DBmat
			}
			mcmc.ts.sub[["DB"]] = DB
		
			## Fraction recruitment (taken from r4ss::SSplotTimeseries)
			Recr   = mcmc.ts.sub[["Recruit_0"]]
			yvals  = Recr[,-(1:4)]
			yvals2 = as.data.frame(array(NA, dim=c(length(Recr$Yr),nmcmc), dimnames=list(rownames(Recr),paste0("s",pad0(1:nmcmc,npad0)) ) ) )
			for (iyr in 1:nrow(yvals)) {
				y <- Recr$Yr[iyr]
				yvals2[iyr,] <- apply(yvals[Recr$Yr == y,],2,sum)
			}
			Frec <- data.frame(cols.init, yvals/yvals2)
			mcmc.ts.sub[["Frec"]] = Frec
			srun = run  ## sub ts run
			attr(mcmc.ts.sub,"samples") = names(mcmc.ts)
#browser();return()
			save(list=c("mcmc.ts.sub","cattab","srun"), file="mcmc.ts.sub.rda")
		}
	} ## end reconstruction of time series

	## Start the processing for figures etc.
	mcmc = mcmc.ts.sub ## just to save on typing
	options(scipen=10) ## stop displaying scientific notation (at least for the first 10 significant digits)
	##  "SpawnBio" "Recruit_0" "dead(B)" "Hrate" "sel(B)" "VB" "DB" "Frec" 
	## "dead(B)" and "sel(B)" don't change in MCMC samples
	plist = qlist = character()
	mcmc.names = c("SpawnBio", "Recruit_0", "u", "VB", "DB", "Frec")
	for (i in mcmc.names) {
		ii = switch(i, 'SpawnBio'="spawning", 'Recruit_0'="recruits", 'u'="exploitation", 'VB'="vulnerable", 'DB'="depletion", 'Frec'="frecruit")
		iii = switch(i, 'SpawnBio'="Spawning Biomass (kt)", 'Recruit_0'="Recruits (millions age-0 fish)", 'u'="Exploitation Rate (/y)", 'VB'="Vulnerable Biomass (kt)", 'DB'="Depletion (Bt/B0)", 'Frec'="Fraction Recruits")
		iv  = switch(i, 'SpawnBio'="B", 'Recruit_0'="R", 'u'="u", 'VB'="V", 'DB'="D", 'Frec'="fR")
		imcmc = mcmc[[i]]
		if (i == "SpawnBio") {
			## Extract SS3's estimation of VIRG biomass (V0, not vulnerable biomass) for allocation of MSY by area (suggested by PJS 230413)
			## Also calculate ORF's version of B0
			B0.mcmc  = t(imcmc[is.element(imcmc$Era, c("TIME")) & is.element(imcmc$Yr, startyr),-c(1:4)])
			colnames(B0.mcmc) = areas
			B0.qmcmc = apply(B0.mcmc, 2, quantile, quants5, na.rm=TRUE)
			V0.mcmc  = t(imcmc[is.element(imcmc$Era, c("VIRG")),-c(1:4)])
			colnames(V0.mcmc) = areas
			pVB.mcmc = t(apply(V0.mcmc, 1, function(x) { x / sum(x) }))    ## proportion Virgin Biomass used for allocating MSY
			if (length(areas)==1)
				pVB.mcmc = t(pVB.mcmc)
			colnames(pVB.mcmc) = areas
			V0.qmcmc  = apply(V0.mcmc, 2, quantile, quants5, na.rm=TRUE)
			pVB.med = V0.qmcmc['50%',] / sum(V0.qmcmc['50%',])  ## proportion SS3 VIRG B by area using median
			V0.mean = apply(V0.mcmc[,-c(1:4)], 1, mean, na.rm=TRUE)
			pVB.mn = V0.mean / sum(V0.mean)                   ## proportion SS3 VIRG B by area using mean
			plist = c(qlist, c("B0.mcmc","V0.mcmc","pVB.mcmc"))
			qlist = c(qlist, c("B0.qmcmc","V0.qmcmc","pVB.med","pVB.mn"))
		}
		imcmc = imcmc[is.element(imcmc$Era, c("TIME","FORE")),]
#browser();return()
		amcmc = split(imcmc, imcmc$Area)
		iyrs  = amcmc[[1]]$Yr
		endyr = rev(amcmc[[1]]$Yr[is.element(amcmc[[1]]$Era, c("TIME"))])[1]  ## first forecast year is actually the endyr of the model
		foryr = rev(amcmc[[1]]$Yr[is.element(amcmc[[1]]$Era, c("FORE"))])[1]
		pmcmc = lapply(amcmc, function(x){
			xx = t(x[,-c(1:4)])
			colnames(xx) = iyrs
			return(xx)
		})
		qmcmc = lapply(amcmc, function(x){
			xx = apply(x[,-c(1:4)], 1, quantile, quants5, na.rm=TRUE)
			colnames(xx) = iyrs
			return(xx)
		})
		names(pmcmc) = names(qmcmc) = areas
		assign( paste0(iv, ".mcmc"), pmcmc)
		assign( paste0(iv, ".qmcmc"), qmcmc)
		plist = c(plist, paste0(iv, ".mcmc"))
		qlist = c(qlist, paste0(iv, ".qmcmc"))
	}

	## Apply PJS allocation to MSY objects
	## -----------------------------------
	if (file.exists(paste0(dir.extra,"/derived_posteriors.sso")))
		dmcmc = SSgetMCMC (dir=dir.extra)
	else if (file.exists(paste0(dir.mcmc,"/derived_posteriors.sso")))
		dmcmc = SSgetMCMC (dir=dir.mcmc)
	else
		stop("Cannot find file 'derived_posteriors.sso'")

	## Sometimes need a subset of dmcmc
	smcmc = attributes(mcmc.ts.sub)$samples  ## available samples from original reps
	if (length(smcmc) != length(dmcmc$Iter)) {
		Amcmc = dmcmc$Iter #seq(thin, iters, thin)  ## all mcmc iterations
		Nmcmc = 1:length(Amcmc)
		pad.thai = floor(log10(max(Amcmc))) + 1  ## get common padding (RH 230905)
		names(Nmcmc) = pad0(Amcmc, pad.thai)
		smcmc = pad0(as.numeric(smcmc), pad.thai)
		Smcmc = Nmcmc[smcmc]
		dmcmc = dmcmc[Smcmc,]
#browser();return()
	}
	msy.mcmc = dmcmc[,grep("(^SSB|^annF|^Dead).*_MSY$",colnames(dmcmc),value=TRUE)]  ## I believe that F method 1 (Pope's approximation) give discrete F
	colnames(msy.mcmc) = sub("Dead_Catch_MSY","MSY", sub("annF_MSY","Fmsy", sub("SSB_MSY","Bmsy",colnames(msy.mcmc))))
	msy.mcmc[is.na(msy.mcmc)] = NA  ## change NaN to NA

	if (Fmethod==1) {
		colnames(msy.mcmc)[grep("Fmsy",colnames(msy.mcmc))] = "umsy"
		msy.mcmc$Fmsy = -log(1 - msy.mcmc$umsy)
		msy.mcmc = msy.mcmc[,c("Bmsy","Fmsy","MSY","umsy")]
	} else {
		msy.mcmc$umsy = 1 - exp(-msy.mcmc$Fmsy)
	}
	msy.mcmc$LRP = 0.4 * msy.mcmc$Bmsy
	msy.mcmc$USR = 0.8 * msy.mcmc$Bmsy
	endcat = cattab[as.character(endyr),"total"]  ## end-year catch for the BC coast
	msy.mcmc$Vmsy = endcat/msy.mcmc$umsy

	MSY.mcmc = MSY.qmcmc = list()
	for (a in areas) {
		paVB = pVB.mcmc[,a]  ## proportion Virgin Biomass by area for allocating MSY
		amsy.mcmc  = sweep(msy.mcmc,1,paVB,"*")
		## Cannot do this to umsy so have to recalculate from Vmsy
		endcat = cattab[as.character(endyr), a]   ## end-year catch for each area
		amsy.mcmc$umsy = endcat/amsy.mcmc$Vmsy
		amsy.mcmc$Fmsy = -log(1 - amsy.mcmc$umsy) ## adjust area-specific Fmsy also, calculating from adjusted umsy
		MSY.mcmc[[a]]  = amsy.mcmc
		MSY.qmcmc[[a]] = sapply(MSY.mcmc[[a]],quantile,quants5, na.rm=TRUE)
#browser();return()
	}
	msy.names = c("BtLRP","BtUSR","BtBmsy","utumsy")
	for (i in msy.names) {
		ii = paste0(i, ".mcmc")
		iii = paste0(i, ".qmcmc")
		assign(ii, list())
		assign(iii, list())
		for (a in areas) {
			aa = strsplit(i,split="t")[[1]]
			pmess = paste0("num=",aa[1],".mcmc[[\"",a,"\"]]; den=MSY.mcmc[[\"",a,"\"]][,\"",aa[2],"\"]; ",ii,"[[\"",a,"\"]]=sweep(num,1,den,\"/\")")
			eval(parse(text=pmess))
			qmess = paste0(iii,"[[\"",a,"\"]] = apply(",ii,"[[\"",a,"\"]],2,quantile,quants5,na.rm=T)")
			eval(parse(text=qmess))
		}
	}
	plist = c(plist, c("MSY.mcmc", paste0(msy.names,".mcmc")))   ## posteriors names
	qlist = c(qlist, c("MSY.qmcmc", paste0(msy.names,".qmcmc"))) ## quantiles names

	save(list=plist, file="mcmc.posts.rda")
	save(list=qlist, file="mcmc.quants.rda")

	if (plot) {
		plotArea = function(qlist, area, hline=NULL, cp=NULL) {
			scale = ifelse (i %in% c("SpawnBio","Recruit_0", "VB"), 1000., 1.)
			ylim  =  range(unlist(qlist[area])/scale, na.rm=TRUE); ylim[1] = 0
#browser();return()
			acols = character()
			plot(0,0, xlim=xlim, ylim=ylim, type="n", xaxs="i", xaxt="n", xlab="", ylab="", cex.axis=1.2, cex.lab=1.5)
			if (!is.null(hline)) {
				hcol = rep("slategray",length(hline))
				if (i %in% c("BtBmsy","DB")) hcol = c("red","green4")
				hcol[match(1,hline)] = "purple"
				abline(h=hline, col="gainsboro", lty=1)
				abline(h=hline, col=hcol, lty="37")
			}
			axis (1, at=seq(1900,2100,5), tcl=-0.2, labels=FALSE)
			axis (1, at=seq(1900,2100,10), tcl=-0.5, labels=ifelse(par()$mfg[1]==par()$mfg[3], TRUE, FALSE), cex.axis=1.4)
			for (a in 1:length(area)){
				aa    = area[a]
				amcmc = qlist[[aa]] / scale
				acol  = switch(aa, '5ABC'="blue", '3CD'="green3", '5DE'="red")
				acols = c(acols,acol)
				env.pyrs.x = c(pyrs, rev(pyrs))
				env.pyrs.y = c(amcmc[1,as.character(pyrs)], rev(amcmc[5,as.character(pyrs)]))
				polygon(env.pyrs.x, env.pyrs.y, col=lucent(acol,0.2), border=FALSE)
				lines(pyrs, amcmc[1,as.character(pyrs)], col=acol, lty=2, lwd=1)
				lines(pyrs, amcmc[5,as.character(pyrs)], col=acol, lty=2, lwd=1)
				lines(pyrs, amcmc[2,as.character(pyrs)], col=acol, lty=3, lwd=1)
				lines(pyrs, amcmc[4,as.character(pyrs)], col=acol, lty=3, lwd=1)
				lines(pyrs, amcmc[3,as.character(pyrs)], col=acol, lty=1, lwd=3)
				env.fyrs.x = c(fyrs, rev(fyrs))
				env.fyrs.y = c(amcmc[1,as.character(fyrs)], rev(amcmc[5,as.character(fyrs)]))
				polygon(env.fyrs.x, env.fyrs.y, col=lucent("gainsboro",0.2), border=FALSE)
				lines(fyrs, amcmc[1,as.character(fyrs)], col=acol, lty=2, lwd=1)
				lines(fyrs, amcmc[5,as.character(fyrs)], col=acol, lty=2, lwd=1)
				lines(fyrs, amcmc[2,as.character(fyrs)], col=acol, lty=3, lwd=1)
				lines(fyrs, amcmc[4,as.character(fyrs)], col=acol, lty=3, lwd=1)
				lines(fyrs, amcmc[3,as.character(fyrs)], col=acol, lty=1, lwd=3)
			}
			mtext("Year", side=1, outer=T, line=2.75, cex=1.4)
			mtext(iii, side=2, outer=T, line=0.5, cex=1.4)
			big.mark = ifelse(is.null(options()$big.mark), ",", options()$big.mark)
#browser();return()
			legtxt   = if (is.null(cp)) area else paste0(area, " (proj.catch = ", formatC(as.numeric(ifelse(length(areas)==1,cp,cp[area])),digits=0,format="f",big.mark=big.mark), " t/y)")
			addLegend(0.99, 0.98, legend=legtxt, xjust=1, yjust=1, lty=1, col=acols, seg.len=3, bty="n")
		} ## end function 'plotArea'

		for (i in c("utumsy", "BtBmsy", mcmc.names)) {
			ii = switch(i, 'SpawnBio'="spawning", 'Recruit_0'="recruits", 'u'="exploitation", 'VB'="vulnerable", 'DB'="depletion", 'Frec'="frecruit", 'BtBmsy'="BtBmsy", 'utumsy'="utumsy")
			iii = switch(i, 'SpawnBio'="Spawning Biomass (kt)", 'Recruit_0'="Recruits (millions age-0 fish)", 'u'="Exploitation Rate (/y)", 'VB'="Vulnerable Biomass (kt)", 'DB'="Depletion (Bt/B0)", 'Frec'="Fraction Recruits", 'BtBmsy'=expression(italic(B)[italic(t)]/italic(B)[MSY]), 'utumsy'=expression(italic(u)[italic(t)]/italic(u)[MSY]))
			iv  = switch(i, 'SpawnBio'="B", 'Recruit_0'="R", 'u'="u", 'VB'="V", 'DB'="D", 'Frec'="fR", 'BtBmsy'="BtBmsy", 'utumsy'="utumsy")

			## Plot quantiles for each factor by area
			xlim  = range(iyrs)
			#ylim  =  range(unlist(qmcmc))
			pyrs  = startyr:endyr
			fyrs  = endyr:foryr
			qmcmc = get(paste0(iv,".qmcmc"))
			cp    = cattab[as.character(endyr+1),areas]  ## catch policies

			if (vertical) {
				rc = if(length(areas)==1) c(1,1) else c(length(areas)+ifelse(show.combo,1,0),1) ## 230822
			} else {
				rc = if(length(areas)==1) c(1,1) else .findSquare(length(areas)+1) ## 230822
			}
			fout.e = paste0("extra.mcmc(", ii, ")")
			if (prod(rc)>1){
				fout.e = paste0(fout.e, "-", prod(rc), "panels")
				if (!vertical)  fout.e = paste0(fout.e, "(square)")
			}
#browser();return()
			for (l in lang) {
				changeLangOpts(L=l)
				fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
				if (png) png(filename=paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
				#expandGraph(mfrow=c(ifelse(length(areas)==1,1,length(areas)+1),1), mar=c(0,2,0,1), oma=c(4,2.5,1,0), mgp=c(1.6,0.75,0))
				expandGraph(mfrow=rc, mar=c(0,2,0,1), oma=c(4,2.5,1,0), mgp=c(1.6,0.75,0))
				hline = if (i=="BtBmsy") c(0.4,0.8)
					else if (i=="utumsy") 1
					else if (i=="DB") c(0.2,0.4)
					else NULL
				for (a in 1:length(areas))
					plotArea(qlist=qmcmc, area=areas[a], hline=hline, cp=cp)
				if (length(areas)>1 && show.combo)
					plotArea(qlist=qmcmc, area=areas)
				if (png) dev.off()
			}; eop()
		} ## end i loop for plots
	} ## end if plot
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~load_extra_mcmc

## load catch policies instead of regular MCMC runs
loadCP=F; png=F; plot=T
#loadCP=T; png=T; plot=T
#d.mcmc="."; d.extra="./sso"  ## defaults  ## not really necessary any more
show.combo=T; vertical=F
#run=19; rwt=0; ver="5a"; areas=c("3CD")
run=17; rwt=0; ver="14a"; areas=c("5ABC","3CD","5DE")


os = Sys.info()['sysname']
if (os %in% c("Linux")) {
	.libPaths("/home/haigh/R/x86_64-pc-linux-gnu-library/4.2")
	require(Kmisc); require(parallel); require(tictoc); require(r4ss); require(PBSmodelling)
	source("/home/haigh/POP2023/R/load-RHfuns.R")
	d.base  = "/home/haigh/POP2023/models"
	d.mcmc  = paste0(d.base, "/Run", pad0(run,2), "v", ver, "/mcmc")
} else {
	require(Kmisc); require(parallel); require(tictoc); require(r4ss)
	d.base = "C:/Users/haighr/Files/GFish/PSARC23/POP/Data/SS/POP2023"
	d.mcmc = paste0(d.base, "/Run", pad0(run,2), "/MCMC.", pad0(run,2), ".", pad0(rwt,2), ".v", ver) ## RH 230822
}
if (loadCP){
	#CPS = list.files(paste0(d.mcmc,"/CC"))
	CPs = list.dirs(paste0(d.mcmc,"/CC"), full.names=FALSE, recursive=FALSE)
	d.extra = paste0(d.mcmc, "/CC/", CPs)
} else {
	d.extra = paste0(d.mcmc,"/sso")
}
run.tag = paste0(pad0(run,2), pad0(rwt,2), "v", ver)

for (d.e in d.extra) {
	PIN = c(9,ifelse(length(areas)==1,6,9))
	#PIN = c(4.5,9)
	out = load_extra_mcmc(dir.mcmc=d.mcmc, dir.extra=d.e, RC=c(F,F), loadCP=loadCP, run=run.tag, areas=areas, Fmethod=3, plot=plot, png=png, PIN=PIN, show.combo=show.combo, vertical=vertical)
}
# I had to install 7zip to /home/haigh/Apps/ ## BTW, Linux sucks
# 7zzs a -r /home/haigh/POP2023/models/SS3.POP.Run17.MCMC.v5b-230606.7z /home/haigh/POP2023/models/Run17.v5b/ -x'!sso'
# 7zzs a -r /home/haigh/POP2023/models/SS3.POP.Run17.MCMC.sso.v5b-230606.7z /home/haigh/POP2023/models/Run17.v5b/mcmc/sso/ -xr'!CompReport_mce*.sso'

## MCMC runs
## /home/haigh/Apps/7zzs a -r /home/haigh/POP2023/models/SS3.POP.Run20.MCMC.v5a-230822.7z /home/haigh/POP2023/models/Run20v5a/mcmc/ -xr'!comps.rda' -xr'!reps.rda' -xr'!CompReport_mce*.sso' -xr'!Report_mce*.sso'

## Catch policies
## /home/haigh/Apps/7zzs a -r /home/haigh/POP2023/models/SS3.POP.Run17.CP01.v7b-230717.7z /home/haigh/POP2023/models/Run17v7b/mcmc/CC/CP01/ -xr'!comps.rda' -xr'!reps.rda' -xr'!CompReport_mce*.sso' -xr'!Report_mce*.sso' -x'!archive'

## History of calls prior to revising code (no longer call these eplicitly):
## -------------------------------------------------------------------------
#out = load_extra_mcmc(RC=c(F,F), Fmethod=3, png=T, PIN=c(7,9))
#out = load_extra_mcmc(RC=c(F,F), run="18v2a", areas="5ABC", Fmethod=3, png=T, PIN=c(7,6))
#out = load_extra_mcmc(RC=c(F,F), run="19v2a", areas="3CD", Fmethod=3, png=T, PIN=c(7,6))
#out = load_extra_mcmc(RC=c(F,F), run="20v2a", areas="5DE", Fmethod=3, png=T, PIN=c(7,6))
#out = load_extra_mcmc(RC=c(F,F), run="19v3a", areas="3CD", Fmethod=3, png=T, PIN=c(7,6))
#out = load_extra_mcmc(RC=c(F,F), run="18v3a", areas="5ABC", Fmethod=3, png=T, PIN=c(7,6))
#out = load_extra_mcmc(RC=c(F,F), run="17v6a", areas=c("5ABC","3CD","5DE"), Fmethod=3, png=T, PIN=c(7,9))
#out = load_extra_mcmc(RC=c(F,F), run="17v7a", areas=c("5ABC","3CD","5DE"), Fmethod=3, png=T, PIN=c(7,9))
#out = load_extra_mcmc(RC=c(F,F), run="17v8a", areas=c("5ABC","3CD","5DE"), Fmethod=3, png=T, PIN=c(7,9))
#out = load_extra_mcmc(RC=c(F,F), run="17v7b", areas=c("5ABC","3CD","5DE"), Fmethod=3, png=T, PIN=c(7,9))
#out = load_extra_mcmc(RC=c(F,F), run="18v4a", areas=c("5ABC"), Fmethod=3, png=T, PIN=c(7,6))
#out = load_extra_mcmc(RC=c(F,F), run="19v4a", areas=c("3CD"), Fmethod=3, png=T, PIN=c(7,6))
#out = load_extra_mcmc(RC=c(F,F), run="20v4a", areas=c("5DE"), Fmethod=3, png=T, PIN=c(7,6))



