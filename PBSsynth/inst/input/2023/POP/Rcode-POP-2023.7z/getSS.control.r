## getSS.control------------------------2020-11-10
##  Get select values out of the control file.
## (May or may not continue using this fn)
## ---------------------------------------------RH
getSS.control = function(fnam="control.ss")
{
	octl = list()
	if (!file.exists(fnam))
		stop (paste0("Control file ", fnam, " does not exist!"))
	rctl = readLines(fnam)
	rctl = gsub("^\\s+|\\s+$", "", rctl)  ## get rid of leading and trailing spaces
	## Maturity
	i  = grep("maturity_option",rctl)
	if (length(i)==0) {
		.flush.cat("Cannot identify maturity option----------","\n"); browser(); return() }
	ii = as.numeric(substring(rctl[i],1,1))
	octl[["maturity_option"]] = ii
	if (ii==3) {
		istring = "#_sumting"; iplus=0
		while (substring(istring,1,1) == "#") {
			iplus = iplus + 1
			istring = rctl[i + iplus]
		}
#browser();return()
		iii = strsplit(istring,split="\\s+")[[1]]
		octl[["maturity_ogive"]] = as.numeric(grep("^#",iii,invert=TRUE,value=TRUE))
	}
	return(octl)
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~getSS.control
#getSS.control(tcall(control.file))$maturity_ogive

