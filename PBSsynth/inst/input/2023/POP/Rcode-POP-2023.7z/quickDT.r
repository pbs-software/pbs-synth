## quickDT------------------------------2023-07-23
##  Produce quick decision tables for Bt/LRP, Bt/USR
## ---------------------------------------------RH
quickDT =function(compo, vals=c("BtLRP","BtUSR","BtBmsy","utumsy"),
   areas=c("5ABC","3CD","5DE"), cp=paste0("CC.", pad0(1:3,2)) )
{
	cc = as.vector(t(compo$xavgCP[1,1:length(areas),(1:length(cp))+1]))
	for (i in 1:length(vals)) {
		ii  = vals[i]
		num = substring(ii,1,2)
		den = substring(ii,3)
		pj  = compo$xavgPJ[,,ii,,cp]
		prb = apply(pj, c("proj","year","area"), function(x,num){
			xx=x[!is.na(x)]; xxx=if(num=="Bt") xx>1 else xx<1; sum(xxx)/length(xxx)
		}, num=num) ## over dims 4=catch policy, 2=year, 3=area
		dns = dimnames(prb); dns[[2]] = c("catch",dns[[2]])
		prb2 = array(NA, dim=sapply(dns,length), dimnames=dns)
		prb2[,-1,] = prb
		prb2[,1,]  = cc  ## insert catches for each policy by area
		num2 = paste0("$",sub("([Bu])","\\1_",num),"$")
		den2 = paste0("$",sub("msy","_\\\\text{MSY}",sub("USR","0.8Bmsy",sub("LRP","0.4Bmsy",den))),"$")
		tabcap = paste0("Probability ", num2, ifelse(num=="Bt"," > "," < "), den2)
#browser();return()
		tex = texArray(prb2, sigdig=4, zero="0", use.row.names=F, name.row.names="", add.header.column=T, new.header=aa, outnam=ii, table.caption=tabcap)
		cmd1 = paste0("pdflatex.exe -quiet ", ii, "+.tex")
		cmd2 = paste0("latexmk.exe  -c ", ii, "+.tex")
		system(command=cmd1, intern=TRUE, wait=TRUE)
		system(command=cmd2, intern=TRUE, wait=TRUE)
	}
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~quickDT

#quickDT(compo=compo)
