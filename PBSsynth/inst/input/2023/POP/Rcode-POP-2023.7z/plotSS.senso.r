## plotSS.senso-------------------------2023-10-10
## Make Sensitivity Figures
## ---------------------------------------------RH
plotSS.senso = function(senso, ptypes, spp.code="POP", istock="POP",
	subset=NULL, redo.figs=FALSE, redo.panels=FALSE, lang, useRlow=FALSE,
	png=F, pngres=400, PIN=c(9,9))
{
	on.exit(gc(verbose=FALSE))
	unpackList(stock[[istock]][["Controls"]])
	unpackList(senso)

	sen.fig = "senso."
	all.run.num = c(exp.run.num, sen.run.num)
	col.senso = c("green4","blue","red","purple","orange","skyblue","gold3","darkolivegreen","lightseagreen","hotpink","brown","cyan","darkorchid1","chartreuse3","tomato")
	lty.senso = c("22", "44", "66", "13", "73", "1551", "1343", "2262", "3573", "654321", "12345678", "88", "17", "5937", "9876")
	names(col.senso) = names(lty.senso) = sen.run.num

	## Check to see if sensitivities are alternative runs (e.g., single-are models)
	is.penso = as.character(substitute(senso)) == "penso"
	if (is.penso) {
		sen.run.num = pen.run.num
		sen.rwt.num = pen.rwt.num
		sen.run.rwt = pen.run.rwt
		sen.lab     = pen.lab
		sen.long    = pen.long
		sen.fig     = "penso."
		col.senso   = c("blue", "green4", "red")  ## may need more when penso changes
	}
	#unpackList(tcall(data.compo.figs))  ## created in Rnw
	createFdir(lang)

	#modYrs      = startYear:currYear
	modYrsChar  = as.character(modYrs)
	## Diagnostics for select parameters
	P.names     = colnames(senPA) ## parameter names
	S.mpd       = smpdPA; storage.mode(S.mpd)="double"     ## For some reason, this matrix is stored as a list (maybe due to NA values?)
	S.runs      = as.numeric(sapply(strsplit(rownames(senPA),"\\."),function(x){x[1]})) ## vector of Runs
	S.run.rwt   = sapply(strsplit(rownames(senPA),"\\."),function(x){paste0(x[1],".",x[2])}) ## vector of Runs and Rwts
	S.run.ord   = unique(S.runs)                           ## unique Run numbers (1st is central run)
	S.run.nmc   = table(S.runs)[as.character(S.run.ord)]   ## vector of sensitivity runs ordered
	
	S.num = match(S.run.ord[-1],sen.run.num)  ## Sensitivity numbers according to control file
	S.run.num = rep(c(0,S.num), S.run.nmc)  ## 1st run is Central Run (include in gatherMCMC senso)
	#S.run.num   = rep(1:length(S.run.nmc), S.run.nmc) - 1  ## 1st run is Central Run (include in gatherMCMC senso)
	CRS.num      = unique(S.run.num)
#browser();return()
	## Look into subsetting later
	use.run.rwt = unique(S.run.rwt)
	#is.element(P.runs, P.run.ord) ## default use all runs but a subset might be used for management advice

	## Create Sensitivity labels
	S.prefix    = paste0("S",pad0(CRS.num,2)," (R", pad0(S.run.ord,2) ,") ")
	if (is.penso) {
		S.prefix    = paste0("A",pad0(CRS.num,1)," (R", pad0(S.run.ord,2) ,") ")
	}
	iCR         = grep( sub("\\.v[0-9]+[a-z]", "", exp.run.rwt), unique(B.index) )
	S.prefix[1] = paste0("B",iCR, " (R", strsplit(exp.run.rwt,"\\.")[[1]][1], ") ")
	S.labels    = paste0(S.prefix, gsub("\\_"," ", c("Base Run",sen.lab[S.num])))  ## Central Run if using a composite
	S.labels    = sub("\\\\pc", "%", S.labels)  ## just in case
#browser();return()

	## Calculate quantiles for later (eventually make this function global)
	calcQs = function (dat, ivec, ovec) {
		F.data = as.data.frame(dat)
		F.list = split(F.data, ivec)
		rr.ord = match(ovec, substring(names(F.list),1,2))  ## oder not so important for sensitivities
#browser();return()
		F.list = F.list[rr.ord]
		F.qnts = lapply(F.list,function(x){
			z = apply(x,2,function(xx){!any(is.na(xx))})
			out = apply(x[z],2,quantile,quants5)
			return(out)
		}) ## lapply does not sort like split does
		return(F.qnts)
	}
	P.qnts = calcQs(senPA, ivec=S.run.rwt, ovec=S.run.ord)
	B.qnts = calcQs(senTS[,,"Bt"], ivec=S.run.rwt, ovec=S.run.ord)
	D.qnts = calcQs(senTS[,,"BtB0"], ivec=S.run.rwt, ovec=S.run.ord)
	U.qnts = calcQs(senTS[,,"ut"], ivec=S.run.rwt, ovec=S.run.ord)
	R.qnts = calcQs(senTS[,,"Rt"], ivec=S.run.rwt, ovec=S.run.ord)
	RD.qnts = calcQs(senTS[,,"Rtdev"], ivec=S.run.rwt, ovec=S.run.ord)
#browser();return()

	L1 = if (spp.code %in% c("REBS")) istock else spp.code  ## RH 200416

sumting=F
if (sumting) {

	## Diagnostics for select parameters
	## ---------------------------------
	if (redo.figs) {
		for (i in c(1)){
			ii   = P.names[i]
			iii  = gsub("[_|[:space:]]","",ii)
			P.i  = split(senPA[,i], S.runs)[as.character(S.run.ord)]
			## splits by 1:length(run.num) in 'gather.compo.case.r' so retains correct order
			P.ii = data.frame(P.i)
			#colnames.e = paste0(ii, ": ", S.labels)
			colnames.e =  S.labels
			colnames.f = linguaFranca(colnames.e, "f")
			fout.e = paste0(prefix, sen.fig, ii, ".traces")
			for (l in lang) {
				changeLangOpts(L=l)
				fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
				colnames(P.ii) = switch(l, 'e'=colnames.e, 'f'=colnames.f)
				for (p in ptypes) {
					if (p=="eps") postscript(paste0(fout,".eps"), width=6.25, height=7, horizontal=FALSE,  paper="special")
					else if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
					panelTraces(mcmc=P.ii, mpd=S.mpd[,i], xlab="Samples", ylab=paste0("Parameter ",ii, " value"), cex.axis=1.2, cex.lab=1.5, cex.strip=1.0, same.limits=ifelse(ii%in%c("LN(R0)"),F,T), lang=l, mar=c(0,2.5,0,0), oma=c(3.2,2,0.5,0.5))
					if (p %in% c("eps","png")) dev.off()
				} ## end p (ptypes) loop
			}; eop()
#browser();return()

			nchains   = 8
			col.trace = rep(rev(c("red", "blue", "black", "green", "orange", "purple", "brown", "pink")), nchains)[1:nchains]
			fout.e = paste0(prefix, sen.fig, ii, ".chains")
			for (l in lang) {  
				changeLangOpts(L=l)
				fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
				colnames(P.ii) = switch(l, 'e'=colnames.e, 'f'=colnames.f)
				for (p in ptypes) {
					if (p=="eps") postscript(paste0(fout,".eps"), width=6.25, height=7, horizontal=FALSE,  paper="special")
					else if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
					##par(mfrow=c(1,1), mar=c(3,3,0.5,1), oma=c(0,0,0,0), mgp=c(1.75,0.5,0))  ## mar and oma ignored, fixed in call to `mochaLatte'
					panelChains(mcmc=P.ii, nchains=nchains, axes=TRUE, pdisc=0, between=list(x=0, y=0), col.trace=col.trace, xlab=paste0("Parameter ",ii, " value"), ylab="Cumulative Frequency", cex.axis=1.2, cex.lab=1.4, cex.strip=ccex.strip, lang=l, mar=c(2,0,0,0), oma=c(3,4,0.5,0.5)) #, yaxt="n"
					if (p %in% c("eps","png")) dev.off()
				} ## end p (ptypes) loop
			}; eop()
#browser();return()

			fout.e = paste0(prefix, sen.fig, ii, ".acfs")
			for (l in lang) {  
				changeLangOpts(L=l)
				fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
				colnames(P.ii) = switch(l, 'e'=colnames.e, 'f'=colnames.f)
				for (p in ptypes) {
					if (p=="eps") postscript(paste0(fout,".eps"), width=8, height=8, horizontal=FALSE,  paper="special")
					else if (p=="png") png(paste0(fout,".png"), width=PIN[1], height=PIN[2], units="in", res=pngres)
					plotACFs(P.ii, lag.max=60, lang=l)
					if (p %in% c("eps","png")) dev.off()
				} ## end p (ptypes) loop
			}; eop()
		}
	}
#browser();return()

	## Make quantile plots of component-run parameters and quantities
	## --------------------------------------------------------------
	## Note: When outliers are plotted, these quantile plots take forever when sent to a png file.
	if (redo.panels) {
		#so("mochaLatte.r","awatea")
		#so("panelBoxes.r","awatea")

		#P.pool = P.mcmc
		#P.sens = S.mcmc ## created in 'gather.sens.runs.'
		### BOR central is 2nd of 3 but need to reduce  by 1 to get right numbe rof rows (1001:2000)
		##i.cent = ((grep(exp.run.rwt,stock[[istock]]$Base$run.rwts)-1)*nmcmc)+(1:nmcmc)  ## a little bit arbitrary
		#i.cent = (1:length(B.index))[is.element(B.index,exp.run.rwt)]  ## RH 200424: Should be more stable when central run is not necessarily 'central'
		#P.cent = P.pool[i.cent,]  ## grab the central run (Run05 for WWR 2019, Run02 for BOR 2019)
		#pflds  = intersect(names(P.cent),names(P.sens))  ## get fields in common
		#P.cent.sens = rbind(P.cent[,pflds],P.sens[,pflds])

#browser();return()
		#qflds  = c("Bcurr", "B0", "Bcurr.B0", "MSY", "Bmsy", "Bmsy.B0", "Umsy")
		#Q.sens = iQ.sens[[1]][,qflds] 
		#Q.cent = data.frame(Bcurr, B0, Bcurr.B0, MSY, Bmsy, Bmsy.B0, Umsy)
		#for (g in 1:Ngear) {
		#	Q.sens.add = iQ.sens[[g]][,c("Ucurr","Umax")]
		#	colnames(Q.sens.add) = paste0(c("Ucurr_", "Umax_"),gseries[g])
		#	Q.sens = cbind(Q.sens, Q.sens.add)
		#	Q.cent.add = data.frame(Ucurr[[g]], Umax[[g]])
		#	colnames(Q.cent.add) = paste0(c("Ucurr_", "Umax_"),gseries[g])
		#	Q.cent = cbind(Q.cent, Q.cent.add)
		#}
		#Q.cent = Q.cent[i.cent,]
		#Q.cent.sens = rbind(Q.cent,Q.sens)
		#nchains = nrow(Q.cent.sens)/nmcmc

		P.collect   = switch(spp.code, 'YMR'=c(1:6), 'CAR'=1:6, 'POP'=c(1,5:8,11,14,17,20)) ## YMR: collect  all parameters except M
		if (is.penso){
			## Fiddly amalgamation of parameters from single-area models for PJS
			if (spp.code=="POP") {
				P.collect = grep("^M_|BH_h|^mu", colnames(senPA)) ## collect M and mu
				P.cent.sens = data.frame( senPA[,P.collect] )
				colnames(P.cent.sens) = colnames(senPA)[P.collect]
				#P.exclude = grep("3CD$|5DE$",colnames(P.cent.sens),invert=TRUE)  ## get rid of 3CD and 5DE
				#P.cent.sens = P.cent.sens[,P.exclude]
				P.penso = as.data.frame(array(NA, dim=c(nrow(P.cent.sens),9), dimnames=list(sample=rownames(P.cent.sens), par=c("M_Female","M_Male","BH_h","mu_5ABC|3CD|5DE","mu_QCS","mu_WCVI","mu_WCHG","mu_GIG","mu_NMFS"))))
				P.penso[,1:3] = P.cent.sens[,1:3] ## M, and hC in same place across models
				for (i in colnames(P.penso)[4:9]) {
					ii  = sub("^mu_","",i)
					iii = grep(ii, colnames(P.cent.sens))
#browser();return()
					P.penso[,i] = apply(P.cent.sens[,iii,drop=F], 1, sum, na.rm=T)
				}
				## Get rid of artifical zeroes created by appply 
				is.zero = P.penso==0 & !is.na(P.penso)
				P.penso[is.zero] = NA

			}
		} else {
			P.cent.sens = data.frame( senPA[,P.collect] )
			colnames(P.cent.sens) = colnames(senPA)[P.collect]
		}

		Q.cent.sens   = data.frame(
			Bcurr      = senRP[,"Bcurr"],
			B0         = senRP[,"B0"],
			Bcurr.B0   = senRP[,"Bcurr"]/senRP[,"B0"],
			MSY        = senRP[,"MSY"],
			Bmsy       = senRP[,"Bmsy"],
			Bmsy.B0    = senRP[,"Bmsy"]/senRP[,"B0"],
			Ucurr      = senRP[,"ucurr"],
			Umsy       = senRP[,"umsy"],
			Umax       = apply(senTS[,,"ut"],1,max) ## for each mcmc sample across the time series
			#Ucurr.Umsy = senRP[,"ucurr"]/senRP[,"umsy"]
		)
		nchains = length(S.run.ord)

		names(Q.cent.sens) = sub("\\.", " / ", gsub("U","u", 
			gsub("Ucurr",paste0("U",currYear-1), 
			gsub("Bcurr",paste0("B",currYear), names(Q.cent.sens)))))

		if (spp.code %in% c("BOR","WWR")) {  ## this code seems to be old so will change without guarantee of compatibility
			P.pars = senPA[,c("R_0","h","q_1","mu_1","q_7","mu_7")]
		} else if (spp.code %in% c("REBS")) {
			if (istock=="BSR")
				P.pars = senPA[,c("R_0","mu_3","q_1","mu_1","q_2","mu_2")]
			if (istock=="RER")
				P.pars = senPA[,c("R_0","q_1","q_2","q_3","mu_4","mu_5")]
		} else if (is.penso) {
			P.pars = P.penso
		} else {
			P.pars  = P.cent.sens
		}
#browser();return()

		## Sometimes want to exclude sensitivities  ## RH 200416
		verboten = NULL
		if (spp.code=="BOR") {
			verboten = "no_CPUE"
			zap.runs = match(verboten,sen.lab)
			#zap.runs = grep("9",c(sen.run.nums))
		}
		if (spp.code=="YMR") {
			verboten = c("estimate_M", "start_Rdevs_in_1970")#, "steepness_h=0.5")
			zap.runs = match(verboten,sen.lab) ## + 1  ## to account for central run
		}
		if (!is.null(verboten)) {
#browser();return()
			## Not really robust to mcsub choices
			nmcmc    = sen.mcsubs[zap.runs]
			bad.rows = lapply(1:length(zap.runs),function(i){ (nmcmc[[i]][1]:nmcmc[[i]][2]) + (zap.runs[i] * nmcmc[[i]][2]) })
			zap.rows = unlist(bad.rows)
			#P.pars[zap.rows,] = NA
		}
		fout.e = paste0(prefix, sen.fig, "pars.qbox")
		for (l in lang) {  
			changeLangOpts(L=l)
			fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
			LP.pars = P.pars
			names(LP.pars) = linguaFranca(names(LP.pars),l)
			for (p in ptypes) {
				if (p=="png")
					png(filename=paste0(fout,".png"), units="in", res=pngres, width=8, height=8)
				#boxfill = c("gainsboro","green4","blue","red","purple","orange","skyblue","gold3","salmon3","red2","hotpink","darkred","dodgerblue") ## colours used in the trajectory plots (REBS)
				boxfill = c("gainsboro",col.senso[S.num]) ## colours used in the trajectory plots (YMR)
				#panelBoxes(P.pars, xlim=c(0.25,nchains+0.75), xlab=linguaFranca("Sensitivity Runs",l), ylab=linguaFranca("Parameter estimates",l), nchains=nchains, xfac=c(ifelse(NrefM>1,"CR","B1"), paste0("S",pad0(1:(nchains-1),2))), boxfill=boxfill, cex.strip=1.2, cex.axis=1.2, cex.lab=1.5, outline=FALSE)
				panelBoxes(LP.pars, xlim=c(0.25,nchains+0.75), xlab="", ylab=linguaFranca("Parameter estimates",l), nchains=nchains, xfac=c(ifelse(NrefM>1,"CR","B1"), paste0(ifelse(is.penso,"A","S"), pad0(S.num,ifelse(is.penso,1,2))) ), boxfill=boxfill, cex.strip=1.2, cex.axis=1.2, cex.lab=1.5, outline=FALSE)
				mtext(linguaFranca(ifelse(is.penso,"Multi-area (B) vs. Single-area (A) Runs","Sensitivity Runs"),l), side=1, outer=T, line=-1.2, cex=1.2, adj=0.55)
				if (p %in% c("png","eps")) dev.off()
			}
		}; eop()
#browser();return()

		Q.pars = Q.cent.sens
		if (!is.null(verboten)) {
			Q.pars[zap.rows,] = NA
			fn.ylim = function(x){extendrange(sapply(split(x,names(x)), quantile,quants5[c(1,5)], na.rm=TRUE))}
		} else {
			## Sometimes the 95pc limits are outrageously high so use this function:
			fn.ylim = function(x,i=rep(1:(length(S.num)+1),each=2000)){ ## hardwire index i for now
				xr = range(x, na.rm=TRUE)
#browser();return()
				xx = split(x,i);
				#if (any(sapply(xx, function(xxx){quantile(xxx,0.99) > 10*quantile(xxx,0.75)}))){
					xr[1] = quantile(x,0.01,na.rm=T)
					xr[2] = quantile(x,0.99,na.rm=T)
				#}
				return(xr)
			}
		}
#browser();return()
		
		fout.e = paste0(prefix, sen.fig, "rfpt.qbox")
		for (l in lang) {  
			changeLangOpts(L=l)
			fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
			LQ.pars = Q.pars
			names(LQ.pars) = linguaFranca(names(LQ.pars),l)
#browser();return()
			for (p in ptypes) {
				if (p=="png") png(filename=paste0(fout,".png"), units="in", res=pngres, width=8, height=8)
				#boxfill = c("gainsboro","green4","blue","red","purple","orange","skyblue","gold3","salmon3","red2","hotpink","darkred","dodgerblue") ## colours used in the trajectory plots (REBS)
				boxfill = c("gainsboro", col.senso[S.num]) ## colours used in the trajectory plots (YMR)
				panelBoxes(LQ.pars, xlim=c(0.25,nchains+0.75), xlab="", ylab=linguaFranca("Derived Quantities",l), nchains=nchains, xfac=c(ifelse(NrefM>1,"CR","B1"), paste0(ifelse(is.penso,"A","S"), pad0(S.num,ifelse(is.penso,1,2))) ), boxfill=boxfill, cex.strip=1.2, cex.axis=1.1, cex.lab=1.5, outline=FALSE, fn.ylim=fn.ylim)
				mtext(linguaFranca(ifelse(is.penso,"Multi-area (B) vs. Single-area (A) Runs","Sensitivity Runs"),l), side=1, outer=T, line=-1.2, cex=1.2, adj=0.55)
				if (p %in% c("png","eps")) dev.off()
			}
		}; eop()
	}
#browser();return()

	## Make plots of median trajectories
	## ---------------------------------
	ii   = as.character(startYear:currYear)
	bb   = list('Bt'=B.qnts, 'BtB0'=D.qnts, 'U'=U.qnts, 'R'=R.qnts, 'RD'=RD.qnts)
	bdat = lapply(bb,function(x){
		sapply (x, function(y){
			#if (!any(grepl("50", rownames(y)))) {browser();return()}
			yyy = rep(NA,length(ii)); names(yyy)=ii
			yy  = y[grep("50%", rownames(y)),]
			yyy[names(yy)] = yy
#browser();return()
			return(yyy)
		})
	})
	bdat$label = S.labels

	tlty = c("solid", lty.senso[S.num])
	tcol = c("black",col.senso[S.num])

	#so("plotTraj.r","awatea")
	if (redo.figs) {
		traj.names = c("Bt","BtB0","U","R","RD")
		Ntraj = length(traj.names)

		for (k in 1:Ntraj){
			kk = traj.names[k]
			logR = FALSE
			traj.meds = bdat[[kk]]
			if (is.null(traj.meds)) next
			fout.e = paste0(prefix, sen.fig, "traj.",kk)
			traj = traj.meds[intersect(rownames(traj.meds),ii),]
			Nruns = ncol(traj)
			Nyrs  = nrow(traj)
			x     = as.numeric(rownames(traj))
			xlim  = range(x)
			ylim = range(traj,na.rm=TRUE)
			##YMR: y0=ifelse(kk=="RD",F,T);   if (y0) ylim[1] = 0; if (kk=="RD") ylim[1]=-3; if (kk=="BtB0") ylim[1]=-0.2; if (kk=="Bt") ylim[2]=50000 #1.1*ylim[2]
			##CAR: y0=ifelse(kk=="RD",F,T);   if (y0) ylim[1] = 0; if (kk=="RD") ylim[1]=-0.5; if (kk=="BtB0") ylim[1]=0; if (kk=="Bt") ylim[2]=21000 #1.1*ylim[2]
			y0=ifelse(kk=="RD",F,T);   if (y0) ylim[1] = 0; if (kk=="RD") ylim[1]=-2; if (kk=="BtB0") ylim[1]=0;# if (kk=="Bt") ylim[2]=21000 #1.1*ylim[2]
			logR=F; if (kk=="R" && logR) ylim[1]=1
			## tcol and legtxt need to be reset inside language loop because they are altered when bdat is supplied
			tcol   = rep(tcol,Nruns)[1:Nruns]
			tlty   = rep(tlty,Nruns)[1:Nruns]
			legtxt = bdat$label
			for (l in lang) {  
				changeLangOpts(L=l)
				fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
				for (p in ptypes) {
					if (p=="eps") postscript(paste0(fout,".eps"), width=PIN[1], height=PIN[2], horizontal=FALSE,  paper="special")
					else if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
					par(mfrow=c(1,1), mar=c(3,3.5,0.5,0), oma=c(0,0,0,1), mgp=c(2,0.5,0))
					plot(0,0,xlim=xlim,ylim=ylim,type="n",xlab="",ylab="",log=ifelse(kk=="R"&&logR,"y",""))
					if (kk %in% c("BtB0"))
						abline(h=c(0.2,0.4,1), lty=5, col="grey20") #col=c("salmon","darkorchid","navy"))
					if (kk %in% c("RD"))
						abline(h=c(0), lty=5, col="grey20") #col=c("salmon","darkorchid","navy"))
					for (j in Nruns:1) {
#.flush.cat(j," ",jj," ", tlty[j], "\n")
						jj = colnames(traj)[j]
						y  = traj[,jj]
						lines(x,y, col=tcol[j], lwd=ifelse(j==1,3,2), lty=tlty[j])
					}
					#lines(x=as.numeric(names(bline)), y=if (jj=="R" && logR) log10(bline) else bline, col="black", lty=1, lwd=3)
					mtext(linguaFranca("Year",l), side=1, line=1.75, cex=ifelse(Nruns==1,1.5,1))
					ylab = switch(kk, 'Bt'="Spawning Biomass", 'BtB0'="Spawning Biomass Depletion", 'B'="Spawning Biomass", 'VB'="Vulnerable Biomass", 'R'="Recruitment", 'RD'="Recruitment Deviation", 'U'="Exploitation Rate", "Unknown")
					#mtext(linguaFranca(ylabs[[jj]],l), side=2, line=1.8, cex=ifelse(Ntraj==1,1.5,1.2))
					mtext(linguaFranca(ylab,l), side=2, line=1.8, cex=ifelse(Ntraj==1,1.5,1.2))
					#if (k==1){
						legtxt = gsub("_"," ",legtxt)
						#addLegend(ifelse(kk%in%c("R","U"),0.025,0.025), ifelse(kk%in%c("BtB0","RD"),0.01,0.975), col=tcol, seg.len=5, legend=linguaFranca(legtxt,l), bty="o", box.col="grey", bg=ifelse(kk%in%c("BtB0"),"white","transparent"), xjust=ifelse(kk%in%c("R","U"),0,0), yjust=ifelse(kk%in%c("BtB0","RD"),0,1), lwd=2, lty=tlty)
						if (kk %in% c("Bt","BtB0", "U","R","RD")) {
							xleg=0.99; yleg=0.99; xjust=1; yjust=1
						} else {
							xleg=0.02; yleg=0.01; xjust=0; yjust=0
						}
						addLegend(xleg, yleg, col=tcol, seg.len=5, legend=linguaFranca(legtxt,l), bty="o", box.col="grey", bg=ifelse(kk%in%c("BtB0"),"white","transparent"), xjust=xjust, yjust=yjust, lwd=2, lty=tlty)
					#}
					#if (Ntraj==1) {
						axis(1,at=intersect(seq(1900,2500,5),x),labels=FALSE,tcl=-0.2)
						axis(1,at=intersect(seq(1900,2500,10),x),labels=FALSE)
					#}
					box()
					if (p %in% c("png","eps")) dev.off()
				}
			}; eop()
#browser();return()
		}
	}

} ## sumting

	## Prepare sensitivity runs for function 'compBmsy' (stock status)
	## ---------------------------------------------------------------
	if (redo.figs) {
		Bsens = list()
		L1    = toupper(ifelse(spp.code=="REBS", istock, spp.code))
		Bsens[[L1]] = list()
		isens  = toupper(istock)

		z   = use.run.rwt  ## look into subsetting later -- perhaps just subset z
		zz  = is.element(use.run.rwt, z)
		zzz = is.element(S.run.rwt, z)
		#zz = sapply(split(z,S.runs),unique)[as.character(S.run.ord)]
		Ubase = sum(zz)
		runlab = S.labels[zz] ## created on L33

		Stemp = data.frame(run=S.runs[zzz], BcurrBmsy=senTS[,as.character(currYear),"BtBmsy"])[zzz,]
		Bcurr.Bmsy = Stemp[is.element(Stemp$run, central.run),"BcurrBmsy"]
		medCR = median(Bcurr.Bmsy)
		Bsens[[L1]][[runlab[1]]] = Bcurr.Bmsy ## central run from composite for snesitivity comparison
		for (i in 2:length(S.run.ord[zz])) {
			ii = S.run.ord[i]
			if (!is.element(ii, Stemp$run)) next
			iStemp = Stemp[is.element(Stemp$run,ii),]
			iii = runlab[i]
			Bsens[[L1]][[iii]] = iStemp$BcurrBmsy
		}
		Mnams = runlab
		## Check for restricting MCMCs to low recruits
		if (useRlow) {
			R.cent = stock[[istock]]$Base[[exp.run.rwt]]$currentMCMC$R
			if (spp.code=="BOR")
				Rlow   = R.cent[,"2017"] < quantile(R.cent[,"2017"], qRlow)
			else {
				R.mean = apply(R.cent,1,mean)  ## mean recruitment 1935-2020
				Rlow   = R.mean < quantile(R.mean, qRlow)
			}
			Mnams = c(Mnams, "low recruitment")
		}
		N = length(Mnams)
		bord=c(1:N); medcol=c(ifelse(istock==names(stock)[1],"blue","red"),rep("grey30",N-1)); 
		boxfill = c(ifelse(istock==names(stock)[1],"aliceblue","mistyrose"), rep("grey95",N-1))
		if (is.penso) {
			medcol = c("slategray", col.senso)
			boxfill = c("grey95", "aliceblue","honeydew","mistyrose")
		}

#ptypes="png"; scenario=0; so("compBmsy.r")
		if ("win" %in% ptypes) resetGraph()
		mess =  paste0("list(",paste0(paste0(ptypes,"=TRUE"),collapse=","),")")

		Bspp = Bsens
		#Bspp = Bsens["BtBmsy"]; names(Bspp)=L1
		#if (spp.code=="BOR")
		#	Bspp[[L1]] = Bspp[[L1]][c(0,iisens)+1]  ## BOR 2021: remove no_CPUE
		#if (useRlow)
		#	Bspp[[L1]][[paste0(names(Bspp$BOR)[1],"_low")]] = Bspp[[L1]][[1]][Rlow]
		boxlim    = c(0, max(sapply(Bspp[[L1]],quantile,quants5[5],na.rm=T)) )
		boxlim[2] = boxlim[2] + diff(boxlim) * 0.04
		left.space = 
			if (istock %in% c("BCN")) c(7.5,10)
			else if (istock %in% c("YMR","CAR","POP")) c(12,16)
			else c(10,12)
		out = compBmsy(Bspp=Bsens, spp=L1, boxwidth=0.5, medcol=medcol, boxfill=boxfill, boxlim=boxlim, whisklwd=2, staplelwd=2, Mnams=Mnams[bord], width=9, height=6, figgy=eval(parse(text=mess)), pngres=pngres, spplabs=F, t.yr=currYear, left.space=left.space, top.space=1.5, fout=paste0(prefix, sub("\\.$","",sen.fig), ifelse(Ubase>1,".stock.","."), "status",ifelse(useRlow,"+","")), calcRat=F, lang=lang, ratios=c(0.4,0.8,medCR), rlty=c(2,2,3), rlwd=c(2,2,1))
		save("Bsens","L1","medcol","boxfill","boxlim","Mnams","bord","mess", file="Bsens.for.PJS.rda")
	}
browser();return()

## Collect BtBmsy for discussions in Sweave ??
	#BtBmsy.med = sapply(Bsens[[1]],function(x){median(x)})
	#BtBmsy.sens.MCMC = list()
	#for (i in 1:(Nsens)) {
	#	iBmcmc = stock[[istock]]$Sens$Bmcmc.sens[[i]]
	#	ii = names(Bmcmc.sens[[i]][[toupper(spp.code)]])
	#	Bsens[[1]][[ii]] = iBmcmc[[toupper(spp.code)]][[ii]]$BoverBmsy[,currYearChar]
	#	BtBmsy.sens.MCMC[[ii]] = iBmcmc[[toupper(spp.code)]][[ii]]$BoverBmsy
	#}
	#BtBmsy.med = sapply(BtBmsy.sens.MCMC,function(x){apply(x,2,median)})

	## Identify lowest median stock status for sensitivities
	#lowSS      = which(BtBmsy.med[-1]==min(BtBmsy.med[-1]))
#browser();return()
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~plotSS.senso

## Activate for debugging only:
source("C:/Users/haighr/Files/Projects/R/Develop/PBSawatea/Authors/Rcode/develop/current/plotFuns.r")
d.awatea = "C:/Users/haighr/Files/Projects/R/Develop/PBSawatea/Authors/Rcode/develop/"
r.awatea = c("mochaLatte", "panelBoxes","plotTraj","panelTraces","panelChains","plotACFs")
for (i in r.awatea) source(paste0(d.awatea,i,".r"))

so("load.preview.r","synth")
#plotSS.senso(senso=senso, ptypes="win", lang=c("e"), redo.figs=T, redo.panels=T)
plotSS.senso(senso=penso, ptypes="win", lang=c("e"), redo.figs=T, redo.panels=F)
#plotSS.senso(senso=penso, ptypes="png", lang=c("f","e"), redo.figs=T, redo.panels=T)

