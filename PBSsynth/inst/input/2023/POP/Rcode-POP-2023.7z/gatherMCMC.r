## gatherMCMC---------------------------2023-10-10
## All values occur at start of year so B2022 is B at end of 2021 or start of 2022;
##   u2022 must be u in 2021 after final catch was specified for 2021 in the data file.
## Ian Taylor (Aug 9, 2021):
##   Everything is start of year throughout.
##   Setting 2021 as the final year of the model allows 2021 catch.
##   The values for derived quantities like SSB_2021 and Bratio_2021 represent the beginning of the year values at the start of 2021 in the main time series.
##   The SSB_2022 is one year later but will only depend on catches up through 2021, so changes in 2022 catch won't impact the 2022 quantities.
## Chantel Wetzel (Jun 27, 2022)
##   The F value in 2023 would be calculated from the total catch at the end of the model year.
##   If the final year in your model with catches input into the data file is 2022, then the F_2023 would be based off the forecast catch from that year.
## Chantel Wetzel (Jul 12, 2023)
##   RH: If I specify year end=2023 in 'data.ss' and specify a 2023 catch in 'data.ss', while in 'forecast.ss' I specify a 2024 catch,
##       are these the same catches? (because end-year 2023 catch = model start-year 2024 catch). 
##   CW: Those catches would be removed from different years. 
##       Any catches input in the forecast file will be removed from the specified year as long as it falls within the forecast period (year, season, fleet, catch (or F).
##       Based on your description, the first forecast year would be 2024 (final data year + 1).
## Rowan Haigh (Jul 13, 2023)
##   ryrs = reconstructed years, needs the first projected year (endyr+1) to be the 'current' year (e.g., 2024 for POP 2023)
##   pyrs = projected years, uses 2nd projected year onwards (e.g., 2025:2034 for POP 2023)
## RH (230719) function 'pad0' automatically pads according to largest number in a vector (since 2011-12-12)
## RH (230720) Need to run 'load_extra_mcmc.r' before collecting extra MCMC stuff (perhaps obvious but...)
## ---------------------------------------------RH
gatherMCMC = function( mcdir=".", type="compo", strSpp="POP",
   basedir="C:/Users/haighr/Files/GFish/PSARC23/POP/Data/SS/POP2023",
   ryrs=1935:2024, pyrs=2025:2034, valTS=c("SSB","F","Recr","RecrDev"), 
   valRP=c("SSB_MSY","annF_MSY","Dead_Catch_MSY"))
{
	ayrs  = c(ryrs, pyrs); nyrs = length(ayrs)
	currYr = rev(ryrs)[1]; byr = cyr = as.character(currYr)
	#prevYr = currYr-1;     byr = as.character(prevYr) ## see notes above
	mclst = Nmcmc = rowN = valPAs = valLLs = list()

	for (m in 1:length(mcdir)){
		mdir = file.path( sub("/$","",basedir), sub("/$","",mcdir[m]) )
		if(!file.exists(mdir)) next
		mm    = substring(basename(mdir),6) #,10)
		#if (penso) {
		#	## Special versions for PJS
		#	mm = substring(mdir,regexpr("Run",mdir)+3,regexpr("Run",mdir)+7)
		#}
		mclst[[mm]] = list()
		cp = "AC.00"

		## Gather MPD information
		d.mpd = sub("[a-z]$","",sub("\\.mh.+","",sub("\\.hm.+","",sub("\\.nuts.+","",sub("MCMC","MPD",mdir)))))
#browser();return()
		mpd = SS_output(dir=d.mpd, verbose=F, printstats=F)
		Fmethod =  mpd$F_method

		## Grab likelihood components
		run = as.numeric(strsplit(mm,"\\.")[[1]][1]); names(run)="Run"
		LL.fleet  = mpd$likelihoods_by_fleet
		LL.fleet.ex = LL.fleet[is.element(LL.fleet$Label,"Surv_like"),grep("OTHER",mpd$FleetNames,invert=T,value=T)]
		names(LL.fleet.ex) = sapply(strsplit(names(LL.fleet.ex),"_"),function(x){return(paste0(x[1],"_",substring(x[2],1,3))) })
		#names(LL.fleet.ex) = sub("TRAWL","CPUE",names(LL.fleet.ex))
		names(LL.fleet.ex)[grep("TRAWL",names(LL.fleet.ex))]="CPUE_BT"
		LL.used   = mpd$likelihoods_used
		LL.used.ex  = LL.used[c("Survey","Age_comp","Recruitment","TOTAL"),"values"]
		names(LL.used.ex) = c("Index","AF","Recruit","Total")
		LL.compo = c(run, LL.fleet.ex, LL.used.ex)
		LL.compo = unlist(LL.compo)
		mclst[[mm]][["LL"]] = LL.compo
		valLLs[[mm]] = names(LL.compo)  ## collect all names
#browser();return()

		## Grab parameter estimates
		parameters = mpd$parameters
		pactive = parameters[!is.na(parameters$Active_Cnt) & parameters$Phase>0 & !is.element(parameters$Pr_type,"dev"),]
		pactive$Label = convPN(pactive$Label)
		P.mpd = pactive$Value; names(P.mpd)=pactive$Label
		valPA = names(P.mpd)
		valPAs[[mm]] = valPA  ## collect all
		if (m==1 && strSpp %in% c("YMR")) {
			valPA = setdiff(valPA,c("M_Female","M_Male"))  ## just in case R79 comes first
			if (any(grepl("Run79",mcdir))) ## Specific to YMR sensitivity run with natural mortality
				valPA = c(valPA, "M_Female", "M_Male")
		}
		## Check for catch policies
		CP = c("AC", c("CC","HR")[file.exists(file.path(mdir,c("CC","HR")))])
		if (type %in% c("senso","penso")) CP = "AC"
		for (n in length(CP)){
			nn = CP[n]
			if (nn=="AC") next
			ndir = file.path(mdir,nn)
			#ncps = dir (ndir)[1]  ## name of catch policy subdirectories (debugging)
			ncps = dir (ndir)  ## name of catch policy subdirectories
			cp = c(cp, paste0(nn,".",sub("^[[:alpha:]]+","",ncps)))
			mdir = c(mdir, file.path(ndir,ncps))
		}
#browser();return()
		for (n in 1:length(mdir)) {
			mmm   = mdir[n]
			ccc   = cp[n]
			.flush.cat(paste0("Getting MCMC: Run ", mm, "; catch policy: ", ccc), "\n")
			if (file.exists(paste0(mmm,"/posteriors.sso"))) {
				mmc   = SSgetMCMC(mmm, verbose=F)
			} else if (file.exists(paste0(mmm,"/sso/posteriors.sso"))) {
				mmc   = SSgetMCMC(paste0(mmm,"/sso"), verbose=F)
			} else {
				stop ("Cannot find MCMC sso files")
			}
			colnames(mmc) = convPN(colnames(mmc))

			## Sometimes need a subset of mmc
			if (file.exists(paste0(mmm,"/mcmc.ts.sub.rda"))) {
				load(paste0(mmm,"/mcmc.ts.sub.rda"))
				smcmc = attributes(mcmc.ts.sub)$samples  ## available samples from original reps
				if (!is.null(smcmc) && length(smcmc) != length(mmc$Iter)) {
					Amcmc = mmc$Iter ## all mcmc iterations
					amcmc = 1:length(Amcmc)
					names(amcmc) = pad0(Amcmc, floor(log10(max(Amcmc))) + 1)
					zmcmc = amcmc[smcmc]
					mmc = mmc[zmcmc,]
				}
			}
#if (n==2) {browser();return()}

			msid  = mmc$Iter
			## ii    = as.character(msid)
			## pad0 automatically pads according to largest number in a vector
			## but if one subset is from early samples (low numbers), the code will break
			npad0 = floor(log10(max(msid))) + 1
			nmc   = length(msid)
			#run  = as.numeric(strsplit(mm,"\\.")[[1]][1])
			run   = mm
			ii = xii = paste0(run,".", pad0(msid,npad0))   ## xii = ii for extra mcmc
#browser(); return()
#print(length(ii))
			if (m==1){
				Nmcmc[[n]] = nmc
				rowN[[n]]  = ii
			} else {
				Nmcmc[[n]] = Nmcmc[[n]] + nmc
				rowN[[n]]  = c(rowN[[n]], ii)
			}

			if (n==1) { ## only need to look at the base catch policy for PA and RP
			## Parameters matrix
				matPA = array(NA, dim=c(nmc, length(valPA)), dimnames=list(sid=ii, val=valPA))
				for (k in 1:length(valPA)) {
					kk = valPA[k]
					vecPA = mmc[[kk]]
					if (is.null(vecPA)) next
					matPA[ii,kk] = vecPA
				}
				mclst[[mm]][["PA"]] = matPA

				## Reference points matrix
				matRP = array(NA, dim=c(nmc, length(valRP)), dimnames=list(sid=ii, val=valRP))
				for (k in 1:length(valRP)) {
					kk = valRP[k]
					vecRP = mmc[[kk]]
					if (is.null(vecRP)) next
					matRP[ii,kk] = vecRP
				}
				mclst[[mm]][["RP"]] = matRP

				## Time series matrix of population reconstruction
				matTS = array(NA, dim=c(nmc, length(ryrs), length(valTS)), dimnames=list(sid=ii, yr=ryrs, val=valTS))
				for ( k in 1:length(valTS) ) {
					kk = valTS[k]
					for (j in ryrs) {
						jj = as.character(j)
						vecTS = mmc[[paste0(kk,"_",jj)]]
						if (is.null(vecTS)) next
						matTS[ii,jj,kk] = vecTS
					}
				}
				mclst[[mm]][["TS"]] = matTS
			}

			## Projection series matrix (average catch and whatever catch policies are available)
			matPJ = array(NA, dim=c(nmc, length(pyrs), length(valTS)), dimnames=list(sid=ii, yr=pyrs, val=valTS))
			for ( k in 1:length(valTS) ) {
				kk = valTS[k]
				for (j in pyrs) {
					jj = as.character(j)
					vecPJ = mmc[[paste0(kk,"_",jj)]]
					if (is.null(vecPJ)) next
					matPJ[ii,jj,kk] = vecPJ
				}
			}
			mclst[[mm]][["PJ"]][[ccc]] = matPJ

			## Catch policy matrix
			matCP = array(NA, dim=c(nmc, length(pyrs)), dimnames=list(sid=ii, yr=pyrs))
			for (j in pyrs) {
				jj = as.character(j)
				vecCP = mmc[[paste0("ForeCatch_",jj)]]
				if (is.null(vecCP)) next
				matCP[ii,jj] = vecCP
			}
			mclst[[mm]][["CP"]][[ccc]] = apply(round(matCP),2,function(x){xx=as.numeric(names(rev(sort(table(x))))[1]); xx[is.na(xx) | !is.finite(xx)]=NA; return(xx)})
			## Note; 0-catch policy is sometimes set to a very small amount; sometimes other catch policies have small amounts added. WTF?
			## PJS thinks it may be a difference between v.2.30.16 and 3.30.17
			#mclst[[mm]][["CP"]][[ccc]] = apply(matCP,2,function(x){xx=mean(x,na.rm=T); xx[is.na(xx) | !is.finite(xx)]=NA; return(xx)})
			## CAUTION: Mode may not be sufficiently robust at higher CPs

			if (file.exists(paste0(mmm,"/mcmc.posts.rda"))) {
				## Binary rda files were generated by 'load_extra_mcmc.r'
				load(paste0(mmm,"/mcmc.posts.rda"))
				load(paste0(mmm,"/mcmc.ts.sub.rda"))  ## for the catch-by-area table (cattab)

				## Collect extra reference points
				rpdata = c("MSY.mcmc","B0.mcmc","V0.mcmc","pVB.mcmc")
				rpnames = c(dimnames(MSY.mcmc[[1]])[[2]], gsub("\\.mcmc$", "", rpdata)[-1])
				anames = names(MSY.mcmc)
browser();return()
				#snumbs = as.numeric(sub("^s", "", dimnames(MSY.mcmc[[1]])[[1]]))     ## even though all except MSY have the right names
				#snames = paste0(run,".",pad0(snumbs, floor(log10(max(snumbs))) + 1)) ## standardise to mesh with xavgRP
				snames = xii ## run and original iteration number
				dnames = list(mcmc=snames, val=rpnames, area=anames)
				xmatRP = array(NA, dim=c(length(snames), length(rpnames), length(anames)), dimnames=dnames)
				for (k in 1:length(rpdata)) {
					kk  = rpdata[k]
					kdat = get(kk)
					for (a in anames) {
						if (kk %in% c("MSY.mcmc")) {
							adat = kdat[[a]]
							ii = colnames(adat)
						} else {
							adat = kdat[,a,drop=FALSE]
							ii = gsub("\\.mcmc$", "", kk)
						}
						xmatRP[,ii,a] = as.matrix(adat)
					}
				}
				mclst[[mm]][["xRP"]][[ccc]] = xmatRP

				## Collect extra time series (note: contains reconstructed and projected years)
				tsdata  = setdiff(ls(pattern="\\.mcmc$"), rpdata)
				tsnames = gsub("\\.mcmc$", "", tsdata)
				#snames  = dimnames(get(tsdata[1])[[1]])[[1]]
				#snumbs = as.numeric(sub("^s", "", snames))
				#snames = paste0(run,".",pad0(snumbs, floor(log10(max(snumbs))) + 1))  ## standardise to mesh with xavgTS
				snames = xii ## run and original iteration number
				ynames  = dimnames(get(tsdata[1])[[1]])[[2]]
				dnames = list(mcmc=snames, year=ynames, val=tsnames, area=anames)
				xmatTS = array(NA, dim=c(length(snames),length(ynames),length(tsnames),length(anames)), dimnames=dnames)
				for (k in 1:length(tsnames)) {
					kk   = tsnames[k]
					kkk  = tsdata[k]
					kdat = get(kkk)
					for (a in anames) {
						adat = kdat[[a]]
						xmatTS[,,kk,a] = as.matrix(adat)
					}
				}
				mclst[[mm]][["xTS"]][[ccc]] = xmatTS

				## Collect extra time series projections (just a subset of xmatTS)
				cpyrs = c(ryrs[length(ryrs)],pyrs)  ## include the current year for convenience later
				xmatPJ = xmatTS[,as.character(cpyrs),,,drop=F]
				mclst[[mm]][["xPJ"]][[ccc]] = xmatPJ

				## Collect area-based catch policies
				xmatCP = cattab[as.character(cpyrs),]
				## To name the dimnames, must convert data.frame to matrix (je ne sais pas pourquoi)
				xmatCP = as.matrix(xmatCP)
				names(dimnames(xmatCP)) = c("year","area")
				mclst[[mm]][["xCP"]][[ccc]] = xmatCP
#if (n==3) {browser();return()}
			}  ## end collecting extras
		}  ## end n loop for mdir (catch policies)
		mclst[[mm]][["MPD"]] = P.mpd  ## for each base run
	}  ## end m loop for mcdir (base component runs)
	## ----- END initial data collection -----

	## Grab parameters across all runs
	if (strSpp %in% c("CAR","POP")) {
		valPA = unique(unlist(valPAs))
		valPA = c(grep("R0",valPA,value=T), grep("Rdist",valPA,value=T), grep("R0|Rdist|theta",valPA,invert=T,value=T), grep("theta",valPA,value=T))
		valLL = unique(unlist(valLLs))
		chunk = "Index|AF|Recruit|Total"
		valLL = c(grep(chunk,valLL,invert=T,value=T), grep(chunk,valLL,value=T))
	}

	mpdPA = list()
	dim1  = Nmcmc[[1]] ## number of rows for base case (cumulative if more than one base run component)
	dnam1 = rowN[[1]]  ## base case row names
	iv    = max(unlist(Nmcmc))
	ivnam = .su(unlist(rowN))
#browser();return()

	avgPA = array(NA, dim=c(dim1, length(valPA)), dimnames=list(mcmc=dnam1, par=valPA))
	vRP   = c("Bcurr","B0","20B0","40B0","Fcurr","ucurr","MSY","Bmsy","LRP","USR","Fmsy","umsy")
	avgRP = array(NA, dim=c(dim1, length(vRP)), dimnames=list(mcmc=dnam1, val=vRP))
	vTS   = c("Bt","BtB0","BtBmsy","Ft","FtFmsy","ut","utumsy","Rt","Rtdev")
	avgTS = array(NA, dim=c(dim1, length(ryrs), length(vTS)), dimnames=list(mcmc=dnam1, yr=ryrs, val=vTS))
	avgCP = array(NA, dim=c(length(pyrs), length(mclst), length(cp)), dimnames=list(yr=pyrs, run=names(mclst), proj=cp))
	avgLL =array(NA, dim=c(length(valLL), length(mclst)), dimnames=list(ll=valLL, run=names(mclst)))
	## Average projections have to be dimensioned by the projection with the most MCMCs
#browser();return()
	avgPJ = array(NA, dim=c(iv, length(pyrs), length(vTS), length(cp)), dimnames=list(mcmc=ivnam, yr=pyrs, val=vTS, proj=cp))

	## Check for extra mcmc stuff (why is the last mm being used here? need to use the first, assuming it's the base case)
	aref = names(mclst)[1]
	if ("xRP" %in% names(mclst[[aref]])) {
		xavgRP = array(NA, dim=c(dim1, dim(mclst[[aref]][["xRP"]][[cp[1]]])[-1]), dimnames=c(list(mcmc=dnam1), dimnames(mclst[[aref]][["xRP"]][[cp[1]]])[-1]) )
	}
	if ("xTS" %in% names(mclst[[aref]])) { ## includes projections
		xavgTS = array(NA, dim=c(dim1, dim(mclst[[aref]][["xTS"]][[cp[1]]])[-1]), dimnames=c(list(mcmc=dnam1), dimnames(mclst[[aref]][["xTS"]][[cp[1]]])[-1]) )
	}
## ***** TO HERE (single-area sensitivities --  dimensioning problems
	if ("xPJ" %in% names(mclst[[aref]])) { ## includes projections
		xavgPJ = array(NA, dim=c(dim1, dim(mclst[[aref]][["xPJ"]][[cp[1]]])[-1], length(cp)), dimnames=c(list(mcmc=dnam1), dimnames(mclst[[aref]][["xPJ"]][[cp[1]]])[-1], list(proj=cp) ))
	}
	if ("xCP" %in% names(mclst[[aref]])) { ## includes projections
		xavgCP = array(NA, dim=c(dim(mclst[[aref]][["xCP"]][[cp[1]]]), length(cp)), dimnames=c(dimnames(mclst[[aref]][["xCP"]][[cp[1]]]), list(proj=cp) ))
	}

	## Build the composite run ('model average')
	for (m in 1:length(mclst)){
		mm    = names(mclst)[m]
.flush.cat(mm, "\n")
		matrix(mclst[[mm]][["MPD"]][valPA],nrow=1)
		mpdPA = rbind(mpdPA, matrix(mclst[[mm]][["MPD"]][valPA], nrow=1))
		mcPA  = mclst[[mm]][["PA"]]
		mcRP  = mclst[[mm]][["RP"]]
		mcTS  = mclst[[mm]][["TS"]]
		mcPJ  = mclst[[mm]][["PJ"]]
		mcCP  = mclst[[mm]][["CP"]]
		#run   = as.numeric(strsplit(mm,"\\.")[[1]][1])
		run   = mm
		#npad0 = floor(log10(max(as.numeric(rownames(mcTS))))) +1
		iii = rownames(mcTS)
		#iii   = paste0(run,".",pad0(as.numeric(rownames(mcTS)), npad0)) ## but padding automatically detects largest number
		#iii   = (lastmc+1):(lastmc+dim(mcTS)[1])

		## Populate likelihood array
		for (n in 1:length(mclst[[mm]][["LL"]])){
			lll = names(mclst[[mm]][["LL"]])[n]
			avgLL[lll, mm] = mclst[[mm]][["LL"]][lll]
		}
		## Populate parameter array
		for (n in 1:length(mclst[[mm]][["MPD"]])){
			ppp = names(mclst[[mm]][["MPD"]])[n]
			avgPA[iii,ppp] = mcPA[,ppp]
		}
#if (m==2) {browser();return()}
		## Populate reference point array
		avgRP[iii,"Bcurr"] = mcTS[,cyr,"SSB"]
		avgRP[iii,"B0"]    = mcTS[,1,"SSB"]
		avgRP[iii,"20B0"]  = 0.2 * mcTS[,1,"SSB"]
		avgRP[iii,"40B0"]  = 0.4 * mcTS[,1,"SSB"]
		avgRP[iii,"MSY"]   = mcRP[,"Dead_Catch_MSY"]
		avgRP[iii,"Bmsy"]  = mcRP[,"SSB_MSY"]
		avgRP[iii,"LRP"]   = 0.4 * mcRP[,"SSB_MSY"]
		avgRP[iii,"USR"]   = 0.8 * mcRP[,"SSB_MSY"]
		if (Fmethod==1) {
			## Pope's approximation (discrete) ## Pope's method: check below (not tested)
			avgRP[iii,"ucurr"] = mcTS[,byr,"F"]
			avgRP[iii,"Fcurr"] = -log(1-mcTS[,byr,"F"])
			avgRP[iii,"umsy"]  = mcRP[,"annF_MSY"]
			avgRP[iii,"Fmsy"]  = -log(1-mcRP[,"annF_MSY"])
		} else {
#browser();return()
			## Baranov or Hybrid (continuous)
			avgRP[iii,"Fcurr"] = mcTS[,byr,"F"]
			avgRP[iii,"ucurr"] = 1 - exp(-mcTS[,byr,"F"])
			avgRP[iii,"Fmsy"]  = mcRP[,"annF_MSY"]
			avgRP[iii,"umsy"]  = 1-exp(-mcRP[,"annF_MSY"])
		}

		## Populate time series array
		avgTS[iii,dimnames(mcTS)$yr,"Bt"]     = mcTS[,,"SSB"]
		avgTS[iii,dimnames(mcTS)$yr,"BtB0"]   = mcTS[,,"SSB"] / avgRP[iii,"B0"]
		avgTS[iii,dimnames(mcTS)$yr,"BtBmsy"] = mcTS[,,"SSB"] / avgRP[iii,"Bmsy"]
		avgTS[iii,dimnames(mcTS)$yr,"Rt"]     = mcTS[,,"Recr"]
		avgTS[iii,dimnames(mcTS)$yr,"Rtdev"]  = mcTS[,,"RecrDev"]
		if (Fmethod==1) {
			## Pope's approximation (discrete) ## Pope's method: check below (not tested)
			avgTS[iii,dimnames(mcTS)$yr,"ut"]     = mcTS[,,"F"]
			avgTS[iii,dimnames(mcTS)$yr,"utumsy"] = mcTS[,,"F"] / avgRP[iii,"umsy"]
			avgTS[iii,dimnames(mcTS)$yr,"Ft"]     = -log(1 - mcTS[,,"F"])
			avgTS[iii,dimnames(mcTS)$yr,"FtFmsy"] = -log(1 - mcTS[,,"F"]) / avgRP[iii,"Fmsy"]
		} else {
			## Baranov or Hybrid (continuous)
			avgTS[iii,dimnames(mcTS)$yr,"Ft"]     = mcTS[,,"F"]
			avgTS[iii,dimnames(mcTS)$yr,"FtFmsy"] = mcTS[,,"F"] / avgRP[iii,"Fmsy"]
			avgTS[iii,dimnames(mcTS)$yr,"ut"]     = 1 - exp(-mcTS[,,"F"])
			avgTS[iii,dimnames(mcTS)$yr,"utumsy"] = (1 - exp(-mcTS[,,"F"])) / avgRP[iii,"umsy"]
		}

		## Loop through catch policies for each run
		for (n in 1:length(cp)){
			ccc = cp[n]
#browser();return()
			avgCP[as.character(pyrs),mm,ccc] =  mcCP[[ccc]]
			ii  = xii = dimnames(mcPJ[[ccc]])$sid
			#iii = dimnames(avgRP)$mcmc
			kkk = dimnames(mcPJ[[ccc]])$yr
#if (n==2) {browser();return()}
			## Populate projection array
			avgPJ[ii,kkk,"Bt",ccc]      = mcPJ[[ccc]][ii,,"SSB"]
			#avgPJ[iii,kkk,"BtB0",ccc]   = mcPJ[[ccc]][iii,kkk,"SSB"] / avgRP[iii,"B0"]
			#avgPJ[iii,kkk,"BtBmsy",ccc] = mcPJ[[ccc]][iii,kkk,"SSB"] / avgRP[iii,"Bmsy"]
			avgPJ[ii,kkk,"BtB0",ccc]   = mcPJ[[ccc]][ii,kkk,"SSB"] / avgRP[ii,"B0"]
			avgPJ[ii,kkk,"BtBmsy",ccc] = mcPJ[[ccc]][ii,kkk,"SSB"] / avgRP[ii,"Bmsy"]
			avgPJ[ii,kkk,"Rt",ccc]      = mcPJ[[ccc]][ii,kkk,"Recr"]
			avgPJ[ii,kkk,"Rtdev",ccc]   = mcPJ[[ccc]][ii,kkk,"RecrDev"]
			if (Fmethod==1) {
				## Pope's approximation (discrete) ## Pope's method: check below (not tested)
				avgPJ[ii,kkk,"ut",ccc]      = mcPJ[[ccc]][ii,kkk,"F"]
				avgPJ[ii,kkk,"utumsy",ccc] = mcPJ[[ccc]][ii,kkk,"F"] / avgRP[ii,"umsy"]
				avgPJ[ii,kkk,"Ft",ccc]      = -log(1 - mcPJ[[ccc]][ii,kkk,"F"])
				avgPJ[ii,kkk,"FtFmsy",ccc] = -log(1 - mcPJ[[ccc]][ii,kkk,"F"]) / avgRP[ii,"Fmsy"]
			} else {
				## Baranov or Hybrid (continuous)
				avgPJ[ii,kkk,"Ft",ccc]      = mcPJ[[ccc]][ii,kkk,"F"]
				avgPJ[ii,kkk,"FtFmsy",ccc] = mcPJ[[ccc]][ii,kkk,"F"] / avgRP[iii,"Fmsy"]
				avgPJ[ii,kkk,"ut",ccc]      = 1 - exp(-mcPJ[[ccc]][ii,kkk,"F"])
				avgPJ[ii,kkk,"utumsy",ccc] = (1 - exp(-mcPJ[[ccc]][ii,kkk,"F"])) / avgRP[ii,"umsy"]
			}
		}  ## end n loop (catch policies)

		## ----- Collect extra mcmc data if they exist -----
		## Extra reference points
		if ("xRP" %in% names(mclst[[mm]])) {
			xmcRP = mclst[[mm]][["xRP"]][[cp[1]]]           ## grab the base runs' reference points (default catch policy)
			xtemp = xmcRP[xii,,,drop=FALSE]                 ## xii = original iteration names for the extra MCMCs
			atemp = dimnames(xmcRP[xii,,,drop=FALSE])$area  ## need specific areas for certain runs (e.g., single-area runs)
			xavgRP[xii,,atemp] = xtemp
		} else {
			xavgRP = NA
		}
		## Extra time series
		if ("xTS" %in% names(mclst[[1]])) {
			xmcTS = mclst[[mm]][["xTS"]][[cp[1]]]
#browser();return()
			xtemp = xmcTS[xii,,,,drop=FALSE]                 ## xii = original iteration names for the extra MCMCs
			atemp = dimnames(xmcTS[xii,,,,drop=FALSE])$area  ## need specific areas for certain runs (e.g., single-area runs)
			xavgTS[xii,,,atemp] = xtemp                      ## xii = original iteration names for the extra MCMCs
			#xavgTS[xii,,,] = xmcTS[xii,,,]
		} else {
			xavgTS = NA
		}
		## Extra projections
		if ("xPJ" %in% names(mclst[[1]])) {
			## Loop through catch policies for each run and collect projections
			for (n in 1:length(cp)){
				ccc   = cp[n]
				xmcPJ = mclst[[mm]][["xPJ"]][[ccc]]
				xtemp = xmcPJ[xii,,,,drop=FALSE]                 ## xii = original iteration names for the extra MCMCs
				atemp = dimnames(xmcPJ[xii,,,,drop=FALSE])$area  ## need specific areas for certain runs (e.g., single-area runs)
				xavgPJ[xii,,,atemp,ccc] = xtemp                  ## xii = original iteration names for the extra MCMCs
#browser();return()
				#xavgPJ[xii,,,,ccc] = xmcPJ[xii,,,]
			}
		} else {
			xavgPJ = NA
		}
#if (m==2) {browser();return()}
		## Extra catch policies
		if ("xCP" %in% names(mclst[[1]])) {
			if (m==1) {
				## Loop through catch policies for each run and collect area-based catch policies
				for (n in 1:length(cp)){
					ccc   = cp[n]
					xmcCP = mclst[[mm]][["xCP"]][[ccc]]
					xavgCP[,,ccc] = xmcCP
				}
			}
		} else {
			xavgCP = NA
		}
	}  ## end m loop (mclst, base components)
#browser();return()

	storage.mode(mpdPA)="double"
	rownames(mpdPA) = names(mclst); colnames(mpdPA) = valPA  ## because of occasional extra parameters
	if (type=="compo")
		out = list(ampdPA=mpdPA, avgLL=avgLL, avgPA=avgPA, avgRP=avgRP, avgTS=avgTS, avgPJ=avgPJ, avgCP=avgCP, xavgRP=xavgRP, xavgTS=xavgTS, xavgPJ=xavgPJ, xavgCP=xavgCP)
	else if (type=="senso")
		out = list(smpdPA=mpdPA, senLL=avgLL, senPA=avgPA, senRP=avgRP, senTS=avgTS, senPJ=avgPJ, senCP=avgCP, xsenRP=xavgRP, xsenTS=xavgTS, xsenPJ=xavgPJ, xsenCP=xavgCP)
	else if (type=="penso")
		out = list(pmpdPA=mpdPA, penLL=avgLL, penPA=avgPA, penRP=avgRP, penTS=avgTS, penPJ=avgPJ, penCP=avgCP, xpenRP=xavgRP, xpenTS=xavgTS, xpenPJ=xavgPJ, xpenCP=xavgCP)
	else if (type=="renso")
		out = list(rmpdPA=mpdPA, renLL=avgLL, renPA=avgPA, renRP=avgRP, renTS=avgTS, renPJ=avgPJ, renCP=avgCP, xrenRP=xavgRP, xrenTS=xavgTS, xrenPJ=xavgPJ, xrenCP=xavgCP)
	else
		out = "sumtingwong"
#browser();return()
	return(out)
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~gatherMCMC

so("convPN.r","synth")
require(r4ss)
basedir = "C:/Users/haighr/Files/GFish/PSARC23/POP/Data/SS/POP2023"
cr.run=21; cr.rwt=1; cr.ver="3a"  ## could be multiple base component runs
xr.run=21; xr.rwt=1; xr.ver="3a"  ## central base component run
sr.run=c(17,27:35); sr.rwt=c(0,rep(1,9)); sr.ver=c("18a", rep("1a",9))
pr.run=c(24:26); pr.rwt=c(1,1,1); pr.ver=c(rep("1a",3))  ## PJS runs (single-area models)
rr.run=c(21); rr.rwt=c(1); rr.ver=c("5a")  ## low-recruitment runs in forecast

redo.compo = T
redo.senso = F
redo.penso = F
redo.renso = F
if (redo.compo) {
	cr.mcmc = rep("",length(cr.run)) ## component runs (latter in case mcmc has some weird suffix lie 'nut2K')
	cr.run.rwt = paste0( pad0(cr.run,2), ".", pad0(cr.rwt,2) )
	cr.run.rwt.ver = paste0( cr.run.rwt, ".v", cr.ver)
	cr.dir = paste0("Run", pad0(cr.run,2), "/MCMC.", cr.run.rwt.ver, cr.mcmc)
	.flush.cat("Gathering component runs...\n")
	compo = gatherMCMC(mcdir=cr.dir, basedir=basedir)
	save("compo", file=paste0("compo.", format(Sys.Date(), "%y%m%d"), ".rda"))
}
## Sensitivities (regular)
if (redo.senso) {  ## !!! include central run in first position !!!
	xsr.run = c(xr.run, sr.run); xsr.rwt=c(xr.rwt, sr.rwt); xsr.ver=c(xr.ver,sr.ver); sr.mcmc = "" #rep(".nuts4K",length(sr.run))  ## sensitivity runs
	xsr.run.rwt = paste0( pad0(xsr.run,2), ".", pad0(xsr.rwt,2) )
	xsr.run.rwt.ver = paste0( xsr.run.rwt, ".v", xsr.ver)
	xsr.dir = paste0("Run", pad0(xsr.run,2), "/MCMC.", xsr.run.rwt.ver, sr.mcmc)
	.flush.cat("Gathering sensitivity runs...\n")
	senso = gatherMCMC(mcdir=xsr.dir, basedir=basedir, type="senso")
	save("senso", file=paste0("senso.", format(Sys.Date(), "%y%m%d"), ".rda"))
}
## Sensitivities (PJS): POP 20203 = single-area MCMCs
if (redo.penso) {  ## !!! include central run in first position !!!
	xpr.run = c(xr.run, pr.run); xpr.rwt=c(xr.rwt, pr.rwt); xpr.ver=c(xr.ver,pr.ver); pr.mcmc = "" #rep(".nuts4K",length(sr.run))  ## sensitivity runs
	xpr.run.rwt = paste0( pad0(xpr.run,2), ".", pad0(xpr.rwt,2) )
	xpr.run.rwt.ver = paste0( xpr.run.rwt, ".v", xpr.ver)
	xpr.dir = paste0("Run", pad0(xpr.run,2), "/MCMC.", xpr.run.rwt.ver, pr.mcmc)
	.flush.cat("Gathering PJS sensitivity runs...\n")
	penso = gatherMCMC(mcdir=xpr.dir, basedir=basedir, type="senso")
	save("penso", file=paste0("penso.", format(Sys.Date(), "%y%m%d"), ".rda"))
}
## Sensitivities on low forecast recruitment: POP 20203 = single-area MCMCs
if (redo.renso) { ## exclude central run
	#xrr.run = c(xr.run, rr.run); xrr.rwt=c(xr.rwt, rr.rwt); xrr.ver=c(xr.ver,rr.ver); rr.mcmc = "" #rep(".nuts4K",length(sr.run))  ## sensitivity runs
	xrr.run = c(rr.run); xrr.rwt=c(rr.rwt); xrr.ver=c(rr.ver); rr.mcmc = "" ## exclude base run
	xrr.run.rwt = paste0( pad0(xrr.run,2), ".", pad0(xrr.rwt,2) )
	xrr.run.rwt.ver = paste0( xrr.run.rwt, ".v", xrr.ver)
	xrr.dir = paste0("Run", pad0(xrr.run,2), "/MCMC.", xrr.run.rwt.ver, rr.mcmc)
	.flush.cat("Gathering low-recruitment sensitivities...\n")
	renso = gatherMCMC(mcdir=xrr.dir, basedir=basedir, type="renso")
	save("renso", file=paste0("renso.", format(Sys.Date(), "%y%m%d"), ".rda"))
}
#if (redo.senso && penso) {  ## !!! include central run in first position !!!
#	## Special case versions for PJS (CAR only to date):
#	sr.run = c(24, 38,38,38); sr.rwt=c(1,stock[["POP"]][["Controls"]]$sen.rwt.num); sr.ver=c(3,6,7,8); sr.mcmc = "" #rep(".nuts4K",length(sr.run))  ## sensitivity runs
#	sr.run.rwt = paste0( pad0(sr.run,2), ".", pad0(sr.rwt,2) )
#	sr.dir = paste0("Run", pad0(sr.run,2), ".v", sr.ver, "/MCMC.", sr.run.rwt.ver, sr.mcmc)
#	.flush.cat("Gathering sensitivity runs...\n")
#	senso = gatherMCMC(mcdir=sr.dir, basedir=paste0(dirname(basedir),"/Versions"), type="senso")
#	save("senso", file=paste0("penso.", format(Sys.Date(), "%y%m%d"), ".rda"))
#}

##Note: need xavgPJ for projections (missing 2024 as this is not really a projection year)


