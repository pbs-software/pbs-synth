## Make Sensitivity Tables
## -----------------------
tabSS.senso = function(istock="YMR", prefix="ymr.", senso, sigdig=4)
{
	on.exit(gc(verbose=FALSE))
	unpackList(stock[[istock]][["Controls"]])
	unpackList(senso)

	## Use same preliminary code from 'plotSS.senso'
	## ---------------------------------------------
	modYrs      = startYear:currYear
	modYrsChar  = as.character(modYrs)
	## Diagnostics for select parameters
	P.names     = colnames(senPA) ## paremeter names
	S.mpd       = smpdPA; storage.mode(S.mpd)="double"     ## For some reason, this matrix is stored as a list (maybe due to NA values?)
	S.runs      = as.numeric(sapply(strsplit(rownames(senPA),"\\."),function(x){x[1]})) ## vector of Runs
	S.run.rwt   = sapply(strsplit(rownames(senPA),"\\."),function(x){paste0(x[1],".",x[2])}) ## vector of Runs and Rwts
	S.run.ord   = unique(S.runs)                           ## unique Run numbers (1st is central run)
	S.run.nmc   = table(S.runs)[as.character(S.run.ord)]   ## vector of sensitivity runs ordered
	S.run.num   = rep(1:length(S.run.nmc), S.run.nmc) - 1  ## 1st run is Central Run
	S.num       = unique(S.run.num)
	## Look into subsetting later
	use.run.rwt = unique(S.run.rwt)
	#is.element(P.runs, P.run.ord) ## default use all runs but a subset might be used for management advice
	if (spp.code %in% c("YMR"))
		P.ord=c(1,seq(2,10,2),seq(3,11,2),12,13)
	else
		P.ord = 1:ncol(smpdPA)

	## Create Sensitivity labels
	S.prefix    = paste0("S",pad0(S.num,2)," (R", pad0(S.run.ord,2) ,") ")
	iCR         = grep(exp.run.rwt,unique(B.index))
	S.prefix[1] = paste0("B",iCR, " (R", strsplit(exp.run.rwt,"\\.")[[1]][1], ") ")
	S.labels    = paste0(S.prefix, gsub("\\_"," ", c("Central Run",sen.lab)))
	S.labels    = sub("\\\\pc", "%", S.labels)  ## just in case

	## Calculate quantiles for later (eventually make this function global)
	calcQs = function (dat, ivec, ovec) {
		F.data = as.data.frame(dat)
		F.list = split(F.data, ivec)
		rr.ord = match(ovec, substring(names(F.list),1,2))  ## oder not so important for sensitivities
		F.list = F.list[rr.ord]
		F.qnts = lapply(F.list,function(x){
			z = apply(x,2,function(xx){!any(is.na(xx))})
			out = apply(x[z],2,quantile,quants5)
			return(out)
		}) ## lapply does not sort like split does
		return(F.qnts)
	}
	P.qnts = calcQs(senPA, ivec=S.run.rwt, ovec=S.run.ord)

	##----------Table 1-----------
	## MCMC model parameters table
	##----------------------------
	tabPmed = array(NA, dim=c(length(P.names),length(use.run.rwt)), dimnames=list(P.names,use.run.rwt))
	for (k in 1:length(use.run.rwt)){
		kk = use.run.rwt[k]
		qq = P.qnts[[kk]]
		ii = qq[grep("50%", rownames(qq)),]
		tabPmed[names(ii), kk] = ii
	}
	tabPmed = tabPmed[P.ord,]
	tab.sens.pars = formatCatch(tabPmed,N=sigdig)
	colnames(tab.sens.pars) = gsub(" +","",S.prefix)

	names.pars = rownames(tab.sens.pars)
	names.pars = sub("Male","{2}",sub("Female","{1}",names.pars))
	fixsub = grep("[^M]_",names.pars)
	names.pars[fixsub] = paste0(sub("_","~(",names.pars[fixsub]),")")
	names.pars = sub("varL\\(","\\\\log v(\\\\mathrm{L}",names.pars)
	names.pars[fixsub] = sub("\\(","_{", sub("\\)","}", names.pars[fixsub]))
	names.pars = gsub("mu","\\\\mu",names.pars)
	names.pars = gsub("Delta","\\\\Delta",names.pars)
	names.pars = sub("LN\\(R0)","\\\\log R_{0}",names.pars)
	names.pars = sub("~\\([[:alpha:]]+(\\+)?\\)$", "", names.pars)  ## keep annotation short 
	#names.pars[fixsub] = sub("\\(","(\\\\mathrm{", sub("\\)","})", names.pars[fixsub]))
	rownames(tab.sens.pars) =  paste(rep("$",nrow(tab.sens.pars)),names.pars,rep("$",nrow(tab.sens.pars)),sep="")

	sen.leg = paste0("Sensitivity runs: ", paste0("S", formatC(S.num[-1], width=0, format="d", flag="0"),"~= ", gsub("\\%","\\\\%",gsub("_"," ",sen.lab)), collapse=", "))
	if (spp.code=="REBS") {  ## need to add Other fishery because it has ages but no CPUE index
		nseries = length(iseries)
		iseries[nseries] = paste0(iseries[nseries],"/Trawl fishery")
		iseries = c(iseries, "Other fishery")
	}
	cap.par = paste0(
		name, ": median values of MCMC samples for the primary estimated parameters, ",
		"comparing the central run to ", Nsens, " sensitivity runs (\\Nmcmc{} samples each). C~=Central, R~= Run, S~= Sensitivity. ",
		#"D~=Diagnostic sensitivity ($M$=0.11). ",
		"Numeric subscripts other than those for $R_0$ and $M$ indicate the following gear types $g$: ",
		texThatVec(paste0(1:length(iseries),"~= ",iseries),simplify=F), ". ", sen.leg
	)
	xtab.sens.pars = xtable(tab.sens.pars, align=paste0("c",paste0(rep("r",Nsens+1),collapse="")),
		label   = paste0("tab:",prefix,"sens.pars"), digits = if (exists("formatCatch")) NULL else sigdig,
		caption = cap.par )
	xtab.sens.pars.out = capture.output( print(xtab.sens.pars, caption.placement="top",
		sanitize.rownames.function=function(x){x},
		add.to.row =list(pos = list(-1), command = c("\\\\[-1.0ex]")),
		size = "\\usefont{\\encodingdefault}{\\familydefault}{\\seriesdefault}{\\shapedefault}\\footnotesize"
	) )
	tput(xtab.sens.pars.out)
#browser();return()

	## MCMC MSY-based quantities
	## -------------------------
	ls2df = function(x) {
		nn = as.character(substitute(x))
		xx = as.data.frame(x)
		colnames(xx) = paste(nn,colnames(xx),sep="_")
		return(xx)
	}
	#D.qnts = calcQs(senTS[,,"BtB0"], ivec=S.run.rwt, ovec=S.run.ord)
	#U.qnts = calcQs(senTS[,,"ut"], ivec=S.run.rwt, ovec=S.run.ord)
	#R.qnts = calcQs(senTS[,,"Rt"], ivec=S.run.rwt, ovec=S.run.ord)
	#RD.qnts = calcQs(senTS[,,"Rtdev"], ivec=S.run.rwt, ovec=S.run.ord)

	Q.mcmc = data.frame (
		B0         = senRP[,"B0"],
		Bcurr      = senRP[,"Bcurr"],
		Bcurr.B0   = senRP[,"Bcurr"] / senRP[,"B0"],
		ucurr      = senRP[,"ucurr"],
		umax       = apply(senTS[,,"ut"],1,max), ## for each mcmc sample across the time series
		MSY        = senRP[,"MSY"],
		Bmsy       = senRP[,"Bmsy"],
		LRP        = senRP[,"LRP"],
		USR        = senRP[,"USR"],
		Bcurr.Bmsy = senRP[,"Bcurr"] / senRP[,"Bmsy"],
		Bmsy.B0    = senRP[,"Bmsy"] / senRP[,"B0"],
		umsy       = senRP[,"umsy"],
		ucurr.umsy = senRP[,"ucurr"] / senRP[,"umsy"]
	)
	Q.mcmc.sens = split(Q.mcmc, S.run.rwt)
	tabQmed = sapply(Q.mcmc.sens, function(Q){
		sapply(Q, median)
	})
	tab.sens.rfpt = formatCatch(tabQmed,N=sigdig-1)  ## use 3 instead of 4
	colnames(tab.sens.rfpt) = gsub(" +","",S.prefix)

	names.rfpt = rownames(tab.sens.rfpt)
	## Use routine from 'make.base.tabs.r':
	names.rfpt =
		gsub("LRP",  paste0("0.4B_{",currYear,"}"),
		gsub("USR",  paste0("0.8B_{",currYear,"}"),
		gsub("umax", "u_\\\\mathrm{max}",
		gsub("msy", "_\\\\mathrm{MSY}",
		gsub("curr",  paste0("_{",currYear,"}"),
		gsub("umsy",  "u_\\\\mathrm{MSY}",
		gsub("ucurr", paste0("u_{",currYear,"}"),
		gsub("0", "_{0}",
		gsub("\\.", "/",
		names.rfpt)))))))))
	rownames(tab.sens.rfpt) =  paste(rep("$",nrow(tab.sens.rfpt)),names.rfpt,rep("$",nrow(tab.sens.rfpt)),sep="")

	cap.rfpt = paste0(
		name, ": medians of MCMC-derived quantities from the central run and ", Nsens,
		" sensitivity runs (\\Nmcmc{} samples each) from their respective MCMC posteriors. Definitions are: ",
		"$B_0$ -- unfished equilibrium spawning biomass (mature females), ",
		#"$V_0$ -- unfished equilibrium vulnerable biomass (males and females), ",
		"$B_{", currYear, "}$ -- spawning biomass at the end of ",currYear, ", ",
		#"$V_{", currYear, "}$ -- vulnerable biomass in the middle of ", currYear, ", ",
		"$u_{", currYear, "}$ -- exploitation rate (ratio of total catch to vulnerable biomass) in the middle of ", currYear, ", ",
		"$u_\\mathrm{max}$ -- maximum exploitation rate (calculated for each sample as the maximum exploitation rate from ",
		startYear , " - ", currYear, "), ",
		"MSY -- maximum sustainable yield at equilibrium, ",
		"$B_\\mathrm{MSY}$ -- equilibrium spawning biomass at MSY, ",
		"$u_\\mathrm{MSY}$ -- equilibrium exploitation rate at MSY, ",
		#"$V_\\mathrm{MSY}$ -- equilibrium vulnerable biomass at MSY. ",
		"All biomass values (and MSY) are in tonnes. ", sen.leg
	)
#browser();return()

	xtab.sens.rfpt = xtable(tab.sens.rfpt, align=paste0("l",paste0(rep("r",Nsens+1),collapse="")),
		label   = paste0("tab:",prefix,"sens.rfpt"), digits = if (exists("formatCatch")) NULL else sigdig,
		caption = cap.rfpt )
	xtab.sens.rfpt.out = capture.output( print(xtab.sens.rfpt, caption.placement="top",
		sanitize.rownames.function=function(x){x},
		add.to.row=list(pos=list(-1,3,11), command=c("\\\\[-1.0ex]", "\\hdashline \\\\[-1.75ex]", "\\hdashline \\\\[-1.75ex]")),
		hline.after =  c(-1,0,5,nrow(xtab.sens.rfpt)),
		size = "\\usefont{\\encodingdefault}{\\familydefault}{\\seriesdefault}{\\shapedefault}\\footnotesize"
	) )
	tput(xtab.sens.rfpt.out)
#browser();return()

	## Sensitivity run likelihoods
	## ---------------------------
	LL.senso =data.frame(
		Sen.Run =c("S00 (R75)", "S01 (R78)", "S02 (R79)", "S03 (R80)", "S04 (R81)", "S05 (R82)", "S06 (R83)", "S07 (R84)", "S08 (R85)", "S09 (R86)", "S10 (R87)", "S11 (R88)", "S12 (R91)", "S13 (R92)", "S14 (R93)"),
		Label   =c("central run", "add 1997 WCHG index", "estimate M", "drop CPUE", "Tweedie CPUE", "sigmaR=0.6", "sigmaR=1.2", "reduce catch 33%", "increase catch 50%", "upweight QC AF", "start Rdevs in 1970", "no ageing error", "steepness h=0.5", "double 2021 catch", "AE from age readers"),
		CPUE    =c(-18.06, -18.13, -17.02, 0, -22.47, -16.83, -18.5, -18.4, -17.4, -18.53, -8.074, -17.87, -18.02, -18.06, -17.87),
		QCS     =c(0.8701, 0.9094, 0.4254, 0.6586, 0.9573, 0.6097, 0.9335, 1.118, 0.5719, 0.6807, -0.8074, 0.9635, 0.927, 0.8724, 0.7353),
		WCVI    =c(7.92, 7.918, 7.937, 7.939, 7.952, 7.749, 8.026, 7.893, 7.943, 7.842, 8.249, 7.819, 7.879, 7.921, 7.952),
		WCHG    =c(19.68, 19.13, 18.93, 19.25, 19.73, 19.43, 19.68, 20.08, 19.2, 19.99, 16.41, 19.9, 19.79, 19.68, 19.44),
		GIG     =c(14.48, 14.5, 14.58, 14.32, 14.52, 14.2, 14.58, 13.67, 15.45, 14.42, 12.13, 14.5, 14.48, 14.48, 14.41),
		Index   =c(24.89, 24.33, 24.86, 42.17, 20.69, 25.16, 24.72, 24.36, 25.77, 24.41, 27.9, 25.31, 25.05, 24.89, 24.67),
		AF      =c(456.4, 456.5, 457.2, 705.9, 715.1, 482.6, 442.4, 451.9, 459.8, 626.8, 540.1, 387.2, 457.1, 458.8, 443.3),
		Recruit =c(41.93, 41.96, 39.27, 51.79, 52.24, 55.48, 39.61, 42.42, 42.87, 51.04, 21.02, 35.09, 42.31, 42.02, 40.69),
		Total   =c(635.1, 634.7, 635.4, 912.2, 900.5, 675, 618.6, 630.5, 640.3, 817.6, 700.7, 560.2, 636.4, 637.6, 621.1)
	)
#browser();return()
	xtab.sruns.ll = xtable(formatCatch(LL.senso, X=1:2), align=paste0("l", paste0(rep("r",dim(LL.senso)[2]),collapse="")),
		label   = paste0("tab:",prefix,"log.likes"), digits=NULL, 
		caption = "Log likelihood (LL) values reported by central and sensitivity runs for survey indices, age composition (AF), recruitment, and total (not all LL components reported here)")
	xtab.sruns.ll.out = capture.output(print(xtab.sruns.ll,  include.rownames=FALSE,
		caption.placement="top", sanitize.rownames.function=function(x){x}, add.to.row =list(pos = list(-1,1), command = c("\\\\[-0.5ex]", "\\hdashline \\\\[-1.75ex]")) ) )
	tput(xtab.sruns.ll.out)

	save("xtab.sens.pars.out", "xtab.sens.rfpt.out", "xtab.sruns.ll.out", file=paste0(prefix,"senso.tabs.rda"))

	collect=c("tab.sens.pars","tab.sens.rfpt")
	for (i in collect) 
		eval(parse(text=paste0("stock[[istock]][[\"Sens\"]][[\"",i,"\"]] = ",i)))
}
## Activate for debugging only:
tabSS.senso(senso=senso) #, prefix="RER.")
