# r4ss Functions
# --------------
plotProfile=function (summaryoutput, plot=TRUE, print=FALSE, models="all", 
	profile.string="steep", profile.label="Spawner-recruit steepness (h)", 
	exact=FALSE, ylab="Change in -log-likelihood", components=c("TOTAL", 
		"Catch", "Equil_catch", "Survey", "Discard", "Mean_body_wt", 
		"Length_comp", "Age_comp", "Size_at_age", "SizeFreq", 
		"Morphcomp", "Tag_comp", "Tag_negbin", "Recruitment", 
		"InitEQ_Regime", "Forecast_Recruitment", "Parm_priors", 
		"Parm_softbounds", "Parm_devs", "F_Ballpark", "Crash_Pen"), 
	component.labels=c("Total", "Catch", "Equilibrium catch", 
		"Index data", "Discard", "Mean body weight", "Length data", 
		"Age data", "Size-at-age data", "Generalized size data", 
		"Morph composition data", "Tag recapture distribution", 
		"Tag recapture total", "Recruitment", "Initital equilibrium recruitment", 
		"Forecast recruitment", "Priors", "Soft bounds", "Parameter deviations", 
		"F Ballpark", "Crash penalty"), minfraction=0.01, sort.by.max.change=TRUE, 
	col="default", pch="default", lty=1, lty.total=1, 
	lwd=2, lwd.total=3, cex=1, cex.total=1.5, xlim="default", 
	ymax="default", xaxs="r", yaxs="r", type="o", legend=TRUE, 
	legendloc="topright", pwidth=8, pheight=6, punits="in", 
	res=400, ptsize=10, cex.main=1, plotdir=NULL, add_cutoff=FALSE, 
	cutoff_prob=0.95, verbose=TRUE, ...) 
{
	pngfun <- function(file) {
		png(filename=file.path(plotdir, file), width=pwidth, 
			height=pheight, units=punits, res=res, pointsize=ptsize)
		expandGraph()
	}
	if (print) {
		if (is.null(plotdir)) {
			stop("to print PNG files, you must supply a directory as 'plotdir'")
		}
		if (!file.exists(plotdir)) {
			if (verbose) 
				cat("creating directory:", plotdir, "\n")
			dir.create(plotdir, recursive=TRUE)
		}
	}
	if (length(components) != length(component.labels)) {
		stop("Inputs 'components' and 'component.labels' should have equal length")
	}
	n <- summaryoutput$n
	likelihoods <- summaryoutput$likelihoods
	if (is.null(likelihoods)) {
		stop("Input 'summaryoutput' needs to be a list output from SSsummarize\n", 
			"and have an element named 'likelihoods'.")
	}
	pars <- summaryoutput$pars
	if (models[1] == "all") {
		models <- 1:n
	}
	else {
		if (!all(models %in% 1:n)) 
			stop("Input 'models' should be a vector of values from 1 to n=", 
				n, " (for your inputs).\n")
	}
	if (exact) {
		parnumber <- match(profile.string, pars$Label)
	}
	else {
		parnumber <- grep(profile.string, pars$Label)
	}
	if (length(parnumber) <= 0) {
		stop("No parameters matching profile.string='", profile.string, 
			"'", sep="")
	}
	parlabel <- pars$Label[parnumber]
	if (length(parlabel) > 1) {
		stop("Multiple parameters matching profile.string='", 
			profile.string, "':\n", paste(parlabel, collapse=", "), 
			"\nYou may need to use 'exact=TRUE'.", sep="")
	}
	parvec <- as.numeric(pars[pars$Label == parlabel, models])
	cat("Parameter matching profile.string='", profile.string, 
		"': '", parlabel, "'\n", sep="")
	cat("Parameter values (after subsetting based on input 'models'):\n")
	print(parvec)
	if (xlim[1] == "default") 
		xlim <- range(parvec)
	prof.table <- data.frame(t(likelihoods[likelihoods$Label %in% components, models]))
	names(prof.table) <- likelihoods[likelihoods$Label %in% components, ncol(likelihoods)]
	component.labels.good <- rep("", ncol(prof.table))
	for (icol in 1:ncol(prof.table)) {
		ilabel <- which(components == names(prof.table)[icol])
		component.labels.good[icol] <- component.labels[ilabel]
	}
	subset <- parvec >= xlim[1] & parvec <= xlim[2]
	for (icol in 1:ncol(prof.table)) {
		prof.table[, icol] <- prof.table[, icol] - min(prof.table[subset, icol])
	}
	if (ymax == "default") 
		ymax <- 1.05 * max(prof.table[subset, ])
	ylim <- c(0, ymax)
	column.max <- apply(prof.table[subset, ], 2, max)
	change.fraction <- column.max/column.max[1]
	include <- change.fraction >= minfraction  ## determines which columns to use
	nlines <- sum(include)
	message("\nLikelihood components showing max change as fraction of total change.\n", 
		"To change which components are included, change input 'minfraction'.\n")
	print(data.frame(frac_change=round(change.fraction, 4), include=include, label=component.labels.good))
#browser();return()

	if (nlines == 0) {
		stop("No components included, 'minfraction' should be smaller.")
	}
	component.labels.used <- component.labels.good[include]
	prof.table            <- prof.table[order(parvec), include]	
	parvec                <- parvec[order(parvec)]
	change.fraction       <- change.fraction[include]
	if (nlines > 1) {
		if (sort.by.max.change) {
			neworder <- c(1, 1 + order(change.fraction[-1], decreasing=TRUE))
			prof.table <- prof.table[, neworder]
			component.labels.used <- component.labels.used[neworder]
		}
	}
	if (col[1] == "default") {
		col <- rich.colors.short(nlines)
	} else {
		col = rep(col,nlines)[1:nlines]
	}
	if (pch[1] == "default") {
		pch <- 1:nlines
	}
	lwd <- c(lwd.total, rep(lwd, nlines - 1))
	cex <- c(cex.total, rep(cex, nlines - 1))
	lty <- c(lty.total, rep(lty, nlines - 1))
	dots = list(...)
	if (is.null(dots$log))
		log = FALSE
	else
		log = dots$log
	plotprofile <- function(log) {
		if (log) {
			ylim = log2(GT0(ylim,eps=0.05))
			ylab = sub("^Change", "Log2 change", ylab)
		}
		plot(0, type="n", xlim=xlim, ylim=ylim, xlab=profile.label, ylab=ylab, yaxs=yaxs, xaxs=xaxs)
#browser();return()
		abline(h=ifelse(log,log2(GT0(0,eps=0.05)),0), col="grey")
		if (add_cutoff) {
			abline(h=0.5 * qchisq(p=cutoff_prob, df=1), lty=2)
		}
		#matplot(parvec, prof.table, type=type, pch=pch, col=lucent(col,0.75), cex=cex, lty=lty, lwd=lwd, add=T)
		ytab = prof.table[,ncol(prof.table):1]
		if (log)
			ytab  = log2(GT0(ytab,eps=0.05))
		matplot(parvec, ytab, type=type, pch=rev(pch), col=rev(lucent(col,0.75)), cex=rev(cex), lty=rev(lty), lwd=rev(lwd), add=T)
		if (legend) 
			legend(legendloc, bty="n", legend=component.labels.used, lwd=lwd, pt.cex=cex, lty=lty, pch=pch, col=col)
		box()
	}
#browser();return()
	if (plot) 
		expandGraph()
		plotprofile(log=log)
	if (print) {
		pngfun(paste0("profile_plot_likelihood-[",profile.string,"]",ifelse(log,"-ylog2",""),".png"))
		plotprofile(log=log)
		dev.off()
	}
	out <- data.frame(parvec=parvec, prof.table)
	names(out)[1] <- parlabel
	return(invisible(out))
}
png = T
require(r4ss)
#setwd("./Prof.R0")
#pmods <- SSgetoutput(dirvec=".", keyvec=1:30)
#psum  <- SSsummarize(pmods, verbose=FALSE)

#plotProfile(psum, profile.string="NatM_p_1_Fem_GP_1", profile.label="Natural mortality (M)", plot=T, print=F, plotdir=".",exact=T)
#plotProfile(psum, profile.string="SR_LN(R0)", profile.label="log R0", plot=ifelse(png,F,T), print=ifelse(png,T,F), plotdir=".",exact=T, minfraction=0.005, col=c("black","blue","green4","red","orange"), log=T)

## PinerPlot -- input 'component' needs to be one of the following:
##   Init_equ_like,  Surv_like, Surv_N_use, Surv_N_skip, Age_like, Age_N_use, Age_N_skip
component = "Surv_like" #"Age_like" #   ## only two components that seem to work
main = paste0("Changes in ",sub("age","age-composition",sub("surv","survey",sub("like","likelihoods",sub("_"," ",tolower(component)))))," by fleet")
expandGraph()
PinerPlot(psum, component=component, main=main, plot=ifelse(png,F,T), print=ifelse(png,T,F), plotdir=".", res=400, pwidth=8, pheight=6, minfraction = 0.005)

