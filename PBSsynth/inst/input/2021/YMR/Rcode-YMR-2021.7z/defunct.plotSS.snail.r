## plotSS.snail-------------------------2021-03-29
## Plot snail-trail plots for MCMC analysis.
##  AME: replacing "2010" with as.character(currYear - 1)
##  RH: added assYrs = years past with estimated Bcurr
##      from previous assessment(s), e.g., 5ABC QCS c(2011, 2017)
## -----------------------------------------AME/RH
plotSS.snail=function (BoverBmsy, UoverUmsy, yrs=1935:2020,
   p=c(0.05,0.95), xLim=NULL, yLim=NULL, Lwd=1.5, ngear=1,
   currYear=2020, assYrs=NULL, outs=FALSE, Cnames,                    ## outs = outliers
   ptypes="win", pngres=400, PIN=c(8,6), outnam, lang="e")
{
	## Cnames: names of commercial gear
	if (missing(Cnames))
		Cnames  = tcall("PBSawatea")$Cnames
	if (is.null(Cnames))
		Cnames = "Some fishery"
	## BU -- B = spawning biomass, U = harvest rate (or exploitation rate)
	BUlist = as.list(0:ngear); names(BUlist)=c("Spawning Biomass",Cnames[1:ngear])
	#BUlist[[1]] = BoverBmsy[,-length(BoverBmsy)]
	colnames(BoverBmsy) = sub("^.+_","",colnames(BoverBmsy))
	colnames(UoverUmsy) = sub("^.+_","",colnames(UoverUmsy))
	## previous conversation with PJS: we both agree that B2021/Bmsy should be paired with u2020/Umsy
	BUlist[[1]] = BoverBmsy[,colnames(BoverBmsy) %in% c(yrs,yrs[length(yrs)]+1)][,-1]
	BUlist[[2]] = UoverUmsy[,colnames(UoverUmsy) %in% yrs]

	## Will have to wait until there are >1 fisheries to see how SS reports them
	#for (g in 1:ngear) {
	#	if (any(grepl("_",names(UoverUmsy)))) {
	#		gfile = UoverUmsy[,grep(paste0("_",g),names(UoverUmsy))]
	#		names(gfile) = substring(names(gfile),1,4)
	#	} else if (is.list(UoverUmsy)) {
	#		gfile = UoverUmsy[[g]]
	#	} else {
	#		gfile = UoverUmsy
	#	}
	#	BUlist[[g+1]] = gfile
	#}

	## Calculate medians to be plotted
	BUmed    = sapply(BUlist,function(x){apply(x,2,median)},simplify=FALSE)  # median each year
	colPal   = colorRampPalette(c("grey95", "grey30"))
	colSlime = rep(c("slategray2","thistle2"),ngear)[1:ngear]  ## RH 200528
	colStart = rep(c("green","yellowgreen"),ngear)[1:ngear]
	colStop  = rep(c("cyan","thistle"),ngear)[1:ngear]  #,"cyan"
	colLim   = rep(c("blue2","purple"),ngear)[1:ngear]
	colAss   = rep(c("gold","orange"),ngear)[1:ngear]

	nB = length(BUmed[[1]])
	if (is.null(xLim))
		xLim=c(0, max(c(BUmed[[1]], rev(apply(BUlist[[1]],2,quantile,ifelse(outs,1,p[2])))[1], 1)))
	if (is.null(yLim)) {
		yUps = sapply(BUlist[(1:ngear)+1],function(x,p){apply(x,2,quantile,p)},p=ifelse(outs,1,p[2]))  ##(RH 200624)
		yLim=c(0, max(c(sapply(BUmed[(1:ngear)+1],max), max(yUps[nrow(yUps),]), 1)))                   ##(RH 200624)
	}
#browser();return()
	P = list(p=p)
	if (outs)
		P = list (o=c(0,1), p=p)

	fout = fout.e = outnam
	for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
		createFdir(lang, dir=".")
		changeLangOpts(L=l)
		fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
		if ("eps" %in% ptypes){
			clearFiles(paste0(fout,".eps"))
			postscript(paste0(fout,".eps"), width=PIN[1], height=PIN[2], horizontal=FALSE, paper="special")
		} else if ("png" %in% ptypes){
			clearFiles(paste0(fout,".png"))
			png(paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
		} else if ("wmf" %in% ptypes){
			clearFiles(paste0(fout,".wmf"))
			do.call("win.metafile", list(filename=paste0(fout,".wmf"), width=PIN[1], height=PIN[2]))
		}
		expandGraph(mfrow=c(1,1), mar= c(3.5,3.5,1,1), mgp=c(2,0.5,0))

		plot(0,0, xlim=xLim, ylim=yLim, type="n", 
			xlab = switch(l, 'e'=expression(paste(italic(B[t])/italic(B)[MSY])),   'f'=expression(paste(italic(B[t])/italic(B)[RMS])) ),
			ylab = switch(l, 'e'=expression(paste(italic(u[t-1])/italic(u)[MSY])), 'f'=expression(paste(italic(u[t-1])/italic(u)[RMS])) ),
			cex.lab=1.25, cex.axis=1.0, las=1)
		abline(h=1, col=c("grey20"), lwd=2, lty=3)
		abline(v=c(0.4,0.8), col=c("red","green4"), lwd=2, lty=2)
		for (i in ngear:1) {
#browser();return()
			lines(BUmed[[1]], BUmed[[i+1]], col=colSlime[i], lwd=Lwd)
			points(BUmed[[1]], BUmed[[i+1]], type="p", pch=19, col=colPal(nB))
			points(BUmed[[1]][1], BUmed[[i+1]][1], pch=21, col=1, bg=colStart[i], cex=1.2)
		}
		## Use three loops to plot the trace, end-year line segments, end-year points (RH 200624)
		for (i in ngear:1) {
			xend = rev(BUmed[[1]])[1]
			yend = rev(BUmed[[i+1]])[1]
			xoff = ifelse(as.logical(i%%2),-1,1) * diff(par()$usr[1:2])*0.0015 ## shift final xpos +/- some small amount (RH 200624)
			for (j in 1:length(P)) {
				q = P[[j]]
				lty = ifelse(j==1 && outs, 3, 1)
				lwd = ifelse(j==1 && outs, 1, 2)
				## Plot horizontal (BtB0) quantile range
	#browser();return()
				xqlo = quantile(BUlist[[1]][,as.character(currYear)],q[1])
				xqhi = quantile(BUlist[[1]][,as.character(currYear)], q[2])
				segments(xqlo, yend, xqhi, yend, col=lucent(colLim[i],0.5), lty=lty, lwd=lwd)
				## Plot vertical (UtU0) quantile range
				yqlo = quantile(BUlist[[i+1]][, as.character(currYear-1)], q[1])
				yqhi = quantile(BUlist[[i+1]][, as.character(currYear-1)], q[2])
				segments(xend+xoff, yqlo, xend+xoff, yqhi, col=lucent(colLim[i],0.5), lty=lty, lwd=lwd)
			}
		}
		for (i in ngear:1) {
			xend = rev(BUmed[[1]])[1]
			yend = rev(BUmed[[i+1]])[1]
			xoff = ifelse(as.logical(i%%2),-1,1) * diff(par()$usr[1:2])*0.0015 ## shift final xpos +/- some small amount (RH 200624)
			if (!is.null(assYrs))
				points(BUmed[[1]][as.character(assYrs)], BUmed[[i+1]][as.character(assYrs)], pch=21, col=1, bg=colAss[i], cex=1.2)
			points(xend+xoff, yend, pch=21, cex=1.2, col=colLim[i], bg=colStop[i])
		}
		if (ngear>1)  addLegend(0.95, 0.80, legend=linguaFranca(Cnames,l), lty=1, lwd=Lwd, col=colSlime, seg.len=4, xjust=1, bty="n", cex=1)
		box()
		if (any(ptypes %in% c("eps","png","wmf"))) dev.off()
	}; eop()
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~plotSS.snail


#plotSS.snail(BoverBmsy, UoverUmsy, p=tcall(quants3)[c(1,3)], ngear=ngear, Cnames="Trawl Plus", assYrs=assYrs, currYear=2021, ptypes="png", lang=c("e","f"), outnam="snail")


