## Make Base Case Figures (200415)
## -------------------------------
make.base.figs = function(istock, simple.names=TRUE, #, policies, projyear
   useRlow=FALSE, qRlow=0.25, 
   ptypes="png", pngres=400, PIN=c(8,8), 
   redo.panels=FALSE, lang="e")
{
	on.exit(gc(verbose=FALSE))
	unpackList(stock[[istock]][["Controls"]])
	unpackList(compo)
	unpackList(tcall(data.compo.figs))  ## created in Rnw
	createFdir(lang)
#browser();return()
	modYrs     = startYear:currYear
	modYrsChar = as.character(modYrs)

redoFigs=FALSE
if (redoFigs) {
	## Spawning biomass (envelope)
	plotSS.pmcmc(Bt.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(paste("Spawning Biomass ", group("(",italic(B)[italic(t)],")"))), outnam="YMR.compo.Bt", xyType="envelope", ptypes=ptypes, pyrs=proYrs)

	## Spawning biomass relative to that at MSY (envelope)
	plotSS.pmcmc(BtBmsy.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(italic(B)[italic(t)] / italic(B)[MSY]), outnam="YMR.compo.BtBmsy", xyType="envelope", ptypes=ptypes, pyrs=proYrs, LRP=0.4, USR=0.8)

	## Spawning biomass relative to that at B0 (envelope)
	plotSS.pmcmc(BtB0.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(paste("Depletion ", group("(",italic(B)[italic(t)] / italic(B)[0],")"))), outnam="YMR.compo.BtBo", xyType="envelope", ptypes=ptypes, pyrs=proYrs, LRP=0.2, USR=0.4)

	## Exploitation rate (quantile boxes)
	plotSS.pmcmc(ut.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(paste("Exploitation rate ", group("(",italic(u)[italic(t)],")"))), outnam="YMR.compo.ut", ptypes=ptypes, USR=mean(apply(ut.mcmc[,as.character(modYrs)],1,median)))

	## Exploitation rate relative to that at MSY (quantile boxes)
	plotSS.pmcmc(utumsy.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(paste("Exploitation rate relative to MSY ", group("(",italic(u)[italic(t)] / italic(u)[MSY],")"))), outnam="YMR.compo.utumsy", ptypes=ptypes, USR=1)

	## Recruitment (quantile boxes)
	plotSS.pmcmc(Rt.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(paste("Recruitment ", group("(",italic(R)[italic(t)],")"))), outnam="YMR.compo.Rt", ptypes=ptypes, USR=mean(apply(Rt.mcmc[,as.character(modYrs)],1,median)))

	## Recruitment deviations (quantile boxes)
	plotSS.pmcmc(Rtdev.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(paste("Recruitment deviations", group("(",delta~italic(R)[italic(t)],")"))), outnam="YMR.compo.Rt", ptypes=ptypes, USR=0, yLim=c(-2.75,3.5))
}
	## Diagnostics for select parameters
	P.names = colnames(avgPA)
	P.runs  = as.numeric(sapply(strsplit(rownames(avgPA),"\\."),function(x){x[1]}))
	P.run.ord = unique(P.runs)
	P.run.nmc = table(P.runs)[as.character(P.run.ord)]
	P.run.num = rep(1:length(P.run.nmc), P.run.nmc)
	use.run.rwt = is.element(P.runs, P.run.ord) ## default use all runs but a subset might be used for management advice

	## Years for previous stock assessments
	## ------------------------------------
	if (is.element(spp.code,c("BOR"))){
		assYrs = c(2008, 2012)
	} else if (is.element(spp.code,c("WWR"))){
		assYrs = c(2019)
	} else if (is.element(spp.code,c("RSR"))){
		assYrs = c(2010, 2018)
	} else if (is.element(spp.code,c("POP"))){
		if (is.element(area.name,c("5ABC"))){
			assYrs = c(2001, 2010, 2017)
		} else if (is.element(area.name,c("3CD","5DE"))){
			assYrs = c(2012)
		}
	} else if (is.element(spp.code,c("WAP"))){
		assYrs = c(2017)
	} else if (is.element(spp.code,c("SBF"))){
		assYrs = c(2016)
	} else if (is.element(spp.code,c("SGR","SST","YYR"))){
		assYrs = c(2015)
	} else if (is.element(spp.code,c("ARF","RBR","YTR"))){
		assYrs = c(2014)
	} else if (is.element(spp.code,c("ROL","SGR"))){
		assYrs = c(2013)
	} else if (is.element(spp.code,c("YMR"))){
		runlab = paste0("Run ",P.run.ord,".01 (M=", seq(0.04,0.06,0.005),")")
		assYrs = c(2011)
	} else {
		assYrs = NULL
	}

	P.mcmc$N = rep(1:Nbase, each=nrow(P.mcmc)/Nbase)

	## Diagnostics for select parameters
	for (i in c("R_0")){
#next
		ii   = gsub("[_|[:space:]]","",i)
		P.i  = split(P.mcmc[,i], P.mcmc$N)  ## splits by 1:length(run.num) in 'gather.base.case.r' so retains correct order
		P.ii = data.frame(P.i)
		#colnames(P.ii) = paste(ii,paste0("B",names(P.i)),sep="_")
		colnames(P.ii) = paste(ii,paste0("B",names(run.num)),sep="_")  ## RH 200508 (for subsets of B)
#browser();return()

		fout = fout.e = paste0(istock,".base.", ii, ".traces")
		for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
			changeLangOpts(L=l)
			fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
			for (p in ptypes) {
				if (p=="eps") postscript(paste0(fout,".eps"), width=6.25, height=7, horizontal=FALSE,  paper="special")
				else if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
				par(mfrow=c(1,1), mar=c(3,3,0.5,1), oma=c(0,0,0,0), mgp=c(1.75,0.5,0))
				panelTraces(mcmc=P.ii, mpd=P.mpd[,i], xlab="Samples", ylab="Parameter value", cex.axis=1.2, cex.lab=1.5, same.limits=ifelse(i%in%c("R_0"),F,T),lang=l)
				if (p %in% c("eps","png")) dev.off()
			} ## end p (ptypes) loop
		}; eop()
#browser();return()

		fout = fout.e = paste0(istock,".base.", ii, ".chains")
		for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
			changeLangOpts(L=l)
			fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
			for (p in ptypes) {
				if (p=="eps") postscript(paste0(fout,".eps"), width=6.25, height=7, horizontal=FALSE,  paper="special")
				else if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
				par(mfrow=c(1,1), mar=c(3,3,0.5,1), oma=c(0,0,0,0), mgp=c(1.75,0.5,0))  ## mar and oma ignored, fixed in call to `mochaLatte'
				panelChains(mcmc=P.ii, axes=TRUE, pdisc=0, between=list(x=0, y=0), col.trace=c("red","blue","black"), xlab="Parameter Value", ylab="Cumulative Frequency", cex.axis=1.2, cex.lab=1.4, yaxt="n", lang=l)
				if (p %in% c("eps","png")) dev.off()
			} ## end p (ptypes) loop
		}; eop()

		fout = fout.e = paste0(istock,".base.", ii, ".acfs")
		for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
			changeLangOpts(L=l)
			fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
			for (p in ptypes) {
				if (p=="eps") postscript(paste0(fout,".eps"), width=8, height=8, horizontal=FALSE,  paper="special")
				else if (p=="png") png(paste0(fout,".png"), width=PIN[1], height=PIN[2], units="in", res=pngres)
				plotACFs(P.ii, lag.max=60, lang=l)
				if (p %in% c("eps","png")) dev.off()
			} ## end p (ptypes) loop
		}; eop()
	}
#browser();return()

	## Determine policies (catch strategies)
	if (missing(policies) && !exists(policies))
		policies = sapply(policy,function(x){x$onePolicy})
	if (is.null(names(policies))) {
		z = policies>1; names(policies)[z]="CC"; names(policies)[!z]="HR"
	}
	policies  = policies[is.element(names(policies),names(B.pols))]
	pol.old   = policies
	pol.index = sapply(1:length(policies), function(i){ findPV(policies[i], as.numeric(names(B.pols[[names(policies)[i]]]))) })
	pol.avail = sapply(1:length(pol.index), function(i){ as.numeric(names(B.pols[[names(pol.index)[i]]]))[pol.index[i]] })
	names(pol.avail) = names(pol.index)
	policies  = pol.avail  ## needed for PBSawatea functions.
	## Note that policies determined here (based on what's available) may differ from those specified in the control oblect.

	## Determine subset vector for low recruitment events
	if (useRlow) {
		if (spp.code=="BOR")
			Rlow   = R.mcmc[,"2017"] < quantile(R.mcmc[,"2017"], qRlow)
		else {
			R.mean = apply(R.mcmc,1,mean)  ## mean recruitment 1935-2019
			Rlow   = R.mean < quantile(R.mean, qRlow)
		}
	} else {
		Rlow = rep(TRUE,nrow(R.mcmc))
	}
	## Subset vector of chosen runs to use in the base composite
	Ruse  = grepl(paste0(paste0("^",use.run.rwt),collapse="|"),rownames(B.mcmc))
	## Combined subset vector
	Rsub  = Rlow & Ruse

	Ubase = sum(use.num)  ## may be different than Ubase in 'gather.base.case.r' if Rlow subsets low-recruitment samples from posterior

	## Subset vector objects for composite base case (same code as in 'make.base.tabs.r')
	vec.nams = c("B0", "Bcurr", "Bcurr.B0", "MSY", "Bmsy", "LRP", "USR", "Bcurr.Bmsy", "Bmsy.B0", "VBmsy", "Umsy")
	for (v in vec.nams)
		eval(parse(text=paste0(v, " = ", v, "[Rsub]")))
	vec.list = c("VB0", "VBcurr", "VBcurr.VB0", "Ucurr", "Umax", "VBmsy.VB0", "Ucurr.Umsy")
	for (vv in vec.list)
		eval(parse(text = paste0(vv, " = lapply(", vv, ",function(x){ x[Rsub] })")))

	## Subset data.frames for composite base case
	df.nams = c("B.mcmc", "R.mcmc", "P.mcmc", "BoverBmsy")
	for (d in df.nams)
		eval(parse(text=paste0(d, " = ", d, "[Rsub,]")))
	df.list = c("U.mcmc", "VB.mcmc","UoverUmsy")
	for (dd in df.list)
		eval(parse(text = paste0(dd, " = lapply(", dd, ",function(x){ x[Rsub,] })")))

	B.nams = names(B.pols)
	B.pols = lapply(names(B.pols),function(i) { A=B.pols[[i]]; Asub=lapply(names(A),function(j) { AA=A[[j]]; AA[Rsub,] }); names(Asub)=names(A); return(Asub) })
	R.pols = lapply(names(R.pols),function(i) { A=R.pols[[i]]; Asub=lapply(names(A),function(j) { AA=A[[j]]; AA[Rsub,] }); names(Asub)=names(A); return(Asub) })
	U.pols = lapply(names(U.pols),function(i) { A=U.pols[[i]]; Asub=lapply(names(A),function(j) { AA=A[[j]]; AA[Rsub,] }); names(Asub)=names(A); return(Asub) })
	names(B.pols) = names(R.pols) = names(U.pols) = B.nams

	B.proj = lapply(1:length(policies), function(i){ B.pols[[names(policies)[i]]][[as.character(policies[i])]] })
	R.proj = lapply(1:length(policies), function(i){ R.pols[[names(policies)[i]]][[as.character(policies[i])]] })
	U.proj = lapply(1:length(policies), function(i){ U.pols[[names(policies)[i]]][[as.character(policies[i])]] })
	names(B.proj) = names(R.proj) = names(U.proj) = names(policies)

	#Bp = lapply(B.proj, function(x){ x[Rlow,] })
	Bp = B.proj
#browser();return()

	B.q5    = apply(B.mcmc,2,quantile,quants5)
	B.ylim  = c(0, max(B.q5, na.rm=TRUE))
	if (useRlow && spp.code=="BOR")
		B.ylim = c(0,45000)
	B.xval  = .su(as.numeric(c(colnames(B.mcmc),colnames(Bp[[1]]))))
	B.xval  = B.xval[B.xval<=projyear]
	B.xlim  = range(B.xval, na.rm=TRUE)
	B.xcurr = B.xval[1:match(currYear,B.xval)]
	B.xproj = B.xval[match(currYear,B.xval):match(projyear,B.xval)]

#return()

	## Plot base case population trajectory
	polleg = paste0(c("(",paste0(names(policies), "=",policies,collapse=","),")"),collapse="")
	if (simple.names)
		fout = fout.e = paste0(istock,".base.BP.traj",ifelse(useRlow,paste0(".Rlow(q=",pad0(qRlow*100,2),")"),""))  ## istock or prefix
	else
		fout = fout.e = paste0(istock,".base.BP.traj.",ifelse(useRlow,".Rlow",""),polleg,".",projyear)  ## istock or prefix
	for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
		changeLangOpts(L=l)
		fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
		for (p in ptypes) {
			if (p=="png") png(filename=paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
			expandGraph(mfrow=c(1,1), mar=c(3,3.5,0.5,0.5))
			plot(0,0,type="n", xlim=B.xlim, ylim=B.ylim, xlab="", ylab="", xaxt="n")
			abline(h=c(median(LRP[Rlow]),median(USR[Rlow])), col=c("red","green4"), lwd=1, lty=5)
			axis(1, at=intersect(seq(1000,3000,5),eval(parse(text=paste0(round(par()$usr[1:2]),collapse=":")))), labels=FALSE, tcl=-0.1)
			axis(1, at=intersect(seq(1000,3000,10),eval(parse(text=paste0(round(par()$usr[1:2]),collapse=":")))), labels=TRUE, tcl=-0.25)
#browser();return()
			yy = pretty(B.ylim)
			axis(2, at=seq(yy[1], rev(yy)[1], diff(yy)[1]/4), labels=FALSE, tcl=-0.25)
			mtext(linguaFranca("Year",l), side=1, line=1.75, cex=1.5)
			mtext(linguaFranca("Biomass (tonnes)",l), side=2, line=2, cex=1.5)

			x  = B.xcurr
			xx = as.character(x)
			polygon(c(x,rev(x)), c(B.q5[1,xx],rev(B.q5[5,xx])), col=lucent("blue",0.05), border=FALSE)
			lines(x, B.q5[3,xx], lty=1, lwd=3, col="blue")
			lines(c(x,NA,x), c(B.q5[1,xx],NA,B.q5[5,xx]), lty=2, lwd=2, col="blue")
			lines(c(x,NA,x), c(B.q5[2,xx],NA,B.q5[4,xx]), lty=3, lwd=1, col="blue")

			pcol = c("red","purple"); names(pcol)=c("CC","HR")
			for (i in rev(names(policies))){
				if (is.null(Bp[[i]])) next
				Bp.q5 = apply(Bp[[i]],2,quantile,quants5)
				#Bp.q5 = cbind(B.q5[,currYearChar], apply(Bp[[i]],2,quantile,quants5))
				#colnames(Bp.q5) = c(currYearChar,colnames(Bp[[i]]))
				
				x  = B.xproj
				xx = as.character(x)
				polygon(c(x,rev(x)), c(Bp.q5[1,xx],rev(Bp.q5[5,xx])), col=lucent(pcol[i],0.05), border=FALSE)
				lines(x, Bp.q5[3,xx], lty=1, lwd=3, col=pcol[i])
				lines(c(x,NA,x), c(Bp.q5[1,xx],NA,Bp.q5[5,xx]), lty=2, lwd=2, col=pcol[i])
				lines(c(x,NA,x), c(Bp.q5[2,xx],NA,Bp.q5[4,xx]), lty=3, lwd=1, col=pcol[i])
			}
			drawCatch=FALSE
			if (drawCatch) {
			drawBars(as.numeric(rownames(catch)), catch[,"Total"], width=1, fill=lucent("gold",0.5), col="grey")
			if (is.element("CC",names(policies)) && !is.null(Bp[["CC"]]))
				drawBars(currYear:projyear, rep(policies["CC"],length(currYear:projyear)), width=1, fill=lucent(pcol["CC"],0.2), col="grey")
			if (is.element("HR",names(policies)) && !is.null(Bp[["HR"]])){
				catHR  = Bp[["HR"]][as.character(currYear:projyear)] * policies["HR"]
				catHRp = apply(catHR,2,quantile,quants3)
				points(currYear:projyear, catHRp[2,], pch=15, cex=0.3, col=pcol["HR"])
				lines(rep(currYear:projyear,each=3), as.vector(rbind(catHRp[c(1,3),], rep(NA,ncol(catHRp)))), col=lucent(pcol["HR"],0.8), lwd=0.8)
				#drawBars(currYear:projyear, apply(Bp[["HR"]]*policies["HR"],2,median)[as.character(currYear:projyear)], width=1, fill=lucent(pcol["HR"],0.2), col="grey")
			}
			}
			zed = !sapply(Bp,is.null)
			addLegend(0.5, 0.975, lty=rep(1,sum(zed)), col=as.vector(pcol[zed]), seg.len=2, legend=paste0(linguaFranca(names(policies)[zed],l), " = ",policies[zed]), bty="n", cex=1, xjust=1)
			if (p %in% c("eps","png")) dev.off()
		}
	}; eop()
#browser();return()

#ptypes="png"
	fout = fout.e = paste0(istock,".base.RprojOnePolicy")
	for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
		changeLangOpts(L=l)
		fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
		for (p in ptypes) {
			if (p=="eps") postscript(paste0(fout,".eps"), width=6.25, height=5, horizontal=FALSE, paper="special")
			else if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=6.5, height=4)
			par(mfrow=c(1,1), mar=c(3,3,1,1), oma=c(0,0,0,0), mgp=c(1.75,0.5,0))
			Ryrs.reco = intersect(colnames(R.mcmc),modYrsChar)
			Ryrs.proj = intersect(colnames(R.proj[[1]]),as.character(setdiff(currYear:projyear,colnames(R.mcmc))))  ## just use first policy for now
			plt.quantBioBB0(R.mcmc, R.pols[[1]], xyType="quantBox", policy=as.character(policies[1]), delta=0.35, lwd=0.75, xaxis.by=10, yaxis.lab="Recruitment (1000s)", save=FALSE, lang=l) ## *AME* (onePolicy)
			if (p %in% c("eps","png")) dev.off()
		} ## end p (ptypes) loop
	}; eop()
#browser();return()

	## Make MCMC quantile plots similar to those in the central run for
	##      recruitment, exploitation, and vulnerable biomass

	fout = fout.e = paste0(istock,".base.recruitsMCMC")
	for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
		changeLangOpts(L=l)
		fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
		for (p in ptypes) {
			if (p=="eps") postscript(paste0(fout,".eps"), width=6.25, height=4, horizontal=FALSE,  paper="special")
			else if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=6.25, height=4)
			par(mfrow=c(1,1), mar=c(3,3,1,1), oma=c(0,0,0,0), mgp=c(1.75,0.5,0))
			plotRmcmcPOP(R.mcmc[,intersect(colnames(R.mcmc),modYrsChar)], yLim=NULL, lang=l)
			if (p %in% c("eps","png")) dev.off()
		} ## end p (ptypes) loop
	}; eop()
#browser();return()

	fout = fout.e = paste0(istock,".base.exploitMCMC")
	for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
		changeLangOpts(L=l)
		fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
		for (p in ptypes) {
			if (p=="eps") postscript(paste0(fout,".eps"), width=6.25, height=4*Ngear, horizontal=FALSE,  paper="special")
			else if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=6.25, height=4*Ngear)
			par(mfrow=c(Ngear,1), mar=c(3,3,1,1), oma=c(0,0,0,0), mgp=c(1.75,0.5,0))
			for (g in 1:Ngear) {
				gfile = U.mcmc[[g]]
				plotRmcmcPOP(gfile[,intersect(colnames(gfile),modYrsChar)], yLim=NULL, yLab="Exploitation rate", yaxis.by=0.01, lang=l)
				addLabel(0.05,0.90, linguaFranca(names(U.mcmc)[g],l), adj=0, cex=1.2)
			}
			if (p %in% c("eps","png")) dev.off()
		} ## end p (ptypes) loop
	}; eop()
#browser();return()

	fout = fout.e = paste0(istock,".base.VBcatch")
	for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
		changeLangOpts(L=l)
		fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
		for (p in ptypes) {
			if (p=="eps") postscript(paste0(fout,".eps"), width=6.25, height=4.5*Ngear, horizontal=FALSE,  paper="special")
			else if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=6.25, height=4.5*Ngear)
			par(mfrow=c(Ngear,1), mar=c(3,3,1,1), oma=c(0,0,0,0), mgp=c(1.75,0.5,0))
			for (g in 1:Ngear) {
				gfile = VB.mcmc[[g]]
				plotVBcatch(gfile, currentRes, gear=g, yLab=ifelse(Ngear==1, "Catch and vulnerable biomass (t)", paste0("Vulnerable biomass (t) - ", gseries[g])), yLim=c(0, max(sapply(gfile, quantile,tcall(quants5)[5]))), cex.lab=1.25, lang=l)
			}
			if (p %in% c("eps","png")) dev.off()
		} ## end p (ptypes) loop
	}; eop()
#browser();return()

	## Prepare base composite and components for function 'compBmsy' (needs B.proj from policies above)
	Bbase = list()
	L1    = toupper(ifelse(spp.code=="REBS", istock, spp.code))
	Bbase[[L1]] = list()
	ibase  = istock
	Bbase[[L1]][[ibase]] = Bcurr.Bmsy ## composite from multiple bases

#ptypes="png"

	##run.rwts = stock[[istock]]$Base$run.rwts
	for (i in use.run.rwt) {
		iBmcmc = stock[[istock]]$Base[[i]]$Bmcmc
		ii = names(iBmcmc[[toupper(L1)]])
		Bbase[[L1]][[ii]] = iBmcmc[[L1]][[ii]]$BoverBmsy[,currYearChar]
	}

	tget(base.runs.lab)  ## constructed in 'gather.base.case.r'
	base.runs.lab = base.runs.lab[use.num]

	L1nam = ifelse(L1=="BSR","REBS North", ifelse(L1=="RER","REBS South", L1))
	Mnams = c(paste0(L1nam," Composite"), gsub("_| AE=3","",base.runs.lab))
	## Add in projections -- CAUTION: for now, the code is hard-wired to have both CC and HR at year 2
	if (spp.code=="BOR") {
		pY = 2
		Bbase[[L1]][["CC-proj"]] = B.proj[["CC"]][,as.character(currYear+pY)]/Bmsy
		Bbase[[L1]][["HR-proj"]] = B.proj[["HR"]][,as.character(currYear+pY)]/Bmsy
		Mnams = c(Mnams, paste0("Comp.",c("CC ","HR "), pY,"y"))
	}
	N = length(Mnams)

	if (spp.code=="BOR") {
		bord=c(1:N); medcol=c(ifelse(istock==names(stock)[1],"blue","red"),rep("grey30",N-Ubase), rep("gold",2)); 
		boxfill=c(ifelse(istock==names(stock)[1],"aliceblue","mistyrose"), rep("grey95",N-Ubase), rep("lightyellow",2))
	} else {
		bord=c(1:N); medcol=c(ifelse(istock==names(stock)[1],"blue","red"),rep("grey30",Ubase)); 
		boxfill=c(ifelse(istock==names(stock)[1],"aliceblue","mistyrose"), rep("grey95",Ubase))
	}
	boxlim = c(0, max(sapply(Bbase[[L1]],quantile,quants5[5])) )
	boxlim[2] = boxlim[2] + diff(boxlim) * 0.04
#ptypes="png"; scenario=0; so("compBmsy.r")

	if ("win" %in% ptypes) resetGraph()
	par(mfrow=c(1,1), oma=c(0,0,0,0), mgp=c(2,0.5,0))
	mess =  paste0("list(",paste0(paste0(ptypes,"=TRUE"),collapse=","),")")

	out = compBmsy(Bspp=Bbase, spp=L1, boxwidth=0.5, medcol=medcol, boxfill=boxfill, boxlim=boxlim, whisklwd=2, staplelwd=2, Mnams=Mnams[bord], width=9, height=6, figgy=eval(parse(text=mess)), pngres=pngres, spplabs=F, t.yr=2021, left.space=11, top.space=2, fout=paste0(istock,".base", ifelse(Ubase>1,".composite.","."), "status"), calcRat=F, lang=lang)

#return()
#browser();return()


	## Make quantile plots of component-run parameters and quantities
	## Note that these plots seem to take forever when sent to a png file
	if (redo.panels) {
		so("mochaLatte.r","awatea")
		so("panelBoxes.r","awatea")

		#P.pool = stock[[istock]]$Base$Pool$P.mcmc
		P.pool = P.mcmc
		if (class(Ucurr)=="list") {
			Ucurr = sapply(Ucurr,function(x){return(x)})
			Umax  = sapply(Umax,function(x){return(x)})
			if (is.matrix(Ucurr)){
				colnames(Ucurr) = paste0("Ucurr_",substring(colnames(Ucurr),1,5))
				colnames(Umax)  = paste0("Umax_",substring(colnames(Umax),1,5))
			}
		}
#browser();return()
		Q.pool = data.frame(Bcurr, B0, Bcurr.B0, MSY, Bmsy, Bmsy.B0, Ucurr, Umsy, Umax)
		names(Q.pool) = sub("\\.", " / ", gsub("U","u", 
			gsub("Ucurr",paste0("U",prevYear), 
			gsub("Bcurr",paste0("B",currYear), names(Q.pool)))))

		if (spp.code %in% c("WWR")){
			nchains = 9; ngroups = nchains/3
			boxfill = paste0(rep(c("cyan","green","coral"),each=ngroups), rep(1:ngroups,3)) 
		}
		if (spp.code %in% c("BOR")){
			nchains = 3; ngroups = nchains/3
			boxfill = paste0(rep(c("cyan","green","salmon"),each=ngroups), rep(1:ngroups,3)) 
		}
		if (spp.code %in% c("REBS")){
			if (istock %in% c("BSR","RER")) {
				#nchains = 9; ngroups = nchains/3
				#boxfill = paste0(rep(c("cyan","green","coral"),each=ngroups), rep(1:ngroups,3)) 
				nchains = Ubase; ngroups = ceiling(as.numeric(names(run.num)[use.num])/3)    ## RH 200508 (for subsets of B)
				colrnum = as.vector(unlist(sapply(split(ngroups,ngroups), function(x){1:length(x)})))
				boxfill = paste0(c("cyan","green","coral")[ngroups], colrnum ) 
			}
		}
		xlim = range(1:nchains)+c(-0.75,0.75)

		fout = fout.e = paste0(istock,".base.pars.qbox")
		for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
			changeLangOpts(L=l)
			fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
			for (p in ptypes) {
				if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=8, height=9)
				pflds  = setdiff(colnames(P.pool), "N")
				#pflds  = c("q_6",pflds)
				panelBoxes(P.pool[,pflds], nchains=nchains, xlab=linguaFranca("Base Runs",l), ylab=linguaFranca("Parameter estimates",l), cex.strip=1.2, cex.axis=1.1, cex.lab=1.5, outline=FALSE, xlim=xlim, boxfill=boxfill, xfac=paste0("B",names(run.num[use.num])))  ## RH 200508 (for subsets of B)
				if (p %in% c("png","eps")) dev.off()
			}
		}; eop()
#browser();return()

		fout = fout.e = paste0(istock,".base.rfpt.qbox")
		for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
			changeLangOpts(L=l)
			fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
			for (p in ptypes) {
				if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=8, height=8)
				panelBoxes(Q.pool, nchains=nchains, xlab=linguaFranca("Base Runs",l), ylab=linguaFranca("Derived Quantities",l), cex.strip=1.2, cex.axis=1.1, cex.lab=1.5, outline=FALSE, xlim=xlim, boxfill=boxfill, xfac=paste0("B",names(run.num[use.num])))  ## RH 200508 (for subsets of B)
				if (p %in% c("png","eps")) dev.off()
			}
		}; eop()
	}
#browser();return()

	## assYrs in run-masterMCMC.Snw
	## ----------------------------
	if (is.element(spp.code,c("BOR"))){
		assYrs = c(2008, 2012)
	} else if (is.element(spp.code,c("WWR"))){
		assYrs = c(2019)
	} else if (is.element(spp.code,c("RSR"))){
		assYrs = c(2010, 2018)
	} else if (is.element(spp.code,c("POP"))){
		if (is.element(area.name,c("5ABC"))){
			assYrs = c(2001, 2010, 2017)
		} else if (is.element(area.name,c("3CD","5DE"))){
			assYrs = c(2012)
		}
	} else if (is.element(spp.code,c("WAP"))){
		assYrs = c(2017)
	} else if (is.element(spp.code,c("SBF"))){
		assYrs = c(2016)
	} else if (is.element(spp.code,c("SGR","SST","YYR"))){
		assYrs = c(2015)
	} else if (is.element(spp.code,c("ARF","RBR","YTR"))){
		assYrs = c(2014)
	} else if (is.element(spp.code,c("ROL","SGR"))){
		assYrs = c(2013)
	} else if (is.element(spp.code,c("YMR"))){
		assYrs = c(2011)
	} else {
		assYrs = NULL
	}

	## BtBmsy UtUmsy snail trail
	fout = fout.e = paste0(istock,".base.snail")
	for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
		changeLangOpts(L=l)
		fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
		for (p in ptypes) {
			if (p=="eps") postscript(paste0(fout,".eps"), width=6.25, height=5, horizontal=FALSE, paper="special")
			else if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2]*0.75)
			par(mfrow=c(1,1), mar=c(3,3.75,0.5,1), oma=c(0,0,0,0), mgp=c(2,0.5,0))
			## see 'assYrs' in run-masterMCMC.Snw
			plotSnail(BoverBmsy, UoverUmsy, p=quants3[c(1,3)], xLim=NULL, yLim=NULL, ngear=Ngear, currYear=currYear, assYrs=assYrs, outs=F, Cnames=gseries, lang=l)
			if (p %in% c("eps","png")) dev.off()
		} ## end p (ptypes) loop
	}; eop()
#browser();return()

	## Prepare stock base composites for function 'compBmsy'
	## If comparing two stocks (e.g., RSR,POP)
	if (length(stock)>2) { ## disable for now (fix later)
		if (istock==names(stock)[1]){
			Bstock = list()
			Bstock[[toupper(spp.code)]] = list()
		}
		ibase  = istock
		Bstock[[1]][[ibase]] = Bcurr.Bmsy ## composite from multiple bases
		tput(Bstock)
		## May have more than on stock so need to save Bstock somewhere for retrieval later
		if (istock==rev(names(stock))[1]) {
			tget(Bstock)
			Mnams = paste0(spp.code,"\n",sapply(stock,function(x){x$area.name}))
			N = length(Mnams)
			bord=c(1:N); medcol=c("blue","red")[1:N]; boxfill=c("aliceblue","mistyrose")[1:N] ## will need more if Nstock>2
			if ("win" %in% ptypes) resetGraph()
			mess =  paste0("list(",paste0(paste0(ptypes,"=TRUE"),collapse=","),")")
			out = compBmsy(Bspp=Bstock, spp=c(spp.code), boxwidth=0.5, medcol=medcol, boxfill=boxfill, whisklwd=2, staplelwd=2, Mnams=Mnams[bord], width=9, height=4, figgy=eval(parse(text=mess)), pngre=pngres, spplabs=F, t.yr=currYear, left.space=6, top.space=1, fout=paste0(spp.code,".base", ifelse(Ubase>1,".composite.","."), "status"), calcRat=F, lang=lang)
		}
	}
#browser();return()
return()
}

## Activate for debugging only:
#make.base.figs(pool=stock[[istock]]$Base$Pool, catpol=2000, ptypes="win",lang=c("e"),redo.panels=T)
#make.base.figs(pool=stock[[istock]]$Base$Pool, catpol=2000, ptypes="png",lang=c("e","f"),redo.panels=T)
#for (q in seq(0.05,0.25,0.05))
#	make.base.figs(istock, projyear=2080, ptypes="png", lang=c("e"), redo.panels=T, policies=c(200), simple.names=T,useRlow=T,qRlow=q)
#so("linguaFranca.r")
#make.base.figs(istock, projyear=2080, ptypes="png",lang=c("f"),redo.panels=T, policies=c(200), simple.names=F, useRlow=F)
#make.base.figs(istock, projyear=2080, ptypes="png", lang=c("f"), redo.panels=T, policies=c(200,0.04), simple.names=T)
## BSR
#make.base.figs(istock, projyear=2096, ptypes="png", lang=c("e"), redo.panels=T, policies=c(switch(istock,'BSR'=600,'RER'=300),0.10), simple.names=T)
#make.base.figs(istock, projyear=2096, ptypes="png", lang=c("e","f"), redo.panels=T, simple.names=T)
make.base.figs(istock, ptypes="win",lang="e") #, projyear=2096, ptypes="png", lang=c("e","f"), redo.panels=T, simple.names=T)
