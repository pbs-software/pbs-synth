## plotSS.rdevs-------------------------2021-04-01
##  Plot reruitment deviations
## ----------------------------------------r4ss|RH
plotSS.rdevs = function (replist, subplots=1:3, plot=TRUE, print=FALSE, 
   add=FALSE, uncertainty=TRUE, minyr=-Inf, maxyr=Inf, 
   forecastplot=FALSE, col1="black", col2="blue", col3="green3", 
   col4="red", legendloc="topleft", labels=c("Year", "Asymptotic standard error estimate", 
   "Log recruitment deviation", "Bias adjustment fraction, 1 - stddev^2 / sigmaR^2"), 
   pwidth=8, pheight=6, punits="in", res=400, ptsize=10, 
   cex.main=1, plotdir="default", verbose=TRUE, outnam, lang="e") 
{
	oldpar = par(no.readonly=TRUE)
	fart = function(opar) { if (any("windows"%in%names(dev.list()))) par(opar); eop() }
	on.exit(fart(oldpar))
	changeLangOpts(L=lang)
	if (missing(outnam))
		outnam = NULL
	ttput(outnam)

	pngfun <- function(file, caption=NA, lang="e") {
		createFdir(lang, dir=plotdir)
		changeLangOpts(L=lang)
		fout = switch(lang, 'e' = file.path(plotdir, file), 'f' = file.path(plotdir,"french", file) )
		clearFiles(fout)
		png(filename=fout, width=pwidth, height=pheight, units=punits, res=res, pointsize=ptsize)
		plotinfo <- rbind(plotinfo, data.frame(file=file, caption=caption))
		return(plotinfo)
	}
	plotinfo <- NULL
	if (plotdir == "default") 
		plotdir <- replist$inputs$dir
	parameters <- replist$parameters
	recruit <- replist$recruit
	startyr <- replist$startyr
	endyr <- replist$endyr
	sigma_R_in <- replist$sigma_R_in
	recdevEarly <- parameters[substring(parameters$Label, 1, 13) %in% c("Early_RecrDev"), ]
	early_initage <- parameters[substring(parameters$Label, 1, 13) %in% c("Early_InitAge"), ]
	main_initage <- parameters[substring(parameters$Label, 1, 12) %in% c("Main_InitAge"), ]
	recdev <- parameters[substring(parameters$Label, 1, 12) %in% c("Main_RecrDev"), ]
	recdevFore <- parameters[substring(parameters$Label, 1, 8) == "ForeRecr", ]
	recdevLate <- parameters[substring(parameters$Label, 1, 12) == "Late_RecrDev", ]
	if (nrow(recdev) == 0 || max(recdev$Value) == 0) {
		if (verbose) 
			cat("Skipped SSplotrecdevs - no rec devs estimated\n")
	}
	else {
		if (nrow(recdev) > 0) {
			recdev$Yr <- as.numeric(substring(recdev$Label, 14))
			if (nrow(recdevEarly) > 0) {
				recdevEarly$Yr <- as.numeric(substring(recdevEarly$Label, 15))
			}
			else {
				recdevEarly$Yr <- integer(0)
			}
			if (nrow(early_initage) > 0) {
				early_initage$Yr <- startyr - as.numeric(substring(early_initage$Label, 15))
				recdevEarly <- rbind(early_initage, recdevEarly)
			}
			if (nrow(main_initage) > 0) {
				main_initage$Yr <- startyr - as.numeric(substring(main_initage$Label, 14))
				recdev <- rbind(main_initage, recdev)
			}
			if (nrow(recdevFore) > 0) {
				recdevFore$Yr <- as.numeric(substring(recdevFore$Label, 10))
			}
			else {
				recdevFore$Yr <- NULL
			}
			if (nrow(recdevLate) > 0) {
				recdevLate$Yr <- as.numeric(substring(recdevLate$Label, 14))
				recdevFore <- rbind(recdevLate, recdevFore)
			}
			Yr <- c(recdevEarly$Yr, recdev$Yr, recdevFore$Yr)
			if (forecastplot) {
				goodyrs <- ifelse(Yr >= minyr & Yr <= maxyr, TRUE, FALSE)
			}
			else {
				goodyrs <- Yr <= endyr + 1 & Yr >= minyr & Yr <= maxyr
			}
			xlim <- range(Yr[goodyrs], na.rm=TRUE)
			ylim <- range(c(recdevEarly$Value, recdev$Value, 
				recdevFore$Value)[goodyrs], na.rm=TRUE)
			recdevfunc <- function(uncertainty, l="e") {
				alldevs <- rbind(recdevEarly, recdev, recdevFore)[goodyrs,]
				colvec <- c(rep(col2, nrow(recdevEarly)), rep(col1,nrow(recdev)), rep(col2, nrow(recdevFore)))[goodyrs]
				val <- alldevs$Value
				Yr <- alldevs$Yr
				if (uncertainty) {
					std <- alldevs$Parm_StDev
					recdev_hi <- val + 1.96 * std
					recdev_lo <- val - 1.96 * std
					ylim <- range(recdev_hi, recdev_lo, na.rm=TRUE)
				}
				else {
					ylim <- range(val, na.rm=TRUE)
				}
				expandGraph(mfrow=c(1,1), mar=c(3.5,3.5,1,1), oma=c(0,0,0,0), mgp=c(2,0.5,0))
				plot(Yr, Yr, type="n", xlab=linguaFranca(labels[1],l), ylab=linguaFranca(labels[3],l), ylim=ylim, cex.axis=1.2, cex.lab=1.5)
				abline(h=0, col="grey")
				if (uncertainty)
					arrows(Yr, recdev_lo, Yr, recdev_hi, length=0.03, code=3, angle=90, lwd=1.2, col=colvec)
				lines(Yr, val, lty=3)
				points(Yr, val, pch=16, col=colvec)
				R0  = replist$parameters[grep("R0",rownames(replist$parameters)),"Value"]
				R0a = show0(round(R0,3),3)
				R0b = formatC(exp(R0),format="d",big.mark=switch(l,'e'=",",'f'=" "))
				addLabel(0.98,0.96,bquote(LN~italic(R)[0]== .(R0a)), cex=1, adj=c(1,0), col="blue")
				addLabel(0.98,0.93,bquote(italic(R)[0]== .(R0b)), cex=1, adj=c(1,0), col="blue")
				recdevs =  alldevs[,c("Yr","Value","Parm_StDev")]
				ttput(recdevs)
#browser();return()
			} ## end recdevfun
			if (uncertainty) {
				recdevfunc3 <- function(l="e") {
					#par(mar=par("mar")[c(1:3, 2)])
					ymax <- 1.1 * max(recdev$Parm_StDev, recdevEarly$Parm_StDev, recdevFore$Parm_StDev, sigma_R_in, na.rm=TRUE)
					expandGraph(mfrow=c(1,1), mar=c(3.5,3.5,2,1), oma=c(0,0,0,0), mgp=c(2,0.5,0))
					plot(recdev$Yr, recdev$Parm_StDev, xlab=linguaFranca(labels[1],l), main=linguaFranca("Recruitment deviation variance",l), cex.main=cex.main, ylab=linguaFranca(labels[2],l), xlim=xlim, ylim=c(0, ymax), type="b")
					if (nrow(recdevEarly) > 0)
						lines(recdevEarly$Yr, recdevEarly$Parm_StDev, type="b", col=col2)
					if (forecastplot & nrow(recdevFore) > 0)
						lines(recdevFore$Yr, recdevFore$Parm_StDev, type="b", col=col2)
					abline(h=0, col="grey")
					abline(h=sigma_R_in, col=col4)
				}
			}
			if (plot) {
				if (1 %in% subplots) 
					recdevfunc(uncertainty=FALSE, l=lang)
				if (uncertainty) {
					if (2 %in% subplots) 
						recdevfunc(uncertainty=TRUE, l=lang)
					if (3 %in% subplots) 
						recdevfunc3(l=lang)
				}
			}
			if (print) {
				if (1 %in% subplots) {
					if (!is.null(ttcall(outnam)))
						file = paste0(sub("\\.png$","",outnam), ".png")
					else
						file <- "recdevs1_points.png"
					caption <- "Recruitment deviations"
					plotinfo <- pngfun(file=file, caption=caption, lang=lang)
					recdevfunc(uncertainty=FALSE, l=lang)
					dev.off(); eop()
				}
				if (uncertainty) {
					if (2 %in% subplots) {
						if (!is.null(ttcall(outnam)))
							file = paste0(sub("\\.png$","",outnam), ".png")
						else
							file <- "recdevs2_withbars.png"
						caption <- "Recruitment deviations with 95% intervals"
						plotinfo <- pngfun(file=file, caption=caption, lang=lang)
						recdevfunc(uncertainty=TRUE, l=lang)
						dev.off(); eop()
					}
					if (3 %in% subplots) {
						if (!is.null(ttcall(outnam)))
							file = paste0(sub("\\.png$","",outnam), ".png")
						else
							file <- "recdevs3_varcheck.png"
						caption <- paste("Recruitment deviations variance check.<br>", 
						"See later figure of transformed variance values for comparison", 
						"with bias adjustment settings in the model.")
						plotinfo <- pngfun(file=file, caption=caption, lang=lang)
						recdevfunc3(l=lang)
						dev.off(); eop()
					}
				}
			}
		}
	}
	if (!is.null(plotinfo)) 
		plotinfo$category <- "RecDev"
	return(invisible(plotinfo))
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~plotSS.rdevs

#so("linguaFranca.r")
#plotSS.rdevs(replist, subplot=1, plot=F, print=F, plotdir=getwd(), outnam="recDev", lang="e")
