## Make Composite Figures (210728)
## ---------------------------------
plotSS.compo = function(compo, spp.code="YMR", istock="YMR", 
   subset=NULL, redo.figs=FALSE, redo.panels=FALSE, 
   ptypes, lang, pngres=400, PIN=c(9,9))
{
	on.exit(gc(verbose=FALSE))
	unpackList(stock[[istock]][["Controls"]])
	unpackList(compo)
	unpackList(tcall(data.compo.figs))  ## created in Rnw
	createFdir(lang)

	modYrsChar  = as.character(modYrs)
	## Diagnostics for select parameters
	P.names     = colnames(avgPA)
	P.runs      = as.numeric(sapply(strsplit(rownames(avgPA),"\\."),function(x){x[1]}))
	P.run.ord   = unique(P.runs)
	P.run.nmc   = table(P.runs)[as.character(P.run.ord)]
	P.run.num   = rep(1:length(P.run.nmc), P.run.nmc)
	use.run.rwt = is.element(P.runs, P.run.ord) ## default use all runs but a subset might be used for management advice

#redoFigs=FALSE
#if (redoFigs) {

	## Need to source code from 2021 (for redoing stupid french figures: 221013)
	d.ymr = "C:/Users/haighr/Files/Projects/R/Develop/PBSsynth/Authors/Rcode/develop/YMR2021"
	source(file.path(d.ymr,"plotSS.pmcmc.r"))

	## Spawning biomass (envelope)
	#.flush.cat("SB envelope","\n")
	#catpol = avgPJ[,,"Bt",c("CC.01","CC.05","CC.08")]  ## YMR RPR wanted to see projections using catches of (0,1250,2500)
	#plotSS.pmcmc(Bt.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(paste("Spawning Biomass ", group("(",italic(B)[italic(t)],")"))), outnam=paste0(prefix,"compo.Bt"), xyType="envelope", ptypes=ptypes, pyrs=proYrs, catpol=catpol)

	## Spawning biomass relative to that at MSY (envelope)
	.flush.cat("BtBmsy envelope","\n")
	catpol = avgPJ[,,"BtBmsy",c("CC.01","CC.05","CC.08")]  ## YMR RPR wanted to see projections using catches of (0,1250,2500)
	plotSS.pmcmc(BtBmsy.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(italic(B)[italic(t)] / italic(B)[MSY]), outnam=paste0(prefix,"compo.BtBmsy"), xyType="envelope", ptypes=ptypes, pyrs=proYrs, LRP=0.4, USR=0.8, catpol=catpol)

	## Spawning biomass relative to that at B0 (envelope)
	#.flush.cat("BtB0 envelope","\n")
	#catpol = avgPJ[,,"BtB0",c("CC.01","CC.05","CC.08")]  ## YMR RPR wanted to see projections using catches of (0,1250,2500)
	#plotSS.pmcmc(BtB0.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(paste("Depletion ", group("(",italic(B)[italic(t)] / italic(B)[0],")"))), #outnam=paste0(prefix,"compo.BtB0"), xyType="envelope", ptypes=ptypes, pyrs=proYrs, LRP=0.2, USR=0.4, catpol=catpol)

	## Exploitation rate (quantile boxes)
	#.flush.cat("ut boxes","\n")
	#plotSS.pmcmc(ut.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(paste("Exploitation rate ", group("(",italic(u)[italic(t)],")"))), #outnam=paste0(prefix,"compo.ut"), ptypes=ptypes, USR=NULL) #mean(apply(ut.mcmc[,as.character(modYrs)],1,median)))

	## Recruitment (quantile boxes)
	#.flush.cat("Rt boxes","\n")
	#plotSS.pmcmc(Rt.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(paste("Recruitment ", group("(",italic(R)[italic(t)],")"))), #outnam=paste0(prefix,"compo.Rt"), ptypes=ptypes, pyrs=proYrs, USR=NULL) ##mean(apply(Rt.mcmc[,as.character(modYrs)],1,median)))

	## Exploitation rate relative to that at MSY (quantile boxes)
	.flush.cat("utumsy boxes","\n")
	plotSS.pmcmc(utumsy.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(paste("Exploitation rate relative to ", italic(u)[MSY], "  ", group("(",italic(u)[italic(t)] / italic(u)[MSY],")"))), outnam=paste0(prefix,"compo.utumsy"), ptypes=ptypes, USR=1)
#browser();return()

	## Recruitment deviations (quantile boxes)
	#.flush.cat("Rtdev boxes","\n")
	#plotSS.pmcmc(Rtdev.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(paste("Recruitment deviations", group("(",delta~italic(R)[italic(t)],")"))), outnam=paste0(prefix,"compo.Rtdev"), ptypes=ptypes, USR=0, yLim=c(-2.75,3.5))
#browser();return()

	## BtBmsy UtUmsy snail trail plot
	## ------------------------------
	z = use.run.rwt
	BoverBmsy = avgTS[z,,"BtBmsy"]
	UoverUmsy = avgTS[z,,"utumsy"]
	outnam    = paste0(prefix,"compo.snail")
	plotSnail(BoverBmsy, UoverUmsy, yrs=modYrs, p=tcall(quants3)[c(1,3)], xLim=NULL, yLim=NULL, ngear=length(gseries), assYrs=assYrs, outs=F, Cnames="Trawl+", ptypes=ptypes, outnam=outnam, lang=lang)

#browser();return()

sumting=F
if (sumting) {

	## Plot MCMC diagnostics select parameters for each component run
	## --------------------------------------------------------------
	for (i in c(1)){
		ii   = P.names[i]
		iii  = gsub("[_|[:space:]]","",ii)
		P.i  = split(avgPA[,i], P.runs)[as.character(P.run.ord)]
		  ## splits by 1:length(run.num) in 'gather.compo.case.r' so retains correct order
		P.ii = data.frame(P.i)
		#colnames(P.ii) = paste(iii,paste0("R",names(P.i)),sep="_")
		#colnames(P.ii) = paste(ii,paste0("B",names(run.num)),sep="_")  ## RH 200508 (for subsets of B)

		## Trace plots
		fout = fout.e = paste0(prefix,"compo.", iii, ".traces")
		for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
			changeLangOpts(L=l)
			fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
			for (p in ptypes) {
				if (p=="eps") postscript(paste0(fout,".eps"), width=6.25, height=7, horizontal=FALSE,  paper="special")
				else if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
				par(mfrow=c(1,1), mar=c(3,3,0.5,1), oma=c(0,0,0,0), mgp=c(1.75,0.5,0))
				#colnames(P.ii) = paste(iii,paste0(switch(l, 'e'="R",'f'="E"),names(P.i)),sep="_")
				colnames(P.ii) = paste(iii,base.lab,sep=" ")
				panelTraces(mcmc=P.ii, mpd=ampdPA[,i], xlab="Samples", ylab="Parameter value", cex.axis=1.2, cex.lab=1.5, same.limits=ifelse(i%in%c(1),F,T),lang=l)
				if (p %in% c("eps","png")) dev.off()
			} ## end p (ptypes) loop
		}; eop()
#browser();return()

		## Split chains
		fout = fout.e = paste0(prefix,"compo.", ii, ".chains")
		for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
			changeLangOpts(L=l)
			fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
			for (p in ptypes) {
				if (p=="eps") postscript(paste0(fout,".eps"), width=6.25, height=7, horizontal=FALSE,  paper="special")
				else if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
				par(mfrow=c(1,1), mar=c(3,3,0.5,1), oma=c(0,0,0,0), mgp=c(1.75,0.5,0))  ## mar and oma ignored, fixed in call to `mochaLatte'
				panelChains(mcmc=P.ii, axes=TRUE, pdisc=0, between=list(x=0, y=0), col.trace=c("red","blue","black"), xlab="Parameter Value", ylab="Cumulative Frequency", cex.axis=1.2, cex.lab=1.4, yaxt="n", lang=l)
				if (p %in% c("eps","png")) dev.off()
			} ## end p (ptypes) loop
		}; eop()
#browser();return()

		## ACF plots
		fout = fout.e = paste0(prefix,"compo.", ii, ".acfs")
		for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
			changeLangOpts(L=l)
			fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
			for (p in ptypes) {
				if (p=="eps") postscript(paste0(fout,".eps"), width=8, height=8, horizontal=FALSE,  paper="special")
				else if (p=="png") png(paste0(fout,".png"), width=PIN[1], height=PIN[2], units="in", res=pngres)
				plotACFs(P.ii, lag.max=60, lang=l)
				if (p %in% c("eps","png")) dev.off()
			} ## end p (ptypes) loop
		}; eop()
	}

} ## end sumting

	## Prepare base composite and components for function 'compBmsy'
	## ------------------------------------------------------------
	Bbase = list()
	L1    = toupper(ifelse(spp.code=="REBS", istock, spp.code))
	Bbase[[L1]] = list()
	ibase  = toupper(istock)

	z  = use.run.rwt
	zz = sapply(split(z,P.runs),unique)[as.character(P.run.ord)]
	Ubase = sum(zz)
	runlab = base.lab[zz]

	Btemp = data.frame(run=P.runs, BcurrBmsy=avgTS[,as.character(currYear),"BtBmsy"])[z,]
	Bcurr.Bmsy = Btemp[,"BcurrBmsy"]
	Bbase[[L1]][[ibase]] = Bcurr.Bmsy ## composite from multiple bases
	for (i in 1:length(P.run.ord[zz])) {
		ii = P.run.ord[i]
		if (!is.element(ii, Btemp$run)) next
		iBtemp = Btemp[is.element(Btemp$run,ii),]
		iii = runlab[i]
		Bbase[[L1]][[paste0("R",ii)]] = iBtemp$BcurrBmsy
	}

	L1nam = ifelse(L1=="BSR","REBS North", ifelse(L1=="RER","REBS South", L1))
	#Mnams = c(paste0(L1nam," Composite"), gsub("_| AE=3","",base.runs.lab))
	Mnams = c(paste0(L1nam," Composite"), runlab)
	## Add in projections -- CAUTION: for now, the code is hard-wired to have both CC and HR at year 2
	if (spp.code=="BOR") {
		pY = 2
		Bbase[[L1]][["CC-proj"]] = B.proj[["CC"]][,as.character(currYear+pY)]/Bmsy
		Bbase[[L1]][["HR-proj"]] = B.proj[["HR"]][,as.character(currYear+pY)]/Bmsy
		Mnams = c(Mnams, paste0("Comp.",c("CC ","HR "), pY,"y"))
	}
	N = length(Mnams)

	if (spp.code=="BOR") {
		bord=c(1:N); medcol=c(ifelse(istock==names(stock)[1],"blue","red"),rep("grey30",N-Ubase), rep("gold",2)); 
		boxfill=c(ifelse(istock==names(stock)[1],"aliceblue","mistyrose"), rep("grey95",N-Ubase), rep("lightyellow",2))
	} else {
		bord=c(1:N); medcol=c(ifelse(istock==names(stock)[1],"blue","red"),rep("grey30",Ubase)); 
		boxfill=c(ifelse(istock==names(stock)[1],"aliceblue","mistyrose"), rep("grey95",Ubase))
	}
	boxlim = c(0, max(sapply(Bbase[[L1]],quantile,tcall(quants5)[5])) )
	boxlim[2] = boxlim[2] + diff(boxlim) * 0.04
#ptypes="png"; scenario=0; so("compBmsy.r")

	if ("win" %in% ptypes) resetGraph()
	par(mfrow=c(1,1), oma=c(0,0,0,0), mgp=c(2,0.5,0))
	mess =  paste0("list(",paste0(paste0(ptypes,"=TRUE"),collapse=","),")")

	out = compBmsy(Bspp=Bbase, spp=L1, boxwidth=0.5, medcol=medcol, boxfill=boxfill, boxlim=boxlim, whisklwd=2, staplelwd=2, Mnams=Mnams[bord], width=9, height=6, figgy=eval(parse(text=mess)), pngres=pngres, spplabs=F, t.yr=currYear, left.space=9, top.space=1, fout=paste0(prefix,"compo", ifelse(Ubase>1,".stock.","."), "status"), calcRat=F, lang=lang)
#}
#browser();return()



	## Make quantile plots of component-run parameters and quantities
	## --------------------------------------------------------------
	if (redo.panels) {
		so("mochaLatte.r","awatea")
		so("panelBoxes.r","awatea")

		P.collect = c(1:11) ## YMR: collect all parameters
		P.pars    = data.frame( avgPA[,P.collect] )
		colnames(P.pars) = colnames(avgPA)[P.collect]

		Q.pars   = data.frame(
			Bcurr      = avgRP[,"Bcurr"],
			B0         = avgRP[,"B0"],
			Bcurr.B0   = avgRP[,"Bcurr"]/avgRP[,"B0"],
			MSY        = avgRP[,"MSY"],
			Bmsy       = avgRP[,"Bmsy"],
			Bmsy.B0    = avgRP[,"Bmsy"]/avgRP[,"B0"],
			Ucurr      = avgRP[,"ucurr"],
			Umsy       = avgRP[,"umsy"],
			Umax       = apply(avgTS[,,"ut"],1,max) ## for each mcmc sample across the time series
			#Ucurr.Umsy = avgRP[,"ucurr"]/avgRP[,"umsy"]
		)
		nchains = length(P.run.ord)

		names(Q.pars) = sub("\\.", " / ", gsub("U","u", 
			gsub("Ucurr",paste0("U",currYear-1), 
			gsub("Bcurr",paste0("B",currYear), names(Q.pars)))))

		if (spp.code %in% c("YMR")){
			## nchains determined above
			nchains = nchains; ngroups = 1  ## no secondary axis of uncertainty
			boxfill = c("cyan","green","coral","dodgerblue","yellow")
		} else if (spp.code %in% c("WWR")){
			nchains = 9; ngroups = nchains/3
			boxfill = paste0(rep(c("cyan","green","coral"),each=ngroups), rep(1:ngroups,3)) 
		} else if (spp.code %in% c("BOR")){
			nchains = 3; ngroups = nchains/3
			boxfill = paste0(rep(c("cyan","green","salmon"),each=ngroups), rep(1:ngroups,3)) 
		} else if (spp.code %in% c("REBS")){
			if (istock %in% c("BSR","RER")) {
				#nchains = 9; ngroups = nchains/3
				#boxfill = paste0(rep(c("cyan","green","coral"),each=ngroups), rep(1:ngroups,3)) 
				nchains = Ubase; ngroups = ceiling(as.numeric(names(run.num)[use.num])/3)    ## RH 200508 (for subsets of B)
				colrnum = as.vector(unlist(sapply(split(ngroups,ngroups), function(x){1:length(x)})))
				boxfill = paste0(c("cyan","green","coral")[ngroups], colrnum ) 
			}
		}
		xlim = range(1:nchains)+c(-0.75,0.75)
#browser();return()

		Q.pars.f = Q.pars
		dimnames(Q.pars.f)[[2]] = c("B2022", "B0", "B2022 / B0", "RMD", "Brmd", "Brmd / B0", "u2021", "urmd", "umax")
		fout = fout.e = paste0(prefix,"compo.rfpt.qbox")
		for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
			changeLangOpts(L=l)
			fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
			for (p in ptypes) {
				if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=8, height=8)
				panelBoxes(switch(l,'e'= Q.pars,'f'=Q.pars.f), nchains=nchains, xlab=linguaFranca("Base Runs",l), ylab=linguaFranca("Derived Quantities",l), cex.strip=1.2, cex.axis=1.1, cex.lab=1.5, outline=FALSE, xlim=xlim, boxfill=boxfill, xfac=paste0("B",names(run.num[use.num])), mar=c(0,3.8,0,0), oma=c(4,2,0.5,1))  ## RH 200508 (for subsets of B)
				if (p %in% c("png","eps")) dev.off()
			}
		}; eop()
	}
#browser();return()
return() ## select french figures for YMR identified by Carley Colclough (22

		fout = fout.e = paste0(prefix,"compo.pars.qbox")
		for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
			changeLangOpts(L=l)
			fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
			for (p in ptypes) {
				if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=8, height=9)
				pflds  = setdiff(colnames(P.pars), "N")
				#pflds  = c("q_6",pflds)
				panelBoxes(P.pars[,pflds], nchains=nchains, xlab=linguaFranca("Base Runs",l), ylab=linguaFranca("Parameter estimates",l), cex.strip=1.2, cex.axis=1.1, cex.lab=1.5, outline=FALSE, xlim=xlim, boxfill=boxfill, xfac=paste0("B",names(run.num[use.num])), mar=c(0,3.8,0,0), oma=c(4,2,0.5,1))  ## RH 200508 (for subsets of B)
				if (p %in% c("png","eps")) dev.off()
			}
		}; eop()

	## Prepare stock base composites for function 'compBmsy'
	## If comparing two stocks (e.g., RSR,POP)
	if (length(stock)>2) { ## disable for now (fix later)
		if (istock==names(stock)[1]){
			Bstock = list()
			Bstock[[toupper(spp.code)]] = list()
		}
		ibase  = istock
		Bstock[[1]][[ibase]] = Bcurr.Bmsy ## composite from multiple bases
		tput(Bstock)
		## May have more than on stock so need to save Bstock somewhere for retrieval later
		if (istock==rev(names(stock))[1]) {
			tget(Bstock)
			Mnams = paste0(spp.code,"\n",sapply(stock,function(x){x$area.name}))
			N = length(Mnams)
			bord=c(1:N); medcol=c("blue","red")[1:N]; boxfill=c("aliceblue","mistyrose")[1:N] ## will need more if Nstock>2
			if ("win" %in% ptypes) resetGraph()
			mess =  paste0("list(",paste0(paste0(ptypes,"=TRUE"),collapse=","),")")
			out = compBmsy(Bspp=Bstock, spp=c(spp.code), boxwidth=0.5, medcol=medcol, boxfill=boxfill, whisklwd=2, staplelwd=2, Mnams=Mnams[bord], width=9, height=4, figgy=eval(parse(text=mess)), pngre=pngres, spplabs=F, t.yr=currYear, left.space=6, top.space=1, fout=paste0(spp.code,".base", ifelse(Ubase>1,".composite.","."), "status"), calcRat=F, lang=lang)
		}
	}
}
so("mochaLatte.r","awatea"); so("panelBoxes.r","awatea"); so("plotSS.pmcmc.r","synth")
#plotSS.compo(compo=compo, ptypes="png", lang=c("f","e"), redo.panels=T)
plotSS.compo(compo=compo, ptypes="png", lang=c("f"), redo.panels=T)

