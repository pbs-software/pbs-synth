## plt.selectivity----------------------2019-07-18
## Transferred selectivity code from PBSscape.r
## into plt function (RH 190718)
## sobj = second object (RH 201119)
## -----------------------------------------AME|RH
plt.selectivity <- function( obj, sobj=NULL, mainTitle="Rockfish", maxage,
   ptypes="win", pngres=400, PIN=c(7,8), lang=c("e","f"))
{
	## Plot the selectivity.
	panel.selex = function(x, y, ...){
		dots = list(...)[[1]]
		unpackList(dots)
		nsex = abs(getNpan()%%2-2)
		#unpackList(tcall(panel.dots))
		abline(h=seq(0.2,0.8,0.2), v=seq(10,max(x)-1,10), lty=3, col="seashell4")
		if (!is.null(sobj)) {
			z  = is.element(sobj$Index, sub("TRAWL\\+","TRAWL",index.e[getNpan()]))
			x2 = sobj$Age[z]; y2=sobj$Sel[z]
			lines(x, y, lty=1, col=scol[nsex], lwd=2)
			lines(x2, y2, lty=2, col=scol[nsex], lwd=2)
			m2 = sobj$Sel[grep("MATURITY: Female",sobj$Index)]
			lines(x2, m2, lty=2, col="grey20")
		}
		else
			lines(x, y, lty=1, col=scol[nsex], lwd=slwd)
		mvec = rep("m", length(m))
		if (length(m)>50)
			mvec[seq(2,length(m),2)]="\225"
		if (getNpan()%%2==1)
			text(x, m, mvec, col=lucent("black",0.75), cex=0.9)
#browser();return()
		#points(x, m, pch=109, col=lucent("black",0.75), cex=0.8) #, bg=lucent("gold",0.25)
		#lines(x, m, lty=1, col="pink", lwd=2); lines(x, m, lty=2, col="grey", lwd=2)
	}
	Pvec = intersect(as.character(0:500), colnames(obj))
	if (!missing(maxage)){
		realmaxage = as.numeric(rev(Pvec)[1])
		Pvec = as.character(0:min(maxage,realmaxage))
	}
	Xfile = NULL
	for (i in 1:nrow(obj)) {
		ifile = data.frame(Index=rep(obj[i,"Index"],length(Pvec)), Age=as.numeric(Pvec), Sel=unlist(obj[i,Pvec]))
		Xfile = rbind(Xfile,ifile)
	}
	## Alter xmax (needs changes in object names)
	#xmax = max(as.numeric(sapply(selP,function(x){names(x[is.element(x,1)])[1]})),na.rm=TRUE) #maximum minimum age when P first hits 1
	#if (is.na(xmax)) xmax = obj$extra$general$Nages
	## Check for dome-selectivity estimation
	#if ( any(unlist(sapply(currentRes$extra$priors[c("log_varRest_prior","log_surveyvarR_prior")],function(x){x[,1]}))>0) )
	#	xmax = obj$extra$general$Nages
	#obj$Sel = obj$Sel[obj$Sel$Age <= xmax,]

	## linguafranca takes too long on big vectors so shorten to unique
	Xfile.f  = Xfile
	index.e  = unique(Xfile$Index)
	index.f  = linguaFranca(index.e,"f")
	Xfile.f$Index = index.f[Xfile$Index]

	rc = c(ceiling(length(index.e)/2),2)

	## Get the maturity ogive
#browser();return()
	mats = getSS.control(tcall(control.file))$maturity_ogive[1:length(Pvec)]

	strip.list = list(col=lucent("black",0.5), bg=lucent("moccasin",0.5), height=0.1, cex=1.8)

	#panel.dots = list(scol=c("red","blue"), lwd=4)
	#tput(panel.dots)
	createFdir(lang)
	fout = fout.e = "selectivity"
	for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
		changeLangOpts(L=l)
		fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
		if (is.null(ptypes)) ptypes="win"
		for (p in ptypes) {
			if (p=="eps")      postscript(paste0(fout,".eps"), width=PIN[1], height=PIN[2], horizontal=FALSE,  paper="special")
			else if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
			## regular par settings are ignored in lattice::xyplot -- need to fiddle with lattice settings
			#par(mfrow=c(1,1), mar=c(3.2,3.2,0.5,1), oma=c(0,0,0,0), mgp=c(2,0.75,0))
			#par.sel = list(layout.widths = list(left.padding=-0.5, right.padding=-0.5),
			#	layout.heights=list(top.padding=0.5, main.key.padding=-0.75, bottom.padding=-2))
			if (l=="f")
				mochaLatte(Xfile.f,"Age","Sel","Index", panel=panel.selex, m=mats, strip=strip.list, scol=c("red","blue"), slwd=2, mar=c(0,0,0,0), oma=c(4,4,4,1), xlab=linguaFranca("Age (years)","f"), ylab=linguaFranca("Proportion","f"), mainTitle=paste0("s\u{00E9}lectivit\u{00E9} du ", linguaFranca(mainTitle,l)), cex.axis=1.2, cex.main=1.5, sobj=sobj, rc=rc, ylim=c(0,1))
			else{
				mochaLatte(Xfile,"Age","Sel","Index", panel=panel.selex, m=mats, strip=strip.list, scol=c("red","blue"), slwd=2, mar=c(0,0,0,0), oma=c(4,4,4,1), xlab="Age (years)", ylab="Proportion", mainTitle = paste0(mainTitle, " Selectivity"), cex.axis=1.2, sobj=sobj, rc=rc, ylim=c(0,1))
				#mtext(paste0(mainTitle, " Selectivity"), side=3, outer=FALSE, line=0, cex=1.5)
#browser();return()
			}
			if (p %in% c("eps","png")) dev.off()
		} ## end p (ptypes) loop
	}; eop()
#browser();return()
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~plt.selectivity
