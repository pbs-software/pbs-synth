## Function to use for priors in table (adapted from PBSawatea).
ptab = function(xx) {
	xx = sub("^\\s+", "", xx)  ## remove leading and trailing whitespace
	xlab = gsub("\\_+"," ",xx[1])
#browser();return()
	xnum =xx[-1]
	xnum[4] = switch(xnum[4], 'Normal'=6, 'No_prior'=0, 'Beta'=2)
	xnum = lapply(xnum,function(x){
		if(is.numStr(x))   as.numeric(x)
		else if (is.na(x)) "--"
		else x
	})
	xout = paste0(c(xlab, " & ", xnum[[1]], " & (", xnum[[2]], ", ", xnum[[3]], ") & ", xnum[[4]], " & (", xnum[[5]], ", ", xnum[[6]], ") & ", xnum[[7]], " & ", show0(round(xnum[[8]],3),3), " \\\\\\\\"), collapse="")
}
#P.tab   = pactive[,c("Label","Phase","Min","Max","Pr_type","Prior","Pr_SD","Init","Value")]
#test = apply(P.tab,1,ptab)
