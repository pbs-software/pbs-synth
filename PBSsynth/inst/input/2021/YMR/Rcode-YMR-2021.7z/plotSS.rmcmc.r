plotSS.rmcmc = function(mcmcObj, mpdObj, ptypes, lang, pngres=400, PIN=c(9,9))
{
	so("linguaFranca.r")
	unpackList(mpdObj); unpackList(mcmcObj)

	## Pairs|density plot comparison among parameters
	plotSS.pairs(P.mpd, P.mcmc, ptypes=ptypes, lang=lang, pngres=pngres, PIN=c(10,10), type="image")

#return(); # browser();return()

	## Parameter posteriors and priors
	for (l in lang) {
		plotSS.pars(replist, nrows=P.rc[1], ncols=P.rc[2], plot=F, print=T, fitrange=T, fitnudge=0.5, showpost=T, strings=names(P.mpd), exact=T, plotdir=getwd(), lang=l, outnam="pdfParameters")
	}

	## Snail plots of Bt/Bmsy and ut/umsy
	for (p in ptypes) {
		plotSS.snail(BoverBmsy, UoverUmsy, yrs=modYrs, p=tcall(quants3)[c(1,3)], ngear=ngear, Cnames="Trawl Plus", assYrs=assYrs, currYear=currYr, ptypes=p, lang=lang, outnam="snail.defunct")
		colnames(BoverBmsy) = sub("^SSB_","",colnames(BoverBmsy))
		colnames(UoverUmsy) = sub("^SSB_","",colnames(UoverUmsy))
		plotSnail(BoverBmsy, UoverUmsy, yrs=modYrs, p=tcall(quants3)[c(1,3)], xLim=NULL, yLim=NULL, ngear=ngear, assYrs=assYrs, outs=F, Cnames="Trawl+", ptypes=ptypes, outnam="snail", lang=l)
	}
}
#so("plotSS.pairs.r","synth")
#plotSS.rmcmc(mcmcObj=diag.mcmc, mpdObj=diag.mpd, ptypes="png", lang=c("e"))
#1.5,1.5,1.5,1.5
