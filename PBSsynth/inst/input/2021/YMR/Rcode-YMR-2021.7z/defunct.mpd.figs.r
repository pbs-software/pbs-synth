require(r4ss)

d.tools = "C:/Users/haighr/Files/Projects/R/Develop/PBStools/Authors/Rcode/develop/"
r.tools = c("linguaFranca", "clearFiles","extractAges","calcStockArea")
for (i in r.tools) source(paste0(d.tools,i,".r"))

d.synth = "C:/Users/haighr/Files/Projects/R/Develop/PBSsynth/Authors/Rcode/develop/"
r.synth = c("PBSsynth","plotFuns","utilFuns","plotSS.pars","plotSS.ts","plotSS.index")
for (i in r.synth) source(paste0(d.synth,i,".r"))

replist=SS_output(dir=getwd())
if (!exists("strSpp")){
	species.name="Yellowmouth Rockfish"; strSpp="YMR"; assyr=2021
}
if (strSpp %in% c("440","YMR") && assyr==2011){
	fleets.af  = c(1:3); fleets.idx = 2:6
	fleets.lab = c("Trawl Fishery", "GIG Historical", "QCS Synoptic", "QCS Shrimp", "WCHG Synoptic", "WCVI Synoptic")
}
if (strSpp %in% c("440","YMR") && assyr==2021){
	fleets.af  = c(1:5); fleets.idx = 2:5
	fleets.lab = c("Trawl+ Fishery","QCS Synoptic","WCVI Synoptic","WCHG Synoptic","GIG Historical")
}
if (strSpp %in% c("REBS","REBSN")){
	fleets.af  = c(1,3); fleets.idx = 1:3
	fleets.lab = c("Trawl Fishery","Other Fishery","WCHG Synoptic")
}
options(scipen=10)

## Compare to Awatea's selectivity
if (strSpp %in% c("REBS","REBSN") && !exists("b46")) {
	wd46 = "C:/Users/haighr/Files/GFish/PSARC20/REBS/Data/Awatea/BSR_2F/BSRrun46/MPD.46.01"
	load(paste0(wd46,"/currentRes.rda"))
	b46=currentRes$B
}
if (strSpp %in% c("440","YMR") && !exists("b29")) {  ## does not exist
	wd29 = "C:/Users/haighr/Files/GFish/PSARC11/YMR/Awatea/YMRrun29/MPD.29.01"
	if (file.exists(paste0(wd29,"/currentRes.rda"))) {
		load(paste0(wd29,"/currentRes.rda"))
		b29=currentRes$B
	}
}
bawa = switch(strSpp, 'REBS'=b46, 'REBSN'=b46, '440'=b29, 'YMR'=b29)

parameters   = replist$parameters
pactive = parameters[!is.na(parameters$Active_Cnt) & parameters$Phase>0 & !is.element(parameters$Pr_type,"dev"),]
P.mpd   = pactive$Value; names(P.mpd)=pactive$Label
P.rc    = .findSquare(length(P.mpd))

for (l in c("e","f"))
{
	## Parameter mles and priors
	plotSS.pars(replist, nrows=P.rc[1], ncols=P.rc[2], plot=F, print=T, fitrange=T, fitnudge=0.5, showpost=F, strings=names(P.mpd), exact=T, lang=l, outnam="mleParameters")

	## Spawning biomass:
	out=plotSS.ts(replist, subplot=7, print=T, plotdir=getwd(), forecast=F, uncertainty=F, sobj=bawa, PIN=c(8,6), outnam="Bt", lang=l)

	## Depletion:
	out=plotSS.ts(replist, subplot=9, print=T, plotdir=getwd(), forecast=F, uncertainty=F, btarg=0.4, minbthresh=0.2, sobj=bawa, PIN=c(8,6), outnam="BtB0", lang=l)

	## Recruitment:
	out=plotSS.ts(replist, subplot=11, print=T, plotdir=getwd(), forecast=F, uncertainty=F, sobj=bawa, PIN=c(8,6), outnam="recruits", lang=l)

	# Abundance index:
	## NOTE!!!! Must include a label for every fleet, regardless of whether it has an index series or not.
	plotSS.index(replist, subplots=2, onepage=T, print=T, plotdir=getwd(), labels=list("Year",fleets.lab), fleets=fleets.idx, PIN=c(9,9), outnam="survIndSer", lang=l)
}
so("plotSS.francis.r","synth")
so("plotSS.comps.r","synth")
so("plotSS.stdres.r","synth")
so("plotSS.selex.r","synth")
so("plotSS.pars.r","synth")
SSplotRecdevs(replist,subplot=1,print=T)


resetGraph();expandGraph()

