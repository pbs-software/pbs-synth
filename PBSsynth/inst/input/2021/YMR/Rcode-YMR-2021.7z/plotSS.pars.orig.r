# r4ss Functions
# --------------
plotSS.pars=function (replist, plotdir=NULL, xlab="Parameter value", 
	ylab="Density", showmle=TRUE, showpost=TRUE, showprior=TRUE, 
	showinit=TRUE, showdev=FALSE, showlegend=TRUE, fitrange=FALSE, fitnudge=0,
	xaxs="i", xlim=NULL, ylim=NULL, verbose=TRUE, debug=FALSE, 
	nrows=3, ncols=3, ltyvec=c(1, 1, 3, 4), colvec=c("blue", 
		"red", "black", "gray60", rgb(0, 0, 0, 0.5)), add=FALSE, 
	plot=TRUE, print=FALSE, pwidth=6.5, pheight=5, punits="in", 
	ptsize=10, res=400, strings=NULL, exact=FALSE, newheaders=NULL,
	lang=c("f","e")) 
{
	GetPrior <- function(Ptype, Pmin, Pmax, Pr, Psd, Pval) {
		Prior_Like <- NULL
		if (is.na(Ptype)) {
			warning("problem with prior type interpretation. Ptype:", Ptype)
		}
		Pconst <- 0.0001
		if (Ptype %in% c("No_prior", "")) {
			Prior_Like <- rep(0, length(Pval))
		}
		if (Ptype == "Normal") {
			Prior_Like <- 0.5 * ((Pval - Pr)/Psd)^2
		}
		if (Ptype == "Sym_Beta") {
			mu <- -(Psd * (log((Pmax + Pmin) * 0.5 - Pmin))) - (Psd * (log(0.5)))
			Prior_Like <- -(mu + (Psd * (log(Pval - Pmin + Pconst))) + (Psd * (log(1 - ((Pval - Pmin - Pconst)/(Pmax - Pmin))))))
		}
		if (Ptype == "Full_Beta") {
			mu <- (Pr - Pmin)/(Pmax - Pmin)
			tau <- (Pr - Pmin) * (Pmax - Pr)/(Psd^2) - 1
			Bprior <- tau * mu
			Aprior <- tau * (1 - mu)
			if (Bprior <= 1 | Aprior <= 1) {
				warning("bad Beta prior")
			}
			Prior_Like <- (1 - Bprior) * log(Pconst + Pval - Pmin) + (1 - Aprior) * log(Pconst + Pmax - Pval) - (1 - Bprior) * log(Pconst + Pr - Pmin) - (1 - Aprior) * log(Pconst + Pmax - Pr)
		}
		if (Ptype == "Log_Norm") {
			Prior_Like <- 0.5 * ((log(Pval) - Pr)/Psd)^2
		}
		if (Ptype == "Log_Norm_w/biasadj") {
			if (Pmin > 0) {
				Prior_Like <- 0.5 * ((log(Pval) - Pr + 0.5 * Psd^2)/Psd)^2
			}
			else {
				warning("cannot do prior in log space for parm with min <=0.0")
			}
		}
		if (Ptype == "Gamma") {
			scale <- (Psd^2)/Pr
			shape <- Pr/scale
			Prior_Like <- -1 * (-shape * log(scale) - lgamma(shape) + (shape - 1) * log(Pval) - Pval/scale)
		}
		if (Ptype == "F") {
			Prior_Like <- rep(0, length(Pval))
		}
		if (is.null(Prior_Like)) {
			warning("Problem calculating prior. The prior type doesn't match ", 
				"any of the options in the SSplotPars function.\n", 
				"Ptype: ", Ptype)
		}
		return(Prior_Like)
	}
	pngfun <- function(file, caption=NA) {
		png(filename=file.path(plotdir, file), width=pwidth, 
			height=pheight, units=punits, res=res, pointsize=ptsize)
		plotinfo <- rbind(plotinfo, data.frame(file=file, caption=caption))
		return(plotinfo)
	}
	plotinfo <- NULL
	if (!"parameters" %in% names(replist)) {
		stop("'replist' input needs to be a list created by the SS_output function")
	}
	if (is.null(plotdir)) {
		plotdir <- replist$inputs$dir
	}
	if (print & add) {
		stop("Inputs 'print' and 'add' can't both be TRUE")
	}
	if (print & plot) {
		warning("Inputs 'print' and 'plot' can't both be TRUE\n", 
			"changing to 'plot=FALSE'")
	}
	parameters <- replist$parameters
	allnames <- parameters$Label[!is.na(parameters$Active_Cnt)]
	if (!is.null(strings)) {
		goodnames <- NULL
		if (exact) {
			goodnames <- allnames[allnames %in% strings]
		}
		else {
			for (i in 1:length(strings)) {
				goodnames <- c(goodnames, grep(strings[i], allnames, fixed=TRUE, value=TRUE))
			}
		}
		goodnames <- unique(goodnames)
		if (verbose) {
			message("Active parameters matching input vector 'strings':")
			print(goodnames)
		}
		if (length(goodnames) == 0) {
			warning("No active parameters match input vector 'strings'.")
			return()
		}
	}
	else {
		goodnames <- allnames
		if (length(goodnames) == 0) {
			warning("No active parameters.")
			return()
		}
	}
	skip <- grep("Impl_err_", goodnames)
	if (length(skip) > 0) {
		goodnames <- goodnames[-skip]
		message("Skipping 'Impl_err_' parameters which don't have bounds reported")
	}
	skip <- grep("F_fleet_", goodnames)
	if (length(skip) > 0) {
		goodnames <- goodnames[-skip]
		message("Skipping 'F_fleet_' parameters which aren't yet supported by this function")
	}
	if (!showdev) {
		devnames <- c("RecrDev", "InitAge", "ForeRecr", "DEVadd", "DEVmult", "DEVrwalk", "DEV_MR_rwalk", "ARDEV")
		devrows <- NULL
		for (iname in 1:length(devnames)) {
			devrows <- unique(c(devrows, grep(devnames[iname], goodnames)))
		}
		if (length(devrows) > 0) {
			goodnames <- goodnames[-devrows]
			if (verbose) {
				message("Excluding ", length(devrows), " deviation parameters because input 'showdev'=FALSE")
			}
			if (length(goodnames) == 0) {
				message("no parameters to plot")
				return()
			}
		}
	}
	else {
		if (length(grep("rwalk", x=goodnames)) > 0 | length(grep("DEVadd", x=goodnames)) > 0 |
			length(grep("DEVmult", x=goodnames)) > 0 | length(grep("ARDEV", x=goodnames)) > 0) {
			warning("Parameter deviates are not fully implemented in this function.\n", 
				"Prior and bounds unavailable so these are skipped and\n", 
				"fitrange is set to TRUE for those parameters.")
		}
	}
	stds <- parameters$Parm_StDev[parameters$Label %in% goodnames]
	if (showmle & (all(is.na(stds)) || min(stds, na.rm=TRUE) <= 0)) {
		message("Some parameters have std. dev. values in Report.sso equal to 0.\n", 
			"  Asymptotic uncertainty estimates will not be shown.\n", 
			"  Try re-running the model with the Hessian but no MCMC.")
	}
	npars <- length(goodnames)
	if (is.null(strings) & verbose) {
		messagetext <- paste0("Plotting distributions for ", npars, " estimated parameters.")
		if (!showdev) {
			messagetext <- gsub(pattern=".", replacement=" (deviations not included).", x=messagetext, fixed=TRUE)
		}
		message(messagetext)
	}
	npages <- ceiling(npars/(nrows * ncols))
	plotPars.fn <- function() {
		if (!add) {
			plot(0, type="n", xlim=xlim2, ylim=ylim2, xaxs=xaxs, yaxs="i", xlab="", ylab="", main=gsub("_"," ",header), cex.main=0.9, axes=FALSE)
			axis(1)
		}
		colval <- colvec[4]
		if (showpost & goodpost) {
			plot(posthist, add=TRUE, freq=FALSE, col=colval, border=colval)
			abline(v=postmedian, col=colvec[5], lwd=2, lty=ltyvec[3])
		}
		if (!isdev & showprior) {
			lines(x, prior, lwd=2, lty=ltyvec[2])
		}
		if (showmle) {
			if (!is.na(parsd) && parsd > 0) {
				lines(x, mle, col=colvec[1], lwd=1, lty=ltyvec[1])
				lines(rep(finalval, 2), c(0, dnorm(finalval, finalval, parsd) * mlescale), col=colvec[1], lty=ltyvec[1])
			}
			else {
				abline(v=finalval, col=colvec[1], lty=ltyvec[1])
			}
		}
		if (showinit) {
			par(xpd=NA)
			points(initval, -0.02 * ymax, col=colvec[2], pch=17, cex=1.2)
			par(xpd=FALSE)
		}
		box()
		if (max(par("mfg")[1:2]) == 1) {
			mtext(xlab, side=1, line=0.5, outer=TRUE)
			mtext(ylab, side=2, line=0.5, outer=TRUE)
			if (showlegend) {
				showvec <- c(showprior, showmle, showpost, showpost, showinit)
				legend("topleft", cex=0.9, bty="n", pch=c(NA,NA,15,NA,17)[showvec], lty=c(ltyvec[2], 
					ltyvec[1], NA, ltyvec[3], NA)[showvec], lwd=c(2,1,NA,2,NA)[showvec], col=c(colvec[3], 
					colvec[1], colvec[4], colvec[5], colvec[2])[showvec], pt.cex=c(1,1,2,1,1)[showvec],
					legend=c("prior", "max. likelihood", "posterior", "posterior median", "initial value")[showvec]
				)
			}
		}
	}
	if (debug) {
		message("Making plots of parameters:")
	}
	if (plot & !add) {
		par(mfcol=c(nrows, ncols), mar=c(1,0.5,2,0), oma=c(2,2,0,1), mgp=c(2,0.5,0))
	}
	for (ipar in 1:npars) {
		ipage <- floor(1 + (ipar - 1)/(nrows * ncols - 1))
		parname <- goodnames[ipar]
		if (debug) {
			message("	", parname)
		}
		parline <- parameters[parameters$Label == parname, ]
		initval <- parline$Init
		finalval <- parline$Value
		parsd <- parline$Parm_StDev
		Pmin <- parline$Min
		Pmax <- parline$Max
		Ptype <- parline$Pr_type
		Psd <- parline$Pr_SD
		Pr <- parline$Prior
		if (is.na(Ptype) || Ptype == "dev") {
			Ptype <- "Normal"
			Pr <- 0
		}
		if (any(sapply(X=c("RecrDev", "InitAge", "ForeRecr"), 
			FUN=grepl, parname))) {
			Psd <- parameters$Value[parameters$Label == "SR_sigmaR"]
		}
		isdev <- FALSE
		if (length(grep("DEVrwalk", x=parname)) > 0 | length(grep("DEVadd", x=parname)) > 0 |
			length(grep("DEVmult", x=parname)) > 0 | length(grep("ARDEV", x=parname)) > 0) {
			initval <- 0
			isdev <- TRUE
		}
		ymax <- 0
		xmin <- NULL
		xmax <- NULL
		if (!isdev) {
			x <- seq(Pmin, Pmax, length=5000)
			negL_prior <- GetPrior(Ptype=Ptype, Pmin=Pmin, Pmax=Pmax, Pr=Pr, Psd=Psd, Pval=x)
			prior <- exp(-1 * negL_prior)
			if (length(prior) == 0) {
				prior <- rep(NA, length(x))
			}
		}
		else {
			x <- finalval + seq(-4 * parsd, 4 * parsd, length=5000)
		}
		if (!isdev & showprior) {
			prior <- prior/(sum(prior) * mean(diff(x)))
			ymax <- max(ymax, max(prior), na.rm=TRUE)
		}
		if (showmle) {
			if (!is.na(parsd) && parsd > 0) {
				mle <- dnorm(x, finalval, parsd)
				mlescale <- 1/(sum(mle) * mean(diff(x)))
				mle <- mle * mlescale
				ymax <- max(ymax, max(mle), na.rm=TRUE)
				xmin <- qnorm(0.001, finalval, parsd)
				xmax <- qnorm(0.999, finalval, parsd)
			}
			else {
				xmin <- xmax <- finalval
			}
		}
		mcmc <- replist$mcmc
		if (showpost && is.null(mcmc)) {
			message("$mcmc not found in input 'replist', changing input to 'showpost=FALSE'")
			showpost <- FALSE
		}
		if (showpost && length(mcmc) < 20) {
			message("mcmc output has fewer than 20 rows, changing input to 'showpost=FALSE'")
			showpost <- FALSE
		}
		goodpost <- FALSE
		if (showpost) {
			postparname <- parname
			if (substring(parname, 1, 1) == "_") {
				postparname <- paste0("X", postparname)
			}
			jpar <- (1:ncol(mcmc))[names(mcmc) == postparname]
			if (length(jpar) == 1) {
				post <- mcmc[, jpar]
				xmin <- min(xmin, quantile(post, 0.001))
				xmax <- max(xmax, quantile(post, 0.999))
				goodpost <- TRUE
			}
			else {
				warning("parameter '", postparname, "', not found in posteriors.")
			}
		}
		if (is.null(xlim)) {
			if (fitrange & ((!is.na(parsd) && parsd != 0) | showpost)) {
				if (fitnudge<=0) {
					xmin <- max(Pmin, xmin, na.rm=TRUE)
					xmax <- min(Pmax, xmax, na.rm=TRUE)
				} else {
					xspan = abs(diff(c(xmin,xmax)))
					xmin  = xmin - (fitnudge * xspan)
					xmax  = xmax + (fitnudge * xspan)
#browser();return()
				}
			}
			else {
				if (!isdev) 
				  xmin <- Pmin
				if (!isdev) 
				  xmax <- Pmax
			}
			xlim2 <- c(xmin, xmax)
		}
		else {
			xlim2 <- xlim
		}
		if (showpost & goodpost) {
			jpar <- (1:ncol(mcmc))[names(mcmc) == postparname]
			post <- mcmc[, jpar]
			breakvec <- seq(xmin, xmax, length=50)
			if (min(breakvec) > min(post)) 
				breakvec <- c(min(post), breakvec)
			if (max(breakvec) < max(post)) 
				breakvec <- c(breakvec, max(post))
			posthist <- hist(post, plot=FALSE, breaks=breakvec)
			postmedian <- median(post)
			ymax <- max(ymax, max(posthist$density), na.rm=FALSE)
		}
		if (is.null(newheaders)) {
			header <- parname
		}
		else {
			header <- newheaders[ipar]
		}
		if (is.null(ylim)) {
			ylim2 <- c(0, 1.1 * ymax)
		}
		else {
			ylim2 <- ylim
		}
		if (print && (ipar%%(nrows * ncols) == 0 | ipar == npars)) {
			caption <- "Parameter distribution plots"
			pagetext <- ""
			if (npages > 1) {
				pagetext <- paste("_page", ipage, sep="")
				caption <- paste(caption, " (plot ", ipage, " of ", npages, ").", sep="")
			}
			if (ipar == 1) {
				if (!showdev) {
					caption <- paste(caption, "<br>Deviation parameters are not included.")
				}
				if (length(grep("F_fleet_", allnames)) > 0) {
					caption <- paste(caption, "<br>F parameters are not included.")
				}
				if (fitrange) {
					caption <- paste(caption, "<br>Plotting range is scaled to fit parameter estimates.", 
					"Use fitrange=FALSE to use parameter bounds instead.")
				}
				else {
					caption <- paste(caption, "<br>Plotting range is equal to input limits on parameters.", 
					"Use fitrange=TRUE to scale the range to the estimates.")
				}
			}
			file <- paste0("parameter_distributions", pagetext, ".png", sep="")
			plotinfo <- pngfun(file=file, caption=caption)
#browser();return()
			par(mfcol=c(nrows, ncols), mar=c(1,0.5,2,0), oma=c(2,2,0,1), mgp=c(2,0.5,0))
		}
		if (print | plot) {
			plotPars.fn()
		}
		if (print && (ipar%%(nrows * ncols) == 0 | ipar == npars)) {
			dev.off()
		}
	}
	if (!is.null(plotinfo)) {
		plotinfo$category <- "Pars"
	}
	return(invisible(plotinfo))
}
plotSS.pars(replist,nrows=P.rc[1],ncols=P.rc[2],plot=T,print=F,fitrange=T,fitnudge=1,showpost=F,strings=names(P.mpd),exact=T,res=400,pwidth=9,pheight=9)

