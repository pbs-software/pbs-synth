## sample_admb_rwm----------------------2021-07-06
##  Sample ADMB using RWM (Random Walk Metropolis) algorithm
## --------------------------------------adnuts|RH
sample_admb_rwm = function (path, model, iter=2000, thin=1, warmup=ceiling(iter/2), 
   init=NULL, chain=1, seed=NULL, control=NULL, verbose=TRUE, 
   duration=NULL, admb_args=NULL, skip_optimization=TRUE, parallel=FALSE) 
{
	wd.old <- getwd()
	on.exit(setwd(wd.old))
	setwd(path)
	if (any(names(control) != "refresh")) 
		warning("Only refresh control argument is used with RWM, ignoring: ", 
			paste(names(control)[names(control) != "refresh"], 
				collapse = ", "), call. = FALSE)
	refresh <- control$refresh
	if (!is.null(refresh) & !is.numeric(refresh)) 
		stop("Invalid refresh value ", refresh)
	metric <- "mle"
	stopifnot(iter >= 1)
	stopifnot(warmup <= iter)
	stopifnot(duration > 0)
	stopifnot(thin >= 1)
	if (is.null(warmup)) 
		stop("Must provide warmup")
	if (thin < 1 | thin > iter) 
		stop("Thin must be >1 and < iter")
	if (skip_optimization) {
		cmd <- paste("-nox -nohess -maxfn 0 -phase 1000 -rwm -mcmc ", iter)
	}
	else {
		cmd <- paste("-rwm -mcmc ", iter)
	}
	cmd <- paste(cmd, "-mcscale", warmup, "-chain", chain)
	if (!is.null(seed)) 
		cmd <- paste(cmd, "-mcseed", seed)
	if (!is.null(duration)) 
		cmd <- paste(cmd, "-duration", duration)
	cmd <- paste(cmd, "-mcsave", thin)
	if (is.matrix(metric)) {
		cor.user <- metric/sqrt(diag(metric) %o% diag(metric))
		if (!matrixcalc::is.positive.definite(x = cor.user)) 
			stop("Invalid mass matrix, not positive definite")
		adnuts:::.write.admb.cov(metric)
	}
	else if (is.null(metric)) {
	}
	else if (metric == "mle") {
	}
	else if (metric == "unit") {
		cmd <- paste(cmd, "-mcdiag")
	}
	else {
		stop("Invalid metric option")
	}
	if (!is.null(init)) {
		cmd <- paste(cmd, "-mcpin init.pin")
		write.table(file = "init.pin", x = unlist(init), row.names = F, 
			col.names = F)
	}
	if (!is.null(refresh)) 
		cmd <- paste(cmd, "-refresh", refresh)
	if (!is.null(admb_args)) 
		cmd <- paste(cmd, admb_args)
#browser();return()
	model2 <- adnuts:::.update_model(model)
	console <- adnuts:::.check_console_printing(parallel)
	progress <- NULL
	if (console) {
		time <- system.time(system2(model2, cmd, stdout = ifelse(verbose, "", FALSE)))[3]
	}
	else {
		fn <- "mcmc_progress.txt"
		if (file.exists(fn)) 
			file.remove(fn)
		time <- system.time(system2(model2, cmd, stdout = ifelse(verbose, 
			fn, FALSE)))[3]
		if (file.exists(fn)) {
			progress <- readLines("mcmc_progress.txt")
		}
		else {
			warning("Progress output file not found. Try troubleshooting in serial model")
		}
	}
	if (!file.exists("unbounded.csv")) 
		stop(paste0("RWM failed to run. Command attempted was:\n", cmd))
	unbounded <- as.matrix(read.csv("unbounded.csv", header = FALSE))
	dimnames(unbounded) <- NULL
	pars <- adnuts:::.get_psv(model)
	par.names <- names(pars)
	lp <- as.vector(read.table("rwm_lp.txt", header = TRUE)[, 1])
	pars[, "log-posterior"] <- lp
	pars <- as.matrix(pars)
	time.total <- time
	time.warmup <- NA
	warmup <- warmup/thin
	gdump = gc(verbose=FALSE)
	return(list(samples = pars, sampler_params = NULL, time.total = time.total, 
		time.warmup = time.warmup, warmup = warmup, model = model, 
		par.names = par.names, cmd = cmd, unbounded = unbounded, 
		progress = progress))
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sample_admb_rwm
