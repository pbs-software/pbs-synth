# r4ss Functions
# --------------
plotSS.spnrec = function (replist, subplot = 1:3, add = FALSE, plot = TRUE, print = FALSE, 
    xlim = NULL, ylim = NULL, labels = c("Spawning biomass (mt)", 
        "Recruitment (1,000s)", "Spawning output", expression(paste("Spawning output (relative to ", 
            italic(B)[0], ")")), expression(paste("Recruitment (relative to  ", 
            italic(R)[0], ")")), "Log recruitment deviation"), 
    bioscale = "default", plotdir = "default", pwidth = 6.5, 
    pheight = 6.5, punits = "in", res = 300, ptsize = 10, verbose = TRUE, 
    colvec = c("blue", "black", "black", gray(0, 0.7)), ltyvec = c(1, 
        2, 1, NA), ptcol = "default", legend = TRUE, legendloc = NULL, 
    minyr = "default", textmindev = 0.5, relative = FALSE, expected = TRUE, 
    estimated = TRUE, bias_adjusted = TRUE, show_env = TRUE, 
    virg = TRUE, init = TRUE, forecast = FALSE) 
{
    pngfun <- function(file, caption = NA) {
        png(filename = file.path(plotdir, file), width = pwidth, 
            height = pheight, units = punits, res = res, pointsize = ptsize)
        plotinfo <- rbind(plotinfo, data.frame(file = file, caption = caption))
        return(plotinfo)
    }
    plotinfo <- NULL
    recruit <- replist[["recruit"]]
    if (is.null(recruit)) {
        message("Skipping stock-recruit plots: no recruitment information available")
        return()
    }
    else {
        if (3 %in% subplot && max(abs(recruit[["dev"]]), na.rm = TRUE) < 
            1e-06) {
            subplot <- setdiff(subplot, 3)
        }
    }
    nsexes <- replist[["nsexes"]]
    xlab <- labels[1]
    ylab <- labels[2]
    if (is.na(replist[["SpawnOutputUnits"]]) || replist[["SpawnOutputUnits"]] == 
        "numbers") {
        xlab <- labels[3]
    }
    if (relative) {
        xlab <- labels[4]
        ylab <- labels[5]
    }
    if (bioscale == "default") {
        if (nsexes == 1) 
            bioscale <- 0.5
        else bioscale <- 1
    }
    if (plotdir == "default") 
        plotdir <- replist[["inputs"]][["dir"]]
    if (minyr == "default") 
        minyr <- min(recruit[["Yr"]])
    recruit <- recruit[recruit[["era"]] %in% c("Early", "Main", 
        "Fixed", "Late", ifelse(forecast, "Forecast", NA)) & 
        recruit[["Yr"]] >= minyr, ]
    timeseries <- replist[["timeseries"]]
    recruit[["spawn_bio"]] <- bioscale * recruit[["SpawnBio"]]
    timeseries[["SpawnBio"]] <- bioscale * timeseries[["SpawnBio"]]
browser();return()
    if (is.null(ylim)) {
        ylim <- c(0, 1.1 * max(recruit[["pred_recr"]], recruit[["exp_recr"]], 
            recruit[["bias_adjusted"]]))
    }
    x <- recruit[["spawn_bio"]]
    if (is.null(xlim)) {
        xlim <- c(0, 1.1 * max(x))
    }
    show_env <- show_env & any(recruit[["with_env"]] != recruit[["exp_recr"]])
    B0 <- sum(timeseries[["SpawnBio"]][timeseries[["Era"]] == 
        "VIRG"], na.rm = TRUE)
    B1 <- sum(timeseries[["SpawnBio"]][timeseries[["Era"]] == 
        "INIT"], na.rm = TRUE)
    R0 <- sum(timeseries[["Recruit_0"]][timeseries[["Era"]] == 
        "VIRG"], na.rm = TRUE)
    R1 <- sum(timeseries[["Recruit_0"]][timeseries[["Era"]] == 
        "INIT"], na.rm = TRUE)
    if (B0 == 0) {
        B0 <- head(recruit[["spawn_bio"]][recruit[["spawn_bio"]] != 
            0], 1)
    }
    if (R0 == 0) {
        R0 <- head(recruit[["exp_recr"]][recruit[["exp_recr"]] != 
            0], 1)
    }
    if (B0 == B1 & R0 == R1) {
        init <- FALSE
    }
    if (relative) {
        x.mult <- 1/B0
        y.mult <- 1/R0
    }
    else {
        x.mult <- 1
        y.mult <- 1
    }
    if (ptcol[1] == "default") {
        ptcol <- rev(rich.colors.short(nrow(recruit) + 10, alpha = 0.8))[-(1:10)]
        color.caption <- paste(" Point colors indicate year, with warmer", 
            "colors indicating earlier years and cooler colors", 
            "in showing later years.")
    }
    else {
        color.caption <- ""
    }
    if (legend) {
        legend_entries <- c(expected, show_env, bias_adjusted, 
            estimated, virg, init)
        legend_col <- colvec[c(3, 1, 2, 4, 3, 3)][legend_entries]
        legend_bg <- c(NA, NA, NA, tail(ptcol)[1], NA, NA)[legend_entries]
        legend_lwd <- c(2, 1, 1, NA, NA, NA)[legend_entries]
        legend_lty <- ltyvec[c(3, 1, 2, 4, 3, 3)][legend_entries]
        legend_pch <- c(NA, NA, NA, 21, 3, 4)[legend_entries]
        legend_cex <- c(1, 1, 1, 1, 1.5, 1.5)[legend_entries]
        legend_lab <- c("Exp. recruitment", "Exp. recruitment with env. link", 
            "Exp. recruitment after bias adj.", "Estimated recruitments", 
            "Unfished equilibrium", "Initial equilibrium")[legend_entries]
    }
    StockRecruitCurve.fn <- function(text = FALSE) {
        if (!add) {
            par(mar = c(4.5, 4.5, 1, 1))
            plot(0, type = "n", xlim = xlim * x.mult, ylim = ylim * 
                y.mult, xaxs = "i", yaxs = "i", xlab = xlab, 
                ylab = ylab)
        }
        if (show_env) {
            lines(x[order(x)] * x.mult, recruit[["with_env"]][order(x)] * 
                y.mult, lwd = 1, lty = ltyvec[1], col = colvec[1])
        }
        if (expected) {
            lines(x[order(x)] * x.mult, recruit[["exp_recr"]][order(x)] * 
                y.mult, lwd = 2, lty = ltyvec[3], col = colvec[3])
        }
        if (bias_adjusted) {
            lines(x * x.mult, recruit[["bias_adjusted"]] * y.mult, 
                lwd = 1, lty = ltyvec[2], col = colvec[2])
        }
        if (estimated) {
            points(x * x.mult, recruit[["pred_recr"]] * y.mult, 
                pch = 21, col = colvec[4], bg = ptcol)
        }
        if (text) {
            show <- abs(recruit[["dev"]]) > textmindev
            show[1] <- show[length(show)] <- TRUE
            text(x[show] * x.mult, recruit[["pred_recr"]][show] * 
                y.mult, labels = recruit[["Yr"]][show], pos = 2, 
                cex = 0.7)
        }
        if (virg) {
            points(B0 * x.mult, R0 * y.mult, pch = 3, cex = 1.5)
        }
        if (init) {
            points(B1 * x.mult, R1 * y.mult, pch = 4, cex = 1.5)
        }
        if (legend) {
            legend.overlap <- function(x, y, ...) {
                legend.out <- legend(..., plot = FALSE)
                leg.left <- legend.out[["rect"]][["left"]]
                leg.right <- legend.out[["rect"]][["left"]] + 
                  legend.out[["rect"]][["w"]]
                leg.top <- legend.out[["rect"]][["top"]]
                leg.bottom <- legend.out[["rect"]][["top"]] - 
                  legend.out[["rect"]][["h"]]
                if (any(x >= leg.left & x <= leg.right & y >= 
                  leg.bottom & y <= leg.top)) {
                  return(TRUE)
                }
                else {
                  return(FALSE)
                }
            }
            legend_added <- FALSE
            if (is.null(legendloc)) {
                for (legendloc in c("topleft", "topright", "bottomright")) {
                  has_overlap <- legend.overlap(x = x * x.mult, 
                    y = recruit[["pred_recr"]] * y.mult, legendloc, 
                    legend = legend_lab, col = legend_col, pt.bg = legend_bg, 
                    lwd = legend_lwd, lty = legend_lty, pch = legend_pch, 
                    bg = rgb(1, 1, 1, 0.6))
                  if (!has_overlap & !legend_added) {
                    legend(legendloc, legend = legend_lab, col = legend_col, 
                      pt.bg = legend_bg, lwd = legend_lwd, lty = legend_lty, 
                      pch = legend_pch, bg = rgb(1, 1, 1, 0.6))
                    legend_added <- TRUE
                  }
                }
                if (!legend_added) {
                  warning("Legend in spawner-recruit plot overlaps at least 1 point\n", 
                    "in the plot. Try running SSplotSpawnrecruit() with\n", 
                    "adjustments to 'ylim' and/or 'legendloc' inputs.")
                  legendloc <- "topleft"
                }
            }
            if (!legend_added) {
                legend(legendloc, legend = legend_lab, col = legend_col, 
                  pt.bg = legend_bg, lwd = legend_lwd, lty = legend_lty, 
                  pch = legend_pch, bg = rgb(1, 1, 1, 0.5))
            }
        }
    }
    stock_vs_devs.fn <- function(text = FALSE) {
        if (!add) {
            par(mar = c(4.5, 4.5, 1, 1))
            xmax <- 1.05 * max(x/B0)
            plot(0, type = "n", xlim = c(0, xmax), ylim = c(-1.1, 
                1.1) * max(abs(recruit[["dev"]]), na.rm = TRUE), 
                las = 1, xaxs = "i", yaxs = "i", xlab = labels[4], 
                ylab = labels[6])
        }
        abline(h = 0, col = "grey")
        points(x/B0, recruit[["dev"]], pch = 21, bg = ptcol, 
            col = colvec[4], cex = 1.5)
        if (text) {
            show <- abs(recruit[["dev"]]) > textmindev
            show[1] <- show[length(show)] <- TRUE
            text(x[show]/B0, recruit[["dev"]][show], labels = recruit[["Yr"]][show], 
                pos = 2, cex = 0.7)
        }
        if (virg) {
            points(1, 0, pch = 3, cex = 2, lwd = 2)
        }
        if (init) {
            points(B1/B0, 0, pch = 4, cex = 2)
        }
    }
    if (plot) {
        if (1 %in% subplot) {
            StockRecruitCurve.fn()
        }
        if (2 %in% subplot) {
            StockRecruitCurve.fn(text = TRUE)
        }
        if (3 %in% subplot) {
            stock_vs_devs.fn(text = TRUE)
        }
    }
    if (print) {
        if (1 %in% subplot) {
            file <- "SR_curve.png"
            caption <- paste("Stock-recruit curve.", color.caption)
            plotinfo <- pngfun(file = file, caption = caption)
            StockRecruitCurve.fn()
            dev.off()
        }
        if (2 %in% subplot) {
            file <- "SR_curve2.png"
            caption <- paste0("Stock-recruit curve with labels on first, last, and ", 
                "years with (log) deviations > ", textmindev, 
                ".", color.caption)
            plotinfo <- pngfun(file = file, caption = caption)
            StockRecruitCurve.fn(text = TRUE)
            dev.off()
        }
        if (3 %in% subplot) {
            file <- "SR_resids.png"
            caption <- paste0("Deviations around the stock-recruit curve. ", 
                "Labels are on first, last, and ", "years with (log) deviations > ", 
                textmindev, ".", color.caption)
            plotinfo <- pngfun(file = file, caption = caption)
            stock_vs_devs.fn(text = TRUE)
            dev.off()
        }
    }
    if (!is.null(plotinfo)) 
        plotinfo[["category"]] <- "S-R"
    return(invisible(plotinfo))
}
plotSS.spnrec(replist)
