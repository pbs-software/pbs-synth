## plotSS.stock.recruit-----------------2021-08-26
## Plot stock-recruitment function (based on MPDs)
## ----------------------------------------r4ss|RH
## xLimSR and yLimSR fixed here for YMR to have Run 26 and 27 figs
##  on same scales. Use these first two values to scale to data:
# xLimSR =c(0, max(obj$B$SB))
# yLimSR=c(0, max(obj$B$R, na.rm=TRUE))
#xLimSR=c(0, max(c(max(obj$B$SB),45000)))   # so it draw bigger if necessary
#yLimSR=c(0, max(c(max(obj$B$R, na.rm=TRUE),55000)))

plotSS.stock.recruit = function (replist, subplot = 1:3, add = FALSE, plot = TRUE, print = FALSE, 
   xlim = NULL, ylim = NULL, labels = c("Spawning biomass (mt)", 
   "Recruitment (1,000s)", "Spawning output", expression(paste("Spawning output (relative to ", 
   italic(B)[0], ")")), expression(paste("Recruitment (relative to  ", 
   italic(R)[0], ")")), "Log recruitment deviation"), 
   bioscale = "default", plotdir = "default", pwidth = 6.5, 
   pheight = 6.5, punits = "in", res = 300, ptsize = 10, verbose = TRUE, 
   colvec = c("blue", "black", "black", gray(0, 0.7)), ltyvec = c(1,2,1,NA),
   ptcol = "default", legend = TRUE, legendloc = NULL, 
   minyr = "default", textmindev = 0.5, relative = FALSE, expected = TRUE, 
   estimated = TRUE, bias_adjusted = TRUE, show_env = TRUE, 
   virg = TRUE, init = TRUE, forecast = FALSE,
   lang=c("f","e"), ptypes="win", pngres=400, PIN=c(8,7), outnam="stockRecruit") 
{
	## Calculating projected R gets tricky
	## Stock-recruitment function
	srFun=function(spawners, h=h.mpd, R0=R0.mpd, B0=B0.mpd) {
		# to input a vector of spawners in year t-1 and calculate recruits in year t 
		4 * h * R0 * spawners / ( ( 1 - h) * B0 + (5 * h - 1) * spawners)
	}
	parameters = replist$parameters
	h.mpd = parameters[grep("steep",rownames(parameters)),"Value"]

	recruit  <- replist[["recruit"]]
	if (minyr == "default") 
		minyr <- min(recruit[["Yr"]])
	recruit    <- recruit[recruit[["era"]] %in% c("Early", "Main", "Fixed", "Late", ifelse(forecast, "Forecast", NA)) &  recruit[["Yr"]] >= minyr, ]
	timeseries <- replist[["timeseries"]]
	nsexes     <- replist[["nsexes"]]
	if (bioscale == "default") {
		if (nsexes == 1) 
			bioscale <- 0.5
		else bioscale <- 1
	}
	recruit[["spawn_bio"]] <- bioscale * recruit[["SpawnBio"]]
	timeseries[["SpawnBio"]] <- bioscale * timeseries[["SpawnBio"]]
	
	if (is.null(ylim)) {
		ylim <- c(0, 1.1 * max(recruit[["pred_recr"]], recruit[["exp_recr"]], recruit[["bias_adjusted"]]))
	}
	x <- recruit[["spawn_bio"]]
	if (is.null(xlim)) {
		xlim <- c(0, 1.1 * max(x))
	}
	show_env <- show_env & any(recruit[["with_env"]] != recruit[["exp_recr"]])
	B0 <- sum(timeseries[["SpawnBio"]][timeseries[["Era"]] == "VIRG"], na.rm = TRUE)
	B1 <- sum(timeseries[["SpawnBio"]][timeseries[["Era"]] == "INIT"], na.rm = TRUE)
	R0 <- sum(timeseries[["Recruit_0"]][timeseries[["Era"]] == "VIRG"], na.rm = TRUE)
	R1 <- sum(timeseries[["Recruit_0"]][timeseries[["Era"]] == "INIT"], na.rm = TRUE)
	if (B0 == 0) {
		B0 <- head(recruit[["spawn_bio"]][recruit[["spawn_bio"]] != 0], 1)
	}
	if (R0 == 0) {
		R0 <- head(recruit[["exp_recr"]][recruit[["exp_recr"]] != 0], 1)
	}
	if (B0 == B1 & R0 == R1) {
		init <- FALSE
	}
	if (relative) {
		x.mult <- 1/B0
		y.mult <- 1/R0
	}
	else {
		x.mult <- 1
		y.mult <- 1
	}
	B0.mpd = B0
	R0.mpd = R0
#browser();return()
	years    <- recruit[["Yr"]]
	B = data.frame(year=recruit[["Yr"]], SB = x * x.mult, R  = recruit[["pred_recr"]] * y.mult)
	xLimSR = c(0, 1.5*max(B$SB,na.rm=TRUE))   # so it draw bigger if necessary
	xxx    = (seq(0, xLimSR[2], length.out=100))
	yyy    = srFun(xxx)
	yLimSR=c(0, 1.1*max(c(yyy,B$R),na.rm=TRUE))

	fout = fout.e = outnam
	for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
		changeLangOpts(L=l)
		fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
		for (p in ptypes) {
			if (p=="eps") postscript(paste0(fout,".eps"), width=6.5, height=4, horizontal=FALSE,  paper="special")
			else if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=6.5, height=4)
			par(mfrow=c(1,1), mar=c(3.25,3.5,1,1), oma=c(0,0,0,0), mgp=c(2,0.75,0))
			ylab = linguaFranca("Recruitment",l)
			plot(xxx, yyy, lwd=2, xlim=xLimSR, ylim=yLimSR, type="l",
				xlab=bquote(.(linguaFranca("Spawning biomass",l)) ~ italic(B)[italic(t)] ~ "(tonnes)" ~ .(linguaFranca("in year ",l)) ~ italic(t)),
				#ylab=bquote(.(linguaFranca("Recruitment",l)) ~ " " ~ italic(R)[italic(t)] ~ " (1000s)" ~ .(linguaFranca("in year ",l)) ~ italic(t) ~ "+1") ) 
				ylab=bquote(.(linguaFranca("Recruitment",l)) ~ "" ~ italic(R)[italic(t)] ~ " (1000s)" ~ .(linguaFranca("in year ",l)) ~ italic(t) ~ "")
			)
			#text(B[-length(years), "SB"], B[-1, "R"], labels=substring(as.character(years[-length(years)]), 3), cex=0.6, col="blue")
			## R = age-0 fish
			text(B[,"SB"], B[,"R"], labels=substring(as.character(years), 3), cex=0.6, col="blue")
			if (p %in% c("eps","png")) dev.off()
		} ## end p (ptypes) loop
	}; eop()
#browser();return()
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~plotSS.stock.recruit

plotSS.stock.recruit(replist, lang="e", ptypes="png")
