## plotSS.pairs-------------------------2021-05-26
##  Pairs|density plot comparison among parameters
## ---------------------------------------------RH
plotSS.pairs = function(P.mpd, P.mcmc, type="image", ptypes, lang=c("e","f"), pngres=400, PIN=c(10,10))
{
	panel.cor <- function(x, y, digits=2, prefix="", ...)
	{
		usr <- par("usr"); on.exit(par(usr))
		par(usr=c(0, 1, 0, 1))
		r <- abs(cor(x, y))
		txt <- format(c(r, 0.123456789), digits=digits)[1]
		txt <- paste(prefix, txt, sep="")
		text(0.5, 0.5, txt, cex=max(cex.min,((r)^0.1)*cex.fac))
	}
	panel.cor.small = eval(parse(text=sub("1\\.75", "1.25", deparse(panel.cor))))

	panel.dens <- function(x, y, type="image", ncol=100, ...)
	{
		cr = colorRampPalette(c("aliceblue","blue","green","yellow","orange","red"))
		if (type %in% "dots"){
			points (x,y,...)
		}
		if (type %in% c("contour","image")){
			xy = cbind(x, y)
			bw = apply(xy,2,function(x){quantile(abs(diff(x))*0.25,0.5)})
			est <- KernSmooth::bkde2D(xy, bandwidth=bw)#c(0.25,0.25))
			#contour(est$x1, est$x2, est$fhat, add=T)
			#image(est$x1,est$x2,est$fhat,col=gray(200:100/200), add=T)
			image(est$x1,est$x2,est$fhat,col=cr(ncol), add=TRUE)
			box()
		}
	}
	panel.dens.type = eval(parse(text=sub("type = \"image\"", paste0("type = \"",type,"\""), deparse(panel.dens))))

	panel.text = function(x, y, labels, cex, font, ...)
	{
		polygon(c(0,0,1,1), c(0,1,1,0), col="gainsboro")
		text(0.5,0.5,labels,cex=cex.max,font=2)
	}
#browser();return()

	## Doing 1 pairs plot with all parameters
	npp = 1
	nuP = length(P.mpd)
	npr = ceiling(nuP/npp)
	P.use = P.mcmc
	N.use = gsub("_"," ",colnames(P.use))
	colnames(P.use) = sapply(lapply(N.use,strwrap,width=10),paste0,collapse="\n")
	colnames(P.use) = gsub("_","\n",colnames(P.use))

	## Pairs plot
	for (i in 1:npp) {
		if (i<npp) ii = (1:npr)+(i-1)*npr
		else       ii = (nuP-npr+1):nuP
		#ii = ii[1:10] ## testing only
		if (length(ii)>20) {
			cex.min=0.6; cex.max=0.8; cex.fac=1.25
		} else if (length(ii)>10) {
			cex.min=0.65; cex.max=0.9; cex.fac=1.75
		} else {
			cex.min=0.7; cex.max=1; cex.fac=2.5
		}
		fout = fout.e = paste0("pairsPars", ifelse(npp>1, pad0(i,2), ""))
		for (l in lang) {  ## could switch to other languages if available in 'linguaFranca'.
			createFdir(lang, dir=".")
			changeLangOpts(L=l)
			fout = switch(l, 'e' = fout.e, 'f' = paste0("./french/",fout.e) )
			for (p in ptypes) {
				if (p=="eps") postscript(paste0(fout,".eps"), width=PIN[1], height=PIN[2], horizontal=FALSE,  paper="special")
				else if (p=="png") png(paste0(fout,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
				par(mar=c(0,0,0,0), oma=c(0,0,0,0), mgp=c(2,0.75,0))
				pairs(P.use[, ii], col=lucent("black",0.1), pch=20, cex=0.2, gap=0, lower.panel=panel.cor.small, upper.panel=panel.dens.type, text.panel=panel.text, cex.axis=1, cex.labels=1)
#browser();return()
				if (p %in% c("eps","png")) dev.off()
			} ## end p (ptypes) loop
		}; eop()
	}
}

