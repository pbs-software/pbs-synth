## plotSS.comps-------------------------2020-08-25
##  Plot age proportions and model fit
##  Source: R package 'r4ss' v.1.39.1
## ----------------------------------------r4ss|RH
plotSS.comps = function (replist, subplots=c(1:21, 24), kind="LEN", sizemethod=1, 
   aalyear=-1, aalbin=-1, plot=TRUE, print=FALSE, fleets="all", 
   fleetnames="default", sexes="all", yupper=0.4, datonly=FALSE, 
   samplesizeplots=TRUE, compresidplots=TRUE, bub=FALSE, 
   showyears=TRUE, showsampsize=TRUE, showeffN=TRUE, aggregates_by_mkt=FALSE, 
   sampsizeline=FALSE, effNline=FALSE, minnbubble=3, pntscalar=NULL, 
   scalebubbles=FALSE, cexZ1=1.5, bublegend=TRUE,
   #colvec=c(rgb(1,0,0,0.7), rgb(0,0,1,0.7), rgb(0.1,0.1,0.1,0.7)),
   #linescol=c(rgb(0,0.5,0,0.7), rgb(0.8,0,0,0.7), rgb(0,0,0.8,0.7)),
   colsex = c("orange","limegreen","slategray3"),
   colvec=lucent(colsex,0.75),
   #linescol=rgb(RYB2RGB(1-RGB2RYB(col2rgb(colsex)))),
   linescol=rep(lucent("black",0.75),3),
   xlas=0, ylas=NULL, axis1=NULL, axis2=NULL, 
   axis1labs=NULL, sizebinlabs=NULL, blue=lucent("limegreen",0.75), red=lucent("purple",0.75),
   #blue=rgb(0,0,1,0.7), red=rgb(1,0,0,0.7),
   pwidth=6.5, pheight=5, punits="in", ptsize=10, res=400,
   plotdir="default", cex.main=1, linepos=1, fitbar=FALSE, do.sqrt=TRUE,
   smooth=TRUE, cohortlines=c(), labels=c("Length (cm)", 
   "Age (yr)", "Year", "Observed sample size", "Effective sample size",
   "Proportion", "cm", "Frequency", "Weight", "Length", "(mt)",
   "(numbers x1000)", "Stdev (Age)", "Conditional AAL plot, ", "Size bin"),
   printmkt=TRUE, printsex=TRUE, maxrows=4, maxcols=4, maxrows2=2, maxcols2=4,
   rows=1, cols=1, andre_oma=c(3,0,3,0), andrerows=3, fixdims=TRUE,
   fixdims2=FALSE, maxneff=5000, verbose=TRUE, scalebins=FALSE, 
   addMeans=TRUE, mainTitle=FALSE, outnam, lang="e", ...) 
{
	oldpar = par(no.readonly=TRUE)
	fart = function(opar) { if (any("windows"%in%names(dev.list()))) par(opar); eop() }
	on.exit(fart(oldpar))
	changeLangOpts(L=lang)
	if (missing(outnam))
		outnam = NULL
	ttput(outnam)

	if (!is.element(subplots, c(1:21, 24))) {
		mess = c(" \n","Choose another subplot from:",
			"  1 = Multipanel (by year) fits to age proportions for multiple fleets",
			"  2 = Single panel (by fleet) bubble plots of age proportions by year",
			"  3 = ???",
			"  4 = ???",
			"  5 = ???",
			"  6 = ???",
			"  7 = ???",
			"  8 = ???",
			"  9 = ???",
			" 11 = ???",
			" 12 = ???",
			" 13 = ???",
			" 14 = ???",
			" 15 = ???",
			" 21 = Multipanel (by fleet) fits to combined age proportions across years",
			" 24 = Multipanel (by fleet) bubble plots of age proportions by year"
		)
		stop(paste0(mess, collapse="\n"))
	}
	pngfun <- function(file, caption=NA, lang="e") {
		addsize = ifelse(length(.su(dbase$Yr))>9, 1, 0)
#browser();return()
		createFdir(lang, dir=plotdir)
		changeLangOpts(L=lang)
		fout = switch(lang, 'e' = file.path(plotdir, file), 'f' = file.path(plotdir,"french", file) )
		clearFiles(fout)
		png(filename=fout, width=pwidth+addsize, height=pheight+addsize, units=punits, res=res, pointsize=ptsize)
		plotinfo <- rbind(plotinfo, data.frame(file=file, caption=caption))
		return(plotinfo)
	}
	plotinfo <- NULL
	SS_versionNumeric <- replist$SS_versionNumeric
	lendbase          <- replist$lendbase
	sizedbase         <- replist$sizedbase
	agedbase          <- replist$agedbase
	condbase          <- replist$condbase
	ghostagedbase     <- replist$ghostagedbase
	ghostlendbase     <- replist$ghostlendbase
	ladbase           <- replist$ladbase
	wadbase           <- replist$wadbase
	tagdbase1         <- replist$tagdbase1
	tagdbase2         <- replist$tagdbase2
	nfleets           <- replist$nfleets
	nseasons          <- replist$nseasons
	seasfracs         <- replist$seasfracs
	FleetNames        <- replist$FleetNames
	nsexes            <- replist$nsexes
	accuage           <- replist$accuage
	Age_tuning        <- replist$Age_comp_Eff_N_tuning_check
	titles            <- NULL
	titlemkt          <- ""
	if (plotdir == "default") {
		plotdir <- replist$inputs$dir
	}
	if (fleets[1] == "all") {
		fleets <- 1:nfleets
	}
	else {
		if (length(intersect(fleets, 1:nfleets)) != length(fleets)) {
			stop("Input 'fleets' should be 'all' or a vector of values between 1 and nfleets.")
		}
	}
	if (fleetnames[1] == "default") {
		fleetnames <- FleetNames
	}
	if (sexes[1] == "all") {
		sexes <- 0:nsexes
	}
	if (nsexes == 1) {
		sexes <- 0:nsexes
	}
	if (nsexes == 1 | length(sexes) > 1) {
		titlesex <- ""
		filesex <- ""
	}
	if (nsexes > 1 & length(sexes) == 1) {
		if (sexes == 0) {
			titlesex <- "sexes combined, "
			filesex <- "sex0"
		}
		if (sexes == 1) {
			titlesex <- "female, "
			filesex <- "sex1"
		}
		if (sexes == 2) {
			titlesex <- "male, "
			filesex <- "sex2"
		}
	}
	titlesex <- ifelse(printsex, titlesex, "")
	if (kind == "LEN") {
		dbase_kind <- lendbase
		kindlab=labels[1]
		if (datonly) {
			filenamestart <- "comp_lendat_"
			titledata <- "Length comp data, "
		}
		else {
			filenamestart <- "comp_lenfit_"
			titledata <- "Length comps, "
		}
	}
	if (kind == "GSTLEN") {
		dbase_kind       <- ghostlendbase
		kindlab=labels[1]
		if (datonly) {
			filenamestart <- "comp_gstlendat_"
			titledata     <- "Ghost length comp data, "
		}
		else {
			filenamestart <- "comp_gstlenfit_"
			titledata     <- "Ghost length comps, "
		}
	}
	if (kind == "SIZE") {
		dbase_kind       <- sizedbase[sizedbase$method == sizemethod,]
		if (!is.null(sizebinlabs)) {
			kindlab <- labels[15]
			axis1 <- sort(unique(dbase_kind$Bin))
			if (length(sizebinlabs) == length(axis1)) {
				axis1labs <- sizebinlabs
			}
			else {
				axis1labs <- axis1
				warning("Input 'sizebinlabs' differs in length from the unique Bin\n", "  values associated with sizemethod=", sizemethod, ". Using bin values instead.")
			}
		}
		else {
			sizeunits <- unique(dbase_kind$units)
			if (length(sizeunits) > 1) {
				stop("!error with size units in generalized size comp plots:\n", "   more than one unit value per method.\n")
			}
			if (sizeunits %in% c("in", "cm")) {
				kindlab <- paste(labels[10], " (", sizeunits, ")", sep="")
			}
			if (sizeunits %in% c("lb", "kg")) {
				kindlab <- paste(labels[9], " (", sizeunits, ")", sep="")
			}
		}
		if (datonly) {
			filenamestart <- "comp_sizedat_"
			titledata <- "Size comp data, "
		}
		else {
			filenamestart <- "comp_sizefit_"
			titledata <- "Size comps, "
		}
		if (length(unique(sizedbase$method)) > 1) {
			filenamestart <- paste0(filenamestart, "method", sizemethod, "_")
			titledata <- paste0(titledata, " size method ", sizemethod, ", ")
		}
	}
	if (kind == "AGE") {
		dbase_kind <- agedbase
		kindlab=labels[2]
		if (datonly) {
			filenamestart <- "comp_agedat_"
			titledata <- "Age comp data, "
		}
		else {
			filenamestart <- "comp_agefit_"
			titledata <- "Age comps, "
		}
	}
	if (kind == "cond") {
		dbase_kind <- condbase
		kindlab=labels[2]
		if (datonly) {
			filenamestart <- "comp_condAALdat_"
			titledata <- "Conditional age-at-length data, "
		}
		else {
			filenamestart <- "comp_condAALfit_"
			titledata <- "Conditional age-at-length, "
		}
	}
	if (kind == "GSTAGE") {
		dbase_kind <- ghostagedbase
		kindlab=labels[2]
		if (datonly) {
			filenamestart <- "comp_gstagedat_"
			titledata <- "Ghost age comp data, "
		}
		else {
			filenamestart <- "comp_gstagefit_"
			titledata <- "Ghost age comps, "
		}
	}
	if (kind == "GSTcond") {
		dbase_kind <- ghostagedbase
		kindlab=labels[2]
		if (datonly) {
			filenamestart <- "comp_gstCAALdat_"
			titledata <- "Ghost conditional age-at-length data, "
		}
		else {
			filenamestart <- "comp_gstCAALfit_"
			titledata <- "Ghost conditional age-at-length comps, "
		}
	}
	if (kind == "L@A") {
		dbase_kind <- ladbase[ladbase$Nsamp_adj != 0, ]
		kindlab=labels[2]
		if (datonly) {
			filenamestart <- "comp_LAAdat_"
			titledata <- "Mean length at age data, "
		}
		else {
			filenamestart <- "comp_LAAfit_"
			titledata <- "Mean length at age fit, "
		}
		dbase_kind$SD <- dbase_kind$Lbin_lo/dbase_kind$Nsamp_adj
	}
	if (kind == "W@A") {
		dbase_kind <- wadbase[wadbase$Nsamp_adj != 0, ]
		kindlab=labels[2]
		if (datonly) {
			filenamestart <- "comp_WAAdat_"
			titledata <- "Mean weight at age data, "
		}
		else {
			filenamestart <- "comp_WAAfit_"
			titledata <- "Mean weight at age fit, "
		}
		dbase_kind$SD <- dbase_kind$Lbin_lo/dbase_kind$Nsamp_adj
	}
	if (!(kind %in% c("LEN", "SIZE", "AGE", "cond", "GSTAGE", "GSTLEN", "L@A", "W@A"))) {
		stop("Input 'kind' to plotSS.comps needs to be one of the following:\n  ", "'LEN','SIZE','AGE','cond','GSTAGE','GSTLEN','L@A','W@A'.")
	}
	if (nrow(dbase_kind) > 0) {
		if (aggregates_by_mkt) {
			dbase_kind$Part_group <- dbase_kind$Part
		}
		else {
			dbase_kind$Part_group <- -1
		}
	}
	if (any(dbase_kind$SuprPer == "Sup" & dbase_kind$Used == "skip")) {
		cat("Note: removing super-period composition values labeled 'skip'\n", "   and designating super-period values with a '*'\n")
		dbase_kind <- dbase_kind[dbase_kind$SuprPer == "No" | dbase_kind$Used != "skip", ]
		dbase_kind$YrSeasName <- paste(dbase_kind$YrSeasName, ifelse(dbase_kind$SuprPer == "Sup", "*", ""), sep="")
	}
	ageerr_warning <- TRUE
	dbase_kind <- dbase_kind[dbase_kind$Fleet %in% fleets & dbase_kind$sex %in% sexes, ]
	for (f in fleets) {
		if (length(dbase_kind$Obs[dbase_kind$Fleet == f]) > 0) {
			dbasef <- dbase_kind[dbase_kind$Fleet == f, ]
			if (kind %in% c("cond", "GSTcond") && f %in% Age_tuning$Fleet) {
				HarmEffNage <- NULL
				MeanNage    <- NULL
			}
			else {
				HarmEffNage <- NULL
				MeanNage    <- NULL
			}
			dbase_k <- dbasef
			for (j in unique(dbase_k$Part)) {
				dbase <- dbase_k[dbase_k$Part == j, ]
				max_n_ageerr <- max(apply(table(dbase$Yr.S, dbase$Ageerr) > 0, 1, sum))
				if (max_n_ageerr > 1) {
					if (ageerr_warning) {
						cat("Note: multiple samples with different ageing error types within fleet/year.\n", "   Plots label '2005a3' indicates ageing error type 3 for 2005 sample.\n", "   Bubble plots may be misleading with overlapping bubbles.\n")
						ageerr_warning <- FALSE
					}
					dbase$Yr.S <- dbase$Yr.S + dbase$Ageerr/1000
					dbase$YrSeasName <- paste(dbase$YrSeasName, "a", dbase$Ageerr, sep="")
				}
				if (j == 0) 
					titlemkt <- "whole catch, "
				if (j == 1) 
					titlemkt <- "discard, "
				if (j == 2) 
					titlemkt <- "retained, "
				titlemkt <- ifelse(printmkt, titlemkt, "")
				if (datonly | fitbar) 
					bars <- TRUE
				else bars <- FALSE
				title_sexmkt <- paste(titlesex, titlemkt, sep="")
				filename_fltsexmkt <- paste("flt", f, filesex, "mkt", j, sep="")
				if (1 %in% subplots & kind != "cond") {
					caption <- paste(titledata, title_sexmkt, fleetnames[f], sep="")
					if (mainTitle) {
						ptitle <- caption
					}
					else {
						ptitle <- ""
					}
					titles <- c(ptitle, titles)
					tempfun <- function(ipage, l="e", ...) {
						sexvec <- dbase$sex
#browser();return()
						if (!(kind %in% c("GSTAGE", "GSTLEN", "L@A", "W@A"))) {
							if ("DM_effN" %in% names(dbase) && any(!is.na(dbase$DM_effN))) {
								make.multifig(ptsx=dbase$Bin, ptsy=dbase$Obs, 
									yr=dbase$Yr.S, linesx=dbase$Bin, 
									linesy=dbase$Exp, sampsize=dbase$Nsamp_adj, 
									effN=dbase$DM_effN, showsampsize=showsampsize, 
									showeffN=showeffN, sampsize_label="N input=", 
									effN_label="N samp.=", bars=bars, 
									linepos=(1 - datonly) * linepos, 
									nlegends=3, legtext=list(dbase$YrSeasName, "sampsize", "effN"),
									main=ptitle, cex.main=cex.main, xlab=kindlab, 
									ylab=labels[6], maxrows=maxrows, 
									maxcols=maxcols, rows=rows, cols=cols, 
									fixdims=fixdims, ipage=ipage, scalebins=scalebins, 
									colvec=colvec, linescol=linescol, 
									xlas=xlas, ylas=ylas, axis1=axis1, 
									axis2=axis2, axis1labs=axis1labs, 
									sexvec=sexvec, yupper=yupper, lang=l, ...)
							}
							else {
								if (all(dbase$Nsamp_adj==dbase$Nsamp_in)) {
									sslab = "N samps obs = "
									obsN  = 0
								} else {
									sslab = "N samps wtd = "
									obsN = dbase$Nsamp_in
								}
#browser();return()
								make.multifig(ptsx=dbase$Bin, ptsy=dbase$Obs, 
									yr=dbase$Yr.S, linesx=dbase$Bin, 
									linesy=dbase$Exp, sampsize=dbase$Nsamp_adj, 
									effN=dbase$effN, showsampsize=showsampsize, 
									showeffN=showeffN, sampsize_label=sslab, 
									effN_label="N eff.=", bars=bars, 
									linepos=(1 - datonly) * linepos, 
									nlegends=3, legtext=list(dbase$YrSeasName, "sampsize", "effN"),
									main=ptitle, cex.main=cex.main, xlab=kindlab, 
									ylab=labels[6], maxrows=maxrows, 
									maxcols=maxcols, rows=rows, cols=cols, 
									fixdims=fixdims, ipage=ipage, scalebins=scalebins, 
									colvec=colvec, linescol=linescol, 
									xlas=xlas, ylas=ylas, axis1=axis1, 
									axis2=axis2, axis1labs=axis1labs, 
									sexvec=sexvec, yupper=yupper, lang=l, obsN=obsN, ...)
							}
						}
						if (kind == "GSTAGE") {
							make.multifig(ptsx=dbase$Bin, ptsy=dbase$Obs, 
								yr=dbase$Yr.S, linesx=dbase$Bin, 
								linesy=dbase$Exp, sampsize=dbase$Nsamp_adj, 
								effN=dbase$effN, showsampsize=FALSE, 
								showeffN=FALSE, bars=bars,
								linepos=(1-datonly) * linepos, nlegends=3,
								legtext=list(dbase$YrSeasName, "sampsize", "effN"),
								main=ptitle, cex.main=cex.main, xlab=kindlab, 
								ylab=labels[6], maxrows=maxrows, 
								maxcols=maxcols, rows=rows, cols=cols, 
								fixdims=fixdims, ipage=ipage, scalebins=scalebins, 
								colvec=colvec, linescol=linescol, 
								xlas=xlas, ylas=ylas, axis1=axis1, 
								axis2=axis2, axis1labs=axis1labs, 
								sexvec=sexvec, yupper=yupper, lang=l, ...)
						}
						if (kind == "GSTLEN") {
							make.multifig(ptsx=dbase$Bin, ptsy=dbase$Obs, 
								yr=dbase$Yr.S, linesx=dbase$Bin, 
								linesy=dbase$Exp, sampsize=dbase$Nsamp_adj, 
								effN=dbase$effN, showsampsize=FALSE, 
								showeffN=FALSE, bars=bars,
								linepos=(1-datonly) * linepos, nlegends=3,
								legtext=list(dbase$YrSeasName, "sampsize", "effN"),
								main=ptitle, cex.main=cex.main, xlab=kindlab, 
								ylab=labels[6], maxrows=maxrows, 
								maxcols=maxcols, rows=rows, cols=cols, 
								fixdims=fixdims, ipage=ipage, scalebins=scalebins, 
								colvec=colvec, linescol=linescol, 
								xlas=xlas, ylas=ylas, axis1=axis1, 
								axis2=axis2, axis1labs=axis1labs, 
								sexvec=sexvec, lang=l, ...)
						}
						if (kind %in% c("L@A", "W@A")) {
							make.multifig(ptsx=dbase$Bin, ptsy=dbase$Obs, 
								yr=dbase$Yr.S, linesx=dbase$Bin, 
								linesy=dbase$Exp, ptsSD=dbase$SD, 
								sampsize=dbase$Nsamp_adj, effN=0, 
								showsampsize=FALSE, showeffN=FALSE, 
								nlegends=1, legtext=list(dbase$YrSeasName), 
								bars=bars, linepos=(1-datonly) * linepos,
								main=ptitle, cex.main=cex.main, 
								xlab=kindlab, ylab=ifelse(kind=="W@A", labels[9], labels[1]),
								maxrows=maxrows, maxcols=maxcols, rows=rows, cols=cols, 
								fixdims=fixdims, ipage=ipage, scalebins=scalebins, 
								colvec=colvec, linescol=linescol, 
								xlas=xlas, ylas=ylas, axis1=axis1, 
								axis2=axis2, axis1labs=axis1labs, 
								sexvec=sexvec, lang=l, ...)
						}
					} ## end tempfun
					if (plot) 
						tempfun(ipage=0, l=lang, ...)
					if (print) {
						npages <- if (fixdims) ceiling(length(unique(dbase$Yr.S))/maxrows/maxcols) else 1  ## (RH 200825)
						for (ipage in 1:npages) {
							pagetext <- ""
							caption_count <- ""
							if (npages > 1) {
								pagetext <- paste0("_page", ipage)
								caption_count <- paste0(" (plot ", ipage, " of ", npages, ")")
							}
							caption_extra <- ""
							if (ipage == 1) {
								if ("DM_effN" %in% names(dbase) && any(!is.na(dbase$DM_effN))) {
									ipar <- replist$age_data_info$ParmSelect[f]
									Theta <- as.numeric(replist$Dirichlet_Multinomial_pars$Theta[ipar])
									caption_extra <- paste0(".<br><br>'N input' is the input sample size. ", "'N samp.' is the sample size after adjustment by the ", "Dirichlet-Multinomial <i>&#920</i> parameter based on the ", "formula N samp.=1 / (1+<i>&#920</i>) + N * <i>&#920</i> / (1+<i>&#920</i>). ", "<br><br>For this fleet, <i>&#920</i>=", round(Theta, 3), " and the sample size multiplier is approximately ", "<i>&#920</i> / (1+<i>&#920</i>)=", round(Theta/(1 + Theta), 3), "<br><br>For more info, see<br>", "<blockquote>", "Thorson, J.T., Johnson, K.F., ", "Methot, R.D. and Taylor, I.G. 2017. ", "Model-based estimates of effective sample size ", "in stock assessment models using the ", "Dirichlet-multinomial distribution. ", "<i>Fisheries Research</i>", "192: 84-93. ", "<a href=https://doi.org/10.1016/j.fishres.2016.06.005>", "https://doi.org/10.1016/j.fishres.2016.06.005</a>", "</blockquote>")
								}
								else {
									caption_extra <- paste0(".<br><br>'N samp.' is the input sample size ", "after data-weighting adjustment. ", "N eff. is the calculated effective sample size used ", "in the McAllister-Iannelli tuning method.")
								}
							}
							if (!is.null(ttcall(outnam)))
								file = paste0(sub("\\.png$","",outnam),f,".png")
							else
								file <- paste(filenamestart, filename_fltsexmkt, pagetext, ".png", sep="")
#browser();return()
							plotinfo <- pngfun(file=file, caption=paste0(caption, caption_count, caption_extra), lang=lang)
							tempfun(ipage=ipage, l=lang, ...)
							dev.off(); eop()
						}
					}
				}
				if (datonly) {
					z <- dbase$Obs
					if (scalebubbles) {
						z <- dbase$Nsamp_adj * dbase$Obs
					}
					col <- rep("black", 2)
					titletype <- titledata
					filetype <- "bub"
					allopen <- TRUE
				}
				else {
					z <- dbase$Pearson
					col <- rep(colvec[3], 2)
					titletype <- "Pearson residuals, "
					filetype <- "resids"
					allopen <- FALSE
				}
#browser();return()
				if (2 %in% subplots & bub & kind != "cond") {
					if (length(cohortlines) > 0) {
						growdat <- replist$endgrowth
						growdatF <- growdat[growdat$Sex == 1 & growdat$Morph == min(growdat$Morph[growdat$Sex == 1]), ]
						if (nsexes > 1) {
							growdatM <- growdat[growdat$Sex == 2 & growdat$Morph == min(growdat$Morph[growdat$Sex == 2]), ]
						}
					}
					caption <- paste(titletype, title_sexmkt, fleetnames[f], sep="")
					caption <- paste(caption, " (max=", round(max(z), digits=2), ")", sep="")
					if (mainTitle) {
						ptitle <- caption
					}
					else {
						ptitle <- ""
					}
					titles <- c(ptitle, titles)

					tempfun2 <- function(l="e") {
						xvals <- dbase$Yr.S
						xdiff <- 0.1 * sort(unique(diff(sort(unique(dbase$Yr.S)), na.rm=TRUE)))[1]
						if (is.na(xdiff)) {
							xdiff <- 0.1
						}
						cols <- rep(colvec[3], nrow(dbase))
						if (nsexes > 1) {
							xvals[dbase$sex > 0] <- dbase$Yr.S[dbase$sex > 0] - (dbase$sex[dbase$sex > 0] - 1.5) * xdiff
							if (length(unique(dbase$Yr.S)) == 1) {
								xvals[dbase$sex > 0] <- floor(dbase$Yr.S[dbase$sex > 0]) - (dbase$sex[dbase$sex > 0] - 1.5) * xdiff
							}
							cols[dbase$sex > 0] <- colvec[dbase$sex[dbase$sex > 0]]
						}
						r4ss:::bubble3(x=xvals, y=dbase$Bin, z=z, xlab=linguaFranca(labels[3],l), ylab=linguaFranca(kindlab,l), col=cols, cexZ1=cexZ1, legend=linguaFranca(bublegend,l), las=1, main=linguaFranca(ptitle,l), cex.main=cex.main, maxsize=pntscalar, allopen=allopen, minnbubble=minnbubble)
						if (length(cohortlines) > 0) {
							for (icohort in 1:length(cohortlines)) {
								cat("  Adding line for", cohortlines[icohort], "cohort\n")
								if (kind == "LEN") {
									if (nsexes > 1) {
										lines(growdatF$Age_Mid + cohortlines[icohort], growdatF$Len_Mid, col=colvec[1])
										lines(growdatM$Age_Mid + cohortlines[icohort], growdatM$Len_Mid, col=colvec[2])
									}
									else {
										lines(growdatF$Age_Mid + cohortlines[icohort], growdatF$Len_Mid, col=colvec[3])
									}
								}
								if (kind %in% c("AGE", "GSTAGE")) {
									lines(0.5 + c(cohortlines[icohort], cohortlines[icohort] + accuage), c(0, accuage), col=colvec[3], lty=3)
								}
							}
						}
					} ## end tempfun2 
					if (plot) 
						tempfun2(l=lang)
					if (print) {
						pagetext <- ""
						if (npages > 1) {
							pagetext <- paste("_page", ipage, sep="")
							caption <- paste(caption, " (plot ", ipage, " of ", npages, ")", sep="")
						}
						if (length(grep("Pearson", caption)) > 0) {
							caption <- paste(caption, "<br> \nClosed bubbles are positive residuals", "(observed > expected)", "and open bubbles are negative residuals", "(observed < expected).")
						}
						if (!is.null(ttcall(outnam)))
							file = paste0(sub("\\.png$","",outnam),f,".png")
						else
							file <- paste(filenamestart, filetype, filename_fltsexmkt, pagetext, ".png", sep="")
						plotinfo <- pngfun(file=file, caption=caption, lang=lang)
						tempfun2(l=lang)
						dev.off(); eop()
					}
				}
				if (3 %in% subplots & kind == "cond") {
					caption <- paste(titletype, title_sexmkt, fleetnames[f], sep="")
					caption <- paste(caption, " (max=", round(max(z), digits=2), ")", sep="")
					if (mainTitle) {
						ptitle <- caption
					}
					else {
						ptitle <- ""
					}
					titles <- c(ptitle, titles)
					sampsizeline.old <- sampsizeline
					effNline.old <- effNline
					if (is.logical(sampsizeline) && sampsizeline) {
						sampsizeline <- max(dbase$Bin)/max(dbase$Nsamp_adj, na.rm=TRUE)
						if (!datonly && is.logical(effNline) && effNline) {
							sampsizeline <- effNline <- max(dbase$Bin)/max(dbase$Nsamp_adj, dbase$effN, na.rm=TRUE)
							cat("  Fleet ", f, " ", titlesex, "adj. input & effective N in red & green scaled by ", effNline, "\n", sep="")
						}
						else {
							cat("  Fleet ", f, " ", titlesex, "adj. input N in red scaled by ", sampsizeline, "\n", sep="")
						}
					}
					tempfun3 <- function(ipage, l="e", ...) {
						sexvec <- dbase$sex
						col.index <- sexvec
						col.index[col.index == 0] <- 3
						cols <- colvec[col.index]
						yrvec <- dbase$Yr.S + dbase$sex * 1e-06
						make.multifig(ptsx=dbase$Bin, ptsy=dbase$Lbin_mid, 
							yr=yrvec, size=z, sampsize=dbase$Nsamp_adj, 
							showsampsize=showsampsize, effN=dbase$effN, 
							showeffN=FALSE, cexZ1=cexZ1, bublegend=bublegend, 
							nlegends=1, legtext=list(dbase$YrSeasName), 
							bars=FALSE, linepos=0, main=ptitle, 
							cex.main=cex.main, xlab=labels[2], 
							ylab=labels[1], ymin0=FALSE, maxrows=maxrows2, 
							maxcols=maxcols2, fixdims=fixdims, 
							allopen=allopen, minnbubble=minnbubble, 
							ptscol=cols, ipage=ipage, scalebins=scalebins, 
							sampsizeline=sampsizeline, effNline=effNline, 
							sampsizemean=MeanNage, effNmean=HarmEffNage, 
							colvec=colvec, linescol=linescol, xlas=xlas, 
							ylas=ylas, axis1=axis1, axis2=axis2, 
							axis1labs=axis1labs, sexvec=sexvec, lang=l, ...)
					} ## end tempfun3
					if (plot) 
						tempfun3(ipage=0, l=lang, ...)
					if (print) {
						npages <- if (fixdims) ceiling(length(unique(dbase$Yr.S)) * length(unique(dbase$sex))/maxrows2/maxcols2) else 1  ## (RH 200825)
						for (ipage in 1:npages) {
							pagetext <- ""
							if (npages > 1) {
								pagetext <- paste("_page", ipage, sep="")
								caption <- paste(caption, " (plot ", ipage, " of ", npages, ")", sep="")
							}
							if (!is.null(ttcall(outnam)))
								file = paste0(sub("\\.png$","",outnam), f, letters[ipage], ".png")
							else
								file <- paste(filenamestart, filetype, filename_fltsexmkt, pagetext, ".png", sep="")
							plotinfo <- pngfun(file=file, caption=caption, lang=lang)
							tempfun3(ipage=ipage, l=lang, ...)
							dev.off(); eop()
						}
					}
					sampsizeline <- sampsizeline.old
					effNline <- effNline.old
				}
				if ((4 %in% subplots | 5 %in% subplots) & aalyear[1] > 0 & kind == "cond") {
					for (y in 1:length(aalyear)) {
						aalyr <- aalyear[y]
						if (length(dbase$Obs[dbase$Yr == aalyr]) > 0) {
							ydbase <- dbase[dbase$Yr == aalyr, ]
							sexvec <- ydbase$sex
							if (4 %in% subplots) {
								caption <- paste(aalyr, " age-at-length bin, ", title_sexmkt, fleetnames[f], sep="")
								if (mainTitle) {
									ptitle <- caption
								}
								else {
								ptitle <- ""
								}
								titles <- c(ptitle, titles)
								lenbinlegend <- paste(ydbase$Lbin_lo, labels[7], sep="")
								lenbinlegend[ydbase$Lbin_range > 0] <- paste(ydbase$Lbin_lo, "-", ydbase$Lbin_hi, labels[7], sep="")
								tempfun4 <- function(ipage, l="e", ...) {
									make.multifig(ptsx=ydbase$Bin, ptsy=ydbase$Obs, 
										yr=ydbase$Lbin_lo, linesx=ydbase$Bin, 
										linesy=ydbase$Exp, sampsize=ydbase$Nsamp_adj, 
										effN=ydbase$effN, showsampsize=showsampsize, 
										showeffN=showeffN, nlegends=3, 
										legtext=list(lenbinlegend, "sampsize", "effN"),
										bars=FALSE, linepos=linepos, 
										main=ptitle, cex.main=cex.main, 
										xlab=labels[2], ylab=labels[6], 
										maxrows=maxrows, maxcols=maxcols, 
										rows=rows, cols=cols, fixdims=fixdims, 
										ipage=ipage, scalebins=scalebins, 
										xlas=xlas, ylas=ylas, axis1=axis1, 
										axis2=axis2, axis1labs=axis1labs, 
										sexvec=sexvec, yupper=yupper, lang=l, ...)
								} ## end tempfun4
								if (plot) 
									tempfun4(ipage=0, l=lang, ...)
								if (print) {
									npages <- if (fixdims) ceiling(length(unique(ydbase$Yr.S))/maxrows/maxcols) else 1  ## (RH 200825)
									for (ipage in 1:npages) {
										pagetext <- ""
										if (npages > 1) {
											pagetext <- paste("_page", ipage, sep="")
											caption <- paste(caption, " (plot ", ipage, " of ", npages, ")", sep="")
										}
										if (length(grep("Pearson", caption)) > 0) {
											caption <- paste(caption, "<br> \nClosed bubbles are positive residuals", "(observed > expected)", "and open bubbles are negative residuals", "(observed < expected).")
										}
										if (!is.null(ttcall(outnam)))
											file = paste0(sub("\\.png$","",outnam), f, letters[ipage], ".png")
										else
											file <- paste0(filenamestart, filename_fltsexmkt, "_", aalyr, pagetext, ".png")
										plotinfo <- pngfun(file=file, caption=caption, lang=lang)
										tempfun4(ipage=ipage, l=lang, ...)
										dev.off(); eop()
									}
								}
							}
							if (5 %in% subplots) {
								z <- ydbase$Pearson
								col.index <- sexvec
								col.index[col.index == 0] <- 3
								cols <- colvec[col.index]
								x.vec <- ydbase$Bin + ydbase$sex * 1e-06
								caption <- paste(aalyr, " Pearson residuals for A-L key, ", title_sexmkt, fleetnames[f], sep="")
								caption <- paste(caption, " (max=", round(abs(max(z)), digits=2), ")", sep="")
								if (mainTitle) {
									ptitle <- caption
								}
								else {
									ptitle <- ""
								}
								titles <- c(ptitle, titles)
								tempfun5 <- function(l="e") {
									r4ss:::bubble3(x=x.vec, y=ydbase$Lbin_lo, z=z, xlab=linguaFranca(labels[2],l), ylab=linguaFranca(labels[1],l), col=cols, las=1, main=linguaFranca(ptitle,l), cex.main=cex.main, maxsize=pntscalar, cexZ1=cexZ1, legend=linguaFranca(bublegend,l), allopen=FALSE, minnbubble=minnbubble)
								} ## end tempfun5
								if (plot) 
									tempfun5(l=lang)
								if (print) {
									pagetext <- ""
									if (npages > 1) {
										pagetext <- paste("_page", ipage, sep="")
										caption <- paste(caption, " (plot ", ipage, " of ", npages, ")", sep="")
									}
									if (length(grep("Pearson", caption)) > 0) {
										caption <- paste(caption, "<br> \nClosed bubbles are positive residuals", "(observed > expected)", "and open bubbles are negative residuals", "(observed < expected).")
									}
									if (!is.null(ttcall(outnam)))
										file = paste0(sub("\\.png$","",outnam), f, ".png")
									else
										file <- paste0(filenamestart, "yearresids_", filename_fltsexmkt, "_", aalyr, pagetext, ".png")
									plotinfo <- pngfun(file=file, caption=caption, lang=lang)
									tempfun5(l=lang)
									dev.off(); eop()
								}
							}
						}
					}
				}
				if (6 %in% subplots & aalbin[1] > 0) {
					badbins <- setdiff(aalbin, dbase$Lbin_hi)
					goodbins <- intersect(aalbin, dbase$Lbin_hi)
					if (length(goodbins) > 0) {
						if (length(badbins) > 0) {
							cat("Error! the following inputs for 'aalbin' do not match the Lbin_hi values for the conditional age-at-length data:", badbins, "\n", "	   the following inputs for 'aalbin' are fine:", goodbins, "\n")
						}
						for (ibin in 1:length(goodbins)) {
							ilenbin <- goodbins[ibin]
							abindbase <- dbase[dbase$Lbin_hi == ilenbin, ]
							if (nrow(abindbase) > 0) {
								sexvec <- abindbase$sex
								caption <- paste0("Age-at-length ", ilenbin, labels[7], ", ", title_sexmkt, fleetnames[f])
								if (mainTitle) {
									ptitle <- caption
								}
								else {
									ptitle <- ""
								}
								titles <- c(ptitle, titles)
								tempfun6 <- function(ipage, l="e", ...) {
									make.multifig(ptsx=abindbase$Bin, 
										ptsy=abindbase$Obs, yr=abindbase$Yr.S, 
										linesx=abindbase$Bin, linesy=abindbase$Exp, 
										sampsize=abindbase$Nsamp_adj, effN=abindbase$effN, 
										showsampsize=showsampsize, showeffN=showeffN, 
										nlegends=3, legtext=list(abindbase$YrSeasName, 
										  "sampsize", "effN"), bars=bars, 
										linepos=(1 - datonly) * linepos, 
										main=ptitle, cex.main=cex.main, 
										xlab=kindlab, ylab=labels[6], 
										maxrows=maxrows, maxcols=maxcols, 
										rows=rows, cols=cols, fixdims=fixdims, 
										ipage=ipage, scalebins=scalebins, 
										sexvec=sexvec, lang=l, ...)
								} ## end tempfun6
								if (plot) 
									tempfun6(ipage=0, l=lang, ...)
								if (print) {
									npages <- if (fixdims) ceiling(length(unique(abindbase$Yr.S))/maxrows/maxcols) else 1  ## (RH 200825)
									for (ipage in 1:npages) {
										pagetext <- ""
										if (npages > 1) {
											pagetext <- paste0("_page", ipage)
											caption <- paste0(caption, " (plot ", ipage, " of ", npages, ")")
										}
										if (!is.null(ttcall(outnam)))
											file = paste0(sub("\\.png$","",outnam), f, letters[ipage], ".png")
										else
											file <- paste0(filenamestart, filename_fltsexmkt, "_length", ilenbin, labels[7], pagetext, ".png")
										plotinfo <- pngfun(file=file, caption=caption, lang=lang)
										tempfun6(ipage=ipage, l=lang, ...)
										dev.off(); eop()
									}
								}
							}
						}
					}
				}
				if (7 %in% subplots & samplesizeplots & !datonly & !("DM_effN" %in% names(dbase) && any(!is.na(dbase$DM_effN))) & !(kind %in% c("GSTAGE", "GSTLEN", "L@A", "W@A"))) {
					caption <- paste0("N-EffN comparison, ", titledata, title_sexmkt, fleetnames[f])
					if (mainTitle) {
						ptitle <- caption
					}
					else {
						ptitle <- ""
					}
					titles <- c(ptitle, titles)
					lfitfunc <- function(l="e") {
						if (kind == "cond") {
							dbasegood <- dbase[dbase$Obs >= 1e-04 & dbase$Exp < 0.99 & !is.na(dbase$effN) & dbase$effN < maxneff, ]
						}
						else {
							dbasegood <- dbase
						}
						if (nrow(dbasegood) > 0) {
							dbasegood2 <- dbasegood[, c("YrSeasName", "Nsamp_adj", "effN", "Nsamp_in")]
							dbasegood2 <- unique(dbasegood2)
							#plot(dbasegood2$Nsamp_adj, dbasegood2$effN, xlab=linguaFranca(labels[4],l), main=linguaFranca(ptitle,l), cex.main=cex.main, ylim=c(0, 1.15 * max(dbasegood2$effN)), xlim=c(0, 1.15 * max(dbasegood2$Nsamp_adj)), col=colvec[3], pch=19, ylab=linguaFranca(labels[5],l), xaxs="i", yaxs="i")
							plot(dbasegood2$Nsamp_adj, dbasegood2$effN, xlab=linguaFranca(labels[4],l), main=linguaFranca(ptitle,l), cex.main=cex.main, ylim=c(0, 1.04 * max(dbasegood2$effN)), xlim=c(0, 1.10 * max(dbasegood2$Nsamp_adj)), col="black", bg="yellow", pch=21, ylab=linguaFranca(labels[5],l), xaxs="i", yaxs="i")
							if (showyears) {
								par(xpd=TRUE)
								text(x=dbasegood2$Nsamp_adj, y=dbasegood2$effN, linguaFranca(dbasegood2$YrSeasName,l), adj=c(-0.2, 0.5))
								par(xpd=FALSE)
							}
							#abline(0, 1, col="black", lty=1)
							abline(0, 1, col="darkslategrey", lty=1, lwd=2)
							if (smooth & length(unique(dbasegood2$Nsamp_adj)) > 6 & diff(range(dbasegood2$Nsamp_adj)) > 2) {
								old_warn <- options()$warn
								options(warn=-1)
								psmooth <- loess(dbasegood2$effN ~ dbasegood2$Nsamp_adj, degree=1)
								options(warn=old_warn)
								lines(psmooth$x[order(psmooth$x)], psmooth$fit[order(psmooth$x)], lwd=2, col="red", lty="dashed")
								#lmfit = lm(dbasegood2$effN ~ dbasegood2$Nsamp_adj); abline(lmfit,col="blue") ## (RH 210709)
							}
							if (addMeans) {
								col.hmr = "blue"
								abline(v=mean(dbasegood2$Nsamp_adj), lty="22", col=col.hmr)
								#text(x=mean(dbasegood2$Nsamp_adj), y=0, col=col.hmr, linguaFranca("arithmetic mean",l), srt=90, adj=c(-0.1, -0.3))
								text(x=mean(dbasegood2$Nsamp_adj), y=max(dbasegood2$effN), col=col.hmr, linguaFranca("arithmetic mean",l), srt=90, adj=c(1, -0.3))
								abline(h=1/mean(1/dbasegood2$effN), lty="22", col=col.hmr)
								text(x=0, y=1/mean(1/dbasegood2$effN), col=col.hmr, linguaFranca("harmonic mean",l), adj=c(-0.1, -0.3))
#browser();return()
							}
						}
					} ## end lfitfunc
					if (plot) 
						lfitfunc(l=lang)
					if (print) {
						if (!is.null(ttcall(outnam)))
							file = paste0(sub("\\.png$","",outnam), f, ".png")
						else
							file <- paste(filenamestart, "sampsize_", filename_fltsexmkt, ".png", sep="")
						plotinfo <- pngfun(file=file, caption=caption, lang=lang)
						lfitfunc(l=lang)
						dev.off(); eop()
					}
				}
				if (8 %in% subplots & kind %in% c("LEN", "SIZE", "AGE")) {
					kind2 <- tolower(kind)
					if (plot) {
						tmp <- SSMethod.TA1.8(fit=replist, type=kind2, fleet=f, fleetnames=fleetnames, datonly=datonly, printit=verbose)
					}
					if (print) {
						## Needs frenchification
						file <- paste0(filenamestart, "data_weighting_TA1.8_", fleetnames[f], ".png")
						png(filename=file.path(plotdir, file), width=pwidth, height=pheight, units=punits, res=res, pointsize=ptsize)
						tmp <- SSMethod.TA1.8(fit=replist, type=kind2, fleet=f, fleetnames=fleetnames, datonly=datonly, printit=verbose)
						caption <- paste0("Mean ", gsub("len", "length", tolower(kind)), " for ", fleetnames[f], " with 95% confidence intervals", " based on current samples sizes.")
						if (!is.null(replist$Dirichlet_Multinomial_pars)) {
							caption <- paste("WARNING: this figure is based on multinomial likelihood", "and has not been updated to account for Dirichlet-Multinomial", "likelihood and the sample size adjustment associated with", "the estimated log(<i>&#920</i>) parameters.<br><br>", caption)
						}
						if (!datonly) {
							caption <- paste0(caption, "<br>Francis data weighting method TA1.8:")
							if (!is.null(tmp[1])) {
								vals <- paste0("thinner intervals (with capped ends) show ", "result of further adjusting sample sizes ", "based on suggested multiplier ", "(with 95% interval) for ",  kind2, " data from ", fleetnames[f], ":<br>", round(tmp[1], 4), " (", round(tmp[2], 4), "-", round(tmp[3], 4), ")")
							}
							else {
								vals <- "too few points to calculate adjustments."
							}
							caption <- paste(caption, vals, "<br><br>For more info, see<br>", "<blockquote>Francis, R.I.C.C. (2011).", "Data weighting in statistical fisheries stock assessment", "models. <i>Can. J. Fish. Aquat. Sci.</i>", "68: 1124-1138. ", "<a href=https://doi.org/10.1139/f2011-025>", "https://doi.org/10.1139/f2011-025</a>", "</blockquote>")
						}
						plotinfo <- rbind(plotinfo, data.frame(file=file, caption=caption))
						dev.off(); eop()
					}
				}
				if (9 %in% subplots & kind == "cond" & (f %in% condbase$Fleet)) {
					if (plot) {
						SSMethod.Cond.TA1.8(fit=replist, fleet=f, fleetnames=fleetnames, datonly=datonly)
					}
					if (print) {
						## Needs frenchification
						file <- paste(filenamestart, "data_weighting_TA1.8_condAge", fleetnames[f], ".png", sep="")
						png(filename=file.path(plotdir, file), width=pwidth, height=pheight, units=punits, res=res, pointsize=ptsize)
						tmp <- SSMethod.Cond.TA1.8(fit=replist, fleet=f, fleetnames=fleetnames, datonly=datonly)
						caption <- paste0("Mean age from conditional data", " (aggregated across length bins) for ", fleetnames[f], " with 95% confidence intervals ", " based on current samples sizes.")
						if (!datonly) {
							caption <- paste0(caption, "<br>Francis data weighting method TA1.8:")
							if (!is.null(tmp[1])) {
								vals <- paste0("thinner intervals (with capped ends) show ", "result of further adjusting sample sizes ", "based on suggested multiplier ", "(with 95% interval) for ", "conditional age-at-length data from ", fleetnames[f], ":<br>", round(tmp[1], 4), " (", round(tmp[2], 4), "-", round(tmp[3], 4), ")", sep="")
							}
							else {
								vals <- "too few points to calculate adjustments."
							}
							caption <- paste(caption, vals, "<br><br>For more info, see<br>", "<blockquote>Francis, R.I.C.C. (2011).", "Data weighting in statistical fisheries stock assessment", "models. <i>Can. J. Fish. Aquat. Sci.</i>", "68: 1124-1138.</blockquote>")
						}
						plotinfo <- rbind(plotinfo, data.frame(file=file, caption=caption))
						dev.off(); eop()
					}
				}
				if (10 %in% subplots & kind == "cond" & length(unique(dbase$Bin)) > 1) {
					caption1 <- paste(labels[14], title_sexmkt, fleetnames[f], sep="")
					if (mainTitle) {
						ptitle <- caption1
					}
					else {
						ptitle <- ""
					}
					andrefun <- function(ipage=0, l="e") {
						Lens <- sort(unique(dbase$Lbin_lo))
						Yrs <- sort(unique(dbase$Yr.S))
						ymax <- 1.1 * max(dbase$Bin, na.rm=TRUE)
						xmax <- max(condbase$Lbin_hi, na.rm=TRUE)
						xmin <- min(condbase$Lbin_lo, na.rm=TRUE)
						npanels <- length(Yrs)
						npages <- npanels/andrerows
						panelrange <- 1:npanels
						if (npages > 1 & ipage != 0) 
							panelrange <- intersect(panelrange, 1:andrerows + andrerows * (ipage - 1))
						Yrs2 <- Yrs[panelrange]
						par(mfrow=c(andrerows, 2), mar=c(2, 4, 1, 1), oma=andre_oma)
						for (Yr in Yrs2) {
							y <- dbase[dbase$Yr.S == Yr, ]
							Size <- NULL
							Size2 <- NULL
							Obs <- NULL
							Obs2 <- NULL
							Pred <- NULL
							Pred2 <- NULL
							Upp <- NULL
							Low <- NULL
							Upp2 <- NULL
							Low2 <- NULL
							for (Ilen in Lens) {
								z <- y[y$Lbin_lo == Ilen, ]
								if (length(z[, 1]) > 0) {
									weightsPred <- z$Exp/sum(z$Exp)
									weightsObs <- z$Obs/sum(z$Obs)
									ObsV <- sum(z$Bin * weightsObs)
									ObsV2 <- sum(z$Bin * z$Bin * weightsObs)
									PredV <- sum(z$Bin * weightsPred)
									PredV2 <- sum(z$Bin * z$Bin * weightsPred)
									NN <- z$Nsamp_adj[1]
									if (max(z$Obs, na.rm=TRUE) > 1e-04 & !is.na(NN) && NN > 0) {
										Size <- c(Size, Ilen)
										Obs <- c(Obs, ObsV)
										Pred <- c(Pred, PredV)
										varn <- sqrt(PredV2 - PredV * PredV)/sqrt(NN)
										Pred2 <- c(Pred2, varn)
										varn <- sqrt(max(0, ObsV2 - ObsV * ObsV, na.rm=TRUE))/sqrt(NN)
										Obs2 <- c(Obs2, varn)
										Low <- c(Low, ObsV - 1.64 * varn)
										Upp <- c(Upp, ObsV + 1.64 * varn)
										if (NN > 1) {
											Size2 <- c(Size2, Ilen)
											Low2 <- c(Low2, varn * sqrt((NN - 1)/qchisq(0.95, NN)))
										  Upp2 <- c(Upp2, varn * sqrt((NN - 1)/qchisq(0.05, NN)))
										}
									}
								}
							}
							if (length(Obs) > 0) {
								plot(Size, Obs, type="n", xlab="", ylab=linguaFranca("Age",l), xlim=c(xmin, xmax), ylim=c(0, ymax), yaxs="i")
								label <- ifelse(nseasons == 1, floor(Yr), Yr)
								text(x=par("usr")[1], y=0.9 * ymax, labels=linguaFranca(label,l), adj=c(-0.5, 0), font=2, cex=1.2)
								if (length(Low) > 1) 
									polygon(c(Size, rev(Size)), c(Low, rev(Upp)), col="grey95", border=NA)
								if (!datonly) 
									lines(Size, Pred, col=4, lwd=3)
								points(Size, Obs, pch=16)
								lines(Size, Low, lty=3)
								lines(Size, Upp, lty=3)
								if (par("mfg")[1] == 1) {
									title(main=linguaFranca(ptitle,l), xlab=linguaFranca(labels[1],l), outer=TRUE, line=1)
								}
								box()
								ymax2 <- max(Obs2, Pred2, na.rm=TRUE) * 1.1
								plot(Size, Obs2, type="n", xlab=linguaFranca(labels[1],l), ylab=linguaFranca(labels[13],l), xlim=c(xmin, xmax), ylim=c(0, ymax2), yaxs="i")
								if (length(Low2) > 1) 
									polygon(c(Size2, rev(Size2)), c(Low2, rev(Upp2)), col="grey95", border=NA)
								if (!datonly) 
									lines(Size, Pred2, col=4, lwd=3)
								points(Size, Obs2, pch=16)
								lines(Size2, Low2, lty=3)
								lines(Size2, Upp2, lty=3)
								if (!datonly & par("mfg")[1] == 1) {
									legend("topleft", legend=linguaFranca(c("Observed (with 90% interval)", "Expected"),l), bty="n", col=c(1, 4), pch=c(16, NA), lty=c(NA, 1), lwd=3)
								}
								box()
							}
						}
					} ## end andrefun
					if (plot) 
						andrefun(l=lang)
					if (print) {
						npages <- if (fixdims) ceiling(length(unique(dbase$Yr.S))/andrerows) else 1  ## (RH 200825)
						for (ipage in 1:npages) {
							pagetext <- ""
							caption <- caption1
							if (npages > 1) {
								pagetext <- paste("_page", ipage, sep="")
								caption <- paste(caption, " (plot ", ipage, " of ", npages, ")", sep="")
							}
							if (ipage == 1) {
								caption <- paste(caption, "\nThese plots show mean age and std. dev. in conditional A@L.<br>", "Left plots are mean A@L by size-class (obs. and pred.) ", "with 90% CIs based on adding 1.64 SE of mean to the data.<br>", "Right plots in each pair are SE of mean A@L (obs. and pred.) ", "with 90% CIs based on the chi-square distribution.", sep="")
							}
							if (!is.null(ttcall(outnam)))
								file = paste0(sub("\\.png$","",outnam), f, letters[ipage], ".png")
							else
								file <- paste(filenamestart, "Andre_plots", filename_fltsexmkt, pagetext, ".png", sep="")
							plotinfo <- pngfun(file=file, caption=caption, lang=lang)
							andrefun(ipage=ipage, l=lang)
							dev.off(); eop()
						}
					}
				}
			}
		}
	}
	if (21 %in% subplots & kind != "cond") {
		if (nrow(dbase_kind) > 0) {
			dbase_k <- dbase_kind
			for (j in unique(dbase_k$Part_group)) {
				dbase <- dbase_k[dbase_k$Part_group == j, ]
				if (nrow(dbase) > 0) {
					if (j == -1) 
						titlemkt <- ""
					if (j == 0) 
						titlemkt <- "whole catch, "
					if (j == 1) 
						titlemkt <- "discard, "
					if (j == 2) 
						titlemkt <- "retained, "
					titlemkt <- ifelse(printmkt, titlemkt, "")
					if (datonly | fitbar) {
						bars <- TRUE; polygons=FALSE
					}
					else {
						bars <- FALSE; polygons=TRUE
					}
					title_sexmkt <- paste(titlesex, titlemkt, sep="")
					filename_fltsexmkt <- paste(filesex)
					if (j > -1) {
						filename_fltsexmkt <- paste0(filename_fltsexmkt, "mkt", j)
					}
					caption <- paste(titledata, title_sexmkt, "aggregated across time by fleet", sep="")
					if (mainTitle) {
						ptitle <- caption
					}
					else {
						ptitle <- ""
					}
					titles <- c(ptitle, titles)
					Bins <- sort(unique(dbase$Bin))
					nbins <- length(Bins)
					df <- data.frame(Nsamp_adj=dbase$Nsamp_adj, effN=dbase$effN, obs=dbase$Obs * dbase$Nsamp_adj, exp=dbase$Exp * dbase$Nsamp_adj)
					if ("DM_effN" %in% names(dbase) && any(!is.na(dbase$DM_effN))) {
						df$DM_effN <- dbase$DM_effN
					}
					agg <- aggregate(x=df, by=list(bin=dbase$Bin, f=dbase$Fleet, sex=dbase$sex, mkt=dbase$Part), FUN=sum)
					agg <- agg[agg$f %in% fleets, ]
					agg$obs <- agg$obs/agg$Nsamp_adj
					agg$exp <- agg$exp/agg$Nsamp_adj
					for (f in unique(agg$f)) {
						for (mkt in unique(agg$mkt[agg$f == f])) {
							sub <- agg$f == f & agg$mkt == mkt
							agg$Nsamp_adj[sub] <- max(agg$Nsamp_adj[sub])
							if ("DM_effN" %in% names(agg) && any(!is.na(agg$DM_effN))) {
								agg$DM_effN[sub] <- max(agg$DM_effN[sub], na.rm=TRUE)
							}
							else {
								if (any(!is.na(agg$effN[sub]))) {
									agg$effN[sub] <- max(agg$effN[sub], na.rm=TRUE)
								}
								else {
									agg$effN[sub] <- NA
								}
							}
						}
					}
					namesvec <- fleetnames[agg$f]
					max_n_mkt <- max(apply(table(agg$f, agg$mkt) > 0, 1, sum))
					if (max_n_mkt > 0) {
						mktnames <- c("", "(discards)", "(retained)")
						namesvec <- paste(fleetnames[agg$f], mktnames[agg$mkt + 1])
					}
					if (!(kind %in% c("GSTAGE", "GSTLEN", "L@A", "W@A"))) {
						tempfun7 <- function(ipage, l="e", ...) {
							if ("DM_effN" %in% names(agg) && any(!is.na(agg$DM_effN))) {
								make.multifig(ptsx=agg$bin, ptsy=agg$obs, 
									yr=paste(agg$f, agg$mkt), linesx=agg$bin, 
									linesy=agg$exp, sampsize=agg$Nsamp_adj, 
									effN=agg$DM_effN, showsampsize=showsampsize, 
									showeffN=showeffN, sampsize_label="Sum of N input=", 
									effN_label="Sum of N samp.=", bars=bars, 
									linepos=(1 - datonly) * linepos, 
									nlegends=3, legtext=list(namesvec, "sampsize", "effN"),
									main=ptitle, cex.main=cex.main, xlab=kindlab, 
									ylab=labels[6], maxrows=maxrows, 
									maxcols=maxcols, rows=rows, cols=cols, 
									fixdims=fixdims2, ipage=ipage, 
									scalebins=scalebins, colvec=colvec, 
									linescol=linescol, xlas=xlas, ylas=ylas, 
									axis1=axis1, axis2=axis2, axis1labs=axis1labs, 
									sexvec=agg$sex, yupper=yupper, lang=l, ...)
							}
							else {
								make.multifig(ptsx=agg$bin, ptsy=agg$obs, 
									yr=paste(agg$f, agg$mkt), linesx=agg$bin, 
									linesy=agg$exp, sampsize=agg$Nsamp_adj, 
									effN=agg$effN, showsampsize=showsampsize, 
									showeffN=showeffN, sampsize_label="Sum of N samp.=", 
									effN_label="Sum of N eff.=", bars=bars, 
									linepos=(1 - datonly) * linepos, 
									nlegends=3, legtext=list(namesvec, "sampsize", "effN"),
									main=ptitle, cex.main=cex.main, xlab=kindlab, 
									ylab=labels[6], maxrows=maxrows, 
									maxcols=maxcols, rows=rows, cols=cols, 
									fixdims=fixdims2, ipage=ipage, 
									scalebins=scalebins, colvec=colvec, 
									linescol=linescol, xlas=xlas, ylas=ylas, 
									axis1=axis1, axis2=axis2, axis1labs=axis1labs, 
									sexvec=agg$sex, yupper=yupper, lang=l, ...)
							}
						} ## end tempfun7
						if (plot) 
							tempfun7(ipage=0, l=lang, ...)
						if (print) {
							npages <- if (fixdims) ceiling(length(unique(agg$f))/maxrows/maxcols) else 1  ## (RH 200825)
							for (ipage in 1:npages) {
								if (max_n_mkt > 0) {
									caption <- paste0(caption, ".\n <br> ", "Labels 'retained' and 'discard' indicate", " discarded or retained sampled for each fleet.", " Panels without this designation represent", " the whole catch.\n")
								}
								pagetext <- ""
								if (npages > 1) {
									pagetext <- paste("_page", ipage, sep="")
									caption <- paste(caption, "<br> (plot ", ipage, " of ", npages, ")", sep="")
								}
								if (!is.null(ttcall(outnam)))
									file = paste0(sub("\\.png$","",outnam), f, letters[ipage], ".png")
								else
									file <- paste(filenamestart, filename_fltsexmkt, pagetext, "_aggregated_across_time.png", sep="")
								plotinfo <- pngfun(file=file, caption=caption, lang=lang)
								tempfun7(ipage=ipage, l=lang, ...)
								dev.off(); eop()
							}
						}
					}
					else {
					}
				}
			}
		}
	}
	if (22 %in% subplots & kind != "cond" & nseasons > 1) {
		dbasef <- dbase_kind[dbase_kind$Fleet %in% fleets, ]
		if ("DM_effN" %in% names(dbasef) && any(!is.na(dbasef$DM_effN))) {
			warning("Sample sizes in plots by fleet aggregating across years within each season have not yet been updated to reflect Dirichlet-Multinomial likelihood")
		}
		if (nrow(dbasef) > 0) {
			testor <- length(dbasef$sex[dbasef$sex == 1 & dbasef$Pick_sex == 0]) > 0
			testor[2] <- length(dbasef$sex[dbasef$sex == 1 & dbasef$Pick_sex %in% c(1, 3)]) > 0
			testor[3] <- length(dbasef$sex[dbasef$sex == 2]) > 0
			for (k in (1:3)[testor]) {
				if (k == 1) {
					dbase_k <- dbasef[dbasef$sex == 1 & dbasef$Pick_sex == 0, ]
				}
				if (k == 2) {
					dbase_k <- dbasef[dbasef$sex == 1 & dbasef$Pick_sex %in% c(1, 3), ]
				}
				if (k == 3) {
					dbase_k <- dbasef[dbasef$sex == 2, ]
				}
				sex <- ifelse(k == 3, 2, 1)
				for (j in unique(dbase_k$Part)) {
					dbase <- dbase_k[dbase_k$Part == j, ]
					if (nrow(dbase) > 0) {
						if (k == 1) 
							titlesex <- "sexes combined, "
						if (k == 2) 
							titlesex <- "female, "
						if (k == 3) 
							titlesex <- "male, "
						titlesex <- ifelse(printsex, titlesex, "")
						if (j == 0) 
							titlemkt <- "whole catch, "
						if (j == 1) 
							titlemkt <- "discard, "
						if (j == 2) 
							titlemkt <- "retained, "
						titlemkt <- ifelse(printmkt, titlemkt, "")
						if (datonly | fitbar) {
							bars <- TRUE; polygons=FALSE
						}
						else {
							bars <- FALSE; polygons=TRUE
						}
						title_sexmkt <- paste(titlesex, titlemkt, sep="")
						filename_fltsexmkt <- paste("sex", k, "mkt", j, sep="")
						caption <- paste0(titledata, title_sexmkt, "\naggregated within season by fleet")
						if (mainTitle) {
							ptitle <- caption
						}
						else {
							ptitle <- ""
						}
						titles <- c(ptitle, titles)
						Bins <- sort(unique(dbase$Bin))
						nbins <- length(Bins)
						df <- data.frame(Nsamp_adj=dbase$Nsamp_adj, effN=dbase$effN, obs=dbase$Obs * dbase$Nsamp_adj, exp=dbase$Exp * dbase$Nsamp_adj)
						agg <- aggregate(x=df, by=list(bin=dbase$Bin, f=dbase$Fleet, s=dbase$Seas), FUN=sum)
						agg <- agg[agg$f %in% fleets, ]
						if (any(agg$s <= 0)) {
							cat("super-periods may not work correctly in plots of aggregated comps\n")
							agg <- agg[agg$s > 0, ]
						}
						agg$obs <- agg$obs/agg$Nsamp_adj
						agg$exp <- agg$exp/agg$Nsamp_adj
						for (f in unique(agg$f)) {
							for (s in unique(agg$s[agg$f == f])) {
								infleetseas <- agg$f == f & agg$s == s
								agg$Nsamp_adj[infleetseas] <- max(agg$Nsamp_adj[infleetseas])
								agg$effN[infleetseas] <- max(agg$effN[infleetseas])
							}
						}
						agg$fseas <- agg$f + seasfracs[agg$s]
						namesvec <- paste(fleetnames[agg$f], " s", agg$s, sep="")
						tempfun8 <- function(ipage, l="e", ...) {
							if (!(kind %in% c("GSTAGE", "GSTLEN", "L@A", "W@A"))) {
								make.multifig(ptsx=agg$bin, ptsy=agg$obs, 
									yr=agg$fseas, linesx=agg$bin, linesy=agg$exp, 
									sampsize=agg$Nsamp_adj, effN=agg$effN, 
									showsampsize=showsampsize, showeffN=showeffN, 
									bars=bars, linepos=(1 - datonly) * linepos,
									nlegends=3, legtext=list(namesvec, "sampsize", "effN"),
									main=ptitle, cex.main=cex.main, xlab=kindlab, 
									ylab=labels[6], maxrows=maxrows, 
									maxcols=maxcols, rows=rows, cols=cols, 
									fixdims=fixdims2, ipage=ipage, 
									scalebins=scalebins, colvec=colvec, 
									linescol=linescol, xlas=xlas, ylas=ylas, 
									axis1=axis1, axis2=axis2, axis1labs=axis1labs, 
									sexvec=agg$sex, yupper=yupper, lang=l, ...)
							}
						} ## end tempfun8
						if (plot) 
							tempfun8(ipage=0, l=lang, ...)
						if (print) {
							npages <- if (fixdims) ceiling(length(unique(agg$fseas))/maxrows/maxcols) else 1  ## (RH 200825)
							for (ipage in 1:npages) {
								pagetext <- ""
								if (npages > 1) {
									pagetext <- paste("_page", ipage, sep="")
									caption <- paste(caption, " (plot ", ipage, " of ", npages, ")", sep="")
								}
								if (!is.null(ttcall(outnam)))
									file = paste0(sub("\\.png$","",outnam), f, letters[ipage], ".png")
								else
									file <- paste(filenamestart, filename_fltsexmkt, pagetext, "_aggregated_within_season.png", sep="")
								plotinfo <- pngfun(file=file, caption=caption, lang=lang)
								tempfun8(ipage=ipage, l=lang, ...)
								dev.off(); eop()
							}
						}
					}
				}
			}
		}
	}
	if (23 %in% subplots & kind != "cond" & nseasons > 1) {
		for (f in fleets) {
			dbasef <- dbase_kind[dbase_kind$Fleet == f, ]
			if ("DM_effN" %in% names(dbasef) && any(!is.na(dbasef$DM_effN))) {
				warning("Sample sizes in plots by fleet aggregating across seasons within a year have not yet been updated to reflect Dirichlet-Multinomial likelihood")
			}
			if (nrow(dbasef) > 0) {
				testor <- length(dbasef$sex[dbasef$sex == 1 & dbasef$Pick_sex == 0]) > 0
				testor[2] <- length(dbasef$sex[dbasef$sex == 1 & dbasef$Pick_sex %in% c(1, 3)]) > 0
				testor[3] <- length(dbasef$sex[dbasef$sex == 2]) > 0
				for (k in (1:3)[testor]) {
					if (k == 1) {
						dbase_k <- dbasef[dbasef$sex == 1 & dbasef$Pick_sex == 0, ]
					}
					if (k == 2) {
						dbase_k <- dbasef[dbasef$sex == 1 & dbasef$Pick_sex %in% c(1, 3), ]
					}
					if (k == 3) {
						dbase_k <- dbasef[dbasef$sex == 2, ]
					}
					sex <- ifelse(k == 3, 2, 1)
					for (j in unique(dbase_k$Part)) {
						dbase <- dbase_k[dbase_k$Part == j, ]
						if (nrow(dbase) > 0) {
							if (k == 1) 
								titlesex <- "sexes combined, "
							if (k == 2) 
								titlesex <- "female, "
							if (k == 3) 
								titlesex <- "male, "
							titlesex <- ifelse(printsex, titlesex, "")
							if (j == 0) 
								titlemkt <- "whole catch, "
							if (j == 1) 
								titlemkt <- "discard, "
							if (j == 2) 
								titlemkt <- "retained, "
							titlemkt <- ifelse(printmkt, titlemkt, "")
							if (datonly | fitbar) {
								bars <- TRUE; polgons=FALSE
							}
							else {
								bars <- FALSE; polgons=TRUE
							}
							title_sexmkt <- paste(titlesex, titlemkt, sep="")
							filename_fltsexmkt <- paste("flt", f, "sex", k, "mkt", j, sep="")
							Bins <- sort(unique(dbase$Bin))
							nbins <- length(Bins)
							df <- data.frame(Nsamp_adj=dbase$Nsamp_adj, effN=dbase$effN, obs=dbase$Obs * dbase$Nsamp_adj, exp=dbase$Exp * dbase$Nsamp_adj)
							agg <- aggregate(x=df, by=list(bin=dbase$Bin, f=dbase$Fleet, y=floor(dbase$Yr.S)), FUN=sum)
							agg <- agg[agg$f %in% fleets, ]
							agg$obs <- agg$obs/agg$Nsamp_adj
							agg$exp <- agg$exp/agg$Nsamp_adj
							for (f in unique(agg$f)) {
								for (y in unique(agg$y[agg$f == f])) {
									infleetyr <- agg$f == f & agg$y == y
									agg$Nsamp_adj[infleetyr] <- max(agg$Nsamp_adj[infleetyr])
									agg$effN[infleetyr] <- max(agg$effN[infleetyr])
								}
							}
							agg$fy <- agg$f + agg$y/10000
							caption <- paste(titledata, title_sexmkt, fleetnames[f], "\naggregated across seasons within year", sep="")
							if (mainTitle) {
								ptitle <- caption
							}
							else {
								ptitle <- ""
							}
							tempfun9 <- function(ipage, l="e", ...) {
								if (!(kind %in% c("GSTAGE", "GSTLEN", "L@A", "W@A"))) {
									make.multifig(ptsx=agg$bin, ptsy=agg$obs, 
										yr=agg$fy, linesx=agg$bin, linesy=agg$exp, 
										sampsize=agg$Nsamp_adj, effN=agg$effN, 
										showsampsize=showsampsize, showeffN=showeffN, 
										bars=bars, linepos=(1-datonly) * linepos,
										nlegends=3, legtext=list(agg$y, "sampsize", "effN"),
										main=ptitle, cex.main=cex.main, xlab=kindlab, 
										ylab=labels[6], maxrows=maxrows, 
										maxcols=maxcols, rows=rows, cols=cols, 
										fixdims=fixdims2, ipage=ipage, 
										scalebins=scalebins, colvec=colvec, 
										linescol=linescol, xlas=xlas, 
										ylas=ylas, axis1=axis1, axis2=axis2, 
										axis1labs=axis1labs, sexvec=agg$sex, 
										yupper=yupper, lang=l, ...)
								}
							} ## end tempfun9
							if (plot) 
								tempfun9(ipage=0, l=lang, ...)
							if (print) {
								npages <- if (fixdims) ceiling(length(unique(agg$fy))/maxrows/maxcols) else 1  ## (RH 200825)
								for (ipage in 1:npages) {
									pagetext <- ""
									if (npages > 1) {
										pagetext <- paste("_page", ipage, sep="")
										caption <- paste(caption, " (plot ", ipage, " of ", npages, ")", sep="")
									}
									if (!is.null(ttcall(outnam)))
										file = paste0(sub("\\.png$","",outnam), f, letters[ipage], ".png")
									else
										file <- paste(filenamestart, filename_fltsexmkt, pagetext, "_aggregated_across_seasons_within_year.png", sep="")
									pngfun(file=file, caption=caption, lang=lang)
									tempfun9(ipage=ipage, l=lang, ...)
									dev.off(); eop()
								}
							}
						}
					}
				}
			}
		}
	}
	if (24 %in% subplots & kind %in% c("LEN", "AGE")) {
		for (j in unique(dbase_kind$Part_group)) {
			dbase_parts <- dbase_kind[dbase_kind$Part_group == j, ]
			dbase_parts$FleetPart <- dbase_parts$Fleet + 0.1 * dbase_parts$Part
			panel_table <- data.frame(FleetPart=sort(unique(dbase_parts$FleetPart)))
			panel_table$Fleet <- floor(panel_table$FleetPart)
			panel_table$Part <- round(10 * (panel_table$FleetPart - panel_table$Fleet))
			panel_table$Name <- fleetnames[panel_table$Fleet]
			max_n_mkt <- max(apply(table(panel_table$Fleet, panel_table$Part) > 0, 1, sum))
			if (max_n_mkt > 1) {
				mktnames <- c("", "(discards)", "(retained)")
				panel_table$Name <- paste(panel_table$Name, mktnames[panel_table$Part + 1])
			}
			npanels <- nrow(panel_table)
			panelvec <- 1:npanels
			xlim <- range(dbase_parts$Yr.S)
			xaxislab <- sort(unique(floor(dbase_parts$Yr.S)))
			if (length(cohortlines) > 0) {
				growdat <- replist$endgrowth
				growdatF <- growdat[growdat$Sex == 1 & growdat$Morph == min(growdat$Morph[growdat$Sex == 1]), ]
				if (nsexes > 1) {
					growdatM <- growdat[growdat$Sex == 2 & growdat$Morph == min(growdat$Morph[growdat$Sex == 2]), ]
				}
			}
			if (j == -1)
				titlemkt <- ""
			if (j == 0)
				titlemkt <- "whole catch"
			if (j == 1)
				titlemkt <- "discard"
			if (j == 2)
				titlemkt <- "retained"
			titlemkt <- ifelse(printmkt, titlemkt, "")
			caption_base <- paste0(titletype, titlemkt, ", comparing across fleets")
			caption_base <- gsub(", ,", ", ", caption_base)
			if (mainTitle) {
				ptitle <- caption_base
			}
			else {
				ptitle <- ""
			}
			titles <- c(ptitle, titles)
			filenamemkt <- ifelse(j > -1, paste("mkt", j, sep=""), "")
			multifleet.bubble.fun <- function(ipage=0, l="e") {
				par_old <- par()
				par(mfrow=c(min(npanels, maxrows), 1), mar=c(0.5, 0, 0, 0), oma=c(4, 6, ifelse(mainTitle, 3, 1), 1))
				panelrange <- 1:npanels
				npages <- ceiling(npanels/maxrows)
				if (npages > 1 & ipage != 0)
					panelrange <- intersect(panelrange, 1:maxrows + maxrows * (ipage - 1))
				for (ipanel in panelvec[panelrange]) {
					flt <- panel_table$Fleet[ipanel]
					mkt <- panel_table$Part[ipanel]
					dbase <- dbase_parts[dbase_parts$Fleet == flt & dbase_parts$Part == mkt, ]
					max_n_ageerr <- max(apply(table(dbase$Yr.S, dbase$Ageerr) > 0, 1, sum))
					if (max_n_ageerr > 1) {
						if (ageerr_warning) {
							cat("Note: multiple samples with different ageing error types within fleet/year.\n", "   Plots label '2005a3' indicates ageing error type 3 for 2005 sample.\n", "   Bubble plots may be misleading with overlapping bubbles.\n")
							ageerr_warning <- FALSE
						}
						dbase$Yr.S <- dbase$Yr.S + dbase$Ageerr/(1000 * max_n_ageerr)
						dbase$YrSeasName <- paste(dbase$YrSeasName, "a", dbase$Ageerr, sep="")
					}
					xdiff <- 0.1 * sort(unique(diff(sort(unique(dbase$Yr.S)), na.rm=TRUE)))[1]
					if (is.na(xdiff)) {
						xdiff <- 0.1
					}
					xvals <- dbase$Yr.S
					cols <- rep(colvec[3], nrow(dbase))
					if (nsexes > 1) {
						xvals[dbase$sex > 0] <- dbase$Yr.S[dbase$sex > 0] - (dbase$sex[dbase$sex > 0] - 1.5) * xdiff
						if (length(unique(dbase$Yr.S)) == 1) {
							xvals[dbase$sex > 0] <- floor(dbase$Yr.S[dbase$sex > 0]) - (dbase$sex[dbase$sex > 0] - 1.5) * xdiff
						}
						cols[dbase$sex > 0] <- colvec[dbase$sex[dbase$sex > 0]]
					}
					if (datonly) {
						z <- dbase$Obs
						if (scalebubbles) 
							z <- dbase$Nsamp_adj * dbase$Obs
						titletype <- titledata
						filetype <- "bub"
						allopen <- TRUE
					}
					else {
						z <- dbase$Pearson
						titletype <- "Pearson residuals, "
						filetype <- "resids"
						allopen <- FALSE
					}
					ylim <- range(dbase$Bin)
					ylim[2] <- ylim[2] + 0.2 * diff(ylim)
					r4ss:::bubble3(x=xvals, y=dbase$Bin, z=z, col=cols, cexZ1=cexZ1, legend=linguaFranca(bublegend,l), las=1, main="", cex.main=cex.main, maxsize=pntscalar, allopen=allopen, xlim=xlim, ylim=ylim, axis1=FALSE)
					legend("topleft", title=linguaFranca(panel_table$Name[ipanel],l), legend=NA, bty="n", cex=1.5)
					if (length(cohortlines) > 0) {
						for (icohort in 1:length(cohortlines)) {
							cat("  Adding line for", cohortlines[icohort], "cohort\n")
							if (kind == "LEN") {
								lines(growdatF$Age + cohortlines[icohort], growdatF$Len_Mid, col=colvec[1])
								if (nsexes > 1) {
									lines(growdatM$Age + cohortlines[icohort], growdatM$Len_Mid, col=colvec[2])
								}
							}
							if (kind == "AGE") {
								lines(0.5 + c(cohortlines[icohort], cohortlines[icohort] + accuage), c(0, accuage), col="red")
							}
						}
					}
					if (par()$mfg[1] == par()$mfg[3] | ipanel == tail(panelvec, 1)) {
						axis(1, at=xaxislab)
					}
					else {
						axis(1, at=xaxislab, labels=rep("", length(xaxislab)))
					}
					if (par()$mfg[1] == 1) 
						title(main=ptitle, outer=TRUE, xlab=linguaFranca(labels[3],l), ylab=linguaFranca(kindlab,l))
				}
				par(mfcol=par_old$mfcol, mar=par_old$mar, oma=par_old$oma)
			} ## end multifleet.bubble.fun
			if (length(panelvec) > 0) {
				if (plot) 
					multifleet.bubble.fun(ipage=0, l=lang)
				if (print) {
					npages <- if (fixdims) ceiling(nrow(panel_table)/maxrows) else 1  ## (RH 200825)
					for (ipage in 1:npages) {
						pagetext <- ""
						caption <- caption_base
						if (npages > 1) {
							pagetext <- paste("_page", ipage, sep="")
							caption <- paste0(caption, " (plot ", ipage, " of ", npages, ")")
						}
						if (ipage == 1 & length(grep("Pearson", caption)) > 0) {
							caption <- paste(caption, "<br> \nClosed bubbles are positive residuals", "(observed > expected)", "and open bubbles are negative residuals", "(observed < expected).")
						}
						if (!is.null(ttcall(outnam)))
							file = paste0(sub("\\.png$","",outnam), letters[ipage], ".png")
						else
							file <- paste(filenamestart, filenamemkt, pagetext, "_multi-fleet_comparison.png", sep="")
						plotinfo <- pngfun(file=file, caption=caption, lang=lang)
						multifleet.bubble.fun(ipage=ipage, l=lang)
						dev.off(); eop()
					}
				}
			}
		}
		par(mfcol=c(rows, cols), mar=c(5, 4, 4, 2) + 0.1, oma=rep(0, 4))
	}
	if (!is.null(plotinfo))
		plotinfo$category <- "Comp"
	return(invisible(plotinfo))
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~plotSS.comps

#so("utilFuns.r","synth"); so("make.multifig.r","synth"); so("linguaFranca.r"); so("clearFiles.r"); so("darkenRGB.r")
#strSpp="440"; assyr=2021
#
#if (strSpp %in% c("440","YMR") && assyr==2011) fleets.af = c(1:3)
#if (strSpp %in% c("440","YMR") && assyr==2021) fleets.af = c(1:5)
#if (strSpp %in% c("REBS","REBSN")) fleets.af = c(1,3)
#
## McAllister and Ianelli https://doi.org/10.1139/f96-285

#plotSS.comps(replist,subplots=1,kind="AGE",fixdims=F,fitbar=T,fleets=5,lwd=1.5,plot=F,print=T,pwidth=8,pheight=9,outnam="agefitFleet",lang="e")
#plotSS.comps(replist,subplots=1,kind="AGE",fixdims=F,fitbar=T,fleets=fleets.af,lwd=1.5,plot=F,print=T,pwidth=7,pheight=9)
#plotSS.comps(replist,subplots=2,kind="AGE",fixdims=F,bub=T,fleets=1,lwd=1.5,plot=T,print=F,pwidth=9,pheight=7)
#plotSS.comps(replist,subplots=21,kind="AGE",fixdims=F,fitbar=T,fleets=1:3,lwd=1.5,plot=T,print=F,pwidth=9,pheight=7)
#plotSS.comps(replist,subplots=1,kind="AGE",fixdims=F,fitbar=T,fleets=1:5,showeffN=F,lwd=1.5,plot=F,print=T,pwidth=6.5,pheight=7,outnam="agefitFleet",lang="e")
#png("harmonica.png", units="in", res=400, width=8, height=6)
#expandGraph(mfrow=.findSquare(1), mar=c(3,3,0.5,0.5), oma=c(0,0,0,0), mgp=c(2,0.5,0))
#plotSS.comps(replist,subplots=7,kind="AGE",fixdims=F,fitbar=T,fleets=1,showeffN=F,plot=T,print=F,lang="e")
#plotSS.comps(replist,subplots=7,kind="AGE",fixdims=F,fitbar=T,fleets=1:5,showeffN=F,lwd=1.5,plot=T,print=F,lang="e")
#dev.off()
#plotSS.comps(replist,subplots=1,kind="AGE",fixdims=F,fitbar=T,fleets=1,showeffN=F,lwd=1.5,plot=T,print=F,pwidth=6.5,pheight=7,outnam="sumtingwong",lang="e")

