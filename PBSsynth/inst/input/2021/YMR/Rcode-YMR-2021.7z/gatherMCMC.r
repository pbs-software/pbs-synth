## gatherMCMC---------------------------2021-08-10
## All values occur at start of year so B2022 is B at end of 2021 or start of 2022;
##   u2022 must be u in 2021 after final catch was specified for 2021 in the data file.
## Ian Taylor (Aug 9, 2021):
##   Everything is start of year throughout.
##   Setting 2021 as the final year of the model allows 2021 catch.
##   The values for derived quantities like SSB_2021 and Bratio_2021 represent the beginning of the year values at the start of 2021 in the main time series.
##   The SSB_2022 is one year later but will only depend on catches up through 2021, so changes in 2022 catch won't impact the 2022 quantities.
## ---------------------------------------------RH
gatherMCMC = function( mcdir=".", type="compo",
   basedir="C:/Users/haighr/Files/GFish/PSARC21/YMR/Data/SS/YMR2021",
   ryrs=1935:2022, pyrs=2023:2032, valTS=c("SSB","F","Recr","RecrDev"), valRP=c("SSB_MSY","annF_MSY","Dead_Catch_MSY"))
{
	ayrs  = c(ryrs, pyrs); nyrs = length(ayrs)
	currYr = rev(ryrs)[1]; byr = cyr = as.character(currYr)
	#prevYr = currYr-1;     byr = as.character(prevYr) ## see note above
	mclst = list()
	Nmcmc=list(); rowN=list()
	for (m in 1:length(mcdir)){
		mdir = file.path( sub("/$","",basedir), sub("/$","",mcdir[m]) )
		if(!file.exists(mdir)) next
		mm    = substring(basename(mdir),6,10)
		mclst[[mm]] = list()
		cp = "AC.00"

		## Gather MPD information
		mpd = SS_output(dir=sub("\\.mh.+","",sub("\\.hm.+","",sub("\\.nuts.+","",sub("MCMC","MPD",mdir)))), verbose=F, printstats=F)
		parameters = mpd$parameters
		pactive = parameters[!is.na(parameters$Active_Cnt) & parameters$Phase>0 & !is.element(parameters$Pr_type,"dev"),]
		pactive$Label = convPN(pactive$Label)
		P.mpd  = pactive$Value; names(P.mpd)=pactive$Label
		if (m==1) {
			valPA = names(P.mpd)
			valPA = setdiff(valPA,c("M_Female","M_Male"))  ## just in case R79 comes first
			if (any(grepl("Run79",mcdir))) ## Specific to YMR sensitivity run with natural mortality
				valPA = c(valPA, "M_Female", "M_Male")
		}
		## Check for catch policies
		CP = c("AC", c("CC","HR")[file.exists(file.path(mdir,c("CC","HR")))])
		for (n in 1:length(CP)){
			nn = CP[n]
			if (nn=="AC") next
			ndir = file.path(mdir,nn)
			ncps = dir (ndir)  ## name of catch policy subdirectories
			cp = c(cp, paste0(nn,".",sub("^[[:alpha:]]+","",ncps)))
			mdir = c(mdir, file.path(ndir,ncps))
		}
#browser();return()
		for (n in 1:length(mdir)) {
			mmm   = mdir[n]
			ccc   = cp[n]
			.flush.cat(paste0("Getting MCMC: Run ", mm, "; catch policy: ", ccc), "\n")
			mmc   = SSgetMCMC(mmm, verbose=F)
			colnames(mmc) = convPN(colnames(mmc))
			msid  = mmc$Iter
			ii    = as.character(msid)
			nmc   = length(msid)
			#run   = as.numeric(strsplit(mm,"\\.")[[1]][1])
			run   = mm
			if (m==1){
				Nmcmc[[n]] = nmc
				rowN[[n]]  = paste0(run,".", pad0(msid,3))
			} else {
#browser();return()
				Nmcmc[[n]] = Nmcmc[[n]] + nmc
				rowN[[n]]  = c(rowN[[n]], paste0(run,".", pad0(msid,3)))
			}
#if (m==2) {browser();return()}

			if (n==1) { ## only need to look at the base catch policy for PA and RP
			## Parameters matrix
				matPA = array(NA, dim=c(nmc, length(valPA)), dimnames=list(sid=msid, val=valPA))
				for (k in 1:length(valPA)) {
					kk = valPA[k]
					vecPA = mmc[[kk]]
					if (is.null(vecPA)) next
					matPA[ii,kk] = vecPA
				}
				mclst[[mm]][["PA"]] = matPA

				## Reference points matrix
				matRP = array(NA, dim=c(nmc, length(valRP)), dimnames=list(sid=msid, val=valRP))
				for (k in 1:length(valRP)) {
					kk = valRP[k]
					vecRP = mmc[[kk]]
					if (is.null(vecRP)) next
					matRP[ii,kk] = vecRP
				}
				mclst[[mm]][["RP"]] = matRP

#browser();return()
				## Time series matrix of population reconstruction
				matTS = array(NA, dim=c(nmc, length(ryrs), length(valTS)), dimnames=list(sid=msid, yr=ryrs, val=valTS))
				for ( k in 1:length(valTS) ) {
					kk = valTS[k]
					for (j in ryrs) {
						jj = as.character(j)
						vecTS = mmc[[paste0(kk,"_",jj)]]
						if (is.null(vecTS)) next
						matTS[ii,jj,kk] = vecTS
					}
				}
				mclst[[mm]][["TS"]] = matTS
			}
			## Projection series matrix (average catch and whatever catch policies are available)
			matPJ = array(NA, dim=c(nmc, length(pyrs), length(valTS)), dimnames=list(sid=msid, yr=pyrs, val=valTS))
			for ( k in 1:length(valTS) ) {
				kk = valTS[k]
				for (j in pyrs) {
					jj = as.character(j)
					vecPJ = mmc[[paste0(kk,"_",jj)]]
					if (is.null(vecPJ)) next
					matPJ[ii,jj,kk] = vecPJ
				}
			}
#if (n==2){browser();return()}
			mclst[[mm]][["PJ"]][[ccc]] = matPJ

			## Catch policy matrix
			matCP = array(NA, dim=c(nmc, length(pyrs)), dimnames=list(sid=msid, yr=pyrs))
			for (j in pyrs) {
				jj = as.character(j)
				vecCP = mmc[[paste0("ForeCatch_",jj)]]
				if (is.null(vecCP)) next
				matCP[ii,jj] = vecCP
			}
#browser();return()
			#if ( all(apply(matCP,2,function(x){length(.su(x))}) %in% c(0,1)) )
			#	mclst[[mm]][["CP"]][[ccc]] = apply(matCP,2,unique)
			#else
			#	mclst[[mm]][["CP"]][[ccc]] = matCP
#if (ccc=="CC.02") {browser();return()}
			## Note; 0-catch policy is sometimes set to a very small amount; sometimes other catch policies have small amounts added. WTF?
			## PJS thinks it may be a difference between v.2.30.16 and 3.30.17
			#mclst[[mm]][["CP"]][[ccc]] = apply(matCP,2,function(x){xx=mean(x,na.rm=T); xx[is.na(xx) | !is.finite(xx)]=NA; return(xx)})
			## CAUTION: Mode may not be sufficiently robust at higher CPs
			mclst[[mm]][["CP"]][[ccc]] = apply(round(matCP),2,function(x){xx=as.numeric(names(rev(sort(table(x))))[1]); xx[is.na(xx) | !is.finite(xx)]=NA; return(xx)})
		}
		mclst[[mm]][["MPD"]] = P.mpd
	}
#browser();return()
	mpdPA = list()
	#avgPA = array(NA, dim=c(Nmcmc[[1]], length(P.mpd)), dimnames=list(mcmc=rowN[[1]], par=names(P.mpd)))
	avgPA = array(NA, dim=c(Nmcmc[[1]], length(valPA)), dimnames=list(mcmc=rowN[[1]], par=valPA))
	vRP   = c("Bcurr","B0","20B0","40B0","Fcurr","ucurr","MSY","Bmsy","LRP","USR","Fmsy","umsy")
	avgRP = array(NA, dim=c(Nmcmc[[1]], length(vRP)), dimnames=list(mcmc=rowN[[1]], val=vRP))
	vTS   = c("Bt","BtB0","BtBmsy","Ft","FtFmsy","ut","utumsy","Rt","Rtdev")
	avgTS = array(NA, dim=c(Nmcmc[[1]], length(ryrs), length(vTS)), dimnames=list(mcmc=rowN[[1]], yr=ryrs, val=vTS))
	avgPJ = array(NA, dim=c(Nmcmc[[1]], length(pyrs), length(vTS), length(cp)), dimnames=list(mcmc=rowN[[1]], yr=pyrs, val=vTS, proj=cp))
	avgCP = array(NA, dim=c(length(pyrs), length(mclst), length(cp)), dimnames=list(yr=pyrs, run=names(mclst), proj=cp))

	## Build the composite run ('model average')
	for (m in 1:length(mclst)){
		mm    = names(mclst)[m]
		matrix(mclst[[mm]][["MPD"]][valPA],nrow=1)
		mpdPA = rbind(mpdPA, matrix(mclst[[mm]][["MPD"]][valPA], nrow=1))
		mcPA  = mclst[[mm]][["PA"]]
		mcRP  = mclst[[mm]][["RP"]]
		mcTS  = mclst[[mm]][["TS"]]
		mcPJ  = mclst[[mm]][["PJ"]]
		mcCP  = mclst[[mm]][["CP"]]
		#run   = as.numeric(strsplit(mm,"\\.")[[1]][1])
		run   = mm
		iii   = paste0(run,".",pad0(as.numeric(rownames(mcTS)),3))
		#iii   = (lastmc+1):(lastmc+dim(mcTS)[1])

		## Populate parameters array
		for (n in 1:length(mclst[[mm]][["MPD"]])){
			ppp = names(mclst[[mm]][["MPD"]])[n]
			avgPA[iii,ppp] = mcPA[,ppp]
		}
#if (m==2) {browser();return()}
		## Populate reference point array
		avgRP[iii,"Bcurr"] = mcTS[,cyr,"SSB"]
		avgRP[iii,"B0"]    = mcTS[,1,"SSB"]
		avgRP[iii,"20B0"]  = 0.2 * mcTS[,1,"SSB"]
		avgRP[iii,"40B0"]  = 0.4 * mcTS[,1,"SSB"]
		avgRP[iii,"Fcurr"] = mcTS[,byr,"F"]
		avgRP[iii,"ucurr"] = 1 - exp(-mcTS[,byr,"F"])
		avgRP[iii,"MSY"]   = mcRP[,"Dead_Catch_MSY"]
		avgRP[iii,"Bmsy"]  = mcRP[,"SSB_MSY"]
		avgRP[iii,"LRP"]   = 0.4 * mcRP[,"SSB_MSY"]
		avgRP[iii,"USR"]   = 0.8 * mcRP[,"SSB_MSY"]
		avgRP[iii,"Fmsy"]  = mcRP[,"annF_MSY"]
		avgRP[iii,"umsy"]  = 1-exp(-mcRP[,"annF_MSY"])

		## Populate time series array
		avgTS[iii,dimnames(mcTS)$yr,"Bt"]     = mcTS[,,"SSB"]
		avgTS[iii,dimnames(mcTS)$yr,"BtB0"]   = mcTS[,,"SSB"] / avgRP[iii,"B0"]
		avgTS[iii,dimnames(mcTS)$yr,"BtBmsy"] = mcTS[,,"SSB"] / avgRP[iii,"Bmsy"]
		avgTS[iii,dimnames(mcTS)$yr,"Ft"]     = mcTS[,,"F"]
		avgTS[iii,dimnames(mcTS)$yr,"FtFmsy"] = mcTS[,,"F"] / avgRP[iii,"Fmsy"]
		avgTS[iii,dimnames(mcTS)$yr,"ut"]     = 1 - exp(-mcTS[,,"F"])
		avgTS[iii,dimnames(mcTS)$yr,"utumsy"] = (1 - exp(-mcTS[,,"F"])) / avgRP[iii,"umsy"]
		avgTS[iii,dimnames(mcTS)$yr,"Rt"]     = mcTS[,,"Recr"]
		avgTS[iii,dimnames(mcTS)$yr,"Rtdev"]  = mcTS[,,"RecrDev"]

		for (n in 1:length(cp)){
			ccc = cp[n]
#if (n==2){browser();return()}
			avgCP[as.character(pyrs),mm,ccc] =  mcCP[[ccc]]

			## Populate projection array
			avgPJ[iii,dimnames(mcPJ[[ccc]])$yr,"Bt",ccc]     = mcPJ[[ccc]][,,"SSB"]
			avgPJ[iii,dimnames(mcPJ[[ccc]])$yr,"BtB0",ccc]   = mcPJ[[ccc]][,,"SSB"] / avgRP[iii,"B0"]
			avgPJ[iii,dimnames(mcPJ[[ccc]])$yr,"BtBmsy",ccc] = mcPJ[[ccc]][,,"SSB"] / avgRP[iii,"Bmsy"]
			avgPJ[iii,dimnames(mcPJ[[ccc]])$yr,"Ft",ccc]     = mcPJ[[ccc]][,,"F"]
			avgPJ[iii,dimnames(mcPJ[[ccc]])$yr,"FtFmsy",ccc] = mcPJ[[ccc]][,,"F"] / avgRP[iii,"Fmsy"]
			avgPJ[iii,dimnames(mcPJ[[ccc]])$yr,"ut",ccc]     = 1 - exp(-mcPJ[[ccc]][,,"F"])
			avgPJ[iii,dimnames(mcPJ[[ccc]])$yr,"utumsy",ccc] = (1 - exp(-mcPJ[[ccc]][,,"F"])) / avgRP[iii,"umsy"]
			avgPJ[iii,dimnames(mcPJ[[ccc]])$yr,"Rt",ccc]     = mcPJ[[ccc]][,,"Recr"]
			avgPJ[iii,dimnames(mcPJ[[ccc]])$yr,"Rtdev",ccc]  = mcPJ[[ccc]][,,"RecrDev"]
		}
	}
	storage.mode(mpdPA)="double"
	rownames(mpdPA) = names(mclst); colnames(mpdPA) = valPA  ## because of occasional extra parameters
	if (type=="senso")
		out = list(senPA=avgPA, senRP=avgRP, senTS=avgTS, senPJ=avgPJ, senCP=avgCP, smpdPA=mpdPA)
	else
		out = list(avgPA=avgPA, avgRP=avgRP, avgTS=avgTS, avgPJ=avgPJ, avgCP=avgCP, ampdPA=mpdPA)
#browser();return()
	return(out)
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~gatherMCMC

so("convPN.r","synth")
require(r4ss)
redo.compo = F
if (redo.compo) {
	cr.run = c(77,71,75,72,76); cr.rwt=rep(1,length(cr.run)); cr.mcmc = rep("nuts4K",length(cr.run))# c(75,78) #  ## component runs
	cr.run.rwt = paste0( pad0(cr.run,2), ".", pad0(cr.rwt,2) )
	cr.dir = paste0("Run", pad0(cr.run,2), "/MCMC.", cr.run.rwt, ".", cr.mcmc)
	#compo = gatherMCMC(mcdir=crdir, pyrs=2022:2037, basedir="C:/Users/haighr/Files/GFish/PSARC21/YMR/Data/SS/Explore")
	.flush.cat("Gathering component runs...\n")
	compo = gatherMCMC(mcdir=cr.dir, basedir="C:/Users/haighr/Files/GFish/PSARC21/YMR/Data/SS/YMR2021")
	save("compo", file=paste0("compo.", format(Sys.Date(), "%y%m%d"), ".rda"))
}
redo.senso = F
if (redo.senso) {
	sr.run = c(75,78:88,91:93); sr.rwt=rep(1,length(sr.run)); sr.mcmc = rep("nuts4K",length(sr.run))  ## sensitivity runs
	#sr.run = c(79:80); sr.rwt=rep(1,length(sr.run)); sr.mcmc = rep("nuts4K",length(sr.run))  ## sensitivity runs
	sr.run.rwt = paste0( pad0(sr.run,2), ".", pad0(sr.rwt,2) )
	sr.dir = paste0("Run", pad0(sr.run,2), "/MCMC.", sr.run.rwt, ".", sr.mcmc)
	.flush.cat("Gathering sensitivity runs...\n")
	senso = gatherMCMC(mcdir=sr.dir, basedir="C:/Users/haighr/Files/GFish/PSARC21/YMR/Data/SS/YMR2021", type="senso")
	save("senso", file=paste0("senso.", format(Sys.Date(), "%y%m%d"), ".rda"))
}
