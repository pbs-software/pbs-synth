## plotSS.pars.prior-----------------2020-07-12
## Adding the prior automatically.
## -----------------------------------------AME/RH
plotSS.pars.prior <- function(
   mcmc, probs=tcall(quants3)[c(1,3)], points=FALSE, axes=TRUE, 
   same.limits=FALSE, between=list(x=axes, y=axes), 
   div=1, log=FALSE, base=10, main=NULL, xlab=NULL, 
   ylab=NULL, cex.main=1.2, cex.lab=1, cex.strip=0.8, 
   cex.axis=0.7, las=0, tck=0.5, tick.number=5, lty.density=1, 
   lwd.density=3, col.density="black", lty.median=2, lwd.median=1, 
   col.median="darkgrey", lty.outer=3, lwd.outer=1, col.outer="darkgrey", 
   pch="|", cex.points=1, col.points="black", plot=TRUE,
   MPD.height=0.04, mpd=mcmc[1,], lang="e", ...)    # MPD.height, how far up to put MPD
{
	panel.dens <- function(x, ...) {
		if (any(is.finite(x)) && var(x) > 0) 
			panel.densityplot(x, lty=lty.density, lwd=lwd.density, 
				col.line=col.density, plot.points=points, 
				pch=pch, cex=cex.points, col=col.points, ...)
		else panel.densityplot(x, type="n", ...)

		panel.abline(v=quantile(x, probs=probs), lty=lty.outer, lwd=lwd.outer, col=col.outer)
		panel.abline(v=median(x), lty=lty.median, lwd=lwd.median, col=col.median)
		panel.xyplot(mpd[panel.number()], current.panel.limits()$ylim[2]*MPD.height, pch=19, col="red") # AME, MPD. 0.04 of way up; assumes ..ylim[1]=0
		panel.xyplot(mpd[panel.number()], current.panel.limits()$ylim[2]*MPD.height, pch=1, col="black") #AME
		# panel.curve(priorDistList[[panel.number()]], min=-1, current.panel.limits()$xlim[1], current.panel.limits()$xlim[2], col="blue")
		# panel.curve(priorDistList[[1]], col="blue")
		# panel.curve(priorDistList[[panel.number()]](x), from=max(priorBoundsList[[panel.number()]][1],
		#		  current.panel.limits()$xlim[1]), to=min(priorBoundsList[[panel.number()]][2], 
		#		  current.panel.limits()$xlim[2]), col="blue") # need the bounds, from max of lower bound and panel xlim[1], to min of upper bound and panel xlim[2]
		panel.curve(priorDistList[[panel.number()]]
			(x, priorInput[panel.number(), ] ),
			from = max(priorInput[panel.number(), 2] , current.panel.limits()$xlim[1]),
			to = min(priorInput[panel.number(), 3], current.panel.limits()$xlim[2]), col="blue")
	}
	relation <- if (same.limits) "same" else "free"
	if (is.null(dim(mcmc))) {
		mcmc.name <- rev(as.character(substitute(mcmc)))[1]
		mcmc <- matrix(mcmc, dimnames=list(NULL, mcmc.name))
	}
	mcmc <- if (log) 
		log(mcmc/div, base=base)
	else mcmc/div
	mcmc <- as.data.frame(mcmc)
	n <- nrow(mcmc)
	p <- ncol(mcmc)
	x <- data.frame(Factor=ordered(rep(names(mcmc), each=n), 
		names(mcmc)), Draw=rep(1:n, p), Value=as.vector(as.matrix(mcmc)))
	#mess = c(
	#"require(grid, quietly=TRUE, warn.conflicts=FALSE)",
	#"require(lattice, quietly=TRUE, warn.conflicts=FALSE)"
	#)
	#eval(parse(text=mess))
	if (trellis.par.get()$background$col == "#909090") {
		for (d in dev.list()) dev.off()
			trellis.device(color=FALSE)
	}
	mymain <- list(label = linguaFranca(main,lang), cex = cex.main)
	myxlab <- list(label = linguaFranca(xlab,lang), cex = cex.lab)
	myylab <- list(label = linguaFranca(ylab,lang), cex = cex.lab)
	myrot <- switch(as.character(las), `0`=0, `1`=0, `2`=90, `3`=90)
	myscales <- list(y=list(draw=FALSE, relation="free"), 
		x=list(draw=axes, relation=relation, cex=cex.axis, 
		tck=tck, tick.number=tick.number, rot=myrot))
	mystrip <- list(cex=cex.strip)
	graph <- densityplot(~Value | Factor, panel=panel.dens, 
		data=x, as.table=TRUE, between=between, main=mymain, 
		xlab=myxlab, ylab=myylab, par.strip.text=mystrip, scales=myscales, ...)
	if (!log) {
		if (is.list(graph$y.limits)) 
			graph$y.limits <- lapply(graph$y.limits, function(y) {
				y[1] <- 0
				return(y)
			})
		else graph$y.limits[1] <- 0
	}
	if (plot) {
		print(graph)
		invisible(x)
	}
	else {
		invisible(graph)
	}
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~plotSS.pars.prior
