## prepMPD------------------------------2021-06-16
##  Prepare MPD runs for likelihood analysis
## ---------------------------------------------RH
prepMPD = function(run.rwt, #n.run, n.rwt, l.run, l.rwt,
	d.base = "C:/Users/haighr/Files/GFish/PSARC21/YMR/Data/SS/YMR2021",
	w=NULL, cvpro=NULL)
{
	padded = pad0(run.rwt,2)
	n.run=padded[1]; n.rwt=padded[2]; l.run=padded[3]; l.rwt=padded[4]
	pre.run.rwt = paste(l.run,l.rwt,sep=".")
	new.run.rwt = paste(n.run,n.rwt,sep=".")
	## Destination directories
	#d.cwd = getwd(); on.exit(setwd(d.cwd))
	d.run = file.path(d.base,paste0("Run",n.run))
	d.mpd = file.path(d.run,paste("MPD",new.run.rwt,sep="."))

	## Previous run from which to poach ssfiles
	p.run = file.path(d.base,paste0("Run",l.run))
	p.mpd = file.path(p.run,paste("MPD",pre.run.rwt,sep="."))
	if (!all(file.exists(c(p.run,p.mpd))))
		stop("Previous Run directory and/or MPD directory does not exist")
	if (!file.exists(d.run)) dir.create(d.run)
	if (!file.exists(d.mpd)) dir.create(d.mpd)
	p.ss  = setdiff(list.files(p.mpd, pattern="\\.ss$"),"runnumber.ss")
	pee   = file.copy(from=file.path(p.mpd,p.ss), to=d.mpd, copy.date=T, overwrite=F)
	poo   = file.rename(from=file.path(d.mpd,paste(c("data","control"),pre.run.rwt,"ss",sep=".")), to=file.path(d.mpd,paste(c("data","control"),new.run.rwt,"ss",sep=".")))

	## Modify starter file to reflect new run
	starter = readLines(file.path(d.mpd,"starter.ss"))
	dline   = grep(paste("data",pre.run.rwt,sep="."),starter)
	cline   = grep(paste("control",pre.run.rwt,sep="."),starter)
#browser();return()
	starter[dline] = sub(paste0("data\\.",l.run,"\\.",l.rwt),paste0("data.",new.run.rwt),starter[dline])
	starter[cline] = sub(paste0("control\\.",l.run,"\\.",l.rwt),paste0("control.",new.run.rwt),starter[cline])
	writeLines(starter, con=file.path(d.mpd,"starter.ss"))

	## Modify data file to add cvpro using the Francis method
	data = readLines(file.path(d.mpd,paste0("data.",new.run.rwt,".ss")))
	if (!is.null(cvpro)){
		vline = intersect(grep("_index$",data), grep("^#",data,invert=TRUE))
		vbits = strsplit(data[vline], split=" +")
		if (length(.su(sapply(vbits,function(x){x[3]}))) != length(cvpro)){
			.flush.cat("User inputs for cvpro do not match indices in data file\n"); browser();return()
		}
		vdump = sapply(1:length(vbits),function(i){vbits[[i]][5] <<- sqrt(as.numeric(vbits[[i]][5])^2 + cvpro[as.numeric(vbits[[i]][3])]^2) })
#browser();return()
		vnew  = sapply(vbits,function(x){ paste0(x,collapse=" ")})
		data[vline] = vnew
		writeLines(data, con=file.path(d.mpd,paste0("data.",new.run.rwt,".ss")))
	}
	## Modify control file to add Francis reweights
	control = readLines(file.path(d.mpd,paste0("control.",new.run.rwt,".ss")))
	if (!is.null(w)){
		fline = intersect(grep("vadj_af",control), grep("^#",control,invert=TRUE))
		if (length(fline)!=length(w)){
			.flush.cat("Francis reweights do not match control lines\n"); browser();return()
		}
		fbits = strsplit(control[fline], split=" +")
		wdump = sapply(1:length(fbits),function(i){fbits[[i]][3] <<- w[i]})
		fnew  = sapply(fbits,function(x){ paste0(x,collapse=" ")})
		control[fline] = fnew
		writeLines(control, con=file.path(d.mpd,paste0("control.",new.run.rwt,".ss")))
	}
#	if (!is.null(w) || !is.null(cvpro)){
#	}
	setwd(d.mpd)
	.flush.cat(paste0("***Edit the ss files in\n\t",d.mpd,"\nbefore proceeding with an MPD fit in SS."),"\n\n")
	return(invisible(list(starter=starter, control=control)))
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~prepMPD

#prepMPD(run.rwt=c(7,0,6,0))
#prepMPD(run.rwt=c(7,1,7,0))
#prepMPD(run.rwt=c(run,rwt,run,rwt-1),w=ttcall(w.francis)$w)

