## make_multifig------------------------2020-08-25
## Source: R package 'r4ss' v.1.39.1
## Plot age proportions and model fit
## ----------------------------------------r4ss|RH
make_multifig = function (ptsx, ptsy, yr, linesx=0, linesy=0, ptsSD=0, 
   sampsize=0, effN=0, showsampsize=TRUE, showeffN=TRUE, 
   sampsize_label="N=", effN_label="effN=", sampsizeround=1, 
   maxrows=6, maxcols=6, rows=1, cols=1, fixdims=TRUE, 
   main="", cex.main=1, xlab="", ylab="", size=1, 
   cexZ1=1.5, bublegend=TRUE, maxsize=NULL, do.sqrt=TRUE, 
   minnbubble=8, allopen=TRUE, xbuffer=c(0.1,0.1), 
   ybuffer=c(0,0.15), yupper=NULL, ymin0=TRUE, xlas=0, ylas=NULL, 
   axis1=NULL, axis2=NULL, axis1labs=NULL, linepos=1, 
   type="o", polygons=TRUE, bars=FALSE, barwidth="default", 
   ptscex=1, ptscol=1, ptscol2=1, 
   colvec=c(rgb(1,0,0,0.7), rgb(0,0,1,0.7), rgb(0.1,0.1,0.1,0.7)),
   linescol=c(rgb(0,0.8,0,0.7), rgb(1,0,0,0.7), rgb(0,0,1,0.7)),
   lty=1, lwd=2, pch=1, nlegends=3, 
   legtext=list("yr", "sampsize", "effN"), legx="default", 
   legy="default", legadjx="default", legadjy="default", 
   legsize=c(1.2, 1), legfont=c(2, 1), venusmars=TRUE, 
   sampsizeline=FALSE, effNline=FALSE, sampsizemean=NULL, 
   effNmean=NULL, ipage=0, scalebins=FALSE, sexvec=NULL, 
   multifig_colpolygon=c("grey60","grey80","grey70"), 
   multifig_oma=NULL, ...) 
{
#polygons=F; bars=T
	twosex <- TRUE
	if (is.null(sexvec)) {
		twosex <- FALSE
	}
	if (length(unique(sexvec)) == 1) {
		twosex <- FALSE
	}
	male_mult <- 1
	if (twosex) {
		male_mult <- -1
	}
	yrvec <- sort(unique(yr))
	npanels <- length(yrvec)
	nvals <- length(yr)
	nrows <- min(ceiling(sqrt(npanels)), maxrows)
	ncols <- min(ceiling(npanels/nrows), maxcols)
	rc=.findSquare(npanels); nrows=rc[1]; ncols=rc[2]  ## (RH 200825)
	if (fixdims) {
		nrows <- maxrows
		ncols <- maxcols
	}
	allbins.obs <- sort(unique(ptsx))
	if (scalebins) {
		if (diff(range(allbins.obs)) > 0 && length(allbins.obs) > 
			2 && length(unique(diff(allbins.obs)))) {
			diffs <- diff(allbins.obs)
			diffs <- c(diffs, diffs[length(diffs)])
			bin.width.table <- data.frame(bin=allbins.obs, 
				width=diffs)
		}
		else {
			scalebins <- FALSE
			warning("Setting scalebins=FALSE. Bins are equal length or too few.")
		}
	}
	npages <- ceiling(npanels/nrows/ncols)
	doSD <- length(ptsSD) == length(ptsx) & max(ptsSD) > 0
	if (doSD) {
		polygons <- FALSE
	}
	if (length(linesx) == 1 | length(linesy) == 1) {
		linepos <- 0
		linesx <- ptsx
		linesy <- ptsy
	}
	anyscaled <- FALSE
	if (bars & barwidth == "default") 
		barwidth <- 400/max(table(yr) + 2)/ncols
	if (length(size) == 1) {
		size <- rep(size, length(yr))
	}
	bub <- diff(range(size, na.rm=TRUE)) != 0
	xrange <- range(c(ptsx, linesx, ptsx, linesx))
	if (ymin0) {
		yrange <- c(0, max(ptsy, linesy))
	}
	else {
		yrange <- range(c(ptsy, linesy, ptsy, linesy))
	}
	yrange <- c(min(yrange[1], yupper), min(yrange[2], yupper))
	xrange_big <- xrange + c(-1, 1) * xbuffer * diff(xrange)
	yrange_big <- yrange + c(-1, 1) * ybuffer * diff(yrange)
	if (twosex & !bub) {
		yrange_big <- range(-yrange, yrange) + c(-1, 1) * ybuffer * diff(yrange)
	}
	yaxs_lab <- pretty(yrange)
	maxchar_yaxs <- max(nchar(yaxs_lab))
	if (is.null(ylas)) {
		if (maxchar_yaxs < 6) {
			ylas <- 1
		}
		else {
			ylas <- 0
		}
	}
	if (is.null(axis1)) {
		axis1 <- pretty(xrange)
	}
	if (is.null(axis1labs)) {
		axis1labs <- axis1
	}
	if (is.null(axis2)) {
		axis2 <- pretty(yrange)
	}
	if (length(sampsize) == 1) {
		sampsize <- 0
	}
	if (length(effN) == 1) {
		effN <- 0
	}
	par_old <- par()
	if (is.null(multifig_oma)) {
		if (main == "") {
			multifig_oma <- c(4, 5, 1, 1) + 0.1  ## (RH 200825)
		}
		else {
			multifig_oma <- c(5, 5, 5, 1) + 0.1
		}
	}
	#par(mfcol=c(nrows, ncols), mar=rep(0, 4), oma=multifig_oma, ...)
	par(mfrow=c(nrows, ncols), mar=rep(0, 4), oma=multifig_oma, ...)  ## (RH 200825)
	panelrange <- 1:npanels
	if (npages > 1 & ipage != 0) {
		panelrange <- intersect(panelrange, 1:(nrows * ncols) + nrows * ncols * (ipage - 1))
	}
	for (ipanel in panelrange) {
		yr_i <- yrvec[ipanel]
		sexvec_i <- sexvec[yr == yr_i]
		ptsx_i0 <- ptsx[yr == yr_i & sexvec == 0]
		ptsx_i1 <- ptsx[yr == yr_i & sexvec == 1]
		ptsx_i2 <- ptsx[yr == yr_i & sexvec == 2]
		ptsy_i0 <- ptsy[yr == yr_i & sexvec == 0]
		ptsy_i1 <- ptsy[yr == yr_i & sexvec == 1]
		ptsy_i2 <- ptsy[yr == yr_i & sexvec == 2] * male_mult
		if (doSD) {
			ptsSD_i0 <- ptsSD[yr == yr_i & sexvec == 0]
			ptsSD_i1 <- ptsSD[yr == yr_i & sexvec == 1]
			ptsSD_i2 <- ptsSD[yr == yr_i & sexvec == 2]
		}
		linesx_i0 <- linesx[yr == yr_i & sexvec == 0]
		linesx_i1 <- linesx[yr == yr_i & sexvec == 1]
		linesx_i2 <- linesx[yr == yr_i & sexvec == 2]
		linesy_i0 <- linesy[yr == yr_i & sexvec == 0]
		linesy_i1 <- linesy[yr == yr_i & sexvec == 1]
		linesy_i2 <- linesy[yr == yr_i & sexvec == 2] * male_mult
		linesy_i0 <- linesy_i0[order(linesx_i0)]
		linesx_i0 <- sort(linesx_i0)
		linesy_i1 <- linesy_i1[order(linesx_i1)]
		linesx_i1 <- sort(linesx_i1)
		linesy_i2 <- linesy_i2[order(linesx_i2)]
		linesx_i2 <- sort(linesx_i2)
		z_i0 <- size[yr == yr_i & sexvec == 0]
		z_i1 <- size[yr == yr_i & sexvec == 1]
		z_i2 <- size[yr == yr_i & sexvec == 2]
		scaled <- FALSE
		if (scalebins) {
			getwidths <- function(ptsx) {
				if (length(ptsx) > 0) {
					widths <- rep(NA, length(ptsx))
					for (ibin in 1:length(ptsx)) {
						widths[ibin] <- bin.width.table$width[bin.width.table$bin == ptsx[ibin]]
					}
				}
				else {
					widths <- NULL
				}
				return(widths)
			}
			widths_i0 <- getwidths(ptsx_i0)
			widths_i1 <- getwidths(ptsx_i1)
			widths_i2 <- getwidths(ptsx_i2)
			ptsy_i0 <- ptsy_i0/widths_i0
			ptsy_i1 <- ptsy_i1/widths_i1
			ptsy_i2 <- ptsy_i2/widths_i2
			linesy_i0 <- linesy_i0/widths_i0
			linesy_i1 <- linesy_i1/widths_i1
			linesy_i2 <- linesy_i2/widths_i2
			scaled <- TRUE
		}
		if (scaled) {
			anyscaled <- TRUE
			if (ylab == "Proportion") {
				ylab <- "Proportion / bin width"
			}
		}
		plot(0, type="n", axes=FALSE, xlab="", ylab="", xlim=xrange_big, ylim=yrange_big, xaxs="i", yaxs=ifelse(bars, "i", "r"), ...)
		abline(h=0, col="grey")
		if (linepos == 2) {
			lines(linesx_i0, linesy_i0, col=linescol[1], lwd=lwd, lty=lty)
			lines(linesx_i1, linesy_i1, col=linescol[2], lwd=lwd, lty=lty)
			lines(linesx_i2, linesy_i2, col=linescol[3], lwd=lwd, lty=lty)
		}
		if (bub) {
			if (length(z_i0) > 0) {
				bubble3(x=ptsx_i0, y=ptsy_i0, z=z_i0, col=rep(colvec[3], length(z_i0)), cexZ1=cexZ1, legend.yadj=1.5, legend=bublegend, legendloc="topright", maxsize=maxsize, minnbubble=minnbubble, allopen=allopen, add=TRUE)
			}
			if (length(z_i1) > 0) {
				bubble3(x=ptsx_i1, y=ptsy_i1, z=z_i1, col=rep(colvec[1], length(z_i1)), cexZ1=cexZ1, legend.yadj=1.5, legend=bublegend, legendloc="topright", maxsize=maxsize, minnbubble=minnbubble, allopen=allopen, add=TRUE)
			}
			if (length(z_i2) > 0) {
				bubble3(x=ptsx_i2, y=abs(ptsy_i2), z=z_i2, col=rep(colvec[2], length(z_i2)), cexZ1=cexZ1, legend.yadj=1.5, legend=bublegend, legendloc="topright", maxsize=maxsize, minnbubble=minnbubble, allopen=allopen, add=TRUE)
			}
			if (linepos == 0) 
				effNline <- 0
			if (effNline > 0 && length(effN) > 0) {
				effN_i1 <- effN[yr == yr_i]
				effN_i1_vec <- unlist(lapply(split(effN_i1, ptsy_i1), unique))
				ptsy_i1_vec <- sort(unique(ptsy_i1))
				lines(effNline * effN_i1_vec, ptsy_i1_vec, col="green3")
				if (!is.null(effNmean)) {
					lines(rep(effNline * effNmean, length(ptsy_i1_vec)), ptsy_i1_vec, col="green3", lty=2)
				}
			}
			if (sampsizeline > 0 && length(sampsize) > 0) {
				sampsize_i1 <- sampsize[yr == yr_i]
				sampsize_i1_vec <- unlist(lapply(split(sampsize_i1, ptsy_i1), unique))
				ptsy_i1_vec <- sort(unique(ptsy_i1))
				lines(sampsizeline * sampsize_i1_vec, ptsy_i1_vec, col=2)
				if (!is.null(sampsizemean)) {
					lines(rep(sampsizeline * sampsizemean, length(ptsy_i1_vec)), ptsy_i1_vec, col=2, lty=3)
				}
			}
		}
		else {
			if (length(ptsx_i0) > 0) {
				if (bars) {
					drawBars(ptsx_i0, ptsy_i0, col="slategray3", fill="slategray3")  ## (RH 200825)
				} else {
					if (polygons)
						polygon(c(ptsx_i0[1], ptsx_i0, tail(ptsx_i0,1)), c(0,ptsy_i0, 0), col=multifig_colpolygon[1])
					points(ptsx_i0, ptsy_i0, type=type, lwd=1,  pch=16, cex=0.7, col=ptscol)
				}
			}
			if (length(ptsx_i1) > 0) {
				if (bars) {
					drawBars(ptsx_i1, ptsy_i1, col=lucent("pink",0.75), fill=lucent("pink",0.75))  ## (RH 200826) -- females
				} else {
					if (polygons)
						polygon(c(ptsx_i1[1], ptsx_i1, tail(ptsx_i1,1)), c(0,ptsy_i1, 0), col=multifig_colpolygon[1])
					points(ptsx_i1, ptsy_i1, type=type, lwd=1,  pch=16, cex=0.7, col=ptscol)
				}
			}
			if (length(ptsx_i2) > 0) {
				if (bars) {
					drawBars(ptsx_i2, ptsy_i2, col=lucent("skyblue",0.75), fill=lucent("skyblue",0.75))  ## (RH 200826) -- males
				} else {
					if (polygons)
						polygon(c(ptsx_i2[1], ptsx_i2, tail(ptsx_i2,1)), c(0,ptsy_i2, 0), col=multifig_colpolygon[1])
					points(ptsx_i2, ptsy_i2, type=type, lwd=1,  pch=16, cex=0.7, col=ptscol)
				}
			}
			if (doSD) {
				old_warn <- options()$warn
				options(warn=-1)
				if (length(ptsx_i0) > 0) {
					arrows(x0=ptsx_i0, y0=qnorm(p=0.05, mean=ptsy_i0, sd=ptsSD_i0), x1=ptsx_i0, y1=qnorm(p=0.95, mean=ptsy_i0, sd=ptsSD_i0), length=0.01, angle=90, code=3, col=ptscol)
				}
				if (length(ptsx_i1) > 0) {
					arrows(x0=ptsx_i1, y0=qnorm(p=0.05, mean=ptsy_i1, sd=ptsSD_i1), x1=ptsx_i1, y1=qnorm(p=0.95, mean=ptsy_i1, sd=ptsSD_i1), length=0.01, angle=90, code=3, col=ptscol)
				}
				if (length(ptsx_i2) > 0) {
					arrows(x0=ptsx_i2, y0=qnorm(p=0.05, mean=ptsy_i2, sd=ptsSD_i2), x1=ptsx_i2, y1=qnorm(p=0.95, mean=ptsy_i2, sd=ptsSD_i2), length=0.01, angle=90, code=3, col=ptscol)
				}
				options(warn=old_warn)
			}
		}
		if (linepos == 1) {
			lines(linesx_i0, linesy_i0, col=linescol[1], lwd=lwd, lty=lty)
			lines(linesx_i1, linesy_i1, col=linescol[2], lwd=lwd, lty=lty)
			lines(linesx_i2, linesy_i2, col=linescol[3], lwd=lwd, lty=lty)
		}
#browser();return()
		usr <- par("usr")
		for (i in 1:nlegends) {
			text_i <- ""
			text_i2 <- ""
			legtext_i <- legtext[[i]]
			if (length(legtext_i) == 1) {
				if (legtext_i == "yr") {
					text_i <- yr_i
				}
				for (sex in sort(unique(sexvec_i))) {
					if (legtext_i == "sampsize" & showsampsize) {
						vals <- unique(sampsize[sexvec == sex & yr == yr_i])
						if (length(vals) > 1) {
							warning("sampsize values are not all equal", "--choosing the first value: ", vals[1], "\n", "  yr=", yr_i, ", and all sampsize values: ", paste(vals, collapse=","), sep="")
							vals <- vals[1]
						}
						text_i <- paste(sampsize_label, round(vals, sampsizeround), sep="")
						if (twosex & sex == 2) {
							text_i2 <- paste(sampsize_label, round(vals, sampsizeround), sep="")
						}
					}
					if (legtext_i == "effN" & showeffN) {
						vals <- unique(effN[sexvec == sex & yr == yr_i])
						if (length(vals) > 1) {
							warning("effN values are not all equal", "--choosing the first value: ", vals[1], "\n", "  yr=", yr_i, ", and all effN values: ", paste(vals, collapse=","), sep="")
							vals <- vals[1]
						}
						text_i <- paste(effN_label, round(vals, sampsizeround), sep="")
						if (twosex & sex == 2) {
							text_i2 <- paste(effN_label, round(vals, sampsizeround), sep="")
						}
					}
				}
			}
			if (length(legtext_i) == nvals) {
				text_i <- legtext_i[yr == yr_i][1]
			}
			if (length(legtext_i) == 1) {
				text_i <- text_i
			}
			if (legx[1] == "default") {
				textx <- ifelse(i == 1, usr[1]+(0.015*diff(usr[1:2])), usr[2]-(0.025*diff(usr[1:2])))  ## (RH 200825)
			}
			else {
				textx <- legx[i]
			}
			if (legy[1] == "default") {
				texty <- usr[4]
				texty2 <- usr[3]
			}
			else {
				texty <- legy[i]
				texty2 <- -legy[i]
			}
			if (legadjx[1] == "default") {
				adjx <- ifelse(i == 1, -0.1, 1)
			}
			else {
				adjx <- legadjx[i]
			}
#if (i==2) {browser();return()}
			if (legadjy[1] == "default") {
				adjy <- ifelse(i < 3, 1.3, 1.3 + 1.3 * (i - 2))
			}
			else {
				adjy <- legadjy[i]
			}
			text(x=textx, y=texty, labels=text_i, adj=c(adjx, 
				adjy), cex=legsize[i], font=legfont[i])
			if (text_i2 != text_i & text_i2 != "") {
				text(x=textx, y=texty2, labels=text_i, adj=c(adjx, -adjy), cex=legsize[i], font=legfont[i])
			}
			if (twosex & !bub & venusmars) {
				pu <- par("usr")
				xval <- pu[2]
				if (length(ptsx_i0) > 0) {
					text(xval, 0.5 * yrange[2], "\\VE+\\MA", vfont=c("serif", "plain"), cex=2, col=linescol[1], pos=2)
				}
				if (length(ptsx_i1) > 0) {
					text(xval, 0.5 * yrange[2], "\\VE", vfont=c("serif", "plain"), cex=2, col=linescol[2], pos=2)
				}
				if (length(ptsx_i2) > 0) {
					text(xval, -0.5 * yrange[2], "\\MA", vfont=c("serif", "plain"), cex=2, col=linescol[3], pos=2)
				}
			}
		}
		mfg <- par("mfg")
		if (mfg[1] == mfg[3] | ipanel == npanels) {
			axis(side=1, at=axis1, labels=axis1labs, las=xlas)
		}
		if (mfg[2] == 1) {
			axis(side=2, at=axis2, las=ylas)
			if (twosex) {
				axis(side=2, at=-axis2[axis2 > 0], labels=format(axis2[axis2 > 0]), las=ylas)
			}
		}
		box()
		if (npanels == 1 | ipanel%%(nrows * ncols) == 1) {
			fixcex <- 1
			if (max(nrows, ncols) == 2) {
				fixcex <- 1/0.83
			}
			if (max(nrows, ncols) > 2) {
				fixcex <- 1/0.66
			}
			if (npanels > 1) {
				title(main=main, line=c(2, 0, 3, 3), outer=TRUE, cex.main=cex.main * fixcex)
				title(xlab=xlab, outer=TRUE, cex.lab=fixcex)
				title(ylab=ylab, line=ifelse(ylas %in% 1:2, max(3, 2 + 0.4 * maxchar_yaxs), 3.5), outer=TRUE, cex.lab=fixcex)
			}
			else {
				title(main=main, xlab=xlab, ylab=ylab, outer=TRUE, cex.main=cex.main)
			}
		}
	}
	par(mfcol=par_old$mfcol, mar=par_old$mar, oma=par_old$oma)
	if (anyscaled) {
		cat("Note: compositions have been rescaled by dividing by binwidth\n")
	}
	return(list(npages=npages, npanels=npanels, ipage=ipage))
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~make_multifig

