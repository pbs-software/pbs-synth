require(r4ss)

d.tools = "C:/Users/haighr/Files/Projects/R/Develop/PBStools/Authors/Rcode/develop/"
r.tools = c("linguaFranca", "clearFiles","extractAges","calcStockArea")
for (i in r.tools) source(paste0(d.tools,i,".r"))

d.synth = "C:/Users/haighr/Files/Projects/R/Develop/PBSsynth/Authors/Rcode/develop/"
r.synth = c("PBSsynth","plotFuns","utilFuns","plotSS.snail")
for (i in r.synth) source(paste0(d.synth,i,".r"))

d.awatea = "C:/Users/haighr/Files/Projects/R/Develop/PBSawatea/Authors/Rcode/develop/"
r.awatea = c("mochaLatte")
for (i in r.awatea) source(paste0(d.awatea,i,".r"))

options(scipen=10)

## MPD values
## will need to get replist from appropriate MPD directory (hm=Hastings-Metropolis,mh=Metropolis-Hastings,nuts=No U-turn sampler)
replist = SS_output(dir=sub("\\.mh.+","",sub("\\.hm.+","",sub("\\.nuts.+","",sub("MCMC","MPD",getwd())))))
B.mpd = replist$timeseries$SpawnBio
R.mpd = replist$timeseries$Recruit_0
names(B.mpd) = names(R.mpd) = replist$timeseries$Yr
parameters   = replist$parameters
pactive = parameters[!is.na(parameters$Active_Cnt) & parameters$Phase>0 & !is.element(parameters$Pr_type,"dev"),]
P.mpd   = pactive$Value; names(P.mpd)=pactive$Label
P.rc    = .findSquare(length(P.mpd))

## MCMC values
mcmc = SSgetMCMC(getwd())
replist$mcmc = mcmc

P.mcmc    = mcmc[,names(P.mpd)]
B.mcmc    = mcmc[,grep("^SSB_[12]",colnames(mcmc))]
D.mcmc    = mcmc[,grep("^Bratio_[12]",colnames(mcmc))]
R.mcmc    = mcmc[,grep("^Recr_[12]",colnames(mcmc))]
Rdev.mcmc = mcmc[,grep("^Main_RecrDev_[12]",colnames(mcmc))]
SPR.mcmc  = mcmc[,grep("^SPRratio_[12]",colnames(mcmc))]
F.mcmc    = mcmc[,grep("^F_[12]",colnames(mcmc))]
u.mcmc    = 1-exp(-F.mcmc)
Bmsy.mcmc = mcmc[,"SSB_MSY"]
Fmsy.mcmc = mcmc[,"annF_MSY"]
umsy.mcmc = 1-exp(-Fmsy.mcmc)
BoverBmsy = B.mcmc/Bmsy.mcmc
UoverUmsy = u.mcmc/umsy.mcmc

diag.mpd  = list(B=B.mpd, R=R.mpd, P=P.mpd)
diag.mcmc = list(B=B.mcmc, R=R.mcmc, P=P.mcmc)

pfigs  = c("pmcmc","dmcmc","rmcmc") #"nada" #"dmcmc" #
ptypes = "png"; lang=c("f","e")
if (all(pfigs=="nada")){
	ptypes = "win"; lang=c("e")
}
do.call("assign", args=list(x="quants3", value=c(0.05,0.50,0.95), envir=.PBSmodEnv))
do.call("assign", args=list(x="quants5", value=c(0.05,0.25,0.50,0.75,0.95), envir=.PBSmodEnv))

currYr = 2020
assYrs = 2011
modYrs = 1935:2020
proYrs = 2021:2030
ngear  = 1  ## number of commercial fisheries

if ("pmcmc" %in% pfigs) { ## Parameter MCMC quantile plots
	so("plotSS.pmcmc.r","synth")
	plotSS.pmcmc(R.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab="Recruitment", outnam="recruitsMCMC", ptypes=ptypes)
	plotSS.pmcmc(F.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab="Fishing mortality", outnam="fishmortMCMC", ptypes=ptypes)
	plotSS.pmcmc(u.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab="Exploitation rate", outnam="exploitMCMC", ptypes=ptypes)
	plotSS.pmcmc(D.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab="Depletion", outnam="depleteMCMC", ptypes=ptypes)
	plotSS.pmcmc(B.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab="Spawning biomass", outnam="sbiomassMCMC", ptypes=ptypes)
	plotSS.pmcmc(SPR.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab="Spawners per recruit", outnam="sprMCMC", ptypes=ptypes)
	plotSS.pmcmc(Rdev.mcmc, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab="Recruitment deviations", outnam="recdevMCMC", ptypes=ptypes, y0=F)
	plotSS.pmcmc(BoverBmsy, yrs=modYrs, lang=lang, cex.axis=1.2, cex.lab=1.5, yLab=expression(B[t] / B[MSY]), outnam="boverbmsyMCMC", xyType="envelope", ptypes=ptypes, pyrs=2021:2030, LRP=0.4, USR=0.8)
}
if ("dmcmc" %in% pfigs) { ## Diagnostic for MCMCs
	so("plotSS.dmcmc.r","synth")
	plotSS.dmcmc(mcmcObj=diag.mcmc, mpdObj=diag.mpd, ptypes=ptypes, lang=lang)
}
if ("rmcmc" %in% pfigs) { ## Routine output for MCMCs
	so("plotSS.rmcmc.r","synth")
	plotSS.rmcmc(mcmcObj=diag.mcmc, mpdObj=diag.mpd, ptypes=ptypes, lang=lang)
}
