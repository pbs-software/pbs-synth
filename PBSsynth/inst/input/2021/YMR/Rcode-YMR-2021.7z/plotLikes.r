plotLikes = function(M=seq(0.02,0.15,0.01), A=c(40,45,50), 
   prefix="WWR-MMM-", suffix="lik", znam="C@A_Commercial", zpos=1,
   outnam="LLcontours", type="contour", 
   png=FALSE, pngres=400, PIN=c(8,8))
{
	## Start subfunctions
	## Determine number of decimal places with non-trailing zeroes
	## See user 'darocsig' @ https://stackoverflow.com/questions/5173692/how-to-return-number-of-decimal-places-in-r
	decimalplaces <- function(x) {
		if (abs(x - round(x)) > .Machine$double.eps^0.5) {
			nchar(strsplit(sub('0+$', '', as.character(x)), ".", fixed = TRUE)[[1]][[2]])
		} else {
			return(0)
		}
	}
	## End subfunctions

	dcM  =  max(sapply(M,decimalplaces))
	ncA  = max(nchar(A))
	xlen = length(M)
	ylen = length(A)
	zlen = length(znam)
	zpos = rep(zpos,zlen)[1:zlen]
	if (any(duplicated(znam)))
		znam = paste0(znam,"_",zpos)
	zmat = array(NA, dim=c(xlen,ylen,zlen), dimnames=list(x=show0(M,dcM), y=pad0(A,ncA), z=znam))
	zint = list()

	for (a in A){
		aa = pad0(a,ncA)
		for (m in M){
			mm = show0(m,dcM)
			mpref = paste0(sub("MM-",paste0(sub("0\\.","",show0(m,dcM)),"-"),prefix),"A",pad0(a,ncA))
			#.flush.cat(paste0("Processing run '", mpref, "' ..."), "\n")
			mfile = paste0(mpref,".",suffix)
			mline = readLines(mfile)
			for (z in 1:zlen) {
				zz   = znam[z]
				zzz  = zpos[z]
#browser();return()
				zlin = mline[grep(sub("_[[:digit:]]$","",zz), mline)]
				zval = as.numeric(strsplit(zlin,split="\\s+")[[1]][zzz+1])
				zmat[mm,aa,zz] = zval
			}
		} ## end m loop (natural mortality)
	} ## end a loop (maximum age for plus class)

	for (z in 1:zlen) {
		zz   = znam[z]
		zint[[zz]] = akima::interp(x=rep(M,ylen),y=rep(A,each=xlen),z=as.vector(zmat[,,zz]), nx=50, ny=50)
	}

	if (png) png(file=paste0(outnam,".png"), units="in", res=pngres, width=PIN[1], height=PIN[2])
	expandGraph(mfrow=findRC(zlen,orient="landscape"), mar=c(3,3,1.75,0.5))
	if (grepl("contour[s]?",type)) {
		sapply(1:zlen, function(x){
			z  = zint[[x]]
			zz = names(zint)[x]
			contour(z, nlevels=10, xlab="Natural Mortality (M)", ylab="Age (y) of plus group", cex.axis=1, cex.lab=1.2 )
			mtext(zz, side=3, line=0.25, cex=1.2)
		})
	} else if (grepl("line[s]?",type)) {
		lcol = c("blue","green4","red")
		llty = c(1,2,3)
		sapply(1:zlen, function(x){
			z  = znam[x]
			zz = zmat[,,z]
			plot(0,0, type="n", xlim=range(M), ylim=range(zz), xlab="Natural Mortality (M)", ylab="Likelihood Value", cex.axis=1, cex.lab=1.2 )
			sapply(1:ncol(zz), function(i){
				lines(M, zz[,i], col=lcol[i], lty=llty[i], lwd=2)
			})
			if (par()$mfg[1]==1 && par()$mfg[2]==par()$mfg[4])
				addLegend(0.95, 0.95, lty=llty, lwd=2, col=lcol, legend=paste0("Max age = ",colnames(zz),"+"), bty="n", xjust=1)
#browser();return()
			mtext(z, side=3, line=0.25, cex=1.2)
		})
	}
	if (png) dev.off()
}
out = plotLikes(znam=c("Total_likelihood", "CPUE", "C@A_Commercial","Priors"), outnam="WWR-LLcontours-Set1", png=T)
out = plotLikes(znam=rep("C@A_survey",4), zpos=1:4, outnam="WWR-LLcontours-Set2", png=T)
out = plotLikes(znam=rep("Survey_Index",5), zpos=1:5, outnam="WWR-LLcontours-Set3", png=T, PIN=c(10,7.5))
#out = plotLikes(znam=c("Total_likelihood", "CPUE", "C@A_Commercial","Priors"), type="line", outnam="WWR-LLvalue-Set1", png=T)
#out = plotLikes(znam=rep("C@A_survey",4), zpos=1:4, type="line", outnam="WWR-LLvalue-Set2", png=T)
#out = plotLikes(znam=rep("Survey_Index",5), zpos=1:5, type="line", outnam="WWR-LLvalue-Set3", png=T, PIN=c(10,7.5))

