## convPN-------------------------------2021-09-05
##  Convert parameter names from SS to Awatea
## ---------------------------------------------RH
convPN = function(pnams) {
	cnams =
		sub("NatM_p_1_Fem_GP_1|NatM_uniform_Fem_GP_1","M_Female",
		sub("NatM_p_1_Mal_GP_1|NatM_uniform_Mal_GP_1","M_Male",
		sub("Early_RecrDev|Main_RecrDev|Late_RecrDev|ForeRecr","RecrDev",
		sub("FISHERY","", 
		sub("SYNOPTIC","",
		sub("HISTORIC(AL)?","",
		sub("^Age_DblN_end_logit","beta6",
		sub("^Age_DblN_top_logit","beta2",
		sub("^Age_DblN_descend_se","varR",
		sub("^Age_DblN_ascend_se","varL",
		sub("^Age_DblN_peak","mu",
		sub("^SR_","",
		pnams))))))))))))
		onams   = sapply(strsplit(cnams,"_"), function(x){
		if(length(x)==3 && x[1] %in% c("mu","beta2","varL","varR","beta6")) {
			paste0(x[1],x[3],"_",x[2])
#browser();return()
		} else {
			paste0(x,collapse="_")
		}
	})
	return(onams)
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~convPN

#d.mcmc = SSgetMCMC(getwd()); test=colnames(d.mcmc)
#test = pactive$Label
#out = convPN(test)
