## runSweave----------------------------2021-07-06
##  Run Sweave code to build pdfs for MPD and MCMC runs (not appendix)
## ---------------------------------------------RH
runSweave = function (d.model=getwd(), d.sweave, type="MPD")
{
	if (missing(d.sweave))
		d.sweave = "C:/Users/haighr/Files/Projects/R/Develop/PBSsynth/Authors/Rcode/develop"
	f.sweave = paste0(basename(d.model),".Rnw")

	if (!file.copy(from=file.path(d.sweave, paste0("sweave",type,".Rnw")), to=file.path(d.model,f.sweave), overwrite=TRUE, copy.date=TRUE))
		stop("Failed to copy Sweave file to directory\n\t",d.model)

	## Other 'log' files (e.g., from Sweave) interfere with r4ss::SS_output
	if (file.exists(sub("\\.Rnw",".log",f.sweave)))
		file.remove(sub("\\.Rnw",".log",f.sweave))

	Sweave(file.path(d.model, f.sweave))
	mpd.sweave = shell(cmd=paste0("texify --pdf --synctex=1 --clean ",sub("\\.Rnw",".tex",f.sweave)), wait=TRUE, intern=TRUE)
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~runSweave
#runSweave(type="MCMC")
