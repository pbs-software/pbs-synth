## Make Sensitivity Tables
## -----------------------
make.sens.tabs = function(istock, prefix)
{
	on.exit(gc(verbose=FALSE))
	unpackList(stock[[istock]][["Controls"]])
	unpackList(stock[[istock]]$Base$Pool)
	unpackList(stock[[istock]]$Sens)
	unpackList(example.run)
	tget(sens.stuff); unpackList(sens.stuff)  ## created in 'gather.base.case()'

	## MCMC model parameters
	#base.pars = sapply(P.mcmc,median)  ## base composite but use central run
	currentMCMC = stock[[istock]]$Base[[exp.run.rwt]]$currentMCMC
	base.pars = sapply(currentMCMC$P,median)
	## Sabotage sen.pars if BOR
	if (spp.code=="BOR") {
		isens    = grep("09",colnames(sen.pars),invert=T)
		sen.pars = sen.pars[,isens]  ## get rid of sensitivity 9 (drop CPUE)
		sen.lab  = sen.lab[isens]
		Nsens    = length(isens)
	}
	tab.sens.pars = array(NA,dim=dim(sen.pars)+c(0,1), dimnames=list(rownames(sen.pars), c(exp.run.rwt,colnames(sen.pars))))
	tab.sens.pars[names(base.pars),exp.run.rwt] = base.pars
	tab.sens.pars[rownames(sen.pars),colnames(sen.pars)] = sen.pars

	colnams = c(paste0("C(R",substring(exp.run.rwt,1,2),")"), paste0("S",pad0(isens,2),"(R",pad0(sen.run.nums[isens],2),")") )
	if (Ndiag>0)
		colnams = c(colnams, paste0("D",1:Ndiag,"(R",pad0(sen.run.nums[idiag],2),")"))
	colnames(tab.sens.pars) = colnams
	if (exists("formatCatch")) {
		tab.sens.pars = formatCatch(tab.sens.pars)
	} else {
		tab.sens.pars["R_0",] = round(tab.sens.pars["R_0",]) }
	names.pars = rownames(tab.sens.pars)
	fixsub = grep("_",names.pars)
	names.pars[fixsub] = paste0(sub("_","_{",names.pars[fixsub]),"}")
	names.pars = gsub("mu","\\\\mu",names.pars)
	names.pars = gsub("Delta","\\\\Delta",names.pars)
	names.pars = sub("log","\\\\mathrm{log}",names.pars)
	#names.pars = gsub("log","\\\\mathrm{log}",gsub("v_","v_{",gsub("L","L}",names.pars)))
	rownames(tab.sens.pars) =  paste(rep("$",nrow(tab.sens.pars)),names.pars,rep("$",nrow(tab.sens.pars)),sep="")

	sen.leg = paste0("Sensitivity runs: ", paste0("S", formatC(isens, width=0, format="d", flag="0"),"~= ", gsub("_"," ",sen.lab), collapse=", "))
	if (spp.code=="REBS") {  ## need to add Other fishery because it has ages but no CPUE index
		nseries = length(iseries)
		iseries[nseries] = paste0(iseries[nseries],"/Trawl fishery")
		iseries = c(iseries, "Other fishery")
	}
	cap.par = paste0(
		name, ": median values of MCMC samples for the primary estimated parameters, ",
		"comparing the central run to ", Nsens, " sensitivity runs (", nmcmc,
		" samples each). C~=Central, R~= Run, S~= Sensitivity. ",
		#"D~=Diagnostic sensitivity ($M$=0.11). ",
		"Numeric subscripts other than those for $R_0$ and $M$ indicate the following gear types $g$: ",
		texThatVec(paste0(1:length(iseries),"~= ",iseries),simplify=F), ". ", sen.leg
	)
	xtab.sens.pars = xtable(tab.sens.pars, align=paste0("c",paste0(rep("r",Nsens+1),collapse="")),
		label   = paste0("tab:",prefix,"sens.mcmc.pars"), digits = if (exists("formatCatch")) NULL else sigdig,
		caption = cap.par )
	xtab.sens.pars.out = capture.output( print(xtab.sens.pars, caption.placement="top",
		sanitize.rownames.function=function(x){x},
		add.to.row =list(pos = list(-1), command = c("\\\\[-1.0ex]")),
		size = "\\usefont{\\encodingdefault}{\\familydefault}{\\seriesdefault}{\\shapedefault}\\footnotesize"
	) )
	tput(xtab.sens.pars.out)

	## MCMC MSY-based quantities
	ls2df = function(x) {
		nn = as.character(substitute(x))
		xx = as.data.frame(x)
		colnames(xx) = paste(nn,colnames(xx),sep="_")
		return(xx)
	}

	M.mcmc = data.frame(B0, ls2df(VB0), Bcurr, ls2df(VBcurr), Bcurr.B0, ls2df(VBcurr.VB0), ls2df(Ucurr), ls2df(Umax), MSY, Bmsy, LRP, USR, Bcurr.Bmsy, Bmsy.B0, VBmsy, ls2df(VBmsy.VB0), Umsy, ls2df(Ucurr.Umsy))

	## Need to extract Central Run ## RH 200504
	i.cent = (1:length(B.index))[is.element(B.index,exp.run.rwt)]  ## RH 200424: Should be more stable when central run is not necessarily 'central'
#browser();return()
	M.mcmc = M.mcmc[i.cent,]
	base.rfpt = sapply(M.mcmc, median)

	## Sabotage sen.rfpt if BOR
	if (spp.code=="BOR") {
		sen.rfpt = sen.rfpt[,isens,]  ## get rid of sensitivity 9 (drop CPUE)
	}
	tab.sens.rfpt = array(NA,dim=c(dim(M.mcmc)[2],dim(sen.rfpt)[2]+1),dimnames=list(colnames(M.mcmc),c("Base",colnames(sen.rfpt))))
	tab.sens.rfpt[names(base.rfpt),"Base"] = base.rfpt

	## Basically have to knit sen.rfpt into tab.sens.rfpt (what a pain).
	for (k in dimnames(sen.rfpt)[[3]]) {
		g.flds = c("VB0","VBcurr","VBcurr.VB0","Ucurr","Umax","VBmsy.VB0","Ucurr.Umsy")
		k.rfpt = sen.rfpt[,,k]
		cnam = colnames(k.rfpt)
		if (k %in% dimnames(sen.rfpt)[[3]][1]) {
			rnam = setdiff(rownames(k.rfpt),g.flds)
			tab.sens.rfpt[rnam,cnam] = k.rfpt[rnam,cnam]
		}
		rnam = paste0(g.flds,"_",k)
		tab.sens.rfpt[rnam,cnam] = k.rfpt[g.flds,cnam]
	}
	colnames(tab.sens.rfpt) = colnams
	if (exists("formatCatch")) {
		tab.sens.rfpt = formatCatch(tab.sens.rfpt)
	} else {
		tab.sens.rfpt["R_0",] = round(tab.sens.rfpt["R_0",]) }
	names.rfpt = rownames(tab.sens.rfpt)
	## Use routine from 'make.base.tabs.r':
	names.rfpt =
		gsub("_Trawl", "~(\\\\mathrm{Trawl})",
		gsub("_Other", "~(\\\\mathrm{Other})",
		gsub("LRP",  paste0("0.4B_{",currYear,"}"),
		gsub("USR",  paste0("0.8B_{",currYear,"}"),
		gsub("VB",  "V",
		gsub("Umax", "u_\\\\mathrm{max}",
		gsub("msy", "_\\\\mathrm{MSY}",
		gsub("curr",  paste0("_{",currYear,"}"),
		gsub("Umsy",  "u_\\\\mathrm{MSY}",
		gsub("Ucurr", paste0("u_{",prevYear,"}"),
		gsub("0", "_{0}",
		gsub("\\.", "/",
		names.rfpt))))))))))))
	rownames(tab.sens.rfpt) =  paste(rep("$",nrow(tab.sens.rfpt)),names.rfpt,rep("$",nrow(tab.sens.rfpt)),sep="")

	cap.rfpt = paste0(
		name, ": medians of MCMC-derived quantities from the central run and ", Nsens,
		" sensitivity runs (", nmcmc, " samples each) from their respective MCMC posteriors. Definitions are: ",
		"$B_0$ -- unfished equilibrium spawning biomass (mature females), ",
		"$V_0$ -- unfished equilibrium vulnerable biomass (males and females), ",
		"$B_{", currYear, "}$ -- spawning biomass at the start of ",currYear, ", ",
		"$V_{", currYear, "}$ -- vulnerable biomass in the middle of ", currYear, ", ",
		"$u_{", currYear-1, "}$ -- exploitation rate (ratio of total catch to vulnerable biomass) in the middle of ", currYear-1, ", ",
		"$u_\\mathrm{max}$ -- maximum exploitation rate (calculated for each sample as the maximum exploitation rate from ",
		substring(names(currentMCMC$U[1,])[1],1,4), " - ", substring(rev(names(currentMCMC$U[1,]))[1],1,4), "), ",
		"$B_\\mathrm{MSY}$ -- equilibrium spawning biomass at MSY (maximum sustainable yield), ",
		"$u_\\mathrm{MSY}$ -- equilibrium exploitation rate at MSY, ",
		"$V_\\mathrm{MSY}$ -- equilibrium vulnerable biomass at MSY. ",
		"All biomass values (and MSY) are in tonnes. ", sen.leg
	)
#browser();return()

	xtab.sens.rfpt = xtable(tab.sens.rfpt, align=paste0("l",paste0(rep("r",Nsens+1),collapse="")),
		label   = paste0("tab:",prefix,"sens.mcmc.rfpt"), digits = if (exists("formatCatch")) NULL else sigdig,
		caption = cap.rfpt )
	xtab.sens.rfpt.out = capture.output( print(xtab.sens.rfpt, caption.placement="top",
		sanitize.rownames.function=function(x){x},
		add.to.row =list(pos = list(-1), command = c("\\\\[-1.0ex]")),
		hline.after =  c(-1,0,13,nrow(xtab.sens.rfpt)),
		size = "\\usefont{\\encodingdefault}{\\familydefault}{\\seriesdefault}{\\shapedefault}\\footnotesize"
	) )
	tput(xtab.sens.rfpt.out)
#browser();return()

	save("xtab.sens.pars.out", "xtab.sens.rfpt.out", file=paste0(prefix,"sensitivity.tables.rda"))

	collect=c("tab.sens.pars","tab.sens.rfpt")
	for (i in collect) 
		eval(parse(text=paste0("stock[[istock]][[\"Sens\"]][[\"",i,"\"]] = ",i)))
}
## Activate for debugging only:
#make.sens.tabs(istock) #, prefix="RER.")
