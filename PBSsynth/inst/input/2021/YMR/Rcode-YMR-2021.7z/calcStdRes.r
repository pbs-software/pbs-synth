## calcStdRes---------------------------2021-04-07
##  This implements standardised residuals for the Awatea
##  implementation of the Fournier robustified normal likelihood
##  for proportions at length. Based on PJS summary of CASAL doc and ACH change to length.
##------------------------------------------AME|RH
calcStdRes <- function( obj, trunc=3, myLab="Age Residuals", prt=TRUE, type="Multinomial",
   afld="Bin", yfld="Yr", ofld="Obs", ffld="Exp", nfld="Nsamp_adj" )
{
	# Make a column for the standardised residuals.
	result <- cbind( obj,stdRes=rep(NA,nrow(obj)) )

	# Raw residuals.
	res <- obj[,ofld] - obj[,ffld]  ## (O-F)

	# Number of age bins.
	# QUESTION: Should this be from FIRST age to plus group?
	nage <- length( unique(obj[,afld]) )

	# Kludgy, but loop through years.
	# Could reformat into matrix and vectorize.

	## Robustifying function
	Z = function (x, r=0.001){
		is.soft = x < r
		if (any(is.soft))
			x[is.soft] = r / (2 - x[is.soft]/r)
		return(x)
	}

	yrList <- sort( unique( obj[,yfld] ) )
	for ( i in 1:length( yrList ) )
	{
		idx <- yrList[i]==obj[,yfld]
		## Pearson residual = (O-F)/std.dev(O)  : see CASAL Manual, Section 6.8 Residuals
		## where std.dev(O) is calculated as:
		Nprime  <- min( obj[,nfld][idx],1000)                         ## N prime
		Fprime  <- obj[,ffld][idx]*(1.0-obj[,ffld][idx]) + 0.1/nage   ## F prime (Fournier uses Fitted)
		Oprime  <- obj[,ofld][idx]*(1.0-obj[,ofld][idx]) + 0.1/nage   ## O prime (Coleraine uses Observed)
		Mprime  <- Z(obj[,ffld][idx]) * (1-Z(obj[,ffld][idx]))        ## M prime (Multinomial uses Fitted)
		SD      <- sqrt(
			switch(type, 'Multinomial'=Mprime, 'Fournier'=Fprime, 'Coleraine'=Oprime) / Nprime )  
		result$stdRes[idx] <- res[idx]/SD                             ## Pearson residuals = Normalised residuals for normal error distributions
#browser();return()
	}
	if ( prt ) {
		sdRes <- sqrt( var( result$stdRes,na.rm=TRUE ) )
		sdTrunc <- ifelse( result$stdRes > trunc, trunc, result$stdRes )
		sdTrunc <- ifelse( result$stdRes < -trunc, -trunc, result$stdRes )
		sdResTrunc <- sqrt( var( sdTrunc,na.rm=TRUE ) )
		cat( "\n",myLab,"\n" )
		cat( "\n     Std. Dev. of standardised Residuals=",sdRes,"\n" )
		cat( "     Std. Dev. of Truncated standardised Residuals=",sdResTrunc,"\n" )
	}
	return(result)
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~calcStdRes

#out = calcStdRes(test)
