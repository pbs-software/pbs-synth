## prepCP-------------------------------2021-08-23
##  Prepare Catch Policies -- 'CC'=constant catch, 'HR'=harvest rate (not implemented yet)
##  fyrs includes the current year (e.g., 2022=beginning of 2022, end of 2021), which is treated as a projection
## ---------------------------------------------RH
prepCP = function(run.rwt, cp=1057, d.cp="CC", tag="nuts4K", 
	fyrs=2022:2032, season=1, fleet=1, ## will need to alter if more than one fleet
	d.base = "C:/Users/haighr/Files/GFish/PSARC21/YMR/Data/SS/YMR2021",
	w=NULL, cvpro=NULL)
{
	padded = pad0(run.rwt,2)
	t.run=padded[1]; t.rwt=padded[2]
	tar.run.rwt = paste(t.run,t.rwt,sep=".")
	d.target = file.path(d.base, paste0("Run", t.run), paste0("MCMC.",tar.run.rwt,".",tag))
	poop = function(){ setwd(d.target); gdump = gc(verbose=FALSE) }
	on.exit(poop())

	need.files = c("starter.ss","forecast.ss",paste0(c("control","data"),".",tar.run.rwt,".ss"), "ss.par","ss.cor","ss.psv", paste0("admodel.",c("hes","cov")))
	for (i in 1:length(cp)) {
		ii = cp[i]
		iii = pad0(i,2)
		#d.catch.policy = file.path(d.target, d.cp, pad0(i,4))
		d.policy.type = file.path(d.target, d.cp)
		if (!file.exists(d.policy.type))
			dir.create(d.policy.type)
		d.catch.policy = file.path(d.policy.type, paste0("CP",iii))
		if (!file.exists(d.catch.policy)){
			dir.create(d.catch.policy)
		} else {
			clearFiles( setdiff(list.files(d.catch.policy,full.names=T),list.dirs(d.catch.policy)) )  ## need full names and explicit exclusion of directories
		}
		pee = file.copy(from=file.path(d.target,need.files), to=d.catch.policy, copy.date=T, overwrite=T)
		
		## Modify forecast file to reflect new catch policies
		forecast = readLines(file.path(d.catch.policy,"forecast.ss"))

		fline    = grep("#_fcast_nyrs",forecast)
		forecast[fline] = sub(substring(forecast[fline],1,(regexpr(" #_fcast_nyrs",forecast[fline])-1)), length(fyrs), forecast[fline])
		fline    = grep("#_ctl_rule_ul",forecast)
		forecast[fline] = sub(substring(forecast[fline],1,(regexpr(" #_ctl_rule_ul",forecast[fline])-1)), 0.002, forecast[fline])
		fline    = grep("#_ctl_rule_ll",forecast)
		forecast[fline] = sub(substring(forecast[fline],1,(regexpr(" #_ctl_rule_ll",forecast[fline])-1)), 0.001, forecast[fline])
#_ctl_rule_ul
		fline    = grep("#_fcast_yr1",forecast)
		forecast[fline] = sub(substring(forecast[fline],1,4), fyrs[2] + 100, forecast[fline])
		f1     = grep("#_Yr Seas Fleet Catch",forecast)
		f2     = grep("#_end_catpols",forecast)
		nyrs   = length(fyrs)
		newpol = data.frame(Yr=fyrs, Seas=rep(season,nyrs), Fleet=rep(fleet,nyrs), Catch=rep(ii,nyrs))
		foopol = apply(newpol,1,paste0,collapse=" ")
		forecast = c(forecast[1:f1], foopol, forecast[f2:length(forecast)])
#browser();return()
		writeLines(forecast, con=file.path(d.catch.policy,"forecast.ss"))

		.flush.cat(paste0("CP = ", i, " -- run mceval to generate catch policies.\n"))
		setwd(d.catch.policy)
		gdump = gc(verbose=FALSE)
		syssy = system("ss -mceval", intern=TRUE)
		writeLines(syssy,paste0("./sys", pad0(i,4), ".txt"))
	}
	.flush.cat("C'est toute, folks\n")
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~prepCP

so("clearFiles.r")
#prepCP(run.rwt=c(75,1), cp=seq(500), fyrs=2022:2031, d.base="C:/Users/haighr/Files/GFish/PSARC21/YMR/Data/SS/Explore")
cp = c(0,500,750,1000,1250,1500,2000,2500,3000)
prepCP(run.rwt=c(77,1), cp=cp, fyrs=2022:2032, d.base="C:/Users/haighr/Files/GFish/PSARC21/YMR/Data/SS/YMR2021")
prepCP(run.rwt=c(71,1), cp=cp, fyrs=2022:2032, d.base="C:/Users/haighr/Files/GFish/PSARC21/YMR/Data/SS/YMR2021")
prepCP(run.rwt=c(75,1), cp=cp, fyrs=2022:2032, d.base="C:/Users/haighr/Files/GFish/PSARC21/YMR/Data/SS/YMR2021")
prepCP(run.rwt=c(72,1), cp=cp, fyrs=2022:2032, d.base="C:/Users/haighr/Files/GFish/PSARC21/YMR/Data/SS/YMR2021")
prepCP(run.rwt=c(76,1), cp=cp, fyrs=2022:2032, d.base="C:/Users/haighr/Files/GFish/PSARC21/YMR/Data/SS/YMR2021")


