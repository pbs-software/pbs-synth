plotSS.profile = function(mydir, string="NatM", p.vec=seq(0.040,0.065,0.005))
{
	## note: don't run this in your main directory; make a copy in case something goes wrong
	#mydir <- "C:/ss/Simple - Copy"
	
	## The following commands related to starter.ss could be done by hand:
	## Read starter file
	starter <- SS_readstarter(file.path(mydir, 'starter.ss'))
	## Change control file name in the starter file
	starter$ctlfile <- "control_modified.ss"
	## Make sure the prior likelihood is calculated for non-estimated quantities
	starter$prior_like <- 1
	# Write modified starter file
	SS_writestarter(starter, dir=mydir, overwrite=TRUE)
	
	## Vector of values to profile over
	#h.vec <- seq(0.3,0.9,.1)
	Nprofile <- length(p.vec)
	
	# Run SS_profile command
	file.copy(from="C:/Users/haighr/Files/Archive/Bat/ss.exe", to=mydir, overwrite=FALSE, copy.date=TRUE)
	profile <- SS_profile(dir=mydir, model="ss", masterctlfile="control.ss_new", newctlfile="control_modified.ss", string=string, profilevec=p.vec)

	# Read the output files (with names like Report1.sso, Report2.sso, etc.)
	profilemodels <- SSgetoutput(dirvec=mydir, keyvec=1:Nprofile)
	ttput(profilemodels)
	# Summarize output
	profilesummary <- SSsummarize(profilemodels)
	ttput(profilesummary)
	
	# OPTIONAL COMMANDS TO ADD MODEL WITH PROFILE PARAMETER ESTIMATED
	#MLEmodel <- SS_output("C:/ss/SSv3.24l_Dec5/Simple")
	#profilemodels$MLE <- MLEmodel
	#profilesummary <- SSsummarize(profilemodels)
	# END OPTIONAL COMMANDS
	
	# plot profile using summary created above
	SSplotProfile(profilesummary, profile.string="NatM_p_1_Fem_GP_1", profile.label="Natural mortality (M)", plot=F, print=T, plotdir=mydir)
	
	# make timeseries plots comparing models in profile
	SSplotComparisons(profilesummary,legendlabels=paste("M =",p.vec), plot=F, print=T, plotdir=mydir)
	return(list(profilesummary=profilesummary, profilemodels=profilemodels))
}
profile = plotSS.profile(mydir=getwd())
