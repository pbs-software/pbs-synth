prepLike = function(run.rwt, #n.run, n.rwt, l.run, l.rwt,
	d.base = "C:/Users/haighr/Files/GFish/PSARC21/YMR/Data/SS/YMR2021",
	w=NULL)
{
	padded = pad0(run.rwt,2)
	n.run=padded[1]; n.rwt=padded[2]; l.run=padded[1]; l.rwt=padded[2]
	pre.run.rwt = paste(l.run,l.rwt,sep=".")
	new.run.rwt = paste(n.run,n.rwt,sep=".")
	## Destination directories
	#d.cwd = getwd(); on.exit(setwd(d.cwd))
	d.run = file.path(d.base,paste0("Like",n.run))
	d.mpd = file.path(d.run,paste("MPD",new.run.rwt,sep="."))
browser(); return()

	## Previous run from which to poach ssfiles
	p.run = file.path(d.base,paste0("Run",l.run))
	p.mpd = file.path(p.run,paste("MPD",pre.run.rwt,sep="."))
	if (!all(file.exists(c(p.run,p.mpd))))
		stop("Previous Run directory and/or MPD directory does not exist")
	if (!file.exists(d.run)) dir.create(d.run)
	if (!file.exists(d.mpd)) dir.create(d.mpd)
	p.ss  = setdiff(list.files(p.mpd, pattern="\\.ss$"),"runnumber.ss")
	pee   = file.copy(from=file.path(p.mpd,p.ss), to=d.mpd, copy.date=T, overwrite=F)
	poo   = file.rename(from=file.path(d.mpd,paste(c("data","control"),pre.run.rwt,"ss",sep=".")), to=file.path(d.mpd,paste(c("data","control"),new.run.rwt,"ss",sep=".")))

	## Modify starter file to reflect new run
	starter = readLines(file.path(d.mpd,"starter.ss"))
	dline   = grep(paste("data",pre.run.rwt,sep="."),starter)
	cline   = grep(paste("control",pre.run.rwt,sep="."),starter)
#browser();return()
	starter[dline] = sub(paste0("data\\.",l.run,"\\.",l.rwt),paste0("data.",new.run.rwt),starter[dline])
	starter[cline] = sub(paste0("control\\.",l.run,"\\.",l.rwt),paste0("control.",new.run.rwt),starter[cline])
	writeLines(starter, con=file.path(d.mpd,"starter.ss"))

	## Modify control file to add Francis reweights
	control = readLines(file.path(d.mpd,paste0("control.",new.run.rwt,".ss")))
	if (!is.null(w)){
		fline = grep("vadj_af",control)
		if (length(fline)!=length(w)){
			.flush.cat("Francis reweights do not match control lines\n"); browser();return()
		}
		fbits = strsplit(control[fline], split=" +")
		wdump = sapply(1:length(fbits),function(i){fbits[[i]][3] <<- w[i]})
		fnew  = sapply(fbits,function(x){ paste0(x,collapse=" ")})
		control[fline] = fnew
		writeLines(control, con=file.path(d.mpd,paste0("control.",new.run.rwt,".ss")))
#browser();return()
	}
	setwd(d.mpd)
	.flush.cat(paste0("***Edit the ss files in\n\t",d.mpd,"\nbefore proceeding with an MPD fit in SS."),"\n\n")
	return(invisible(list(starter=starter, control=control)))
}
prepLike(run.rwt=c(22,1))
#prepLike(run.rwt=c(7,1,7,0))
#prepLike(run.rwt=c(run,rwt,run,rwt-1),w=ttcall(w.francis)$w)

