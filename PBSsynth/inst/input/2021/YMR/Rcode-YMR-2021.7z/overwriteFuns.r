##==========================================================
## PBS Stock Synthesis:
##   Overwrite existing functions from other packages.
## ---------------------------------------------------------
## launch_shinyadmb......Launch shiny but useless GUI system to explore fits (mod.adnuts).
## pairs_admb............Plot pairwise parameter posteriors (mod.adnuts).
## sample_admb...........Bayesian inference of an ADMB model using the no-U-turn sampler (mod.adnuts)
## sample_admb_parallel..Sample ADMB MCMCs using parallel cores (mod.adnuts)
##==========================================================


## launch_shinyadmb---------------------2020-11-11
## adnuts Functions: launch_shinyadmb
## --------------------------------------adnuts|RH
launch_shinyadmb=function(fit)
{
	tmp_params=fit$sampler_params
	nms_params=lapply(tmp_params,function(x){x[,setdiff(colnames(x),"lp__")]})
	fit$sampler_params=nms_params
	ttput(fit)
	shinystan::launch_shinystan(.as.shinyadnuts(fit))
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~launch_shinyadmb


## pairs_admb---------------------------2020-10-26
## adnuts function: 'pairs_admb'
## --------------------------------------adnuts|RH
pairs_admb=function (fit, diag=c("trace", "acf", "hist"), acf.ylim=c(-1,1), 
   ymult=NULL, axis.col=gray(0.5), pars=NULL, label.cex=0.5, limits=NULL, ...) 
{
	mle <- fit$mle
	posterior <- extract_samples(fit, inc_lp=TRUE)
	chains <- rep(1:dim(fit$samples)[2], each=dim(fit$samples)[1] - fit$warmup)
	divs <- if (fit$algorithm == "NUTS") 
		extract_sampler_params(fit)$divergent__
	else NULL
	ptcex <- 0.1
	divcex <- 0.5
	chaincols <- 1:length(unique(chains))
	wp <- function(par.name) {
		x <- which(mle$par.names == par.name)
		if (length(x) == 0) 
			return(NA)
		if (length(x) > 1) 
			stop("Par matched multiple??")
		return(x)
	}
	old.par <- par(no.readonly=TRUE)
	on.exit(par(old.par))
	diag <- match.arg(diag)
	par.names <- names(posterior)
	if (is.null(pars)) {
		if (NCOL(posterior) > 10) {
			warning("Only showing first 10 parameters, use 'pars' argument to adjust")
			pars <- par.names[1:10]
		}
		else {
			pars <- par.names[1:NCOL(posterior)]
		}
	}
	else if (is.numeric(pars[1])) {
		pars <- par.names[pars]
	}
	pars.bad <- match(x=pars, table=names(posterior))
	if (any(is.na(pars.bad))) {
		warning("Some par names did not match -- dropped")
		pars <- pars[!is.na(pars.bad)]
	}
	n <- length(pars)
	if (n == 1) 
		stop("This function is only meaningful for >1 parameter")
	posterior <- posterior[, pars]

	## Fix sizing of correlations to be relative to chosen parameters RH 201026
	post.par=posterior
	post.cor=cex.cor=round(cor(post.par),2)
	z.cor   =abs(post.cor) < 1
	cex.cor[z.cor]=scaleVec(abs(post.cor[z.cor]),1,3)

	if (is.null(ymult)) 
		ymult <- rep(1.3, n)
	if (is.null(limits)) {
		limits <- list()
		for (i in 1:n) {
			pp <- wp(pars[i])
			limit.temp <- if (is.na(pp)) NULL
			else mle$est[pp] + c(-1, 1) * 1.96 * mle$se[pp]
			min.temp <- min(posterior[, i], limit.temp[1])
			max.temp <- max(posterior[, i], limit.temp[2])
			margin <- 0.15 * (max.temp - min.temp)
			limits[[i]] <- c(min.temp - margin, max.temp + margin)
		}
	}
	N <- NROW(posterior)
	mypch <- 16
	mycol <- 1
	if (N >= 1000) {
		mycol <- rgb(0, 0, 0, 0.5)
	}
	else if (N >= 10000) {
		mycol <- rgb(0, 0, 0, 0.05)
	}
	if (is.null(divs))
		divs <- rep(0, N)
	par(mfrow=c(n,n), mar=0 * c(0.1,0.1,0.1,0.1), yaxs="i", xaxs="i", mgp=c(0.25,0.25,0), tck=-0.02, cex.axis=1, col.axis=axis.col, oma=c(2,2,2,2))
	temp.box <- function() box(col=axis.col, lwd=0.5)
	for (row in 1:n) {
		for (col in 1:n) {
			if (row == col) {
				if (diag == "hist") {
					h <- hist(posterior[, row], plot=F)
					if (is.null(limits)) {
						hist(posterior[, row], axes=F, freq=FALSE, ann=F, ylim=c(0, ymult[row] * max(h$density)), col=gray(0.8), border=gray(0.5))
					}
					else {
						hist(posterior[, row], axes=F, freq=FALSE, ann=F, ylim=c(0, ymult[row] * max(h$density)), col=gray(0.8), border=gray(0.5), xlim=limits[[row]])
					}
					temp.box()
				}
				else if (diag == "acf") {
					acf(posterior[, row], axes=F, ann=F, ylim=acf.ylim)
					temp.box()
				}
				else if (diag == "trace") {
					xlim <- c(1, length(chains[chains == 1]))
					plot(x=0, y=0, type="n", axes=FALSE, ann=FALSE, ylim=limits[[row]], xlim=xlim)
					for (ll in unique(chains)) {
						lines(posterior[chains == ll, row], col=chaincols[ll], lwd=0.1)
					}
					temp.box()
				}
			}
			if (row > col) {
				par(xaxs="r", yaxs="r")
				plot(x=posterior[, col], y=posterior[, row], axes=FALSE, ann=FALSE, pch=mypch, cex=ptcex, col=mycol, xlim=limits[[col]], ylim=limits[[row]], ...)
				points(x=posterior[which(divs == 1), col], y=posterior[which(divs == 1), row], pch=mypch, cex=divcex, col="red")
				p1 <- wp(pars[row])
				p2 <- wp(pars[col])
				if (!is.na(p1) & !is.na(p2)) {
					points(x=mle$est[p2], y=mle$est[p1], pch=16, 
					cex=0.5, col=2)
					if (!requireNamespace("ellipse", quietly=TRUE)) {
						warning("ellipse package needs to be installed to show ellipses")
					}
					else {
						ellipse.temp <- ellipse:::ellipse(x=mle$cor[p2, p1], scale=mle$se[c(p2, p1)], centre=mle$est[c(p2,p1)], npoints=1000, level=0.95)
						lines(ellipse.temp, lwd=0.5, lty=1, col="red")
					}
				}
				par(xaxs="i", yaxs="i")
				temp.box()
			}
			if (row < col) {
				plot(0, 0, type="n", xlim=c(0,1), ylim=c(0,1), axes=F, ann=F)
				temp.cor <- round(cor(posterior[, c(row, col)])[1, 2], 2)
#browser();return()
				#legend("center", legend=NA, title=temp.cor, cex=(3 * abs(temp.cor) + 0.25) * 0.5, bty="n")
				#addLegend(0.5,0.5, legend=post.cor[row,col], cex=cex.cor[row,col], adj=c(0.5,0.5), bty="n")
				text(0.5, 0.5, labels=post.cor[row,col], cex=cex.cor[row,col])
				temp.box()
			}
			if (row == n) {
				par(mgp=c(0.05, ifelse(col%%2 == 0, 0, 0.5), 0))
				axis(1, col=axis.col, lwd=0.5)
			}
			if (col == 1 & row > 1) {
				par(mgp=c(0.05, ifelse(row%%2 == 1, 0.15, 0.5), 0))
				axis(2, col=axis.col, lwd=0.5)
			}
			if (col == 1 & row == 1) {
				par(mgp=c(0.05, ifelse(row%%2 == 1, 0.15, 0.5), 0))
				axis(2, col=axis.col, lwd=0.5)
			}
			if (row == 1) 
				mtext(pars[col], line=ifelse(col%%2 == 1, 0.1, 1.1), cex=label.cex)
			if (col == n) 
				mtext(pars[row], side=4, line=ifelse(row%%2 == 1, 0, 1), cex=label.cex)
		}
	}
	return(list(post.cor=post.cor, cex.cor=cex.cor))
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~pairs_admb


## sample_admb--------------------------2021-03-10
## adnuts Function: sample_admb
## --------------------------------------adnuts|RH
sample_admb = function (model, path=getwd(), iter=2000, init=NULL, chains=3, 
   warmup=NULL, seeds=NULL, thin=1, mceval=FALSE, duration=NULL, 
   parallel=FALSE, cores=NULL, control=NULL, algorithm="NUTS", ...) 
{
	stopifnot(thin >= 1)
	stopifnot(chains >= 1)
	if (is.null(seeds)) 
		seeds <- sample.int(1e+07, size=chains)
	if (iter < 10 | !is.numeric(iter)) 
		stop("iter must be > 10")
	stopifnot(is.character(path))
	stopifnot(is.character(model))
	if (!dir.exists(path)) 
		stop(paste("Folder", path, "does not exist. Check argument 'path'"))
	if (.Platform$OS.type == "windows") {
		sspath="C:/Users/haighr/Files/Archive/Bat"            ## RH 201021
		ff <- file.path(sspath, paste(sub("\\.exe$","",model), ".exe", sep=""))  ## RH 201021
	}
	else {
		ff <- file.path(path, paste("./", model, sep=""))
	}
	if (!file.exists(ff)) 
		stop(paste("File", ff, "not found. Check 'path' and 'model' arguments"))
	control <- adnuts:::.update_control(control)
	if (is.null(warmup)) 
		warmup <- floor(iter/2)
	if (!(algorithm %in% c("NUTS", "RWM"))) 
		stop("Invalid algorithm specified")
	if (is.null(init)) {
		warning("Using MLE inits for each chain -- strongly recommended to use dispersed inits")
	}
	else if (is.function(init)) {
		init <- lapply(1:chains, function(x) init())
	}
	else if (!is.list(init)) {
		stop("init must be NULL, a list, or a function")
	}
	if (!is.null(init) & length(init) != chains) {
		stop("Length of init does not equal number of chains.")
	}
	trash <- file.remove(list.files()[grep(".psv", x=list.files())])
	if (!parallel) {
		if (algorithm == "NUTS") {
			mcmc.out <- lapply(1:chains, function(i) adnuts:::sample_admb_nuts(path=path, 
				model=model, warmup=warmup, duration=duration, 
				iter=iter, init=init[[i]], chain=i, seed=seeds[i], 
				thin=thin, control=control, ...))
		}
		else {
			mcmc.out <- lapply(1:chains, function(i) adnuts:::sample_admb_rwm(path=path, 
				model=model, warmup=warmup, duration=duration, 
				iter=iter, init=init[[i]], chain=i, seed=seeds[i], 
				thin=thin, control=control, ...))
		}
	}
	else {
		if (!requireNamespace("snowfall", quietly=TRUE)) 
			stop("snowfall package not found")
		snowfall::sfInit(parallel=TRUE, cpus=cores)
		snowfall::sfExportAll()
		on.exit(snowfall::sfStop())
		mcmc.out <- snowfall::sfLapply(1:chains, function(i) sample_admb_parallel(parallel_number=i, 
			path=path, model=model, duration=duration, algorithm=algorithm, iter=iter, init=init[[i]], 
			warmup=warmup, seed=seeds[i], thin=thin, control=control, ...))
	}
	warmup <- mcmc.out[[1]]$warmup
#browser();return()
	mle <- adnuts:::.read_mle_fit(model=model, path=path)
	if (is.null(mle)) {
		par.names <- dimnames(mcmc.out[[1]]$samples)[[2]]
		par.names <- par.names[-length(par.names)]
	}
	else {
		par.names <- mle$par.names
	}
	iters <- unlist(lapply(mcmc.out, function(x) dim(x$samples)[1]))
	if (any(iters != iter/thin)) {
		N <- min(iters)
		warning(paste("Variable chain lengths, truncating to minimum=", N))
	}
	else {
		N <- iter/thin
	}
	samples <- array(NA, dim=c(N, chains, 1 + length(par.names)), dimnames=list(NULL, NULL, c(par.names, "lp__")))
	for (i in 1:chains) samples[, i, ] <- mcmc.out[[i]]$samples[1:N,]
	if (algorithm == "NUTS") 
		sampler_params <- lapply(mcmc.out, function(x) x$sampler_params[1:N,])
	else sampler_params <- NULL
	time.warmup <- unlist(lapply(mcmc.out, function(x) as.numeric(x$time.warmup)))
	time.total <- unlist(lapply(mcmc.out, function(x) as.numeric(x$time.total)))
	cmd <- unlist(lapply(mcmc.out, function(x) x$cmd))
	if (N < warmup) 
		warning("Duration too short to finish warmup period")
	message(paste("... Merging post-warmup chains into main folder:", path))
	samples2 <- do.call(rbind, lapply(1:chains, function(i) samples[-(1:warmup), i, -dim(samples)[3]]))
	adnuts:::.write_psv(fn=model, samples=samples2, model.path=path)
	unbounded <- do.call(rbind, lapply(mcmc.out, function(x) x$unbounded))
#browser();return()
	oldwd <- getwd()
	on.exit(setwd(oldwd))
	setwd(path)
	write.table(unbounded, file="unbounded.csv", sep=",", col.names=FALSE, row.names=FALSE)
	if (mceval) {
		message("... Running -mceval on merged chains")
		#system(paste(model, "-mceval -maxI 0 -nohess"), ignore.stdout=FALSE)  ## this only reports one sample of derived_paramters
		system(paste(model, "-mceval"), ignore.stdout=FALSE)
	}
	covar.est <- cov(unbounded)
	result <- list(samples=samples, sampler_params=sampler_params, time.warmup=time.warmup, time.total=time.total, algorithm=algorithm, warmup=warmup, model=model, max_treedepth=mcmc.out[[1]]$max_treedepth, cmd=cmd, covar.est=covar.est, mle=mle)
	attr(result,"class")=c("adfit","list")
	return(invisible(result))
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~sample_admb


## sample_admb_parallel-----------------2020-10-28
## adnuts Function: sample_admb_parallel
## --------------------------------------adnuts|RH
sample_admb_parallel=function (parallel_number, path, algorithm, ...) 
{
	olddir <- getwd()
	on.exit(setwd(olddir))
	#newdir <- paste0(file.path(getwd(), path), "_chain_", parallel_number)  ## WTF
#browser();return()
	newdir <- paste0(sub("/$","",file.path(path)), "/chain_", parallel_number) ## RH 201021
	if (dir.exists(newdir)) {
		unlink(newdir, TRUE)
		if (dir.exists(newdir)) 
			stop(paste("Could not remove folder:", newdir))
	}
	dir.create(newdir)
	trash <- file.copy(from=list.files(path, full.names=TRUE), to=newdir, overwrite=T, copy.date=T)
	if (algorithm == "NUTS") 
		fit <- adnuts:::sample_admb_nuts(path=newdir, chain=parallel_number, ...)
	if (algorithm == "RWM") 
		fit <- adnuts:::sample_admb_rwm(path=newdir, chain=parallel_number, ...)
	unlink(newdir, TRUE)
	return(fit)
}
##~~~~~~~~~~~~~~~~~~~~~~~~~~~~sample_admb_parallel


