## Make Base Case Tables
## ----------------------
tabSS.compo = function(istock="YMR", prefix="ymr.", compo,
  useRlow=FALSE, qRlow=0.25, sigdig=4)
{
	on.exit(gc(verbose=FALSE))
	unpackList(stock[[istock]][["Controls"]])
	unpackList(compo)

	modYrs      = startYear:currYear
	modYrsChar  = as.character(modYrs)
	## Diagnostics for select parameters
	P.mpd       = ampdPA; storage.mode(P.mpd)="double"     ## For some reason, this matrix is stored as a list (maybe due to NA values?)
	P.names     = colnames(avgPA)
	P.runs      = as.numeric(sapply(strsplit(rownames(avgPA),"\\."),function(x){x[1]}))
	P.run.rwt   = sapply(strsplit(rownames(avgPA),"\\."),function(x){paste0(x[1],".",x[2])}) ## vector of Runs and Rwts
	P.run.ord   = unique(P.runs)
	P.run.nmc   = table(P.runs)[as.character(P.run.ord)]
	P.run.num   = rep(1:length(P.run.nmc), P.run.nmc)
	use.run.rwt = is.element(P.runs, P.run.ord) ## default use all runs but a subset might be used for management advice
	B.labs      = paste0(rep("B",NrefM),1:NrefM," (R",P.run.ord,")")
	if (spp.code %in% c("YMR"))
		P.ord=c(1,seq(2,10,2),seq(3,11,2))
	else
		P.ord = 1:ncol(ampdPA)

	##----------Table 1-----------
	## MCMC model parameters table
	##----------------------------
	tabPmed = t(apply(avgPA,2,quantile,tcall(quants5)))  ## arrays so cannot use sapply
	tabPmed = tabPmed[P.ord,]
	tabPmed = formatCatch(tabPmed,N=sigdig)

	names.pars = rownames(tabPmed)
	fixsub = grep("_",names.pars)
	names.pars[fixsub] = paste0(sub("_","~(",names.pars[fixsub]),")")
	names.pars = sub("varL\\(","\\\\log v(\\\\mathrm{L}",names.pars)
	names.pars[fixsub] = sub("\\(","_{", sub("\\)","}", names.pars[fixsub]))
	names.pars = gsub("mu","\\\\mu",names.pars)
	names.pars = gsub("Delta","\\\\Delta",names.pars)
	names.pars = sub("LN\\(R0)","\\\\log R_{0}",names.pars)
	names.pars[fixsub] = sub("\\(","(\\\\text{", sub("\\)","})", names.pars[fixsub]))
	#names.pars = gsub("log","\\\\mathrm{log}",gsub("v_","v_{",gsub("L","L}",names.pars)))

	rownames(tabPmed) =  paste(rep("$",nrow(tabPmed)),names.pars,rep("$",nrow(tabPmed)),sep="")
	#colnames(tabPmed) =  gsub("\\%","\\\\%",colnames(tabPmed))

	xtab.compo.pars = xtable(tabPmed, align="lrrrrr",
		label   = paste0("tab:",prefix,"base.pars"), digits = if (exists("formatCatch")) NULL else sigdig,
		caption = paste0("Composite base case: the ", texThatVec(tcall(quants5)), " quantiles for pooled model parameters (defined in \\AppEqn) from MCMC estimation of ", "\\numberstringnum{", NrefM, "} component model runs of \\Nmcmc{} samples each.") )
	xtab.compo.pars.out = capture.output(print(xtab.compo.pars,
		caption.placement="top", sanitize.rownames.function=function(x){x}, add.to.row =list(pos=list(-1), command=c("\\\\[-1.0ex]")) ) )
	tput(xtab.compo.pars.out)
#browser();return()
# \\hline\\\\[-2.2ex] CC & 2023 & 2024 & 2025 & 2026 & 2027 & 2028 & 2029 & 2030 & 2031 \\\\[0.2ex]\\hline\\\\[-1.5ex]
	##----------Table 2-----------
	## MCMC Derived Parameters
	##----------------------------
	yrsUse = modYrs[c(1,length(modYrs)+c(-1,0))]
	yrsChr = as.character(yrsUse)

	B.mcmc = data.frame (
		B0         = avgRP[,"B0"],
		Bcurr      = avgRP[,"Bcurr"],
		Bcurr.B0   = avgRP[,"Bcurr"] / avgRP[,"B0"],
		ucurr      = avgRP[,"ucurr"],
		umax       = apply(avgTS[,,"ut"],1,max), ## for each mcmc sample across the time series
		MSY        = avgRP[,"MSY"],
		Bmsy       = avgRP[,"Bmsy"],
		LRP        = avgRP[,"LRP"],
		USR        = avgRP[,"USR"],
		Bcurr.Bmsy = avgRP[,"Bcurr"] / avgRP[,"Bmsy"],
		Bmsy.B0    = avgRP[,"Bmsy"] / avgRP[,"B0"],
		umsy       = avgRP[,"umsy"],
		ucurr.umsy = avgRP[,"ucurr"] / avgRP[,"umsy"]
	)
	tabmsy = t(apply(B.mcmc,2,quantile,tcall(quants5))) 
	tabmsy = formatCatch(tabmsy, N=sigdig)
	#colnames(tabmsy) =  gsub("\\%","\\\\%",colnames(tabmsy))
	names.msy = rownames(tabmsy)
	names.msy =
		gsub("_Trawl", "~(\\\\mathrm{trawl})",
		gsub("_Other", "~(\\\\mathrm{other})",
		gsub("LRP",  paste0("0.4B_{\\\\mathrm{MSY}}"),
		gsub("USR",  paste0("0.8B_{\\\\mathrm{MSY}}"),
		gsub("VB",  "V",
		gsub("[Uu]max", "u_\\\\mathrm{max}",
		gsub("msy", "_\\\\mathrm{MSY}",
		gsub("curr",  paste0("_{",currYear,"}"),
		gsub("[Uu]msy",  "u_\\\\mathrm{MSY}",
		gsub("[Uu]curr", paste0("u_{",prevYear,"}"),
		gsub("B0", "B_{0}",
		gsub("\\.", "/",
		gsub("currB","curr/B",
		gsub("curru","curr/u",
		gsub("msyB","msy/B",
		names.msy)))))))))))))))
	rownames(tabmsy) =  paste(rep("$",nrow(tabmsy)),names.msy,rep("$",nrow(tabmsy)),sep="")
	
	cap.msy = paste0(
		"Composite base case: the ", texThatVec(tcall(quants5)), " quantiles of MCMC-derived quantities from \\Nbase", 
		" samples pooled from ", NrefM, " component runs. Definitions are: ",
		"$B_0$ -- unfished equilibrium spawning biomass (mature females), ",
		#"$V_0$ -- unfished equilibrium vulnerable biomass (males and females), ",
		"$B_{", currYear, "}$ -- spawning biomass at the end of ", currYear, ", ",
		#"$V_{", currYear, "}$ -- vulnerable biomass in the middle of ", currYear, ", ",
		"$u_{", prevYear, "}$ -- exploitation rate (ratio of total catch to vulnerable biomass) in the middle of ", prevYear, ", ",
		"$u_\\mathrm{max}$ -- maximum exploitation rate (calculated for each sample as the maximum exploitation rate from ",
		modYrs[1], "-", currYear, "), ",
		"$B_\\mathrm{MSY}$ -- equilibrium spawning biomass at MSY (maximum sustainable yield), ",
		"$u_\\mathrm{MSY}$ -- equilibrium exploitation rate at MSY, ",
		#"$V_\\mathrm{MSY}$ -- equilibrium vulnerable biomass at MSY. ",
		"All biomass values (and MSY) are in tonnes. ", refCC.sentence
	)
	
	xtab.compo.rfpt = xtable(tabmsy, align="lrrrrr",
		label=paste0("tab:",prefix,"base.rfpt"), digits=if (exists("formatCatch")) NULL else sigdig, caption=cap.msy )
	xtab.compo.rfpt.out = capture.output( print(xtab.compo.rfpt,
		caption.placement="top", sanitize.rownames.function=function(x){x}, add.to.row=list(pos=list(-1,3,11), command=c("\\\\[-1.0ex]", "\\hdashline \\\\[-1.75ex]", "\\hdashline \\\\[-1.75ex]")), hline.after=c(-1,0,5,nrow(xtab.compo.rfpt)) ) )
	tput(xtab.compo.rfpt.out)

#browser();return()

	## Component run likelihoods
	## -------------------------
	LL.compo =data.frame(
		Run = c(77L, 71L, 75L, 72L, 76L),
		M = c(0.04, 0.045, 0.05, 0.055, 0.06),
		CPUE = c(-18.44, -18.29, -18.06, -17.77, -17.41),
		QCS = c(1.275, 1.060, 0.870, 0.703, 0.555),
		WCVI = c(7.863, 7.898, 7.920, 7.934, 7.939),
		WCHG = c(20.36, 20.00, 19.68, 19.40, 19.14),
		GIG = c(14.33, 14.41, 14.48, 14.54, 14.57),
		Index = c(25.39, 25.08, 24.89, 24.80, 24.80),
		AF = c(453.6, 456.1, 456.4, 457.2, 457.5),
		Recruit = c(47.46, 43.51, 41.93, 40.80, 39.93),
		Total = c(638.5, 636.6, 635.1, 634.7, 634.0)
	)
#browser();return()
	xtab.cruns.ll = xtable(formatCatch(LL.compo), align=paste0("l", paste0(rep("r",dim(LL.compo)[2]),collapse="")),
		label   = paste0("tab:",prefix,"log.likes"), digits=NULL, 
		caption = "Log likelihood (LL) values reported by component base runs for survey indices, age composition (AF), recruitment, and total (not all LL components reported here)")
	xtab.cruns.ll.out = capture.output(print(xtab.cruns.ll,  include.rownames=FALSE,
		caption.placement="top", sanitize.rownames.function=function(x){x}, add.to.row =list(pos = list(-1), command = c("\\\\[-1.0ex]")) ) )
	tput(xtab.cruns.ll.out)

	## PJS wants to see parmeter comparisons among component runs (of course he does)
	## ----------------------------------------------------------
	## Calculate quantiles for later (eventually make this function global)
	calcQs = function (dat, ivec, ovec, qval=quants3) {
		F.data = as.data.frame(dat)
		F.list = split(F.data, ivec)
		rr.ord = match(ovec, substring(names(F.list),1,2))  ## oder not so important for sensitivities
		F.list = F.list[rr.ord]
		F.qnts = lapply(F.list,function(x){
			z = apply(x,2,function(xx){!any(is.na(xx))})
			out = apply(x[z],2,quantile,qval)
			return(out)
		}) ## lapply does not sort like split does
		return(F.qnts)
	}
	P.qnts = calcQs(avgPA, ivec=P.run.rwt, ovec=P.run.ord)
	P.med  = lapply(P.qnts,function(x){apply(x,2,function(xx){c(xx[2],xx[1],xx[3])})})
	P.mpd.mcmc = as.list(rownames(ampdPA)); names(P.mpd.mcmc) = rownames(ampdPA)
	for (i in names(P.mpd.mcmc)){
		P.mpd.mcmc[[i]] = rbind(ampdPA[i,P.ord,drop=FALSE], P.med[[i]][,P.ord])
	}
	P.vals = lapply(lapply(P.mpd.mcmc,t),formatCatch)
	P.tabs = lapply(P.vals, function(mat){
		t(t(apply(mat, 1, function(x) {
			paste0(c("|", c(x[1], "| ", x[2], " (", x[3],",",x[4],")")), collapse="")
			#paste0(c(x[1], " , ", x[2], " (", x[3],",",x[4],")"), collapse="")
		})))
	})
	P.tab = array(NA,dim=rev(dim(ampdPA)), dimnames=list(names.pars,names(P.qnts)))
	for (i in names(P.tabs)){
		P.tab[,i] = P.tabs[[i]]
	}
	rownames(P.tab) =  paste(rep("$",nrow(P.tab)),  gsub("\\s*~\\(.*?\\)$","",rownames(P.tab)), rep("$",nrow(P.tab)),sep="")
	colnames(P.tab) = B.labs

	xtab.cruns.pars = xtable(P.tab, align=paste0("l", paste0(rep("c",dim(P.tab)[2]),collapse="")),
		label   = paste0("tab:",prefix,"runs.pars"), digits = if (exists("formatCatch")) NULL else sigdig,
		caption = paste0("Component base case runs: model parameter MPDs (delimited by `|') and MCMC medians (with 0.05 and 0.95 quantile limits) for each of the ",
		"\\numberstringnum{", NrefM, "} component model runs of \\Nmcmc{} samples each.") )
	xtab.cruns.pars.out = capture.output(print(xtab.cruns.pars,
		caption.placement="top", sanitize.rownames.function=function(x){x}, add.to.row =list(pos = list(-1), command = c("\\\\[-1.0ex]")) ) )
	tput(xtab.cruns.pars.out)

	## PJS ALSO wants to see comparisons among derived quantities for component runs (of course he does)
	## ----------------------------------------------------------
	Q.qnts = calcQs(B.mcmc, ivec=P.run.rwt, ovec=P.run.ord)
	Q.med  = lapply(Q.qnts,function(x){apply(x,2,function(xx){c(xx[2],xx[1],xx[3])})})
#browser();return()

	#Q.mpd.mcmc = as.list(colnames(B.mcmc)); names(Q.mpd.mcmc) = colnames(B.mcmc)  ## have not collected MPD estimates of 
	#for (i in names(Q.mpd.mcmc)){
	#	Q.mpd.mcmc[[i]] = rbind(ampdPA[i,,drop=FALSE], Q.med[[i]])
	#}
	#Q.vals = lapply(lapply(Q.mpd.mcmc,t),formatCatch)
	Q.vals = lapply(lapply(Q.med,t), formatCatch, N=2)
	Q.tabs = lapply(Q.vals, function(mat){
		t(t(apply(mat, 1, function(x) {
			paste0(c(x[1], " (", x[2],",",x[3],")"), collapse="")
			#paste0(c("|", c(x[1], "| ", x[2], " (", x[3],",",x[4],")")), collapse="")
			#paste0(c(x[1], " , ", x[2], " (", x[3],",",x[4],")"), collapse="")
		})))
	})
	Q.tab = array(NA,dim=c(ncol(B.mcmc),NrefM), dimnames=list( dimnames(B.mcmc)[[2]],names(Q.qnts)))
	for (i in names(Q.tabs)){
		Q.tab[,i] = Q.tabs[[i]]
	}
	rownames(Q.tab) = names.msy
	rownames(Q.tab) = paste(rep("$",nrow(Q.tab)),  gsub("\\s*~\\(.*?\\)$","",rownames(Q.tab)), rep("$",nrow(Q.tab)),sep="")
	colnames(Q.tab) = B.labs

	xtab.cruns.rfpt = xtable(Q.tab, align=paste0("l", paste0(rep("r",dim(Q.tab)[2]),collapse="")),
		label   = paste0("tab:",prefix,"runs.rfpt"), digits = if (exists("formatCatch")) NULL else sigdig,
		caption = paste0("Component base case runs: MCMC median (with 0.05 and 0.95 quantile limits) for derived model quantities for each of the ",
		"\\numberstringnum{", NrefM, "} component model runs of \\Nmcmc{} samples each.") )
	xtab.cruns.rfpt.out = capture.output(print(xtab.cruns.rfpt,
		caption.placement="top", sanitize.rownames.function=function(x){x}, add.to.row=list(pos=list(-1,3,11), command=c("\\\\[-1.0ex]", "\\hdashline \n", "\\hdashline \n")), hline.after=c(-1,0,5,nrow(xtab.cruns.rfpt)) ) )
	tput(xtab.cruns.rfpt.out)
#browser();return()

	save("xtab.compo.pars.out", "xtab.compo.rfpt.out", "xtab.cruns.pars.out", "xtab.cruns.rfpt.out", "xtab.cruns.ll.out", file=paste0(prefix,"compo.tabs", ifelse(useRlow, paste0(".Rlow(q=",pad0(qRlow*100,2),")"),""), ".rda") )
#browser();return()
return()
}
## Activate for debugging only:
tabSS.compo(istock="YMR", compo=compo) ##, prefix="RER.") ##, useRlow=F, qRlow=0.05)

